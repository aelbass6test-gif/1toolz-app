import { useState, useMemo, useEffect, useRef, useCallback, lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Outlet, useNavigate, useParams, Navigate, useLocation } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

import { User, Store, StoreData, Order, Settings, Wallet, OrderItem, Employee, Product, PlaceOrderData, CustomerProfile, Warehouse, PurchaseReturn, OrderReturn, TreasuryAccount, TreasuryTransaction, Partner, PartnerTransaction, Permission } from './types';
import * as db from './services/databaseService';
import { onSnapshot, collection, query, where, doc, getDocs } from 'firebase/firestore';
import { db as firebaseDb, auth } from './services/firebaseClient';
import { getSupabaseClient } from './services/databaseService';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, getAuth } from 'firebase/auth';
import { getApps, initializeApp } from 'firebase/app';
import firebaseConfig from './firebase-applet-config.json';
import { INITIAL_SETTINGS } from './constants';
import { normalizePhone } from './utils/phoneUtils';
import { verifyPasswordSecure } from './utils/syncIntegrity';
import { oneToolzProducts } from './data/one-toolz-products';

import { triggerWebhooks } from './utils/webhook';
import { audioSynth } from './utils/audioSynth';
import { lazyWithRetry } from './utils/lazyWithRetry';
import GlobalLoader from './components/GlobalLoader';
import WelcomeLoader from './components/WelcomeLoader';
import { computeEnrichedCustomers } from './components/crm/crmUtils';

const getAuthOtpApiBase = () => {
    if (import.meta.env.VITE_AUTH_API_URL) {
        return import.meta.env.VITE_AUTH_API_URL.replace(/\/$/, '');
    }
    if (typeof window !== 'undefined') {
        const host = window.location.hostname.toLowerCase();
        // If in production on abdomedi.com, use official API host
        if (host === 'abdomedi.com' || host.endsWith('.abdomedi.com')) {
            return 'https://api.abdomedi.com';
        }
        // When running in AI Studio (Cloud Run *.run.app) or localhost, use same-origin relative API
        return '';
    }
    return '';
};
const AUTH_OTP_API_BASE = getAuthOtpApiBase();

// Page Components (will be loaded via router with automatic retry on chunk updates)
const SignUpPage = lazyWithRetry(() => import('./components/SignUpPage'));
const EmployeeLoginPage = lazyWithRetry(() => import('./components/EmployeeLoginPage'));
const CreateStorePage = lazyWithRetry(() => import('./components/CreateStorePage'));
const ManageSitesPage = lazyWithRetry(() => import('./components/ManageSitesPage'));
const Dashboard = lazyWithRetry(() => import('./components/Dashboard'));
const OrdersList = lazyWithRetry(() => import('./components/OrdersList'));
const ProductsPage = lazyWithRetry(() => import('./components/ProductsPage'));
const CustomersPage = lazyWithRetry(() => import('./components/CustomersPage'));
const WalletPage = lazyWithRetry(() => import('./components/WalletPage'));
const SettingsPage = lazyWithRetry(() => import('./components/SettingsPage'));
const StorefrontPage = lazyWithRetry(() => import('./components/StorefrontPage'));
const ProductDetailPage = lazyWithRetry(() => import('./components/ProductDetailPage'));
const CheckoutPage = lazyWithRetry(() => import('./components/CheckoutPage'));
const OrderSuccessPage = lazyWithRetry(() => import('./components/OrderSuccessPage'));
const StoreCustomizationPage = lazyWithRetry(() => import('./components/StoreCustomizationPage'));
const ShippingPage = lazyWithRetry(() => import('./components/ShippingPage'));
const ConfirmationQueuePage = lazyWithRetry(() => import('./components/ConfirmationQueuePage'));
const AbandonedCartsPage = lazyWithRetry(() => import('./components/AbandonedCartsPage'));
const DiscountsPage = lazyWithRetry(() => import('./components/DiscountsPage'));
const ReviewsPage = lazyWithRetry(() => import('./components/ReviewsPage'));
const CollectionsPage = lazyWithRetry(() => import('./components/CollectionsPage'));
const ProductOptionsPage = lazyWithRetry(() => import('./components/ProductOptionsPage'));
const ExpensesPage = lazyWithRetry(() => import('./components/ExpensesPage'));
const MarketingPage = lazyWithRetry(() => import('./components/MarketingPage'));
const AnalyticsPage = lazyWithRetry(() => import('./components/AnalyticsPage'));
const AdminPage = lazyWithRetry(() => import('./components/AdminPage'));
const MaintenancePage = lazyWithRetry(() => import('./src/pages/MaintenancePage'));
const EmployeeLayout = lazyWithRetry(() => import('./components/EmployeeLayout'));
const EmployeeDashboardPage = lazyWithRetry(() => import('./components/EmployeeDashboardPage'));
const EmployeeAccountSettingsPage = lazyWithRetry(() => import('./components/EmployeeAccountSettingsPage'));
const EmployeeActivityPage = lazyWithRetry(() => import('./components/EmployeeActivityPage'));
const AccountSettingsPage = lazyWithRetry(() => import('./components/AccountSettingsPage'));
const CollectionsReportPage = lazyWithRetry(() => import('./components/CollectionsReportPage'));
const ActivityLogsPage = lazyWithRetry(() => import('./components/ActivityLogsPage'));
const SuppliersPage = lazyWithRetry(() => import('./components/SuppliersPage'));
const PartnersPage = lazyWithRetry(() => import('./components/PartnersPage'));
const PartnerProfilePage = lazyWithRetry(() => import('./components/PartnerProfilePage'));
const PartnerPortal = lazyWithRetry(() => import('./components/PartnerPortal'));
const MerchantPortal = lazyWithRetry(() => import('./components/MerchantPortal'));
const MerchantProfilePage = lazyWithRetry(() => import('./components/MerchantProfilePage'));
const MerchantsPage = lazyWithRetry(() => import('./components/MerchantsPage'));
const ExcelReconciliationPage = lazyWithRetry(() => import('./components/ExcelReconciliationPage'));
const PagesManager = lazyWithRetry(() => import('./components/PagesManager'));
const PaymentSettingsPage = lazyWithRetry(() => import('./components/PaymentSettingsPage'));
const DeveloperSettingsPage = lazyWithRetry(() => import('./components/DeveloperSettingsPage'));
const TeamChatPage = lazyWithRetry(() => import('./components/TeamChatPage'));
const WhatsAppPage = lazyWithRetry(() => import('./components/WhatsAppPage'));
const EmployeesPage = lazyWithRetry(() => import('./components/EmployeesPage'));
const EmployeesPayrollPage = lazyWithRetry(() => import('./components/EmployeesPayrollPage'));
const ReportsPage = lazyWithRetry(() => import('./components/ReportsPage'));
const InventoryTransfers = lazyWithRetry(() => import('./components/InventoryTransfers'));
const MerchantSettlementPage = lazyWithRetry(() => import('./components/MerchantSettlementPage').then(m => ({ default: m.MerchantSettlementPage })));
const OrderReturnsPage = lazyWithRetry(() => import('./components/OrderReturnsPage'));
const PurchaseReturnsPage = lazyWithRetry(() => import('./components/PurchaseReturnsPage'));
const POSPage = lazyWithRetry(() => import('./components/POSPage'));
const CashManagement = lazyWithRetry(() => import('./components/CashManagement'));
const CreateOrderPage = lazyWithRetry(() => import('./components/CreateOrderPage'));
const EditOrderPage = lazyWithRetry(() => import('./components/EditOrderPage'));
const QuotationsPage = lazyWithRetry(() => import('./components/QuotationsPage'));
const ChatBot = lazyWithRetry(() => import('./components/ChatBot'));
const CongratsModal = lazyWithRetry(() => import('./components/CongratsModal'));
const OrderTrackingPage = lazyWithRetry(() => import('./components/OrderTrackingPage'));
const CustomerOrderActionPage = lazyWithRetry(() => import('./components/CustomerOrderActionPage'));
const CustomerQuoteApprovalPage = lazyWithRetry(() => import('./components/CustomerQuoteApprovalPage'));
const WelcomeLandingPage = lazyWithRetry(() => import('./components/WelcomeLandingPage'));
const OtpVerificationPage = lazyWithRetry(() => import('./components/OtpVerificationPage'));
const FirebaseActionPage = lazyWithRetry(() => import('./components/FirebaseActionPage'));
const IosInstallPrompt = lazyWithRetry(() => import('./components/IosInstallPrompt'));
const ComingSoonPage = lazyWithRetry(() => import('./components/ComingSoonPage'));
const AppsPage = lazyWithRetry(() => import('./components/AppsPage'));
const ApiDocsPage = lazyWithRetry(() => import('./components/ApiDocsPage'));
const UniversalInstallPrompt = lazyWithRetry(() => import('./components/UniversalInstallPrompt'));
const CreateDropshippingOrderPage = lazyWithRetry(() => import('./components/CreateDropshippingOrderPage'));
const WarehouseSubmitPage = lazyWithRetry(() => import('./components/WarehouseSubmitPage'));

const TreasuryPage = lazyWithRetry(() => import('./components/TreasuryPage'), 'TreasuryPage');
const DomainSettingsPage = lazyWithRetry(() => import('./components/DomainSettingsPage'), 'DomainSettingsPage');
const SharedReportView = lazyWithRetry(() => import('./components/SharedReportView'), 'SharedReportView');
const FailedDeliveryCompensationPage = lazyWithRetry(() => import('./components/FailedDeliveryCompensationPage'), 'FailedDeliveryCompensationPage');
const DropshippingPage = lazyWithRetry(() => import('./components/DropshippingPage'), 'DropshippingPage');
const SmartUpdatesWidget = lazyWithRetry(() => import('./components/SmartUpdatesWidget'), 'SmartUpdatesWidget');
const WebhookMonitorPage = lazyWithRetry(() => import('./components/WebhookMonitorPage'));

import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MobileNavigation from './components/MobileNavigation';
import { ShippingCalculatorWidget } from './components/ShippingCalculatorWidget';
import { InAppAlertSystem } from './components/InAppAlertSystem';
import { NewOrderAlertModal } from './components/NewOrderAlertModal';
import { showOrderWebNotification, isPendingOrderStatus } from './utils/webNotification';

interface EmployeeRegisterRequestData {
  fullName: string;
  phone: string;
  password: string;
  storeId: string;
  email: string;
}

const normalizeName = (name: string): string => {
  if (!name) return name;
  let normalized = name.trim().replace(/\s+/g, ' ');
  normalized = normalized.replace(/\s*\((شريك|موظف|المدير|شريكه|partner|employee|admin)\)/gi, '');
  normalized = normalized.replace(/\s+(شريك|موظف|المدير|شريكه|partner|employee|admin)$/gi, '');
  normalized = normalized.trim();
  if (/^(زهره|زهرة)/.test(normalized)) {
      return 'زهره';
  }
  return normalized;
};

const MainLayout = ({ 
    currentUser, 
    handleLogout, 
    isSidebarOpen, 
    setSidebarOpen, 
    activeStore, 
    settings,
    orders = [],
    theme, 
    setTheme,
    forceSync,
    saveStatus,
    saveMessage,
    isShippingCalculatorOpen,
    setIsShippingCalculatorOpen,
    pendingRequestsCounts
}: any) => {
    const location = useLocation();

    // Desktop Screen Expansion & Sidebar Collapse State (persisted locally)
    const [isDesktopCollapsed, setIsDesktopCollapsed] = useState<boolean>(() => {
        try {
            return localStorage.getItem('sidebar_desktop_collapsed') === 'true';
        } catch {
            return false;
        }
    });

    const toggleDesktopSidebar = useCallback(() => {
        setIsDesktopCollapsed(prev => {
            const next = !prev;
            try {
                localStorage.setItem('sidebar_desktop_collapsed', String(next));
            } catch {}
            return next;
        });
    }, []);

    // Global keyboard shortcut: Ctrl+B / Cmd+B to toggle sidebar & expand screen
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
                const target = e.target as HTMLElement;
                const tag = target?.tagName?.toLowerCase();
                if (tag !== 'input' && tag !== 'textarea' && !target?.isContentEditable) {
                    e.preventDefault();
                    toggleDesktopSidebar();
                }
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [toggleDesktopSidebar]);

    const isStoreManagementOrCreationPage = useMemo(() => {
        const path = location.pathname;
        return (
            path === '/' ||
            path === '/select-store' ||
            path === '/projects' ||
            path === '/manage-stores' ||
            path === '/create-store' ||
            path === '/admin/manage-stores' ||
            path.endsWith('/select-store') ||
            path.endsWith('/projects') ||
            path.endsWith('/manage-stores') ||
            path.endsWith('/create-store')
        );
    }, [location.pathname]);

    const effectiveActiveStore = isStoreManagementOrCreationPage ? undefined : activeStore;

    const [sharedAudits, setSharedAudits] = useState<any[]>([]);
    const [chatMessages, setChatMessages] = useState<any[]>([]);

    useEffect(() => {
        if (!activeStore?.id) {
            setSharedAudits([]);
            setChatMessages([]);
            return;
        }

        let unsubAudit: (() => void) | undefined;
        let unsubChat: (() => void) | undefined;

        try {
            const qAudit = query(
                collection(firebaseDb, 'shared_audits'),
                where('storeId', '==', activeStore.id)
            );
            unsubAudit = onSnapshot(qAudit, (snapshot) => {
                const list: any[] = [];
                snapshot.forEach(docSnap => {
                    list.push({ id: docSnap.id, ...docSnap.data() });
                });
                setSharedAudits(list);
            }, (err) => {
                const msg = String(err?.message || err);
                if (msg.includes('quota') || msg.includes('resource-exhausted') || (err as any)?.code === 'resource-exhausted') {
                    console.warn('[Notification] Firestore quota reached for shared_audits. Using cached data seamlessly.');
                } else {
                    console.warn('[Notification] shared_audits notice:', msg);
                }
            });
        } catch (e) {
            console.warn('[Notification] shared_audits subscription notice:', e);
        }

        try {
            const qChat = query(
                collection(firebaseDb, 'chat_messages'),
                where('storeId', '==', activeStore.id)
            );
            unsubChat = onSnapshot(qChat, (snapshot) => {
                const list: any[] = [];
                snapshot.forEach(docSnap => {
                    const d = docSnap.data();
                    list.push({
                        id: docSnap.id,
                        senderId: d.senderId,
                        receiverId: d.receiverId,
                        content: d.content,
                        createdAt: d.createdAt?.seconds ? new Date(d.createdAt.seconds * 1000).toISOString() : new Date().toISOString()
                    });
                });
                setChatMessages(list);
            }, (err) => {
                const msg = String(err?.message || err);
                if (msg.includes('quota') || msg.includes('resource-exhausted') || (err as any)?.code === 'resource-exhausted') {
                    console.warn('[Notification] Firestore quota reached for chat_messages. Using cached data seamlessly.');
                } else {
                    console.warn('[Notification] chat_messages notice:', msg);
                }
            });
        } catch (e) {
            console.warn('[Notification] chat_messages subscription notice:', e);
        }
        return () => {
            if (unsubAudit) unsubAudit();
            if (unsubChat) unsubChat();
        };
    }, [activeStore?.id]);

    const inventoryAlerts = useMemo(() => {
        if (!settings) return [];
        
        const alerts: any[] = [];
        const products = settings.products || [];
        const auditAlertDays = settings.auditAlertDays || 30;
        const suppliers = settings.suppliers || [];
        
        const now = new Date();

        // 0. Shared Audit Sessions & Warehouse Responses (Category: 'audit', Link: '/inventory-audit')
        sharedAudits.forEach(audit => {
            if (audit.status === 'submitted') {
                alerts.push({
                    type: 'shared_audit_submitted',
                    category: 'audit',
                    id: `shared-audit-submitted-${audit.id}`,
                    title: `📬 تم تسليم جرد ميداني: ${audit.title || 'جلسة جرد'}`,
                    message: `قام مسؤول الجرد (${audit.managerName || 'المسؤول'}) بتسليم الكميات الفعلية للمستودع (${audit.warehouseName || 'الرئيسي'}). بانتظار مراجعتك والاعتماد المالي.`,
                    severity: 'warning',
                    link: '/inventory-audit',
                    date: audit.submittedAt || audit.createdAt || now.toISOString()
                });
            } else if (audit.status === 'rejected') {
                alerts.push({
                    type: 'shared_audit_rejected',
                    category: 'audit',
                    id: `shared-audit-rejected-${audit.id}`,
                    title: `❌ جلسة جرد مرفوضة: ${audit.title || 'جلسة جرد'}`,
                    message: `تم رفض الجرد وتسجيل السبب: ${audit.rejectReason || 'يرجى إعادة العد الفعلي'}.`,
                    severity: 'critical',
                    link: '/inventory-audit',
                    date: audit.rejectedAt || audit.createdAt || now.toISOString()
                });
            } else if (audit.status === 'pending') {
                alerts.push({
                    type: 'shared_audit_pending',
                    category: 'audit',
                    id: `shared-audit-pending-${audit.id}`,
                    title: `📋 جرد مفتوح بالمستودع: ${audit.title || 'جلسة جرد'}`,
                    message: `رابط الجرد النشط يعمل الآن في المستودع (${audit.warehouseName || 'الرئيسي'}) لحصر ${audit.items?.length || 0} صنف.`,
                    severity: 'info',
                    link: '/inventory-audit',
                    date: audit.createdAt || now.toISOString()
                });
            }
        });

        // 1. Check Low Stock, Audits & Expiry (Category: 'audit', Link: '/inventory-audit')
        products.forEach(p => {
            if (p.hasVariants && p.variants) {
                p.variants.forEach(v => {
                    const stock = v.stockQuantity ?? 0;
                    const minStock = v.minStockLevel || 0;
                    if (minStock > 0 && stock <= minStock) {
                        alerts.push({
                            type: 'low_stock',
                            category: 'audit',
                            id: `lowstock-${p.id}-${v.id}`,
                            title: 'مخزون منخفض',
                            message: `المنتج "${p.name} - ${Object.values(v.options || {}).join(' ')}" وصل للحد الأدنى (المتاح: ${stock})`,
                            severity: stock === 0 ? 'critical' : 'warning',
                            link: '/inventory-audit'
                        });
                    }
                    
                    // Expiry check for variants
                    if (v.expiryDate) {
                        const expDate = new Date(v.expiryDate);
                        const daysToExpiry = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                        if (daysToExpiry <= 30 && daysToExpiry > 0) {
                            alerts.push({
                                type: 'expiry',
                                category: 'audit',
                                id: `expiry-${p.id}-${v.id}`,
                                title: 'اقتراب تاريخ الانتهاء',
                                message: `المنتج "${p.name} - ${Object.values(v.options || {}).join(' ')}" سينتهي خلال ${daysToExpiry} يوم.`,
                                severity: daysToExpiry <= 7 ? 'critical' : 'warning',
                                link: '/inventory-audit'
                            });
                        } else if (daysToExpiry <= 0) {
                            alerts.push({
                                type: 'expiry_expired',
                                category: 'audit',
                                id: `expired-${p.id}-${v.id}`,
                                title: 'منتج منتهي الصلاحية',
                                message: `المنتج "${p.name} - ${Object.values(v.options || {}).join(' ')}" منتهي الصلاحية منذ ${Math.abs(daysToExpiry)} يوم.`,
                                severity: 'critical',
                                link: '/inventory-audit'
                            });
                        }
                    }
                });
            } else {
                const stock = p.stockQuantity ?? 0;
                const minStock = p.minStockLevel || 0;
                if (minStock > 0 && stock <= minStock) {
                    alerts.push({
                        type: 'low_stock',
                        category: 'audit',
                        id: `lowstock-${p.id}`,
                        title: 'مخزون منخفض',
                        message: `المنتج "${p.name}" وصل للحد الأدنى (المتاح: ${stock})`,
                        severity: stock === 0 ? 'critical' : 'warning',
                        link: '/inventory-audit'
                    });
                }

                // Expiry check for products
                if (p.expiryDate) {
                    const expDate = new Date(p.expiryDate);
                    const daysToExpiry = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                    if (daysToExpiry <= 30 && daysToExpiry > 0) {
                        alerts.push({
                            type: 'expiry',
                            category: 'audit',
                            id: `expiry-${p.id}`,
                            title: 'اقتراب تاريخ الانتهاء',
                            message: `المنتج "${p.name}" سينتهي خلال ${daysToExpiry} يوم.`,
                            severity: daysToExpiry <= 7 ? 'critical' : 'warning',
                            link: '/inventory-audit'
                        });
                    } else if (daysToExpiry <= 0) {
                        alerts.push({
                            type: 'expiry_expired',
                            category: 'audit',
                            id: `expired-${p.id}`,
                            title: 'منتج منتهي الصلاحية',
                            message: `المنتج "${p.name}" منتهي الصلاحية منذ ${Math.abs(daysToExpiry)} يوم.`,
                            severity: 'critical',
                            link: '/inventory-audit'
                        });
                    }
                }
            }

            const audits = p.lastAudited || {};
            const lastAuditDateStr = audits['all'] || Object.values(audits)[0];
            if (lastAuditDateStr) {
                const lastAuditDate = new Date(lastAuditDateStr);
                const diffTime = Math.abs(now.getTime() - lastAuditDate.getTime());
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                
                if (diffDays >= auditAlertDays) {
                    alerts.push({
                        type: 'audit_overdue',
                        category: 'audit',
                        id: `audit-${p.id}`,
                        title: 'جرد متأخر',
                        message: `المنتج "${p.name}" لم يتم جرده منذ ${diffDays} يوم.`,
                        severity: 'info',
                        link: '/inventory-audit'
                    });
                }
            }
        });

        // 2. Check Pending Orders (Category: 'orders', Link: '/orders')
        orders.forEach(order => {
            if (order.status === 'pending') {
                const orderDate = new Date(order.date);
                const hoursDiff = Math.abs(now.getTime() - orderDate.getTime()) / 36e5;
                if (hoursDiff >= 24) {
                    alerts.push({
                        type: 'pending_order',
                        category: 'orders',
                        id: `pending-${order.id}`,
                        title: 'أوردر معلق متأخر',
                        message: `الأوردر #${order.orderNumber || order.id.slice(-6)} ينتظر التأكيد منذ ${Math.floor(hoursDiff)} ساعة.`,
                        severity: 'warning',
                        link: '/orders'
                    });
                }
            }
        });

        // 3. Check High Supplier Debts (Category: 'finance', Link: '/treasury')
        suppliers.forEach(sup => {
            if ((sup.balance || 0) >= 5000) {
                alerts.push({
                    type: 'supplier_debt',
                    category: 'finance',
                    id: `debt-${sup.id}`,
                    title: 'مديونية مورد مرتفعة',
                    message: `المورد "${sup.name}" لديه مديونية مستحقة بقيمة ${(sup.balance ?? 0).toLocaleString()} ج.م`,
                    severity: 'warning',
                    link: '/treasury'
                });
            }
        });

        // 4. Check High Cash Holder Balances (Category: 'finance', Link: '/treasury')
        const cashHolders = settings.cashHolders || [];
        const groupedHolders = new Map<string, { userName: string, totalBalance: number, ids: string[] }>();
        cashHolders.forEach(ch => {
            const norm = normalizeName(ch.userName);
            const current = groupedHolders.get(norm);
            if (current) {
                current.totalBalance += (ch.currentBalance || 0);
                current.ids.push(ch.userId);
            } else {
                groupedHolders.set(norm, {
                    userName: ch.userName,
                    totalBalance: ch.currentBalance || 0,
                    ids: [ch.userId]
                });
            }
        });

        groupedHolders.forEach((data, normName) => {
            if (data.totalBalance >= 5000) {
                const isPartner = settings.partners?.some(p => normalizeName(p.name) === normName);
                const titleRole = isPartner ? 'الشريك' : 'الموظف';
                alerts.push({
                    type: 'cash_balance',
                    category: 'finance',
                    id: `cash-group-${normName}`,
                    title: 'عهدة نقدية مرتفعة',
                    message: `${titleRole} "${data.userName.replace(/\s*\((شريك|موظف|المدير|شريكه|partner|employee|admin)\)/gi, '')}" يحمل عهدة نقدية كبيرة بقيمة ${(data.totalBalance ?? 0).toLocaleString()} ج.م`,
                    severity: 'warning',
                    link: '/treasury'
                });
            }
        });

        // 5. Check Abandoned Carts (Category: 'orders', Link: '/orders')
        const abandonedCarts = settings.abandonedCarts || [];
        abandonedCarts.forEach(cart => {
            if ((cart.totalValue || 0) >= 2000) {
                const cartDate = new Date(cart.date);
                const hoursDiff = Math.abs(now.getTime() - cartDate.getTime()) / 36e5;
                if (hoursDiff <= 48) { // Only alert for recent ones
                    alerts.push({
                        type: 'abandoned_cart',
                        category: 'orders',
                        id: `abandoned-${cart.id}`,
                        title: 'سلة متروكة هامة',
                        message: `العميل "${cart.customerName}" ترك سلة بقيمة ${(cart.totalValue ?? 0).toLocaleString()} ج.م`,
                        severity: 'info',
                        link: '/orders'
                    });
                }
            }
        });

        // 6. Check Team Chat Messages (Category: 'messages', Link: '/team-chat')
        if (chatMessages && chatMessages.length > 0) {
            const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
            const recentTeamMsgs = chatMessages.filter(m => {
                const mDate = new Date(m.createdAt);
                return mDate >= last24h && m.senderId !== currentUser?.phone;
            });

            if (recentTeamMsgs.length > 0) {
                const sortedMsgs = [...recentTeamMsgs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                sortedMsgs.slice(0, 5).forEach((msg, idx) => {
                    alerts.push({
                        type: 'team_message',
                        category: 'messages',
                        id: `chat-msg-${msg.id || idx}`,
                        title: '💬 رسالة جديدة من طاقم العمل',
                        message: msg.content ? (msg.content.length > 60 ? msg.content.substring(0, 60) + '...' : msg.content) : 'رسالة جديدة في دردشة الفريق',
                        severity: 'info',
                        link: '/team-chat',
                        date: msg.createdAt
                    });
                });
            }
        }

        return alerts;
    }, [settings, orders, sharedAudits, chatMessages, currentUser]);



    return (
        <div className="flex flex-col h-screen bg-[#f6f7f5] dark:bg-[#0b1210] text-slate-900 dark:text-slate-50 transition-colors duration-300 overflow-hidden relative" dir="rtl">
            {/* Immersive Floating Ambient Glow Elements */}
            <div className="absolute top-[-12%] right-[-8%] w-[42vw] h-[42vw] rounded-full bg-emerald-500/5 dark:bg-emerald-500/10 blur-[130px] pointer-events-none z-0" />
            <div className="absolute bottom-[-16%] left-[-10%] w-[38vw] h-[38vw] rounded-full bg-lime-500/5 dark:bg-lime-500/8 blur-[140px] pointer-events-none z-0" />

            <div className="relative z-10 flex flex-col h-full min-h-0 overflow-hidden">
                <div className="no-print shrink-0">
                    <Header 
                        currentUser={currentUser} 
                        onLogout={handleLogout} 
                        onToggleSidebar={() => setSidebarOpen(true)} 
                        isDesktopSidebarCollapsed={isDesktopCollapsed}
                        onToggleDesktopSidebar={toggleDesktopSidebar}
                        theme={theme} 
                        setTheme={setTheme} 
                        activeStore={effectiveActiveStore} 
                        forceSync={forceSync}
                        saveStatus={saveStatus}
                        saveMessage={saveMessage}
                        inventoryAlerts={isStoreManagementOrCreationPage ? [] : inventoryAlerts}
                        onOpenShippingCalculator={() => setIsShippingCalculatorOpen(true)}
                    />
                </div>
                <div className="flex flex-1 min-h-0 overflow-hidden relative">
                    {!isStoreManagementOrCreationPage && (
                        <div className="no-print h-full flex shrink-0">
                            <Sidebar 
                                activeStore={activeStore} 
                                settings={settings} 
                                isOpen={isSidebarOpen} 
                                onClose={() => setSidebarOpen(false)} 
                                isDesktopCollapsed={isDesktopCollapsed}
                                onToggleDesktopCollapse={toggleDesktopSidebar}
                                pendingRequestsCounts={pendingRequestsCounts}
                            />
                        </div>
                    )}
                    <main className="flex-1 overflow-y-auto p-3 sm:p-4 lg:p-6 pb-24 md:pb-6 no-scrollbar relative print:overflow-visible print:h-auto print:static">
                        <Outlet />
                    </main>
                    {!isStoreManagementOrCreationPage && (
                        <div className="no-print">
                            <MobileNavigation activeStoreId={activeStore?.id} />
                        </div>
                    )}
                </div>
            </div>
            {settings && !isStoreManagementOrCreationPage && (
                <ShippingCalculatorWidget 
                    settings={settings} 
                    isOpen={isShippingCalculatorOpen} 
                    onClose={() => setIsShippingCalculatorOpen(false)} 
                />
            )}
        </div>
    );
};

const AdminLayout = ({ currentUser, handleLogout, theme, setTheme, isInitialLoad }: any) => {
    if (isInitialLoad) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-[#030712] text-slate-900 dark:text-slate-100" dir="rtl">
                <div className="flex flex-col items-center gap-3">
                    <Loader2 className="animate-spin text-indigo-500" size={36} />
                    <p className="text-sm font-bold text-slate-500 dark:text-slate-400">جاري تحميل لوحة الإدارة...</p>
                </div>
            </div>
        );
    }
    if (!currentUser || !currentUser.isAdmin) {
        return <Navigate to="/owner-login" replace />;
    }
    return (
        <div className="flex flex-col h-screen bg-slate-100 dark:bg-[#030712] text-slate-900 dark:text-slate-50 overflow-hidden relative" dir="rtl">
            {/* Floating Ambient Glow Elements */}
            <div className="absolute top-[-5%] right-[-5%] w-[45vw] h-[45vw] rounded-full bg-indigo-500/10 dark:bg-indigo-500/15 blur-[120px] pointer-events-none z-0 animate-ambient-pulse" />
            <div className="absolute bottom-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-purple-500/8 dark:bg-purple-500/12 blur-[140px] pointer-events-none z-0 animate-ambient-pulse-slow" />
            
            <div className="relative z-10 flex flex-col h-full overflow-hidden">
                <Header currentUser={currentUser} onLogout={handleLogout} theme={theme} setTheme={setTheme} onToggleSidebar={() => {}} />
                <main className="flex-1 overflow-y-auto p-4 md:p-6 no-scrollbar relative">
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

const EmployeeLayoutWrapper = ({ children, isEmployeeSession, ...props }: any) => {
    if (!props.currentUser || !isEmployeeSession) {
        return <Navigate to="/employee-login" replace />;
    }
    return <EmployeeLayout currentUser={props.currentUser} {...props}>{children}</EmployeeLayout>;
};
const EmployeePermissionRoute = ({ currentUser, permission, children }: { currentUser: User | null; permission: Permission; children: React.ReactNode }) => {
    const hasPermission = Boolean(currentUser?.isAdmin || currentUser?.permissions?.includes(permission));
    if (!currentUser) return <Navigate to="/employee-login" replace />;
    if (!hasPermission) return <Navigate to="/employee/dashboard" replace />;
    return <>{children}</>;
};
function autoHealProducts(products: Product[] = [], warehouses: Warehouse[] = []): Product[] {
    const warehouseIds = warehouses.map(w => w.id);
    const defaultWhId = warehouseIds[0];
    if (!defaultWhId || !products || products.length === 0) return products;

    let arrayChanged = false;
    const updated = products.map(p => {
        if (p.hasVariants && p.variants) {
            let varArrayChanged = false;
            const updatedVariants = p.variants.map(v => {
                let whStock = { ...(v.warehouseStock || {}) };
                let whChanged = false;
                Object.keys(whStock).forEach(whId => {
                    if (!warehouseIds.includes(whId)) {
                        delete whStock[whId];
                        whChanged = true;
                    }
                });
                const dist = Object.values(whStock).reduce((sum, val) => sum + (Number(val) || 0), 0);
                const target = Number(v.stockQuantity !== undefined ? v.stockQuantity : (v.stock || 0));
                if (dist !== target || !v.warehouseStock || Object.keys(v.warehouseStock).length === 0 || whChanged) {
                    const gap = target - dist;
                    whStock[defaultWhId] = Math.max(0, (Number(whStock[defaultWhId]) || 0) + gap);
                    const newDist = Object.values(whStock).reduce((sum, val) => sum + (Number(val) || 0), 0);
                    return {
                        ...v,
                        warehouseStock: whStock,
                        stockQuantity: newDist,
                        stock: newDist
                    };
                }
                return v;
            });
            varArrayChanged = updatedVariants.some((v, i) => v !== p.variants![i]);
            if (varArrayChanged) {
                arrayChanged = true;
                const totalFromVariants = updatedVariants.reduce((t, v) => t + (v.stockQuantity || 0), 0);
                return {
                    ...p,
                    variants: updatedVariants,
                    stockQuantity: totalFromVariants,
                    stock: totalFromVariants,
                    inStock: totalFromVariants > 0
                };
            }
            return p;
        } else {
            let whStock = { ...(p.warehouseStock || {}) };
            let whChanged = false;
            Object.keys(whStock).forEach(whId => {
                if (!warehouseIds.includes(whId)) {
                    delete whStock[whId];
                    whChanged = true;
                }
            });
            const dist = Object.values(whStock).reduce((sum, val) => sum + (Number(val) || 0), 0);
            const target = Number(p.stockQuantity !== undefined ? p.stockQuantity : (p.stock || 0));
            if (dist !== target || !p.warehouseStock || Object.keys(p.warehouseStock).length === 0 || whChanged) {
                const gap = target - dist;
                whStock[defaultWhId] = Math.max(0, (Number(whStock[defaultWhId]) || 0) + gap);
                const newDist = Object.values(whStock).reduce((sum, val) => sum + (Number(val) || 0), 0);
                arrayChanged = true;
                return {
                    ...p,
                    warehouseStock: whStock,
                    stockQuantity: newDist,
                    stock: newDist,
                    inStock: newDist > 0
                };
            }
            return p;
        }
    });

    return arrayChanged ? updated : products;
}

function sanitizeData(storeData: StoreData): StoreData {
    if (!storeData) return storeData;

    const isoDateRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/; 
    let hasChanges = false;

    let sanitizedSettings = storeData.settings;
    if (sanitizedSettings?.products) {
        const healedProducts = autoHealProducts(sanitizedSettings.products, sanitizedSettings.warehouses || []);
        let mediaNormalized = false;
        const normalizedProducts = healedProducts.map(p => {
            const finalThumb = p.thumbnail || (Array.isArray(p.images) && p.images[0]) || '';
            const finalImages = (Array.isArray(p.images) && p.images.length > 0) ? p.images : (finalThumb ? [finalThumb] : []);
            if (p.thumbnail !== finalThumb || (Array.isArray(p.images) && p.images.length !== finalImages.length)) {
                mediaNormalized = true;
                return { ...p, thumbnail: finalThumb, images: finalImages };
            }
            return p;
        });
        if (healedProducts !== sanitizedSettings.products || mediaNormalized) {
            hasChanges = true;
            sanitizedSettings = { ...sanitizedSettings, products: normalizedProducts };
        }
    }

    const fixDate = (dateString: string): string | null => {
        if (!dateString || typeof dateString !== 'string') return null;
        if (isoDateRegex.test(dateString)) return null;
        
        const parsedDate = new Date(dateString);
        if (isNaN(parsedDate.getTime()) || /[٠-٩]/.test(dateString)) {
            hasChanges = true;
            return new Date().toISOString();
        } else {
            hasChanges = true;
            return parsedDate.toISOString();
        }
    };
    
    const sanitizedTransactions = storeData.wallet?.transactions?.map(tx => {
        const fixedDate = fixDate(tx.date);
        return fixedDate ? { ...tx, date: fixedDate } : tx;
    });

    const sanitizedOrders = storeData.orders?.map(order => {
        const fixedDate = fixDate(order.date);
        return fixedDate ? { ...order, date: fixedDate } : order;
    });

    if (hasChanges) {
        return {
            ...storeData,
            settings: sanitizedSettings || storeData.settings || INITIAL_SETTINGS,
            wallet: {
                ...(storeData.wallet || {balance: 0, transactions: []}),
                transactions: sanitizedTransactions || storeData.wallet?.transactions || []
            },
            orders: sanitizedOrders || storeData.orders || [],
            quotations: storeData.quotations || [],
        };
    }

    return storeData;
}

// -------------------------------------------------------------------------------------------------
// تم سحب المكونات الداخلية للخارج لمنع إعادة البناء وتدمير واجهة المستخدم (The Flicker Fix)
// -------------------------------------------------------------------------------------------------
const OwnerLayoutWrapper = ({
    currentUser,
    isEmployeeSession,
    welcomeScreenShown,
    setWelcomeScreenShown,
    handleLogout,
    isSidebarOpen,
    setIsSidebarOpen,
    activeStore,
    activeStoreId,
    handleSetActiveStore,
    settings,
    orders = [],
    theme,
    setTheme,
    forceSync,
    saveStatus,
    saveMessage,
    isShippingCalculatorOpen,
    setIsShippingCalculatorOpen,
    isInitialLoad
}: any) => {
    const location = useLocation();
    const { storeId: urlStoreId } = useParams();

    const [allPartnerRequests, setAllPartnerRequests] = useState<db.PartnerPortalRequest[]>([]);

    useEffect(() => {
        if (!activeStoreId) {
            setAllPartnerRequests([]);
            return;
        }
        try {
            const q = query(
                collection(firebaseDb, 'partner_requests'),
                where('storeId', '==', activeStoreId)
            );
            return onSnapshot(q, (snapshot) => {
                const list: db.PartnerPortalRequest[] = [];
                snapshot.forEach(docSnap => {
                    list.push({ id: docSnap.id, ...docSnap.data() } as db.PartnerPortalRequest);
                });
                setAllPartnerRequests(list);
            });
        } catch (e) {
            console.warn('[Notification] partner_requests subscription error:', e);
        }
    }, [activeStoreId]);

    const pendingRequestsCounts = useMemo(() => {
        const merchantReqs = allPartnerRequests.filter(r => {
            return r.status === 'pending' && (
                r.id?.startsWith('REQ-M-') || 
                r.isMerchantRequest === true || 
                (r.typeArabic && r.typeArabic.includes('الموكل')) ||
                (r.partnerId && (r.partnerId.startsWith('m_') || r.partnerId.startsWith('sup_')))
            );
        });
        
        const partnerReqs = allPartnerRequests.filter(r => {
            const isMerchant = r.id?.startsWith('REQ-M-') || 
                               r.isMerchantRequest === true || 
                               (r.typeArabic && r.typeArabic.includes('الموكل')) ||
                               (r.partnerId && (r.partnerId.startsWith('m_') || r.partnerId.startsWith('sup_')));
            return r.status === 'pending' && !isMerchant;
        });

        return {
            merchants: merchantReqs.length,
            partners: partnerReqs.length
        };
    }, [allPartnerRequests]);

    useEffect(() => {
        if (urlStoreId && urlStoreId !== activeStoreId) {
            handleSetActiveStore(urlStoreId);
        }
    }, [urlStoreId, activeStoreId, handleSetActiveStore]);

    useEffect(() => {
        if (!welcomeScreenShown && settings && !isInitialLoad && currentUser) {
            // Preload the sound immediately when settings are available
            const confettiSettings = settings?.confettiSettings;
            const soundMap: any = {
                standard: 'https://assets.mixkit.co/active_storage/sfx/2013/2013-preview.mp3',
                cash: 'https://assets.mixkit.co/active_storage/sfx/133/133-preview.mp3',
                success: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
                trumpet: 'https://assets.mixkit.co/active_storage/sfx/2017/2017-preview.mp3',
                fireworks: 'https://assets.mixkit.co/active_storage/sfx/619/619-preview.mp3',
                magic: 'https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3',
                modern_shine: 'https://assets.mixkit.co/active_storage/sfx/2567/2567-preview.mp3',
                pro_chime: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3',
                future_ui: 'https://assets.mixkit.co/active_storage/sfx/2357/2357-preview.mp3',
                soft_welcome: 'https://assets.mixkit.co/active_storage/sfx/2003/2003-preview.mp3',
                tech_rise: 'https://assets.mixkit.co/active_storage/sfx/611/611-preview.mp3'
            };
            const selectedType = confettiSettings?.welcomeSoundType || 'standard';
            const soundUrl = soundMap[selectedType] || soundMap.standard;
            const welcomeAudio = new Audio(soundUrl);
            welcomeAudio.preload = 'auto';
            welcomeAudio.volume = confettiSettings?.soundVolume ?? 0.3;

            // Loading sound logic
            let loadingAudio: HTMLAudioElement | null = null;
            if (confettiSettings?.enableLoadingSound !== false) {
                loadingAudio = new Audio('https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3');
                loadingAudio.volume = (confettiSettings?.soundVolume ?? 0.3) * 0.5; // Slightly quieter
                loadingAudio.loop = true;
                loadingAudio.play().catch(() => {
                    // Fallback play if blocked
                    const playOnInteract = () => {
                        if (loadingAudio) loadingAudio.play().catch(() => {});
                        window.removeEventListener('mousedown', playOnInteract);
                    };
                    window.addEventListener('mousedown', playOnInteract);
                });
            }

            const timer = setTimeout(() => {
                // Stop loading sound
                if (loadingAudio) {
                    loadingAudio.pause();
                    loadingAudio = null;
                }

                setWelcomeScreenShown(true);
                
                if (confettiSettings?.enableWelcomeSound !== false && currentUser) {
                    const playWelcome = () => {
                        welcomeAudio.play().catch(() => {
                            // Fallback: play on first user interaction if blocked
                            const playOnInteract = () => {
                                welcomeAudio.play().catch(() => {});
                                window.removeEventListener('click', playOnInteract);
                            };
                            window.addEventListener('click', playOnInteract);
                        });
                    };
                    playWelcome();
                }
            }, 1800); // Slightly longer to ensure loading and visual impact
            
            return () => {
                clearTimeout(timer);
                if (loadingAudio) {
                    loadingAudio.pause();
                    loadingAudio = null;
                }
            };
        }
    }, [welcomeScreenShown, setWelcomeScreenShown, settings, currentUser, isInitialLoad]);

    // 1. While initial session load is in progress, show WelcomeLoader smoothly without redirecting prematurely
    if (isInitialLoad) {
        return (
            <WelcomeLoader 
                userName={currentUser?.fullName || ''} 
                userRole="جاري تحضير بيئة العمل..."
                storeName={activeStore?.name}
                storeSubdomain={activeStore?.subdomain}
                onFastPass={() => setWelcomeScreenShown(true)}
            />
        );
    }

    // 2. Routing checks after initial session resolution
    if (isEmployeeSession) {
        return <Navigate to="/employee/dashboard" replace />;
    }
    if (!currentUser) {
        return <Navigate to="/welcome" replace />;
    }

    const hasNoStores = !currentUser.stores || currentUser.stores.length === 0;

    if (hasNoStores && !currentUser.isAdmin) {
        if (location.pathname !== '/create-store') {
            return <Navigate to="/create-store" replace />;
        }
        return (
            <div className="bg-slate-100/70 dark:bg-gradient-to-b dark:from-slate-950 dark:to-[#111827] text-slate-800 dark:text-slate-200 min-h-screen" dir="rtl">
                <Header currentUser={currentUser} onLogout={handleLogout} onToggleSidebar={() => {}} theme={theme} setTheme={setTheme} />
                <main className="flex-1 p-4 md:p-6">
                    <Outlet />
                </main>
            </div>
        );
    }

    // 3. Render WelcomeLoader ONCE per user session
    if (!welcomeScreenShown) {
        return (
            <WelcomeLoader 
                userName={currentUser?.fullName || ''} 
                userRole={currentUser?.isAdmin ? 'المدير العام للمنصة' : (isEmployeeSession ? 'فريق العمليات' : 'مالك المتجر')}
                storeName={activeStore?.name}
                storeSubdomain={activeStore?.subdomain}
                onFastPass={() => setWelcomeScreenShown(true)}
            />
        );
    }

    return (
        <MainLayout 
            currentUser={currentUser} 
            handleLogout={handleLogout} 
            isSidebarOpen={isSidebarOpen} 
            setSidebarOpen={setIsSidebarOpen} 
            activeStore={activeStore} 
            settings={settings}
            orders={orders}
            theme={theme} 
            setTheme={setTheme} 
            forceSync={forceSync}
            saveStatus={saveStatus}
            saveMessage={saveMessage}
            isShippingCalculatorOpen={isShippingCalculatorOpen}
            setIsShippingCalculatorOpen={setIsShippingCalculatorOpen}
            pendingRequestsCounts={pendingRequestsCounts}
        />
    );
};

const CatchAllRedirect = ({ currentUser, isEmployeeSession, activeStoreId }: any) => {
    if (!currentUser) return <Navigate to="/owner-login" replace />;
    if (isEmployeeSession) return <Navigate to="/employee/dashboard" replace />;
    if (currentUser.isAdmin) return <Navigate to="/admin" replace />;
    
    if (activeStoreId) {
        return <Navigate to={`/store/${activeStoreId}/dashboard`} replace />;
    }
    
    return <Navigate to="/select-store" replace />;
};
// -------------------------------------------------------------------------------------------------


export const AppComponent = () => {
    const [users, setUsers] = useState<User[]>([]);
    const [allStoresData, setAllStoresData] = useState<Record<string, StoreData>>({});
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [activeStoreId, setActiveStoreId] = useState<string | null>(null);
    const [isInitialLoad, setIsInitialLoad] = useState<boolean>(true);
    const [syncedSnapshot, setSyncedSnapshot] = useState<{ users: User[]; allStoresData: Record<string, StoreData>; } | null>(null);
    const [authChecked, setAuthChecked] = useState<boolean>(false);
    const [cart, setCart] = useState<OrderItem[]>(() => {
        try {
            const saved = localStorage.getItem('storefront_cart');
            return saved ? JSON.parse(saved) : [];
        } catch {
            return [];
        }
    });

    useEffect(() => {
        try {
            localStorage.setItem('storefront_cart', JSON.stringify(cart));
        } catch (e) {}
    }, [cart]);
    const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
    const [isEmployeeSession, setIsEmployeeSession] = useState<boolean>(false);
    const enrichedCustomers = useMemo(() => {
        if (!activeStoreId || !allStoresData[activeStoreId]) return [];
        const store = allStoresData[activeStoreId];
        return computeEnrichedCustomers(store.orders || [], {}, store.customers || []);
    }, [activeStoreId, allStoresData]);
    const [theme, setTheme] = useState<string>(() => localStorage.getItem('theme') || 'light');
    const [showCongratsModal, setShowCongratsModal] = useState<boolean>(false);
    const [welcomeScreenShown, setWelcomeScreenShownState] = useState<boolean>(() => {
        try {
            return sessionStorage.getItem('welcomeScreenShown') === 'true';
        } catch {
            return false;
        }
    });

    const setWelcomeScreenShown = useCallback((shown: boolean) => {
        setWelcomeScreenShownState(shown);
        try {
            if (shown) {
                sessionStorage.setItem('welcomeScreenShown', 'true');
            } else {
                sessionStorage.removeItem('welcomeScreenShown');
            }
        } catch (e) {}
    }, []);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'local_saved' | 'success' | 'pending' | 'error'>('idle');
    const [saveMessage, setSaveMessage] = useState('');
    const [isStandaloneStorefront, setIsStandaloneStorefront] = useState<boolean>(false);
    const [isStoreNotFound, setIsStoreNotFound] = useState<boolean>(false);
    const [isShippingCalculatorOpen, setIsShippingCalculatorOpen] = useState<boolean>(false);
    
    const [dbSyncMode, setDbSyncModeState] = useState<'manual' | 'auto'>(() => {
        const value = localStorage.getItem('dbSyncMode');
        return (value === 'auto' || value === 'manual') ? value : 'auto';
    });

    const setDbSyncMode = (mode: 'manual' | 'auto') => {
        localStorage.setItem('dbSyncMode', mode);
        setDbSyncModeState(mode);
        // Force state update to trigger listener changes
        window.dispatchEvent(new Event('storage'));
    };
    
    const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
    const refreshDebounceTimers = useRef<Record<string, ReturnType<typeof setTimeout> | null>>({});
    const isRefreshing = useRef(false);
    const notifiedWhatsAppMessagesRef = useRef<Set<string>>(new Set());
    
    // Stable refs for unstable dependencies
    const refreshStoreDataRef = useRef<any>(null);
    const refreshGlobalDataRef = useRef<any>(null);
    const activeStoreRef = useRef<any>(null);
    const allStoresDataRef = useRef<any>(null);
    const knownOrderIdsRef = useRef<Set<string>>(new Set());
    const hasInitialOrdersLoadedRef = useRef<boolean>(false);
    
    // 2FA State
    const [userForOtp, setUserForOtp] = useState<User | null>(null);
    const [sessionInfoForOtp, setSessionInfoForOtp] = useState<{isEmployee: boolean, storeId: string} | null>(null);
    const [otpError, setOtpError] = useState<string>('');
    const [otpTargetEmail, setOtpTargetEmail] = useState<string>('');

    // PWA Install State
    const [installPrompt, setInstallPrompt] = useState<any>(null);
    const [isStandalone, setIsStandalone] = useState(window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true);
    const [isIos, setIsIos] = useState(false);
    
    const navigate = useNavigate();
    const location = useLocation();

    // تشغيل أصوات المأثرات التفاعلية لجميع أزار وتبويبات اللوحة تلقائياً وبشكل شيك جداً
    useEffect(() => {
        const handleGlobalClick = (e: MouseEvent) => {
            const target = e.target as HTMLElement;
            if (!target) return;

            // البحث عن أقرب عنصر قابل للنقر
            const clickable = target.closest('button, [role="button"], a, input[type="submit"], input[type="button"], select');
            if (!clickable) return;

            const textContent = (clickable.textContent || '').trim();
            const classList = clickable.className || '';
            
            // تصنيف الصوت ومستوى التفاعل
            const isDelete = classList.includes('delete') || 
                             classList.includes('trash') || 
                             classList.includes('remove') || 
                             classList.includes('clear') || 
                             textContent.includes('مسح') || 
                             textContent.includes('حذف') || 
                             textContent.includes('إلغاء');

            const isSuccess = classList.includes('success') || 
                              textContent.includes('حفظ') || 
                              textContent.includes('تأكيد') || 
                              textContent.includes('إضافة') || 
                              textContent.includes('نشر') ||
                              textContent.includes('إرسال') ||
                              textContent.includes('تفعيل') ||
                              textContent.includes('دفع') ||
                              textContent.includes('شحن');

            const isTabOrNav = classList.includes('tab') || 
                               classList.includes('nav') || 
                               clickable.tagName === 'A' || 
                               clickable.getAttribute('role') === 'tab' ||
                               clickable.closest('nav') ||
                               classList.includes('sidebar-link');

            if (isDelete) {
                audioSynth.playTone('warning');
            } else if (isSuccess) {
                audioSynth.playTone('success');
            } else if (isTabOrNav) {
                audioSynth.playTone('info'); // نغمة انسيابية وناعمة للتبويبات
            } else {
                audioSynth.playTone('click'); // نقرة هادئة للأزرار العادية
            }
        };

        document.addEventListener('click', handleGlobalClick, { capture: true });
        return () => {
            document.removeEventListener('click', handleGlobalClick, { capture: true });
        };
    }, []);

    // إغلاق القائمة تلقائياً عند تغيير المسار في الموبايل
    useEffect(() => {
        setIsSidebarOpen(false);
    }, [location.pathname]);

    // تتبع حالة الحفظ لمنع تداخل التحديثات اللحظية وحماية طابور الحفظ
    const isSavingRef = useRef(false);
    const isDirtyRef = useRef(false);
    const isFirstSyncAfterLoadRef = useRef(true);
    const pendingCloudSaveRef = useRef(false);
    const latestStateRef = useRef<{ users: User[], allStoresData: Record<string, StoreData>, activeStore: Store | undefined, activeStoreId: string }>({
        users,
        allStoresData,
        activeStore: undefined,
        activeStoreId
    });

    useEffect(() => {
        isSavingRef.current = (saveStatus === 'saving');
    }, [saveStatus]);

    const activeStore = useMemo(() => {
        if (!activeStoreId) return undefined;
        const owner = users.find(u => u.stores?.some(s => s.id === activeStoreId));
        return owner?.stores?.find(s => s.id === activeStoreId);
    }, [activeStoreId, users]);

    // Capture/update synced snapshot
    useEffect(() => {
        if (isInitialLoad) return;
        
        // When initial load is done, set the initial snapshot
        if (!syncedSnapshot && users.length > 0) {
            setSyncedSnapshot({
                users: JSON.parse(JSON.stringify(users)),
                allStoresData: JSON.parse(JSON.stringify(allStoresData))
            });
        }
    }, [isInitialLoad, users, allStoresData, syncedSnapshot]);

    useEffect(() => {
        if (saveStatus === 'success') {
            setSyncedSnapshot({
                users: JSON.parse(JSON.stringify(users)),
                allStoresData: JSON.parse(JSON.stringify(allStoresData))
            });
        }
    }, [saveStatus, users, allStoresData]);

    const getUnsavedChanges = (): any[] => {
        if (!syncedSnapshot || !activeStoreId) return [];

        const currentStore = allStoresData[activeStoreId];
        const snapStore = syncedSnapshot.allStoresData[activeStoreId];

        if (!currentStore) return [];

        const changes: any[] = [];

        const oldProducts = snapStore?.settings?.products || [];
        const newProducts = currentStore.settings?.products || [];

        const oldOrders = snapStore?.orders || [];
        const newOrders = currentStore.orders || [];

        const oldSuppliers = snapStore?.settings?.suppliers || [];
        const newSuppliers = currentStore.settings?.suppliers || [];

        const oldSupplyOrders = snapStore?.settings?.supplyOrders || [];
        const newSupplyOrders = currentStore.settings?.supplyOrders || [];

        const oldDiscountCodes = snapStore?.settings?.discountCodes || [];
        const newDiscountCodes = currentStore.settings?.discountCodes || [];

        const oldReviews = snapStore?.settings?.reviews || [];
        const newReviews = currentStore.settings?.reviews || [];

        const oldTreasury = snapStore?.treasury?.accounts || [];
        const newTreasury = currentStore.treasury?.accounts || [];

        const oldPartners = snapStore?.settings?.partners || [];
        const newPartners = currentStore.settings?.partners || [];

        const oldUsers = syncedSnapshot.users || [];
        const newUsers = users || [];

        // Products comparison
        newProducts.forEach(p => {
            const oldP = oldProducts.find(o => o.id === p.id);
            if (!oldP) {
                changes.push({ type: 'product', action: 'add', name: p.name });
            } else {
                if (oldP.name !== p.name || oldP.price !== p.price || oldP.costPrice !== p.costPrice || oldP.stockQuantity !== p.stockQuantity) {
                    changes.push({ type: 'product', action: 'modify', name: p.name });
                }
            }
        });
        oldProducts.forEach(p => {
            if (!newProducts.some(n => n.id === p.id)) {
                changes.push({ type: 'product', action: 'delete', name: p.name });
            }
        });

        // Orders comparison
        newOrders.forEach(o => {
            const oldO = oldOrders.find(oldItem => oldItem.id === o.id);
            if (!oldO) {
                changes.push({ type: 'order', action: 'add', name: `طلب #${o.id.slice(-6)}` });
            } else {
                if (oldO.status !== o.status || oldO.totalPrice !== o.totalPrice || (oldO.items || []).length !== (o.items || []).length) {
                    changes.push({ type: 'order', action: 'modify', name: `طلب #${o.id.slice(-6)}` });
                }
            }
        });
        oldOrders.forEach(o => {
            if (!newOrders.some(n => n.id === o.id)) {
                changes.push({ type: 'order', action: 'delete', name: `طلب #${o.id.slice(-6)}` });
            }
        });

        // Suppliers comparison
        newSuppliers.forEach(s => {
            const oldS = oldSuppliers.find(o => o.id === s.id);
            if (!oldS) {
                changes.push({ type: 'supplier', action: 'add', name: s.name });
            } else {
                if (oldS.name !== s.name || oldS.balance !== s.balance || oldS.phone !== s.phone) {
                    changes.push({ type: 'supplier', action: 'modify', name: s.name });
                }
            }
        });
        oldSuppliers.forEach(s => {
            if (!newSuppliers.some(n => n.id === s.id)) {
                changes.push({ type: 'supplier', action: 'delete', name: s.name });
            }
        });

        // Supply Orders comparison
        newSupplyOrders.forEach(so => {
            const oldSo = oldSupplyOrders.find(o => o.id === so.id);
            if (!oldSo) {
                changes.push({ type: 'supply_order', action: 'add', name: `فاتورة شراء #${so.orderNumber || so.id.slice(-6)}` });
            } else {
                if (oldSo.status !== so.status || oldSo.totalCost !== so.totalCost) {
                    changes.push({ type: 'supply_order', action: 'modify', name: `فاتورة شراء #${so.orderNumber || so.id.slice(-6)}` });
                }
            }
        });
        oldSupplyOrders.forEach(so => {
            if (!newSupplyOrders.some(n => n.id === so.id)) {
                changes.push({ type: 'supply_order', action: 'delete', name: `فاتورة شراء #${so.orderNumber || so.id.slice(-6)}` });
            }
        });

        // Discount Codes comparison
        newDiscountCodes.forEach(d => {
            const oldD = oldDiscountCodes.find(o => o.id === d.id);
            if (!oldD) {
                changes.push({ type: 'discount', action: 'add', name: d.code });
            } else {
                if (oldD.code !== d.code || oldD.value !== d.value || oldD.active !== d.active) {
                    changes.push({ type: 'discount', action: 'modify', name: d.code });
                }
            }
        });
        oldDiscountCodes.forEach(d => {
            if (!newDiscountCodes.some(n => n.id === d.id)) {
                changes.push({ type: 'discount', action: 'delete', name: d.code });
            }
        });

        // Reviews comparison
        newReviews.forEach(r => {
            const oldR = oldReviews.find(o => o.id === r.id);
            if (!oldR) {
                changes.push({ type: 'review', action: 'add', name: r.comment || `تقييم العميل ${r.customerName}` });
            } else {
                if (oldR.status !== r.status || oldR.rating !== r.rating) {
                    changes.push({ type: 'review', action: 'modify', name: r.comment || `تقييم العميل ${r.customerName}` });
                }
            }
        });
        oldReviews.forEach(r => {
            if (!newReviews.some(n => n.id === r.id)) {
                changes.push({ type: 'review', action: 'delete', name: r.comment || `تقييم العميل ${r.customerName}` });
            }
        });

        // Treasury comparison
        newTreasury.forEach(a => {
            const oldA = oldTreasury.find(o => o.id === a.id);
            if (!oldA) {
                changes.push({ type: 'treasury', action: 'add', name: a.name });
            } else if (oldA.balance !== a.balance) {
                changes.push({ type: 'treasury', action: 'modify', name: a.name });
            }
        });

        // Partners comparison
        newPartners.forEach(p => {
            const oldP = oldPartners.find(o => o.id === p.id);
            if (!oldP) {
                changes.push({ type: 'partner', action: 'add', name: p.name });
            } else if (oldP.balance !== p.balance) {
                changes.push({ type: 'partner', action: 'modify', name: p.name });
            }
        });

        // Users comparison
        newUsers.forEach(u => {
            const oldU = oldUsers.find(o => o.phone === u.phone);
            if (!oldU) {
                changes.push({ type: 'user', action: 'add', name: u.fullName });
            } else {
                if (oldU.fullName !== u.fullName || oldU.email !== u.email || oldU.isAdmin !== u.isAdmin || JSON.stringify(oldU.stores) !== JSON.stringify(u.stores)) {
                    changes.push({ type: 'user', action: 'modify', name: u.fullName });
                }
            }
        });
        oldUsers.forEach(u => {
            if (!newUsers.some(n => n.phone === u.phone)) {
                changes.push({ type: 'user', action: 'delete', name: u.fullName });
            }
        });

        // Settings comparison
        if (snapStore) {
            const keysToCompare = [
                'store_name', 'phone', 'address', 'currency', 'taxNumber', 'commercialRegister', 'shippingVatRate',
                'enableInsurance', 'enableInspection', 'enableReturnShipping', 'enableFlexShip', 'flexShipFee', 'flexShipCompanyFee',
                'enableReturnAfterPrice', 'enableExchangePrice', 'enableGlobalCod', 'insuranceFeePercent'
            ];
            const settingsChanged = keysToCompare.some(k => currentStore.settings?.[k as keyof Settings] !== snapStore.settings?.[k as keyof Settings]);
            if (settingsChanged) {
                changes.push({ type: 'settings', action: 'modify', name: 'الإعدادات العامة للمتجر' });
            }
        }

        return changes;
    };

    // Ensure every store has a subdomain and generate a random one if missing
    useEffect(() => {
        if (isInitialLoad || isRefreshing.current) return;
        
        let changed = false;
        const newAllStoresData = { ...allStoresData };
        
        Object.keys(newAllStoresData).forEach(storeId => {
            const data = newAllStoresData[storeId];
            if (data && data.settings && !data.settings.subdomain && !data.settings.isSubdomainFixed) {
                // Find existing subdomain in users object first
                const owner = users.find(u => u.stores?.some(s => s.id === storeId));
                const storeMeta = owner?.stores?.find(s => s.id === storeId);
                const existingSub = storeMeta?.subdomain;

                const generatedSubdomain = existingSub || (() => {
                    const storeName = storeId;
                    const base = storeName.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 15);
                    const random = Math.floor(1000 + Math.random() * 9000).toString();
                    return `${base || 'store'}-${random}`;
                })();
                
                newAllStoresData[storeId] = {
                    ...data,
                    settings: {
                        ...data.settings,
                        subdomain: generatedSubdomain,
                        isSubdomainFixed: true
                    }
                };
                changed = true;
            }
        });
        
        if (changed) {
            setAllStoresData(newAllStoresData);
        }
    }, [allStoresData, isInitialLoad, users]);

    // Sync domains to users for ALL stores that have loaded data
    useEffect(() => {
        if (isInitialLoad || isRefreshing.current) return;

        const updateTimeout = setTimeout(() => {
            setUsers(prevUsers => {
                let changed = false;
                const newUsers = prevUsers.map(user => {
                    if (!user.stores) return user;
                    
                    let storesChanged = false;
                    const newStores = user.stores.map(store => {
                        const storeData = allStoresData[store.id];
                        
                        let currentCustomDomain = store.customDomain;
                        let currentSubdomain = store.subdomain;
                        
                        if (storeData && storeData.settings) {
                            currentCustomDomain = storeData.settings.customAppDomain || currentCustomDomain;
                            currentSubdomain = storeData.settings.subdomain || currentSubdomain;
                            // If it's fixed in settings, respect that even if currentSubdomain is somehow null in store object
                            if (storeData.settings.isSubdomainFixed && storeData.settings.subdomain) {
                                currentSubdomain = storeData.settings.subdomain;
                            }
                        }

                        if (!currentSubdomain && !storeData?.settings?.isSubdomainFixed && (!store.url || store.url.includes('wuitstore') || store.url.includes('---'))) {
                            const base = store.name.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 15);
                            const random = Math.floor(1000 + Math.random() * 9000).toString();
                            currentSubdomain = `${base || 'store'}-${random}`;
                        }
                        
                        let bestUrl = store.url;
                        if (currentCustomDomain) {
                            bestUrl = currentCustomDomain;
                        } else if (currentSubdomain) {
                            bestUrl = `${currentSubdomain}.abdomedi.com`;
                        }

                        if (
                            store.customDomain !== currentCustomDomain || 
                            store.subdomain !== currentSubdomain ||
                            store.url !== bestUrl
                        ) {
                            changed = true;
                            storesChanged = true;
                            return { 
                                ...store, 
                                customDomain: currentCustomDomain, 
                                subdomain: currentSubdomain,
                                url: bestUrl
                            };
                        }
                        return store;
                    });
                    
                    if (storesChanged) return { ...user, stores: newStores };
                    return user;
                });
                
                return changed ? newUsers : prevUsers;
            });
        }, 1000);

        return () => clearTimeout(updateTimeout);
    }, [allStoresData, isInitialLoad]);

    // Update browser tab title dynamically based on active store and current route
    useEffect(() => {
        const path = location.pathname;
        const isStorefrontRoute = isStandaloneStorefront || 
            path === '/' ||
            path.startsWith('/store') || 
            path.startsWith('/product') || 
            path.startsWith('/products') || 
            path.startsWith('/p/') || 
            path.startsWith('/cart') || 
            path.startsWith('/checkout') || 
            path.startsWith('/order-success');

        const currentSettings = (activeStoreId && allStoresData[activeStoreId]?.settings) || INITIAL_SETTINGS;
        const storeName = activeStore?.name || (currentSettings as any)?.storeName || (activeStore as any)?.settings?.storeName || 'المتجر الإلكتروني';

        if (isStorefrontRoute) {
            if (path.includes('/checkout')) {
                document.title = `إتمام الطلب | ${storeName}`;
            } else if (path.includes('/cart')) {
                document.title = `سلة المشتريات | ${storeName}`;
            } else if (path.includes('/order-success')) {
                document.title = `تم تأكيد طلبك بنجاح 🎉 | ${storeName}`;
            } else if (!path.includes('/product') && !path.includes('/p/')) {
                document.title = `${storeName} | المتجر الإلكتروني`;
            }
            return;
        }

        if (activeStore?.name) {
            document.title = `${activeStore.name} | لوحة التحكم`;
        } else {
            document.title = `لوحة التحكم | ${storeName}`;
        }
    }, [activeStore?.name, activeStoreId, allStoresData, isStandaloneStorefront, location.pathname]);

    // --- Aggressive Auto-Save Logic ---
    // 1. Instant local persistence to IndexedDB
    useEffect(() => {
        if (isInitialLoad || isRefreshing.current) return;

        const fastLocalSave = async () => {
            try {
                // Always save global users immediately locally
                await db.saveLocal('global', { users, loyaltyData: {} });
                
                // Save active store data immediately locally
                if (activeStoreId && allStoresData[activeStoreId]) {
                    await db.saveLocal(activeStoreId, allStoresData[activeStoreId]);
                }
                
                // Set status to local_saved to reassure the user, but don't overwrite if we are currently cloud-saving or in error
                setSaveStatus(prev => {
                    if (prev === 'saving' || prev === 'error') return prev;
                    return 'local_saved';
                });
            } catch (err) {
                console.warn('[LOCAL-SAVE] Quick local save failed:', err);
            }
        };

        const timer = setTimeout(fastLocalSave, 200); // 200ms for responsiveness
        return () => clearTimeout(timer);
    }, [users, allStoresData, activeStoreId, isInitialLoad]);

    // 2. Network sync debounce (Firebase)
    useEffect(() => {
        if (isInitialLoad) {
            isFirstSyncAfterLoadRef.current = true;
            return;
        }
        
        latestStateRef.current = { users, allStoresData, activeStore, activeStoreId };

        // Do not trigger a dirty cloud sync immediately on the first render when initial load completes
        if (isFirstSyncAfterLoadRef.current) {
            isFirstSyncAfterLoadRef.current = false;
            return;
        }

        if (isRefreshing.current) {
            isRefreshing.current = false; 
            return;
        }

        // Bypasses auto-cloud writes when in manual (local desktop) mode.
        if (dbSyncMode === 'manual') {
            setSaveStatus('local_saved');
            setSaveMessage('محفوظ محلياً (ديسك توب)');
            return;
        }

        if (saveStatus !== 'saving') {
            setSaveStatus('pending');
            setSaveMessage('تغييرات غير محفوظة...');
        }

        isDirtyRef.current = true;
        if (debounceTimer.current) clearTimeout(debounceTimer.current);

        const executeCloudSync = async () => {
            if (isSavingRef.current) {
                // If save is already in-flight, mark pending so the next batch is queued and never lost
                pendingCloudSaveRef.current = true;
                return;
            }

            isSavingRef.current = true;
            setSaveStatus('saving');
            setSaveMessage('جاري المزامنة مع السحاب...');

            try {
                const { users: curUsers, allStoresData: curAllStoresData, activeStore: curActiveStore, activeStoreId: curActiveStoreId } = latestStateRef.current;

                const cloudPromises = [];
                cloudPromises.push(db.saveGlobalData({ users: curUsers, loyaltyData: {} }));
                
                if (curActiveStoreId && curAllStoresData[curActiveStoreId] && curActiveStore) {
                    const storeDataToSync = curAllStoresData[curActiveStoreId];
                    // Safeguard: only sync to cloud if store data is actually populated
                    const isUninitializedShell = !storeDataToSync.settings?.storeName && 
                        (!storeDataToSync.settings?.products || storeDataToSync.settings.products.length === 0) && 
                        (!storeDataToSync.orders || storeDataToSync.orders.length === 0);

                    if (!isUninitializedShell) {
                        cloudPromises.push(db.saveStoreData(curActiveStore, storeDataToSync));
                    }
                }

                const results = await Promise.all(cloudPromises);
                const quotaExceeded = results.some(r => r.error === 'QUOTA_EXCEEDED');
                
                if (quotaExceeded) {
                    setDbSyncMode('manual');
                    setSaveStatus('error');
                    setSaveMessage('تم استهلاك حصة الاستخدام اليومية. تم التحويل للعمل دون اتصال.');
                    return;
                }

                const failed = results.find(r => !r.success);
                
                if (failed) {
                    console.warn('[AUTO-SYNC] Cloud sync failed partially:', failed.error);
                    setSaveStatus('local_saved');
                    return;
                }

                isDirtyRef.current = false;
                setSaveStatus('success');
                setSaveMessage('تمت المزامنة بنجاح!');
                setTimeout(() => {
                    setSaveStatus(prev => prev === 'success' ? 'idle' : prev);
                }, 3000);
            } catch (e: any) {
                if (e?.message === 'QUOTA_EXCEEDED' || e === 'QUOTA_EXCEEDED') {
                    setDbSyncMode('manual');
                    setSaveStatus('error');
                    setSaveMessage('تم استهلاك حصة الاستخدام اليومية. تم التحويل للعمل دون اتصال.');
                    return;
                }
                console.error('[AUTO-SYNC] Error during cloud sync:', e);
                setSaveStatus('local_saved');
                setSaveMessage('محفوظ محلياً (المزامنة معطلة مؤقتاً)');
            } finally {
                isSavingRef.current = false;
                // If newer changes arrived while the network request was in-flight, execute them now
                if (pendingCloudSaveRef.current) {
                    pendingCloudSaveRef.current = false;
                    setTimeout(() => {
                        executeCloudSync();
                    }, 500);
                }
            }
        };

        debounceTimer.current = setTimeout(() => {
            executeCloudSync();
        }, 5000); // 5s debounce to batch cloud requests and drastically reduce Egress

        return () => {
            if (debounceTimer.current) clearTimeout(debounceTimer.current);
        };
    }, [users, allStoresData, activeStore, activeStoreId, isInitialLoad, dbSyncMode]);

    // 3. Emergency save on close/visibility change
    useEffect(() => {
        const handleEmergencySave = () => {
            if (activeStoreId && allStoresData[activeStoreId]) {
                db.saveLocal('global', { users, loyaltyData: {} });
                db.saveLocal(activeStoreId, allStoresData[activeStoreId]);
            }
        };

        window.addEventListener('beforeunload', handleEmergencySave);
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') {
                handleEmergencySave();
            }
        });

        return () => {
            window.removeEventListener('beforeunload', handleEmergencySave);
            document.removeEventListener('visibilitychange', handleEmergencySave);
        };
    }, [users, allStoresData, activeStoreId]);


    useEffect(() => {
        const applyTheme = () => {
            // If we are on a storefront page, we ALWAYS want light mode (no 'dark' class on element)
            const isStorefrontPath = isStandaloneStorefront || 
                location.pathname === '/store' || 
                location.pathname === '/cart' || 
                location.pathname === '/checkout' || 
                location.pathname.startsWith('/order-success');

            if (isStorefrontPath) {
                document.documentElement.classList.remove('dark');
                return;
            }

            const themeToApply = theme === 'dark' ? 'dark' : 'light';

            if (themeToApply === 'dark') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        };
        applyTheme();
        localStorage.setItem('theme', theme);
    }, [theme, location.pathname, isStandaloneStorefront]);

    // Proactive background migration for legacy accounts when Admin loads user list
    useEffect(() => {
        if (currentUser?.isAdmin && users && users.length > 0) {
            migrateLegacyUsersToAuth(users);
        }
    }, [currentUser, users]);

    // Helper to wait for Firebase Auth to initialize and return the authenticated user
    const getCurrentAuthenticatedUser = (): Promise<any> => {
        return new Promise((resolve) => {
            const unsubscribe = auth.onAuthStateChanged((user) => {
                unsubscribe();
                resolve(user);
            });
        });
    };

    // Background migration for legacy accounts using a secondary auth instance
    const getMigrationAuth = () => {
        const migrationApp = getApps().find(app => app.name === "MigrationApp") 
            || initializeApp(firebaseConfig, "MigrationApp");
        return getAuth(migrationApp);
    };

    const migrateLegacyUsersToAuth = async (usersToMigrate: User[]) => {
        try {
            const mAuth = getMigrationAuth();
            console.log(`[MIGRATION] Starting background migration check for ${usersToMigrate.length} users...`);
            // Run sequentially in the background to avoid rate limits
            for (const user of usersToMigrate) {
                if (!user.phone) continue;
                const password = user.password;
                if (!password) {
                    console.log(`[MIGRATION] Skipping background migration for user ${user.phone}: No legacy password stored in legacy database.`);
                    continue;
                }
                if (password.length < 6) {
                    console.log(`[MIGRATION] Skipping background migration for user ${user.phone}: Password is shorter than 6 characters (does not meet Firebase Auth security requirements).`);
                    continue;
                }
                
                // Use real email if available, otherwise generated one
                const email = (user.email && user.email.includes('@') && !user.email.includes('mystore-auth.app'))
                    ? user.email
                    : `${user.phone.trim()}@mystore-auth.app`;
                
                try {
                    await createUserWithEmailAndPassword(mAuth, email, password);
                    console.log(`[MIGRATION] Successfully created Firebase Auth account for legacy user ${user.phone}.`);
                } catch (err: any) {
                    if (err.code === 'auth/email-already-in-use') {
                        // Already exists, skip
                    } else if (err.code === 'auth/operation-not-allowed') {
                        console.error('[MIGRATION] Email/Password provider is not enabled in Firebase project! Please enable it in the console.');
                        break; // Stop if provider is disabled to avoid spamming errors
                    } else {
                        console.error(`[MIGRATION] Error migrating user ${user.phone}:`, err);
                    }
                }
            }
        } catch (migrationErr) {
            console.error('[MIGRATION] Fatal migration error:', migrationErr);
        }
    };

    const loadData = async () => {
        setIsInitialLoad(true);
        isRefreshing.current = true;
        try {
            // We no longer fetch all users on load to prevent Firestore permission errors.
            // Admin users will fetch the global users list when needed or via the snapshot listener.
            setUsers([]);
            
            // Check if there is a store ID in the path (e.g. /store/:storeId/partner-portal or /store/:storeId)
            const pathParts = window.location.pathname.split('/');
            let pathStoreId = '';
            if (pathParts[1] === 'store' && pathParts[2] && pathParts[2].startsWith('store-')) {
                pathStoreId = pathParts[2];
            }

            if (pathStoreId) {
                console.log('[STORE-PATH-LOOKUP] Preloading store data from URL path:', pathStoreId);
                const storeData = await db.getStoreData(pathStoreId, dbSyncMode === 'auto') as StoreData | null;
                if (storeData) {
                    const sanitizedStoreData = sanitizeData(storeData);
                    setAllStoresData(prev => ({ ...prev, [pathStoreId]: sanitizedStoreData }));
                    setActiveStoreId(pathStoreId);
                }
            }

            const host = window.location.hostname.toLowerCase();
            const hostNoWww = host.replace(/^www\./, '');
            const mainDomains = ['app.abdomedi.com', 'abdomedi.com', 'fallback.abdomedi.com', 'localhost', '127.0.0.1'];
            
            // Refined isMainDomain check: exact match for root domains or the dev/preview pages
            const isExactMainDomain = mainDomains.includes(hostNoWww) || hostNoWww.includes('run.app') || hostNoWww.includes('pages.dev') || hostNoWww.includes('aistudio.google') || hostNoWww.includes('web-preview');
            
            // Support for forcing storefront view in development via query param
            const urlParams = new URLSearchParams(window.location.search);
            const previewId = urlParams.get('preview_store');

            let foundStoreId: string | null = previewId;
            
            if (!foundStoreId && !isExactMainDomain) {
                // 1. HIGH-PERFORMANCE DIRECT LOOKUP IN STORES_DATA COLLECTION
                // This bypasses Firebase Auth guest list restriction and quota issues
                try {
                    console.log('[STOREFRONT-LOOKUP] Attempting direct stores_data query for:', host);
                    
                    if (host.endsWith('.abdomedi.com')) {
                        const sub = host.split('.')[0].toLowerCase();
                        if (sub && sub !== 'www' && sub !== 'app' && sub !== 'fallback') {
                            const qSub = query(collection(firebaseDb, 'stores_data'), where('settings.subdomain', '==', sub));
                            const subSnap = await getDocs(qSub);
                            if (!subSnap.empty) {
                                foundStoreId = subSnap.docs[0].id;
                                console.log('[STOREFRONT-LOOKUP] Matched store ID via subdomain query:', foundStoreId);
                            }
                        }
                    }
                    
                    if (!foundStoreId) {
                        const qCD = query(collection(firebaseDb, 'stores_data'), where('settings.customDomain', '==', hostNoWww));
                        const cdSnap = await getDocs(qCD);
                        if (!cdSnap.empty) {
                            foundStoreId = cdSnap.docs[0].id;
                            console.log('[STOREFRONT-LOOKUP] Matched store ID via customDomain query:', foundStoreId);
                        }
                    }

                    if (!foundStoreId) {
                        const qCAD = query(collection(firebaseDb, 'stores_data'), where('settings.customAppDomain', '==', hostNoWww));
                        const cadSnap = await getDocs(qCAD);
                        if (!cadSnap.empty) {
                            foundStoreId = cadSnap.docs[0].id;
                            console.log('[STOREFRONT-LOOKUP] Matched store ID via customAppDomain query:', foundStoreId);
                        }
                    }

                    if (!foundStoreId && host !== hostNoWww) {
                        const qCDHost = query(collection(firebaseDb, 'stores_data'), where('settings.customDomain', '==', host));
                        const cdHostSnap = await getDocs(qCDHost);
                        if (!cdHostSnap.empty) {
                            foundStoreId = cdHostSnap.docs[0].id;
                        }
                    }
                } catch (lookupErr) {
                    console.error('[STOREFRONT-LOOKUP] Error in direct stores_data lookup:', lookupErr);
                }
            }
            
            if (foundStoreId) {
                setIsStandaloneStorefront(true);
                setActiveStoreId(foundStoreId);
                const storeData = await db.getStoreData(foundStoreId, dbSyncMode === 'auto') as StoreData | null;
                if (storeData) {
                    const sanitizedStoreData = sanitizeData(storeData);
                    setAllStoresData(prev => ({ ...prev, [foundStoreId!]: sanitizedStoreData }));
                } else if (!isExactMainDomain || previewId) {
                    setIsStoreNotFound(true);
                }
            } else if (!isExactMainDomain) {
                // Not a main domain and no store matched by domain/subdomain
                setIsStoreNotFound(true);
            } else {
                // Normal Dashboard flow (no match found or it is the main domain)
                const savedUserPhone = localStorage.getItem('currentUserPhone');
                const savedStoreId = localStorage.getItem('lastActiveStoreId');
                const savedSessionType = localStorage.getItem('sessionType');
                
                if (savedUserPhone) {
                    try {
                        let user = await db.getUserByPhone(savedUserPhone);
                        
                        if (user) {
                            const localDefault = localStorage.getItem('defaultStoreId');
                            if (!user.defaultStoreId && localDefault) {
                                user.defaultStoreId = localDefault;
                                user.autoLaunchDefaultStore = true;
                            }
                            setUsers(prev => prev.some(u => u.phone === user!.phone) ? prev : [...prev, user!]);
                            setCurrentUser(user);
                            if (savedSessionType === 'employee') {
                                setIsEmployeeSession(true);
                            }
                            const storeId = user.defaultStoreId || savedStoreId || (user.stores && user.stores.length > 0 ? user.stores[0].id : null);
                            if (storeId) {
                                setActiveStoreId(storeId);
                                localStorage.setItem('lastActiveStoreId', storeId);
                                
                                const storeData = await db.getStoreData(storeId, false) as StoreData | null;
                                if (storeData) {
                                    const sanitizedStoreData = sanitizeData(storeData);
                                    setAllStoresData(prev => ({ ...prev, [storeId]: sanitizedStoreData }));
                                }
                            }
                        } else {
                            // Invalid session or doc not found
                            localStorage.removeItem('currentUserPhone');
                            localStorage.removeItem('lastActiveStoreId');
                            localStorage.removeItem('sessionType');
                        }
                    } catch (sessionErr) {
                        console.warn('Could not restore user session:', sessionErr);
                    }
                }
            }
        } catch (error) {
            console.error("Failed to load initial data:", error);
        } finally {
            setAuthChecked(true);
            setIsInitialLoad(false);
        }
    };

    useEffect(() => {
        const handleBeforeInstallPrompt = (e: Event) => {
            e.preventDefault();
            setInstallPrompt(e);
        };
        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

        const mediaQuery = window.matchMedia('(display-mode: standalone)');
        const handleDisplayModeChange = (e: MediaQueryListEvent) => setIsStandalone(e.matches);
        mediaQuery.addEventListener('change', handleDisplayModeChange);
        setIsIos(/iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream);

        loadData();

        return () => {
            window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
            mediaQuery.removeEventListener('change', handleDisplayModeChange);
        };
    }, []);

    const handleLogout = () => {
        setCurrentUser(null);
        setActiveStoreId(null);
        setIsEmployeeSession(false);
        localStorage.removeItem('currentUserPhone');
        localStorage.removeItem('lastActiveStoreId');
        localStorage.removeItem('sessionType');
        setWelcomeScreenShown(false);
        navigate('/welcome');
    };

    const startOtpFlow = async (user: User, sessionInfo: { isEmployee: boolean, storeId: string } | null, password?: string) => {
        setUserForOtp(user);
        setSessionInfoForOtp(sessionInfo);
        setOtpError('');
        setOtpTargetEmail(user.email || '');

        const payload = JSON.stringify({
            phone: user.phone,
            email: user.email,
            userName: user.fullName
        });

        const sendReq = async (url: string) => {
            const resp = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: payload
            });
            const data = await resp.json().catch(() => ({}));
            return { ok: resp.ok, status: resp.status, data };
        };

        try {
            const primaryUrl = AUTH_OTP_API_BASE ? `${AUTH_OTP_API_BASE}/api/send-otp` : '/api/send-otp';
            let res = await sendReq(primaryUrl);

            // If primary remote endpoint rejected origin (403 / "مصدر الطلب غير مسموح") or network failed, fallback to local backend
            if ((!res.ok || res.status === 403 || res.data?.error?.includes('مصدر الطلب')) && primaryUrl !== '/api/send-otp') {
                console.warn('[AUTH] Primary OTP URL rejected or failed. Trying same-origin fallback...');
                const fallbackRes = await sendReq('/api/send-otp').catch(() => null);
                if (fallbackRes && (fallbackRes.ok || !fallbackRes.data?.error?.includes('مصدر الطلب'))) {
                    res = fallbackRes;
                }
            }

            if (res.data?.email) {
                setOtpTargetEmail(res.data.email);
            }
            if (!res.ok || !res.data?.success) {
                setOtpError(res.data?.error || 'تعذر إرسال رمز التحقق إلى البريد الإلكتروني.');
            }
        } catch (err: any) {
            console.warn('[AUTH] Error sending OTP:', err);
            try {
                const fbRes = await sendReq('/api/send-otp');
                if (fbRes.data?.email) setOtpTargetEmail(fbRes.data.email);
                if (!fbRes.ok || !fbRes.data?.success) {
                    setOtpError(fbRes.data?.error || 'تعذر إرسال رمز التحقق إلى البريد الإلكتروني.');
                }
            } catch (fbErr: any) {
                setOtpError('تعذر الاتصال بخادم إرسال الرمز.');
            }
        }
    };

    const handleOtpVerification = async (otp: string) => {
        if (!userForOtp) return;
        setOtpError('');

        const payload = JSON.stringify({ 
            phone: userForOtp.phone,
            email: userForOtp.email || otpTargetEmail, 
            otp 
        });

        const verifyReq = async (url: string) => {
            const resp = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: payload
            });
            const data = await resp.json().catch(() => ({}));
            return { ok: resp.ok, status: resp.status, data };
        };

        try {
            const primaryUrl = AUTH_OTP_API_BASE ? `${AUTH_OTP_API_BASE}/api/verify-otp` : '/api/verify-otp';
            let res = await verifyReq(primaryUrl);

            if ((!res.ok || res.status === 403 || res.data?.error?.includes('مصدر الطلب')) && primaryUrl !== '/api/verify-otp') {
                const fallbackRes = await verifyReq('/api/verify-otp').catch(() => null);
                if (fallbackRes && (fallbackRes.ok || fallbackRes.data?.valid)) {
                    res = fallbackRes;
                }
            }

            if (res.ok && res.data?.valid) {
                completeLogin(userForOtp, sessionInfoForOtp);
            } else {
                setOtpError(res.data?.message || res.data?.error || 'رمز التحقق غير صحيح أو منتهي الصلاحية.');
            }
        } catch (err: any) {
            console.error('Error verifying OTP:', err);
            try {
                const fbRes = await verifyReq('/api/verify-otp');
                if (fbRes.ok && fbRes.data?.valid) {
                    completeLogin(userForOtp, sessionInfoForOtp);
                    return;
                }
                setOtpError(fbRes.data?.message || fbRes.data?.error || 'حدث خطأ أثناء التحقق من الرمز.');
            } catch {
                setOtpError('حدث خطأ أثناء التحقق من الرمز. يرجى المحاولة مرة أخرى.');
            }
        }
    };

    const handleOtpCancel = () => {
        setUserForOtp(null);
        setSessionInfoForOtp(null);
        setOtpError('');
        setOtpTargetEmail('');
    };
    
    const syncSupabaseAuth = async (user: User, password?: string, storeId?: string) => {
        const supabase = getSupabaseClient();
        if (!supabase || !password) return;
        const email = user.email || `${user.phone}@mystore-auth.app`;
        let { data } = await supabase.auth.signInWithPassword({ email, password });
        if (!data.session) {
            const signup = await supabase.auth.signUp({
                email,
                password,
                options: { data: { phone: user.phone, full_name: user.fullName } }
            });
            data = signup.data;
            if (signup.error && !signup.error.message.toLowerCase().includes('already')) {
                console.warn('[SUPABASE AUTH] Could not create shadow session:', signup.error.message);
                return;
            }
            if (!data.session) {
                const retry = await supabase.auth.signInWithPassword({ email, password });
                data = retry.data;
            }
        }
        const supabaseUserId = data.user?.id;
        if (!supabaseUserId) return;
        const memberships = [
            ...(user.stores || []).map(store => ({ user_id: supabaseUserId, store_id: store.id, role: user.isAdmin ? 'owner' : 'staff' })),
            ...(storeId ? [{ user_id: supabaseUserId, store_id: storeId, role: 'staff' }] : [])
        ];
        if (memberships.length > 0) {
            await supabase.from('store_memberships').upsert(memberships, { onConflict: 'user_id,store_id' });
        }
    };

    const completeLogin = (user: User, sessionInfo: {isEmployee: boolean, storeId: string} | null, password?: string) => {
        void syncSupabaseAuth(user, password, sessionInfo?.storeId);
        setUsers(prev => {
            if (!prev.some(u => u.phone === user.phone)) {
                return [...prev, user];
            }
            return prev.map(u => u.phone === user.phone ? user : u);
        });

        if (sessionInfo?.isEmployee) {
            setCurrentUser(user);
            setIsEmployeeSession(true);
            setActiveStoreId(sessionInfo.storeId);
            localStorage.setItem('currentUserPhone', user.phone);
            localStorage.setItem('lastActiveStoreId', sessionInfo.storeId);
            localStorage.setItem('sessionType', 'employee');
            navigate('/employee/dashboard');
        } else {
            setCurrentUser(user);
            setIsEmployeeSession(false);
            localStorage.setItem('currentUserPhone', user.phone);
            
            if (user.isAdmin) {
                localStorage.setItem('sessionType', 'admin');
                setActiveStoreId(null);
                localStorage.removeItem('lastActiveStoreId');
                navigate('/admin/manage-stores?welcome=true');
            } else {
                localStorage.setItem('sessionType', 'owner');
                const targetStoreId = user.defaultStoreId || localStorage.getItem('defaultStoreId');
                
                // If user has a pinned/default store, launch directly into it:
                if (targetStoreId && user.stores?.some(s => s.id === targetStoreId)) {
                    handleSetActiveStore(targetStoreId);
                    navigate(`/store/${targetStoreId}/dashboard`);
                } else if (user.stores && user.stores.length === 1) {
                    handleSetActiveStore(user.stores[0].id);
                    navigate(`/store/${user.stores[0].id}/dashboard`);
                } else if (user.stores && user.stores.length > 0) {
                    // Navigate to the Store Management Hub
                    navigate('/manage-stores?welcome=true');
                } else {
                    setActiveStoreId(null); 
                    navigate('/create-store');
                }
            }
        }
    
        setUserForOtp(null);
        setSessionInfoForOtp(null);
        setOtpError('');
    };

    const handleSetActiveStore = async (storeId: string) => {
        setActiveStoreId(storeId);
        localStorage.setItem('lastActiveStoreId', storeId);
        setCart([]); 
        if (!allStoresData[storeId]) {
            const storeData = await db.getStoreData(storeId, dbSyncMode === 'auto') as StoreData | null;
            if (storeData) {
                const sanitizedStoreData = sanitizeData(storeData);
                setAllStoresData(prev => ({ ...prev, [storeId]: sanitizedStoreData }));
            }
        }
    };

    const handleEmployeeLogin = async ({ storeId, phone, password }: { storeId: string; phone: string; password: string }) => {
        let storeData = allStoresData[storeId];
        if (!storeData) {
            const data = await db.getStoreData(storeId, dbSyncMode === 'auto') as StoreData | null;
            if (data) {
                const sanitizedData = sanitizeData(data);
                setAllStoresData(prev => ({ ...prev, [storeId]: sanitizedData }));
                storeData = sanitizedData;
            } else {
                 throw new Error("كود المتجر غير صحيح أو لا يمكن تحميل بياناته.");
            }
        }
        
        const normalizePhoneForMatch = (p: string): string => {
            if (!p) return '';
            let clean = p.replace(/\D/g, '');
            if (clean.startsWith('20') && clean.length === 12) {
                clean = clean.substring(2);
            } else if (clean.startsWith('0020') && clean.length === 14) {
                clean = clean.substring(4);
            }
            return clean.replace(/^0+/, '');
        };

        const inputNormalized = normalizePhoneForMatch(phone);
        const employeeRecord = storeData.settings.employees.find(e => {
            const idNormalized = normalizePhoneForMatch(e.id);
            const phoneNormalized = e.phone ? normalizePhoneForMatch(e.phone) : '';
            return e.id === phone || 
                   idNormalized === inputNormalized || 
                   (phoneNormalized && phoneNormalized === inputNormalized);
        });

        let isOwnerSession = false;
        let recognizedOwnerUser: User | null = null;

        if (!employeeRecord) {
            // Check if user is the Owner of this store or Admin (تمييز المالك عن الموظف)
            const matchedUser = users.find(u => {
                const uPhoneNorm = normalizePhoneForMatch(u.phone);
                return u.phone === phone || uPhoneNorm === inputNormalized;
            });

            let candidateUser = matchedUser;
            if (!candidateUser) {
                try {
                    const dbCandidate = await db.getUserByPhone(phone);
                    if (dbCandidate) candidateUser = dbCandidate;
                } catch {
                    // Ignore DB lookup error
                }
            }

            if (candidateUser) {
                const ownsStore = Boolean(
                    candidateUser.isAdmin || 
                    candidateUser.defaultStoreId === storeId || 
                    candidateUser.ownedStoreIds?.includes(storeId) || 
                    candidateUser.stores?.some(s => s.id === storeId)
                );
                if (ownsStore) {
                    isOwnerSession = true;
                    recognizedOwnerUser = candidateUser;
                }
            }

            if (!isOwnerSession) {
                throw new Error("هذا الرقم غير مسجل كموظف في هذا المتجر. إذا كنت مالك المتجر، يرجى استخدام بوابة دخول المالك (بدون الحاجة لكود متجر).");
            }
        }

        if (employeeRecord && employeeRecord.status !== 'active') {
            const statusMap: Record<string, string> = { 'invited': 'في انتظار القبول', 'pending': 'معلق' };
            const statusText = statusMap[employeeRecord.status || ''] || employeeRecord.status;
            throw new Error(`حالة حسابك هي "${statusText}". يرجى التواصل مع مدير المتجر.`);
        }

        const authPhone = (isOwnerSession && recognizedOwnerUser ? recognizedOwnerUser.phone : (employeeRecord?.phone || employeeRecord?.id || phone)).trim();
        const firebaseEmail = `${authPhone}@mystore-auth.app`;
        console.log('[AUTH] Login attempt for phone:', authPhone, isOwnerSession ? '(Owner Mode)' : '(Employee Mode)');
        try {
             await signInWithEmailAndPassword(auth, firebaseEmail, password);
             console.log('[AUTH] Firebase Auth login successful for employee:', authPhone);
        } catch (err: any) {
             const isUserNotFoundOrInvalid = err?.code === 'auth/user-not-found' || 
                                            err?.code === 'auth/invalid-credential' || 
                                            err?.message?.includes('user-not-found') || 
                                            err?.message?.includes('invalid-credential');
             if (isUserNotFoundOrInvalid) {
                  console.log('[MIGRATION] Employee Auth failed. Checking Supabase for custom email or legacy account:', authPhone);
                  // Search ONLY in Supabase for user
                  const legacyUser = await db.getUserByPhoneFromSupabase(authPhone);
                  
                  if (legacyUser) {
                      // 1. Check if they have a CUSTOM email
                      if (legacyUser.email && legacyUser.email !== firebaseEmail) {
                          console.log('[AUTH] Found custom email for employee in Supabase, trying login with:', legacyUser.email);
                          try {
                              await signInWithEmailAndPassword(auth, legacyUser.email, password);
                              console.log('[AUTH] Firebase Auth custom email login successful for employee:', authPhone);
                              return; // Success
                          } catch (secondErr: any) {
                              console.log('[AUTH] Custom email login failed for employee:', secondErr.code);
                              // Continue to legacy check
                          }
                      }

                      console.log('[MIGRATION] Legacy user found in Supabase. Verifying old password...');
                      const storedPassword = legacyUser.password;
                      if (storedPassword === password) {
                          // Check if old password meets security length requirement (>= 6)
                          if (password.length < 6) {
                              console.warn('[MIGRATION] Weak password detected (<6 characters) during legacy employee login:', authPhone);
                              throw new Error("يجب إعادة تعيين كلمة المرور لأن كلمة المرور القديمة لا تستوفي متطلبات Firebase Authentication.");
                          }
                          
                          // Use real email if available, otherwise generated one
                          const emailToCreate = legacyUser.email || firebaseEmail;
                          
                          const migratedLegacyUser: User = {
                              ...legacyUser,
                              migrationStatus: 'migrated',
                              migratedAt: new Date().toISOString(),
                              legacyVerified: true
                          };

                          try {
                              console.log('[MIGRATION] Creating Firebase Auth account for legacy employee:', authPhone, 'using email:', emailToCreate);
                              await createUserWithEmailAndPassword(auth, emailToCreate, password);
                              console.log('[MIGRATION] Creating Firestore user doc for legacy employee:', authPhone);
                              await db.createUserDoc(migratedLegacyUser);
                          } catch (createErr: any) {
                              if (createErr.code === 'auth/email-already-in-use') {
                                  console.log('[MIGRATION] Firebase Auth account already exists for legacy employee, attempting sign-in...');
                                  try {
                                      // Try signing in with BOTH potential emails
                                      try {
                                          await signInWithEmailAndPassword(auth, emailToCreate, password);
                                      } catch (signInErr: any) {
                                          if (emailToCreate !== firebaseEmail) {
                                              await signInWithEmailAndPassword(auth, firebaseEmail, password);
                                          } else {
                                              throw signInErr;
                                          }
                                      }
                                      // If sign-in succeeds now, ensure Firestore doc exists
                                      console.log('[MIGRATION] Sign-in successful for existing account, checking Firestore doc...');
                                      const existingFsUser = await db.getUserByPhone(authPhone);
                                      if (!existingFsUser) {
                                          await db.createUserDoc(migratedLegacyUser);
                                      }
                                  } catch (signInErr: any) {
                                      if (signInErr.code === 'auth/invalid-credential' || signInErr.code === 'auth/wrong-password') {
                                          console.warn('[MIGRATION] Existing account found but password mismatch for legacy employee:', authPhone);
                                          throw new Error("رقم الهاتف أو كلمة المرور غير صحيحة.");
                                      }
                                      console.error('[MIGRATION] Sign-in failed after email-already-in-use:', signInErr);
                                      throw new Error("رقم الهاتف أو كلمة المرور غير صحيحة.");
                                  }
                              } else {
                                  console.error('[MIGRATION] On-the-fly signup failed for legacy employee:', createErr);
                                  if (createErr.code === 'auth/weak-password') {
                                      throw new Error("يجب إعادة تعيين كلمة المرور لأن كلمة المرور القديمة لا تستوفي متطلبات Firebase Authentication.");
                                  }
                                  throw new Error("رقم الهاتف أو كلمة المرور غير صحيحة.");
                              }
                          }
                      } else {
                          console.log('[MIGRATION] Legacy password mismatch for employee:', authPhone);
                          throw new Error("رقم الهاتف أو كلمة المرور غير صحيحة.");
                      }
                  } else {
                      console.log('[MIGRATION] Legacy user not found in Supabase for employee:', authPhone);
                      const fsUser = await db.getUserByPhone(authPhone);
                      if (fsUser && fsUser.password && (await verifyPasswordSecure(password, fsUser.password)).valid) {
                          console.log('[AUTH] Employee password verified from Firestore record:', authPhone);
                      } else {
                          throw new Error("رقم الهاتف أو كلمة المرور غير صحيحة.");
                      }
                  }
             } else {
                  if (err.code === 'auth/network-request-failed') {
                      throw new Error("فشل الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت.");
                  }
                  console.error('[AUTH] Employee login Firebase Auth failure:', err);
                  const fsUser = await db.getUserByPhone(authPhone);
                  if (fsUser && fsUser.password && (await verifyPasswordSecure(password, fsUser.password)).valid) {
                      console.log('[AUTH] Employee password verified from Firestore record (post-reset):', authPhone);
                  } else {
                      throw new Error("رقم الهاتف أو كلمة المرور غير صحيحة.");
                  }
             }
        }

        const targetUser = (isOwnerSession && recognizedOwnerUser) ? recognizedOwnerUser : await db.getUserByPhone(authPhone);
        if (!targetUser) {
            throw new Error(isOwnerSession ? "لم يتم العثور على بيانات المالك." : "لم يتم العثور على بيانات الموظف.");
        }

        if (isOwnerSession) {
            console.log('[AUTH] Owner recognized on portal. Starting full Owner session for:', targetUser.fullName);
            startOtpFlow(targetUser, null, password);
        } else {
            startOtpFlow(targetUser, { isEmployee: true, storeId: storeId }, password);
        }
    };

    const handleEmployeeRegisterRequest = async (data: EmployeeRegisterRequestData) => {
        const { fullName, phone, password, storeId, email } = data;
        
        let storeData = allStoresData[storeId];
        if (!storeData) {
            const data = await db.getStoreData(storeId, dbSyncMode === 'auto') as StoreData | null;
            if (data) {
                const sanitizedData = sanitizeData(data);
                setAllStoresData(prev => ({ ...prev, [storeId]: sanitizedData }));
                storeData = sanitizedData;
            } else {
                 throw new Error("لا يمكن تحميل بيانات المتجر.");
            }
        }
        if (storeData.settings.employees.some(e => e.id === phone)) {
            throw new Error("لديك بالفعل طلب انضمام معلق أو أنت موظف في هذا المتجر.");
        }

        const firebaseEmail = `${phone.trim()}@mystore-auth.app`;
        try {
            const userCred = await createUserWithEmailAndPassword(auth, firebaseEmail, password);
            if (!userCred.user) {
                throw new Error("فشل إنشاء حساب المصادقة.");
            }
        } catch (err: any) {
            if (err.code === 'auth/email-already-in-use') {
                throw new Error("هذا الرقم مسجل بالفعل في نظام المصادقة.");
            }
            throw new Error("حدث خطأ أثناء التسجيل.");
        }

        const newUser: User = { fullName, phone, email, joinDate: new Date().toISOString() };
        const success = await db.createUserDoc(newUser);
        if (!success) {
            throw new Error("فشل إنشاء حساب الموظف في قاعدة البيانات.");
        }
        setUsers(prev => [...prev, newUser]);

        const newEmployee: Employee = { id: phone, name: fullName, email, permissions: [], status: 'pending' };
        
        const updatedStoreData: StoreData = {
            ...storeData,
            settings: {
                ...storeData.settings,
                employees: [...storeData.settings.employees, newEmployee]
            }
        };

        setAllStoresData(p => ({
            ...p, 
            [storeId]: updatedStoreData
        }));

        await db.saveStoreData({
            id: storeId,
            name: (storeData.settings as any).storeName || storeId,
            specialization: '',
            language: 'ar',
            currency: 'EGP',
            url: '',
            creationDate: new Date().toISOString()
        }, updatedStoreData);
    };

    const handleStoreCreated = (newStore: Store, initialCustomization?: any, initialSettingsOverride?: any) => {
        if (!currentUser) return;

        const newStoreData: StoreData = {
            orders: [],
            settings: {
                ...INITIAL_SETTINGS,
                subdomain: newStore.subdomain,
                isSubdomainFixed: true,
                products: initialSettingsOverride?.products || oneToolzProducts,
                customization: initialCustomization ? {
                    ...INITIAL_SETTINGS.customization,
                    ...initialCustomization
                } : INITIAL_SETTINGS.customization,
                ...(initialSettingsOverride || {})
            },
            wallet: { balance: 0, transactions: [] },
            cart: [],
            customers: [],
        };
        
        const updatedUsers = users.map(user => {
            if (user.phone === currentUser.phone) {
                return { ...user, stores: [...(user.stores || []), newStore] };
            }
            return user;
        });

        setUsers(updatedUsers);
        setCurrentUser(prevUser => prevUser ? { ...prevUser, stores: [...(prevUser.stores || []), newStore] } : null);
        
        setAllStoresData(prevData => ({
            ...prevData,
            [newStore.id]: newStoreData
        }));
        
        handleSetActiveStore(newStore.id);

        // Persist to local & Firestore database immediately
        db.saveStoreData(newStore, newStoreData).catch(err => {
            console.warn('[NEW-STORE-SYNC] Failed to save new store to DB:', err);
        });
        db.saveGlobalData({ users: updatedUsers, loyaltyData: {} }).catch(console.warn);
    };

    const handleManualMigration = async () => {
        const result = await db.migrateAllLegacyDataToRelational(users);
        if (!result.success && result.error) {
            alert(`فشل النقل!\nالخطأ: ${result.error}\nالملخص: ${result.summary}`);
        } else {
            alert(`اكتمل النقل!\nالملخص: ${result.summary}`);
        }
        return { success: result.success, error: result.error };
    };

    const handleImpersonate = (userToImpersonate: User) => {
        console.log(`Impersonating user: ${userToImpersonate.fullName}`);
        completeLogin(userToImpersonate, null); 
    };

    const refreshStoreData = (storeId: string): Promise<void> => {
        if (isSavingRef.current || isDirtyRef.current) {
            console.log(`[REALTIME] Ignoring refresh to prevent flicker during active save or pending changes.`);
            return Promise.resolve();
        }

        if (!storeId || storeId !== activeStoreId) {
            if (storeId !== activeStoreId) console.log(`[REALTIME] Ignoring refresh for non-active store: ${storeId}`);
            return Promise.resolve();
        }

        if (refreshDebounceTimers.current[storeId]) {
            clearTimeout(refreshDebounceTimers.current[storeId]!);
        }

        return new Promise((resolve) => {
            refreshDebounceTimers.current[storeId] = setTimeout(async () => {
                console.log(`[REALTIME] Debounced refresh executing for store: ${storeId}`);
                const storeData = await db.getStoreData(storeId, true) as StoreData | null;
                if (storeData) {
                    const sanitizedStoreData = sanitizeData(storeData);
                    
                    setAllStoresData(prev => {
                        const isIdentical = JSON.stringify(prev[storeId]) === JSON.stringify(sanitizedStoreData);
                        if (isIdentical) {
                            resolve();
                            return prev;
                        }
                        
                        isRefreshing.current = true;
                        return { ...prev, [storeId]: sanitizedStoreData };
                    });
                    console.log(`[REALTIME] Store ${storeId} data updated via debounce.`);
                }
                refreshDebounceTimers.current[storeId] = null;
                resolve();
            }, 500);
        });
    };

    const refreshGlobalData = () => {
        if (isSavingRef.current || isDirtyRef.current) {
            console.log(`[REALTIME] Ignoring global refresh to prevent flicker during active save or pending changes.`);
            return;
        }
        const key = 'global';
        if (refreshDebounceTimers.current[key]) {
            clearTimeout(refreshDebounceTimers.current[key]!);
        }
        refreshDebounceTimers.current[key] = setTimeout(async () => {
            console.log('[REALTIME] Debounced global refresh executing.');
            const globalData = await db.getGlobalData(true);
            if (globalData?.users) {
                isRefreshing.current = true;
                setUsers(globalData.users);
                setCurrentUser(prevUser => {
                    if (!prevUser) return null;
                    const updatedCurrentUser = globalData.users.find(u => u.phone === prevUser.phone);
                    return updatedCurrentUser || prevUser;
                });
                console.log('[REALTIME] Global user data updated via debounce.');
            }
            refreshDebounceTimers.current[key] = null;
        }, 1500);
    };

    useEffect(() => {
        if (dbSyncMode === 'manual') {
            console.log('[REALTIME] Manual desktop database mode active: Live cloud listeners and background intervals are paused.');
            return () => {};
        }

        if (db.isSupabaseActive()) {
            const supabase = getSupabaseClient();
            if (!supabase || !activeStoreId) {
                return () => {};
            }

            console.log('[REALTIME] Custom Supabase cloud active: subscribing to live orders updates.');
            refreshStoreDataRef.current = refreshStoreData;
            activeStoreRef.current = activeStore;
            allStoresDataRef.current = allStoresData;

            const notifyWhatsAppMessage = (message: any) => {
                if (message.direction !== 'incoming') return;
                const messageKey = String(message.provider_message_id || message.id || '');
                if (!messageKey || notifiedWhatsAppMessagesRef.current.has(messageKey)) return;
                notifiedWhatsAppMessagesRef.current.add(messageKey);
                if (notifiedWhatsAppMessagesRef.current.size > 250) {
                    const oldest = notifiedWhatsAppMessagesRef.current.values().next().value;
                    if (oldest) notifiedWhatsAppMessagesRef.current.delete(oldest);
                }
                const action = message.metadata?.action;
                const title = action === 'confirm' ? 'تأكيد طلب جديد عبر واتساب' : action === 'cancel' ? 'إلغاء طلب عبر واتساب' : 'رسالة جديدة من عميل';
                const body = message.body || 'وصلت رسالة جديدة من العميل.';
                audioSynth.playTone(action === 'confirm' ? 'success' : action === 'cancel' ? 'warning' : 'info');
                if ('Notification' in window) {
                    if (Notification.permission === 'granted') {
                        new Notification(title, { body, tag: `whatsapp-${message.id}` });
                    } else if (Notification.permission === 'default') {
                        void Notification.requestPermission().then(permission => {
                            if (permission === 'granted') new Notification(title, { body, tag: `whatsapp-${message.id}` });
                        });
                    }
                }
            };

            const messagesChannel = supabase
                .channel(`whatsapp-inbox-realtime-${activeStoreId}`)
                .on('postgres_changes', {
                    event: 'INSERT',
                    schema: 'public',
                    table: 'whatsapp_messages',
                    filter: `store_id=eq.${activeStoreId}`
                }, (payload: any) => {
                    if (isSavingRef.current || isDirtyRef.current) return;
                    console.log('[REALTIME] WhatsApp message received:', payload.new?.id);
                    notifyWhatsAppMessage(payload.new);
                })
                .subscribe((status: string) => console.log(`[REALTIME] WhatsApp messages channel status: ${status}`));

            const channel = supabase
                .channel(`orders-realtime-${activeStoreId}`)
                .on(
                    'postgres_changes',
                    {
                        event: '*',
                        schema: 'public',
                        table: 'orders',
                        filter: `store_id=eq.${activeStoreId}`
                    },
                    (payload: any) => {
                        if (isSavingRef.current || isDirtyRef.current) return;

                        const eventType = payload.eventType;
                        const incoming = eventType === 'DELETE' ? payload.old : payload.new;
                        if (!incoming?.id) return;

                        console.log(`[REALTIME] Supabase orders change received: ${eventType}`, incoming.id);
                        isRefreshing.current = true;
                        setAllStoresData(prev => {
                            const store = prev[activeStoreId];
                            if (!store) return prev;
                            const currentOrders = store.orders || [];

                            if (eventType === 'DELETE') {
                                return {
                                    ...prev,
                                    [activeStoreId]: {
                                        ...store,
                                        orders: currentOrders.filter((order: any) => order.id !== incoming.id)
                                    }
                                };
                            }

                            const existingIndex = currentOrders.findIndex((order: any) => order.id === incoming.id);
                            const nextOrder = {
                                ...(existingIndex >= 0 ? currentOrders[existingIndex] : {}),
                                ...incoming,
                                whatsappLogs: incoming.whatsappLogs || incoming.whatsapp_logs || (existingIndex >= 0 ? (currentOrders[existingIndex] as any).whatsappLogs : []),
                                whatsapp_logs: incoming.whatsapp_logs || incoming.whatsappLogs || (existingIndex >= 0 ? (currentOrders[existingIndex] as any).whatsapp_logs : []),
                                updatedAt: incoming.updatedAt || incoming.updated_at,
                                updated_at: incoming.updated_at || incoming.updatedAt,
                                items: Array.isArray(incoming.items)
                                    ? incoming.items
                                    : (existingIndex >= 0 ? currentOrders[existingIndex].items || [] : [])
                            };
                            const nextOrders = [...currentOrders];
                            if (existingIndex >= 0) nextOrders[existingIndex] = nextOrder;
                            else nextOrders.unshift(nextOrder);

                            return {
                                ...prev,
                                [activeStoreId]: { ...store, orders: nextOrders }
                            };
                        });
                    }
                )
                .subscribe((status: string) => {
                    console.log(`[REALTIME] Supabase orders channel status: ${status}`);
                });

            // Custody and treasury must follow the same Supabase source as orders.
            // Refresh the normalized store snapshot after any financial change so
            // holders, handovers, and treasury balances cannot drift between tabs.
            const financeChannel = supabase
                .channel(`finance-realtime-${activeStoreId}`);
            let financeRefreshTimer: ReturnType<typeof setTimeout> | null = null;
            let financeRefreshInFlight = false;
            const refreshFinanceOnly = () => {
                if (financeRefreshTimer) clearTimeout(financeRefreshTimer);
                financeRefreshTimer = setTimeout(async () => {
                    if (financeRefreshInFlight) return;
                    financeRefreshInFlight = true;
                    try {
                        const [holdersResult, handoversResult, accountsResult, treasuryTxResult] = await Promise.all([
                            supabase.from('cash_holders').select('*').eq('store_id', activeStoreId),
                            supabase.from('cash_handovers').select('*').eq('store_id', activeStoreId),
                            supabase.from('treasury_accounts').select('*').eq('store_id', activeStoreId),
                            supabase.from('treasury_transactions').select('*').eq('store_id', activeStoreId)
                        ]);
                        if (holdersResult.error || handoversResult.error || accountsResult.error || treasuryTxResult.error) return;
                        const cashHolders = (holdersResult.data || []).map((h: any) => ({
                            ...h,
                            userId: h.userId || h.user_id || '',
                            userName: h.userName || h.user_name || '',
                            currentBalance: Number(h.currentBalance ?? h.current_balance ?? 0),
                            lastUpdated: h.lastUpdated || h.last_updated || ''
                        }));
                        const cashHandovers = (handoversResult.data || []).map((h: any) => ({
                            ...h,
                            fromUserId: h.fromUserId || h.from_user_id || '',
                            fromUserName: h.fromUserName || h.from_user_name || '',
                            toUserId: h.toUserId || h.to_user_id || '',
                            toUserName: h.toUserName || h.to_user_name || '',
                            amount: Number(h.amount ?? 0),
                            orderNumber: h.orderNumber || h.order_number || '',
                            isVirtual: Boolean(h.isVirtual ?? h.is_virtual ?? false)
                        }));
                        const treasury = {
                            accounts: (accountsResult.data || []).map((a: any) => ({ ...a, balance: Number(a.balance ?? 0), accountNumber: a.accountNumber || a.account_number || '', beneficiaryName: a.beneficiaryName || a.beneficiary_name || '', bankName: a.bankName || a.bank_name || '', walletNumber: a.walletNumber || a.wallet_number || '', walletName: a.walletName || a.wallet_name || '' })),
                            transactions: (treasuryTxResult.data || []).map((tx: any) => ({ ...tx, fromAccountId: tx.fromAccountId || tx.from_account_id || '', toAccountId: tx.toAccountId || tx.to_account_id || '', amount: Number(tx.amount ?? 0) }))
                        };
                        isRefreshing.current = true;
                        setAllStoresData(prev => {
                            const store = prev[activeStoreId];
                            if (!store) return prev;
                            return { ...prev, [activeStoreId]: { ...store, settings: { ...store.settings, cashHolders, cashHandovers }, treasury } };
                        });
                    } finally {
                        financeRefreshInFlight = false;
                        financeRefreshTimer = null;
                    }
                }, 500);
            };
            ['cash_holders', 'cash_handovers', 'treasury_accounts', 'treasury_transactions'].forEach((table) => {
                financeChannel.on('postgres_changes', {
                    event: '*',
                    schema: 'public',
                    table,
                    filter: `store_id=eq.${activeStoreId}`
                }, (payload: any) => {
                    if (isSavingRef.current || isDirtyRef.current) return;
                    const changedId = payload.new?.id || payload.old?.id || payload.new?.user_id || payload.old?.user_id;
                    console.log(`[REALTIME] Supabase ${table} change received: ${payload.eventType}`, changedId || 'unknown');
                    refreshFinanceOnly();
                });
            });
            financeChannel.subscribe((status: string) => {
                console.log(`[REALTIME] Supabase finance channel status: ${status}`);
            });

            return () => {
                console.log('[REALTIME] Removing Supabase orders subscription.');
                void supabase.removeChannel(channel);
                void supabase.removeChannel(messagesChannel);
                void supabase.removeChannel(financeChannel);
                if (financeRefreshTimer) clearTimeout(financeRefreshTimer);
            };
        }

        console.log('[REALTIME] Setting up Firestore snapshots...');
        
        // Update refs with current values
        refreshStoreDataRef.current = refreshStoreData;
        refreshGlobalDataRef.current = refreshGlobalData;
        activeStoreRef.current = activeStore;
        allStoresDataRef.current = allStoresData;
        
        const unsubscribers: (() => void)[] = [];

        const handleRealtimeError = (err: any, label: string) => {
            const msg = String(err?.message || err);
            if (msg.includes('quota') || msg.includes('resource-exhausted') || (err as any)?.code === 'resource-exhausted') {
                console.warn(`[REALTIME] Firestore quota reached on ${label}. Using local/offline cache mode seamlessly.`);
            } else {
                console.warn(`[REALTIME] Notice on ${label}:`, msg);
            }
        };

        if (activeStoreId) {
            // Listen for changes on store configuration
            const unsubStore = onSnapshot(doc(firebaseDb, 'stores_data', activeStoreId), (snap) => {
                if (snap.exists() && !isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    const snapData = snap.data() as any;
                    console.log('[REALTIME] Store settings change detected via Firestore snapshot');
                    isRefreshing.current = true;
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        // Only update name and settings from the store document
                        return {
                            ...prev,
                            [activeStoreId]: {
                                ...store,
                                name: snapData.name || store.name,
                                settings: {
                                    ...store.settings,
                                    ...(snapData.settings || {})
                                }
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'stores_data'));
            unsubscribers.push(unsubStore);

            // Listen for changes on orders
            const qOrders = query(collection(firebaseDb, 'orders'), where('storeId', '==', activeStoreId));
            const unsubOrders = onSnapshot(qOrders, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    console.log('[REALTIME] Orders change detected via Firestore snapshot');
                    isRefreshing.current = true;
                    const newOrders = snap.docs.map(doc => {
                        const data = doc.data();
                        const docItems = Array.isArray(data.items) ? data.items : (data.items && typeof data.items === 'object' ? Object.values(data.items) : []);
                        return { 
                            id: doc.id.startsWith(activeStoreId + '_') ? doc.id.substring(activeStoreId.length + 1) : doc.id, 
                            ...data,
                            items: docItems
                        } as Order;
                    });

                    // 🔔 Web Notifications & Manager Alert for incoming new pending orders
                    if (!hasInitialOrdersLoadedRef.current) {
                        knownOrderIdsRef.current = new Set(newOrders.map(o => o.id));
                        hasInitialOrdersLoadedRef.current = true;
                    } else {
                        newOrders.forEach(order => {
                            if (!knownOrderIdsRef.current.has(order.id)) {
                                knownOrderIdsRef.current.add(order.id);
                                if (isPendingOrderStatus(order.status)) {
                                    console.log('🔔 [WEB NOTIFICATION] Incoming pending order detected:', order.id);
                                    showOrderWebNotification(order, {
                                        storeName: activeStoreRef.current?.name || 'متجري'
                                    });
                                }
                            }
                        });
                    }

                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: { ...store, orders: newOrders }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'orders'));
            unsubscribers.push(unsubOrders);

            // Listen for changes on products
            const qProducts = query(collection(firebaseDb, 'products'), where('storeId', '==', activeStoreId));
            const unsubProducts = onSnapshot(qProducts, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    console.log('[REALTIME] Products change detected via Firestore snapshot');
                    isRefreshing.current = true;
                    const newProducts = snap.docs.map(doc => ({ 
                        id: doc.id.startsWith(activeStoreId + '_') ? doc.id.substring(activeStoreId.length + 1) : doc.id, 
                        ...doc.data() 
                    } as Product));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: { 
                                ...store, 
                                settings: { ...store.settings, products: newProducts } 
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'products'));
            unsubscribers.push(unsubProducts);

            // Listen for changes on employees
            const qEmployees = query(collection(firebaseDb, 'employees'), where('storeId', '==', activeStoreId));
            const unsubEmployees = onSnapshot(qEmployees, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    console.log('[REALTIME] Employees change detected via Firestore snapshot');
                    isRefreshing.current = true;
                    const newEmployees = snap.docs.map(doc => {
                        const data = doc.data() || {};
                        const phone = doc.id.split('_').pop() || '';
                        const emp: Employee = {
                            id: data.id || phone,
                            name: data.name || '',
                            email: data.email || '',
                            phone: data.phone || phone,
                            permissions: data.permissions || [],
                            status: data.status || 'active'
                        };
                        return emp;
                    });
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: { 
                                ...store, 
                                settings: { ...store.settings, employees: newEmployees } 
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'employees'));
            unsubscribers.push(unsubEmployees);
            
            // Listen for changes on purchase returns
            const qPurchaseReturns = query(collection(firebaseDb, 'purchase_returns'), where('storeId', '==', activeStoreId));
            const unsubPurchaseReturns = onSnapshot(qPurchaseReturns, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    console.log('[REALTIME] Purchase Returns change detected via Firestore snapshot');
                    isRefreshing.current = true;
                    const newPurchaseReturns = snap.docs.map(doc => ({ 
                        id: doc.id.split('_').pop() || doc.id, 
                        ...doc.data() 
                    } as PurchaseReturn));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        // Avoid updating if data is identical to prevent loops
                        if (JSON.stringify(store.settings.purchaseReturns) === JSON.stringify(newPurchaseReturns)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: { 
                                ...store, 
                                settings: { ...store.settings, purchaseReturns: newPurchaseReturns } 
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'purchase_returns'));
            unsubscribers.push(unsubPurchaseReturns);

            // Listen for changes on order returns
            const qOrderReturns = query(collection(firebaseDb, 'order_returns'), where('storeId', '==', activeStoreId));
            const unsubOrderReturns = onSnapshot(qOrderReturns, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    isRefreshing.current = true;
                    const newOrderReturns = snap.docs.map(doc => ({ 
                        id: doc.id.split('_').pop() || doc.id, 
                        ...doc.data() 
                    } as OrderReturn));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        if (JSON.stringify(store.settings.orderReturns) === JSON.stringify(newOrderReturns)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: { 
                                ...store, 
                                settings: { ...store.settings, orderReturns: newOrderReturns } 
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'order_returns'));
            unsubscribers.push(unsubOrderReturns);

            // Listen for changes on cash holders (Custody balances)
            const qCashHolders = query(collection(firebaseDb, 'cash_holders'), where('storeId', '==', activeStoreId));
            const unsubCashHolders = onSnapshot(qCashHolders, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    isRefreshing.current = true;
                    const newCashHolders = snap.docs.map(doc => {
                        const data = doc.data();
                        return { 
                            ...data,
                            userId: data.userId || data.user_id || doc.id.split('_').pop() || doc.id,
                        } as any;
                    });
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        if (JSON.stringify(store.settings.cashHolders) === JSON.stringify(newCashHolders)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: { 
                                ...store, 
                                settings: { ...store.settings, cashHolders: newCashHolders } 
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'cash_holders'));
            unsubscribers.push(unsubCashHolders);

            // Listen for changes on treasury accounts
            const qTreasuryAccounts = query(collection(firebaseDb, 'treasury_accounts'), where('storeId', '==', activeStoreId));
            const unsubTreasuryAccounts = onSnapshot(qTreasuryAccounts, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    isRefreshing.current = true;
                    const newAccounts = snap.docs.map(doc => ({
                        id: doc.id.startsWith(activeStoreId + '_') ? doc.id.substring(activeStoreId.length + 1) : doc.id,
                        ...doc.data()
                    } as TreasuryAccount));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        const currentAccounts = store.treasury?.accounts || [];
                        if (JSON.stringify(currentAccounts) === JSON.stringify(newAccounts)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: {
                                ...store,
                                treasury: { ...(store.treasury || { accounts: [], transactions: [] }), accounts: newAccounts }
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'treasury_accounts'));
            unsubscribers.push(unsubTreasuryAccounts);

            // Listen for changes on treasury transactions
            const qTreasuryTx = query(collection(firebaseDb, 'treasury_transactions'), where('storeId', '==', activeStoreId));
            const unsubTreasuryTx = onSnapshot(qTreasuryTx, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    isRefreshing.current = true;
                    const newTxs = snap.docs.map(doc => ({
                        id: doc.id.startsWith(activeStoreId + '_') ? doc.id.substring(activeStoreId.length + 1) : doc.id,
                        ...doc.data()
                    } as TreasuryTransaction));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        const currentTxs = store.treasury?.transactions || [];
                        if (JSON.stringify(currentTxs) === JSON.stringify(newTxs)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: {
                                ...store,
                                treasury: { ...(store.treasury || { accounts: [], transactions: [] }), transactions: newTxs }
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'treasury_transactions'));
            unsubscribers.push(unsubTreasuryTx);

            // Listen for changes on partners
            const qPartners = query(collection(firebaseDb, 'partners'), where('storeId', '==', activeStoreId));
            const unsubPartners = onSnapshot(qPartners, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    isRefreshing.current = true;
                    const newPartners = snap.docs.map(doc => ({
                        id: doc.id.startsWith(activeStoreId + '_') ? doc.id.substring(activeStoreId.length + 1) : doc.id,
                        ...doc.data()
                    } as Partner));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        if (JSON.stringify(store.settings?.partners) === JSON.stringify(newPartners)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: {
                                ...store,
                                settings: { ...store.settings, partners: newPartners }
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'partners'));
            unsubscribers.push(unsubPartners);

            // Listen for changes on partner transactions
            const qPartnerTx = query(collection(firebaseDb, 'partner_transactions'), where('storeId', '==', activeStoreId));
            const unsubPartnerTx = onSnapshot(qPartnerTx, (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    isRefreshing.current = true;
                    const newPartnerTxs = snap.docs.map(doc => ({
                        id: doc.id.startsWith(activeStoreId + '_') ? doc.id.substring(activeStoreId.length + 1) : doc.id,
                        ...doc.data()
                    } as PartnerTransaction));
                    setAllStoresData(prev => {
                        const store = prev[activeStoreId];
                        if (!store) return prev;
                        if (JSON.stringify(store.settings?.partnerTransactions) === JSON.stringify(newPartnerTxs)) return prev;
                        return {
                            ...prev,
                            [activeStoreId]: {
                                ...store,
                                settings: { ...store.settings, partnerTransactions: newPartnerTxs }
                            }
                        };
                    });
                }
            }, (err) => handleRealtimeError(err, 'partner_transactions'));
            unsubscribers.push(unsubPartnerTx);
        }

        // Listen for user collections change (Admin only)
        let unsubUsers = () => {};
        if (currentUser?.isAdmin) {
            unsubUsers = onSnapshot(collection(firebaseDb, 'users'), (snap) => {
                if (!isSavingRef.current && !isDirtyRef.current && !snap.metadata.hasPendingWrites) {
                    console.log('[REALTIME] Users collection change detected via Firestore snapshot');
                    isRefreshing.current = true;
                    const updatedUsers = snap.docs.map(doc => {
                        const data = doc.data();
                        return {
                            fullName: data.fullName || '',
                            phone: doc.id,
                            password: data.password || '',
                            email: data.email || '',
                            stores: data.stores || [],
                            sites: data.sites || [],
                            isAdmin: data.isAdmin || false,
                            isBanned: data.isBanned || false,
                            joinDate: data.joinDate || ''
                        } as User;
                    });
                    setUsers(updatedUsers);
                }
            }, (err) => handleRealtimeError(err, 'users'));
            unsubscribers.push(unsubUsers);
        }

        // No redundant polling - onSnapshot handles real-time updates efficiently.
        // Background Auto-Sync for Platforms (Wuilt, etc.)
        const autoSyncInterval = setInterval(async () => {
            if (activeStoreId && !isSavingRef.current && activeStoreRef.current) {
                const connectedPlatforms = allStoresDataRef.current[activeStoreId]?.settings?.connectedPlatforms || [];
                const platformConfigs = (allStoresDataRef.current[activeStoreId]?.settings as any)?.platformConfigs || {};

                for (const platformId of connectedPlatforms) {
                    const config = platformConfigs[platformId];
                    if (config?.isActive) {
                        console.log(`[AUTO-SYNC] Triggering background sync for ${platformId}...`);
                        try {
                            isRefreshing.current = true;
                            
                            const response = await fetch(`/api/sync/platform/${platformId}/${activeStoreId}?type=orders`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' }
                            });
                            
                            if (response.ok) {
                                console.log(`[AUTO-SYNC] Successfully synced orders for ${platformId}`);
                                await refreshStoreDataRef.current(activeStoreId);
                            } else {
                                isRefreshing.current = false;
                            }
                        } catch (err) {
                            console.error(`[AUTO-SYNC] Failed to sync ${platformId}:`, err);
                            isRefreshing.current = false;
                        }
                    }
                }
            }
        }, 120000); // Every 2 minutes

        return () => {
            console.log('[REALTIME] Unsubscribing Firestore listeners and background intervals.');
            unsubscribers.forEach(unsub => unsub());
            clearInterval(autoSyncInterval);
        };
    }, [activeStoreId, dbSyncMode]); 

    // 🔔 Global Manager Alert Actions Listener (Web Notification Click & Status Updates)
    useEffect(() => {
        const handleNavToOrder = (e: Event) => {
            const { orderId } = (e as CustomEvent)?.detail || {};
            if (orderId) {
                if (activeStoreId) {
                    navigate(`/store/${activeStoreId}/orders?search=${encodeURIComponent(orderId)}`);
                } else if (isEmployeeSession) {
                    navigate('/employee/confirmation-queue');
                }
            }
        };

        const handleStatusUpdateEvent = (e: Event) => {
            const { orderId, status } = (e as CustomEvent)?.detail || {};
            if (orderId && status && activeStoreId) {
                setAllStoresData(p => {
                    const currentOrders = p[activeStoreId]?.orders || [];
                    return {
                        ...p,
                        [activeStoreId]: {
                            ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                            orders: currentOrders.map(o => o.id === orderId ? { ...o, status } : o)
                        }
                    };
                });
            }
        };

        window.addEventListener('NAVIGATE_TO_ORDER', handleNavToOrder);
        window.addEventListener('UPDATE_ORDER_STATUS_EVENT', handleStatusUpdateEvent);
        return () => {
            window.removeEventListener('NAVIGATE_TO_ORDER', handleNavToOrder);
            window.removeEventListener('UPDATE_ORDER_STATUS_EVENT', handleStatusUpdateEvent);
        };
    }, [activeStoreId, isEmployeeSession, navigate]);

    if (!authChecked) {
        return <GlobalLoader message="جاري التحقق من أمان الجلسة والربط السحابي..." />;
    }

    if (userForOtp) {
        return <OtpVerificationPage 
            user={userForOtp} 
            onVerifyAttempt={handleOtpVerification}
            onCancel={handleOtpCancel}
            error={otpError}
            targetEmail={otpTargetEmail}
        />;
    }
    
    const forceSync = async (customStoreData?: any, customUsers?: any) => {
        if (debounceTimer.current) clearTimeout(debounceTimer.current);
        setSaveStatus('saving');
        setSaveMessage('جاري الحفظ والمزامنة...');
        try {
            isSavingRef.current = true;
            
            if (activeStoreId && customStoreData) {
                setAllStoresData(p => ({
                    ...p,
                    [activeStoreId]: customStoreData
                }));
            }

            // 1. Sync custom domains up to users
            let updatedUsers = customUsers || [...users];
            const storeDataToSync = customStoreData || allStoresDataRef.current?.[activeStoreId!] || allStoresData[activeStoreId!];
            if (activeStoreId && storeDataToSync) {
                const storeSettings = storeDataToSync.settings;
                updatedUsers = updatedUsers.map(user => {
                    if (user.stores) {
                        return {
                            ...user,
                            stores: user.stores.map(store => {
                                if (store.id === activeStoreId) {
                                    return {
                                        ...store,
                                        customDomain: storeSettings.customDomain,
                                        subdomain: storeSettings.subdomain
                                    };
                                }
                                return store;
                            })
                        }
                    }
                    return user;
                });
                
                // Update users state if it's different
                if (JSON.stringify(users) !== JSON.stringify(updatedUsers)) {
                    setUsers(updatedUsers);
                }
            }
            
            // 2. Local backup (Instant)
            await db.saveLocal('global', { users: updatedUsers, loyaltyData: {} });
            if (activeStoreId && storeDataToSync) {
                await db.saveLocal(activeStoreId, storeDataToSync);
            }

            // 3. Cloud sync (Parallel with Timeout)
            const syncPromises = [];
            syncPromises.push(db.saveGlobalData({ users: updatedUsers, loyaltyData: {} }));
            if (activeStoreId && storeDataToSync && activeStore) {
                // Must pass updated version of store!
                const updatedStore = updatedUsers.find(u => u.stores?.some(s => s.id === activeStoreId))?.stores?.find(s => s.id === activeStoreId) || activeStore;
                syncPromises.push(db.saveStoreData(updatedStore, storeDataToSync));
            }

            const results = await Promise.all(syncPromises);
            const failed = results.find(r => !r.success);
            
            if (failed) {
                console.warn('[MANUAL-SYNC] Cloud failed, but data saved locally:', failed.error);
                setSaveStatus('local_saved');
                setSaveMessage('تم الحفظ محلياً (فشل المزامنة السحابية)');
                return;
            }

            setSaveStatus('success');
            setSaveMessage('تم الحفظ والمزامنة بنجاح!');
            setTimeout(() => setSaveStatus(prev => prev === 'success' ? 'idle' : prev), 3000);
        } catch (e: any) {
            console.error('[MANUAL-SAVE] Save failed:', e);
            // Even if everything fails, we likely have it in fastLocalSave already, 
            // but let's at least show local_saved if we think we got it.
            setSaveStatus('local_saved');
            setSaveMessage('محفوظ على هذا الجهاز (خطأ سحابي)');
        } finally {
            isSavingRef.current = false;
        }
    };

    const forcePullFromCloud = async () => {
        if (!activeStoreId || !activeStore) {
            return { success: false, error: 'لم يتم اختيار متجر نشط' };
        }
        setSaveStatus('saving');
        setSaveMessage('جاري سحب البيانات كلياً من السحاب للمحلي...');
        try {
            isSavingRef.current = true;
            // Force pull remote data directly from Firestore bypassing local cache
            const remoteData = await db.getStoreData(activeStoreId, true);
            if (remoteData) {
                setAllStoresData(prev => ({
                    ...prev,
                    [activeStoreId]: remoteData
                }));
                // Save immediately to IndexedDB
                await db.saveLocal(activeStoreId, remoteData);
                
                setSaveStatus('success');
                setSaveMessage('تم سحب وتزامن البيانات المحلية بنجاح!');
                setTimeout(() => setSaveStatus('idle'), 3000);
                return { success: true };
            } else {
                throw new Error('فشل استيراد البيانات: لم يتم العثور على أي سجلات في السحابة لهذا المتجر');
            }
        } catch (e: any) {
            console.error('[CLOUD-PULL] cloud pull failed:', e);
            setSaveStatus('error');
            setSaveMessage('فشل سحب البيانات: ' + (e.message || String(e)));
            setTimeout(() => setSaveStatus('idle'), 4000);
            return { success: false, error: e.message || String(e) };
        } finally {
            isSavingRef.current = false;
        }
    };

    const pageProps = {
        users, setUsers, allStoresData, setAllStoresData, currentUser, activeStore, activeStoreId,
        orders: activeStoreId ? allStoresData[activeStoreId]?.orders || [] : [],
        products: activeStoreId ? allStoresData[activeStoreId]?.settings?.products || [] : [],
        settings: (() => {
            const rawSettings = activeStoreId ? allStoresData[activeStoreId]?.settings || INITIAL_SETTINGS : INITIAL_SETTINGS;
            
            // Deep merge essential configs from INITIAL_SETTINGS if missing
            let finalSettings = { 
                ...rawSettings,
                whatsappConfig: {
                    ...INITIAL_SETTINGS.whatsappConfig,
                    ...(rawSettings.whatsappConfig || {})
                },
                whatsappTemplates: rawSettings.whatsappTemplates || INITIAL_SETTINGS.whatsappTemplates,
                callScripts: rawSettings.callScripts || INITIAL_SETTINGS.callScripts,
                employeeDashboardSettings: {
                    ...INITIAL_SETTINGS.employeeDashboardSettings,
                    ...(rawSettings.employeeDashboardSettings || {})
                }
            };
            
            return finalSettings;
        })(),
        wallet: (() => {
            const rawWallet = activeStoreId ? allStoresData[activeStoreId]?.wallet || { balance: 0, transactions: [] } : { balance: 0, transactions: [] };
            const rawTreasury = activeStoreId ? allStoresData[activeStoreId]?.treasury || { accounts: [], transactions: [] } : { accounts: [], transactions: [] };
            const txs = rawWallet.transactions || [];
            const liveBalance = txs.length > 0 ? txs.reduce((sum: number, t: any) => {
                const amount = Number(t.amount) || 0;
                if (t.category === 'supply_purchase' || t.category === 'supply_deposit' || t.category?.startsWith('supply_expense_')) return sum;
                if ((t.details?.paidByPartnerId || t.details?.expensePaidBy || t.note?.includes('دفعهم') || t.note?.includes('شريك')) && !t.note?.includes('المحفظة المركزية')) return sum;
                if (t.type === 'إيداع') {
                    if (t.status === 'cancelled') return sum;
                    if (t.status === 'pending' && (t.category === 'wallet_charge' || t.category === 'charge')) return sum;
                    return sum + amount;
                }
                if (t.type === 'سحب') {
                    if (t.details?.treasuryAccountId && t.details.treasuryAccountId !== 'main_wallet') return sum;
                    return t.status === 'cancelled' ? sum : sum - amount;
                }
                if (t.type === 'تحويل') {
                    if (t.category === 'treasury_sync') {
                        const treasuryTxId = t.id.replace('TR-', '');
                        const tTx = rawTreasury.transactions?.find((x: any) => x.id === treasuryTxId);
                        if (tTx) {
                            if (tTx.toAccountId === 'main_wallet') return sum + amount;
                            if (tTx.fromAccountId === 'main_wallet') return sum - amount;
                        } else if (t.note?.includes('إنستاباي') || t.note?.includes('بنك') || t.note?.includes('إيداع') || t.note?.includes('تحويل')) {
                            return sum + amount;
                        }
                    }
                    return sum;
                }
                return sum;
            }, 0) : (Number(rawWallet.balance) || 0);
            return {
                ...rawWallet,
                balance: liveBalance
            };
        })(),
        treasury: activeStoreId ? allStoresData[activeStoreId]?.treasury || { accounts: [{ id: '1', name: 'الخزينة الرئيسية', type: 'safe', balance: 0, currency: 'EGP' }, { id: '2', name: 'فودافون كاش', type: 'wallet', balance: 0, currency: 'EGP' }, { id: '3', name: 'الحساب البنكي', type: 'bank', balance: 0, currency: 'EGP' }], transactions: [] } : undefined,
        cart,
        forceSync,
        forcePullFromCloud,
        dbSyncMode,
        setDbSyncMode,
        saveStatus,
        saveMessage,
        onRefresh: async () => { if (activeStoreId) await refreshStoreData(activeStoreId); },
        customers: enrichedCustomers,
        setCustomers: (updater: any) => {
            if(activeStoreId) {
                setAllStoresData(p => {
                    const currentCustomers = p[activeStoreId]?.customers || [];
                    const newCustomers = typeof updater === 'function' ? updater(currentCustomers) : updater;
                    
                    if (currentCustomers === newCustomers) return p;

                    return {
                        ...p, 
                        [activeStoreId]: {
                            ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                            customers: newCustomers
                        }
                    };
                });
            }
        },
        onUpdateCustomer: (phone: string, updates: Partial<CustomerProfile>) => {
          const normalizedPhone = normalizePhone(phone);
          if (!normalizedPhone || !activeStoreId) return;
          
          setAllStoresData(p => {
              const store = p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] };
              const currentCustomers = store.customers || [];
              const exists = currentCustomers.some(customer => normalizePhone(customer.phone) === normalizedPhone);
              
              let newCustomers: CustomerProfile[];
              if (exists) {
                newCustomers = currentCustomers.map(customer => normalizePhone(customer.phone) === normalizedPhone ? { ...customer, ...updates } : customer);
              } else {
                const savedCustomer = currentCustomers.find((customer: CustomerProfile) => normalizePhone(customer.phone) === normalizedPhone);
                const sourceOrder = store.orders.find((order: Order) => normalizePhone(order.customerPhone) === normalizedPhone);
                const baseCustomer: CustomerProfile = {
                  id: savedCustomer?.id || normalizedPhone,
                  name: savedCustomer?.name || sourceOrder?.customerName || '',
                  phone: savedCustomer?.phone || sourceOrder?.customerPhone || phone,
                  address: savedCustomer?.address || sourceOrder?.customerAddress || '',
                  totalOrders: savedCustomer?.totalOrders || 0,
                  successfulOrders: savedCustomer?.successfulOrders || 0,
                  returnedOrders: savedCustomer?.returnedOrders || 0,
                  totalSpent: savedCustomer?.totalSpent || 0,
                  lastOrderDate: savedCustomer?.lastOrderDate || sourceOrder?.date || new Date().toISOString(),
                  firstOrderDate: savedCustomer?.firstOrderDate || sourceOrder?.date || new Date().toISOString(),
                  averageOrderValue: savedCustomer?.averageOrderValue || 0,
                  loyaltyPoints: savedCustomer?.loyaltyPoints || 0,
                  ...updates
                };
                newCustomers = [...currentCustomers, baseCustomer];
              }

              return {
                ...p,
                [activeStoreId]: {
                  ...store,
                  customers: newCustomers
                }
              };
          });
        },
        quotations: activeStoreId ? allStoresData[activeStoreId]?.quotations || [] : [],
        setQuotations: (updater: any) => {
            if(activeStoreId) {
                setAllStoresData(p => {
                    const currentQuotations = p[activeStoreId]?.quotations || [];
                    const newQuotations = typeof updater === 'function' ? updater(currentQuotations) : updater;
                    
                    if (currentQuotations === newQuotations) return p;

                    return {
                        ...p, 
                        [activeStoreId]: {
                            ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                            quotations: newQuotations
                        }
                    };
                });
            }
        },
        setOrders: (updater: any) => {
            if(activeStoreId) {
                setAllStoresData(p => {
                    const currentStore = p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] };
                    const currentOrders = currentStore.orders || [];
                    const rawNewOrders = typeof updater === 'function' ? updater(currentOrders) : updater;
                    
                    if (currentOrders === rawNewOrders || !Array.isArray(rawNewOrders)) return p;

                    let currentSettings = currentStore.settings || INITIAL_SETTINGS;
                    let settingsChanged = false;
                    let nextSuppliers: any[] = Array.isArray(currentSettings.suppliers) ? [...currentSettings.suppliers] : [];
                    let nextPartners: any[] = Array.isArray(currentSettings.partners) ? [...currentSettings.partners] : [];
                    let nextMerchantTxs: any[] = Array.isArray(currentSettings.merchantTransactions) ? [...currentSettings.merchantTransactions] : [];

                    const deductionTriggerStatuses = ['قيد_التنفيذ', 'تم_الارسال', 'قيد_الشحن'];

                    const processedOrders = rawNewOrders.map((order: any) => {
                        if (!order || order.managerFeeDeducted || order.quotaConsumedAt) return order;
                        if (!deductionTriggerStatuses.includes(order.status)) return order;

                        // Audit Fix #7: Respect the plan mode stamped at creation; never re-price historical self-service orders
                        if (order.planModeAtCreation === 'self_service') {
                            return {
                                ...order,
                                quotaConsumedAt: new Date().toISOString(),
                                managerFeeDeducted: true,
                                managerFeeAmount: 0
                            };
                        }

                        const mId = String(order.merchantId || '').trim();
                        const mName = String(order.merchantName || '').trim().toLowerCase();
                        if (!mId && !mName) return order;

                        const matchedSupIdx = nextSuppliers.findIndex(s =>
                            (mId && String(s?.id || '').trim() === mId) ||
                            (mName && String(s?.name || '').trim().toLowerCase() === mName)
                        );
                        const matchedSup = matchedSupIdx >= 0 ? nextSuppliers[matchedSupIdx] : null;
                        const mgrPlan = matchedSup?.managerPlan;

                        if (!mgrPlan || mgrPlan.status !== 'active') return order;
                        if (mgrPlan.endDate && new Date(mgrPlan.endDate).getTime() <= Date.now()) return order;

                        const effectivePlanId = order.planIdAtCreation || mgrPlan.planId;
                        const effectiveCycleId = order.planCycleId || mgrPlan.cycleId || `MGR-${effectivePlanId}`;
                        const nowIso = new Date().toISOString();

                        // Count already-consumed orders in this cycle
                        const consumedInCycle = rawNewOrders.filter((o: any) => {
                            if (!o || o.id === order.id || o.status === 'ملغي') return false;
                            const sameMerchant =
                                (mId && String(o.merchantId || '').trim() === mId) ||
                                (mName && String(o.merchantName || '').trim().toLowerCase() === mName);
                            if (!sameMerchant) return false;
                            const sameCycle = (o.planCycleId || mgrPlan.cycleId || `MGR-${effectivePlanId}`) === effectiveCycleId;
                            return sameCycle && Boolean(o.quotaConsumedAt || o.managerFeeDeducted);
                        }).length;

                        const cycleOrderNumber = consumedInCycle + 1;
                        let feeToDeduct = 0;
                        let quotaIncludedOrder = false;

                        if (effectivePlanId === 'monthly_1000' || effectivePlanId === 'monthly_700') {
                            const includedQuota = Number(mgrPlan.includedOrdersQuota ?? 50);
                            if (consumedInCycle < includedQuota) {
                                feeToDeduct = 0;
                                quotaIncludedOrder = true;
                            } else {
                                feeToDeduct = Number(mgrPlan.extraOrderFee ?? 20);
                                quotaIncludedOrder = false;
                            }
                        } else if (effectivePlanId === 'per_order_20') {
                            feeToDeduct = Number(order.lockedManagerFee ?? mgrPlan.orderFee ?? 20);
                        } else if (effectivePlanId === 'custom_manager' && !mgrPlan.customPrepaidQuota) {
                            feeToDeduct = Number(order.lockedManagerFee ?? mgrPlan.customOrderFee ?? mgrPlan.orderFee ?? 20);
                        }

                        // Deterministic financial key: merchantId + orderId + feeType
                        const deterministicTxId = `MGR-FEE-${matchedSup.id}-${order.id}`;
                        const existingTxs = Array.isArray(matchedSup.transactions) ? matchedSup.transactions : [];
                        const alreadyChargedInLedger = existingTxs.some(
                            (tx: any) => tx.id === deterministicTxId || (tx.type === 'manager_order_fee' && tx.referenceId === String(order.id))
                        );

                        if (feeToDeduct > 0 && !alreadyChargedInLedger) {
                            settingsChanged = true;
                            const prevBalPiasters = Math.round(Number(matchedSup.balance || 0) * 100);
                            const feePiasters = Math.round(feeToDeduct * 100);
                            const newBal = Number(((prevBalPiasters - feePiasters) / 100).toFixed(2));
                            const orderRef = order.orderNumber || order.id;
                            const feeTx = {
                                id: deterministicTxId,
                                merchantId: matchedSup.id,
                                merchantName: matchedSup.name,
                                date: nowIso,
                                type: 'manager_order_fee',
                                amount: -feeToDeduct,
                                balanceAfter: newBal,
                                referenceId: String(order.id || ''),
                                notes:
                                    effectivePlanId === 'monthly_1000' || effectivePlanId === 'monthly_700'
                                        ? `رسوم أوردر إضافي بعد كوتة الـ 50 المجانية (${feeToDeduct} ج.م) للأوردر #${orderRef} (ترتيب #${cycleOrderNumber})`
                                        : `خصم رسوم المدير المخصص (${feeToDeduct} ج.م) للأوردر #${orderRef}`
                            };

                            nextSuppliers[matchedSupIdx] = {
                                ...matchedSup,
                                balance: newBal,
                                transactions: [feeTx, ...existingTxs]
                            };

                            nextPartners = nextPartners.map(pt =>
                                (mId && String(pt?.id || '').trim() === mId) ||
                                (mName && String(pt?.name || '').trim().toLowerCase() === mName)
                                    ? { ...pt, balance: newBal, transactions: [feeTx, ...(pt.transactions || [])] }
                                    : pt
                            );

                            nextMerchantTxs = [feeTx, ...nextMerchantTxs.filter((tx: any) => tx.id !== deterministicTxId)];
                        }

                        return {
                            ...order,
                            quotaConsumedAt: nowIso,
                            quotaIncludedOrder,
                            cycleOrderNumber,
                            managerFeeDeducted: true,
                            managerFeeAmount: feeToDeduct,
                            lockedManagerFee: feeToDeduct
                        };
                    });

                    if (settingsChanged) {
                        currentSettings = {
                            ...currentSettings,
                            suppliers: nextSuppliers,
                            partners: nextPartners,
                            merchantTransactions: nextMerchantTxs
                        };
                    }

                    return {
                        ...p, 
                        [activeStoreId]: {
                            ...currentStore,
                            orders: processedOrders,
                            settings: currentSettings
                        }
                    };
                });
            }
        },
        setSettings: (updater: any) => {
            if(activeStoreId) {
                setAllStoresData(p => {
                    const currentSettings = p[activeStoreId]?.settings || INITIAL_SETTINGS;
                    let newSettings = typeof updater === 'function' ? updater(currentSettings) : updater;
                    
                    if (currentSettings === newSettings) return p;

                    if (newSettings.products && newSettings.products !== currentSettings.products) {
                        const healed = autoHealProducts(newSettings.products, newSettings.warehouses || []);
                        if (healed !== newSettings.products) {
                            newSettings = { ...newSettings, products: healed };
                        }
                    }

                    const updatedStoreData = {
                        ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                        settings: newSettings
                    };

                    // Immediate local persistence ensures quick reloads never lose freshly added products or images
                    db.saveLocal(activeStoreId, updatedStoreData);

                    return {
                        ...p, 
                        [activeStoreId]: updatedStoreData
                    };
                });
            }
        },
        setWallet: (updater: any) => {
             if(activeStoreId) {
                setAllStoresData(p => {
                    const currentWallet = p[activeStoreId]?.wallet || { balance: 0, transactions: [] };
                    const newWallet = typeof updater === 'function' ? updater(currentWallet) : updater;
                    
                    if (currentWallet === newWallet) return p;

                    if (newWallet && Array.isArray(newWallet.transactions)) {
                        const txs = newWallet.transactions;
                        newWallet.balance = txs.reduce((sum: number, t: any) => {
                            const amount = Number(t.amount) || 0;
                            if (t.category === 'supply_purchase' || t.category === 'supply_deposit' || t.category?.startsWith('supply_expense_')) return sum;
                            if ((t.details?.paidByPartnerId || t.details?.expensePaidBy || t.note?.includes('دفعهم') || t.note?.includes('شريك')) && !t.note?.includes('المحفظة المركزية')) return sum;
                            if (t.type === 'إيداع') {
                                if (t.status === 'cancelled') return sum;
                                if (t.status === 'pending' && (t.category === 'wallet_charge' || t.category === 'charge')) return sum;
                                return sum + amount;
                            }
                            if (t.type === 'سحب') return t.status === 'cancelled' ? sum : sum - amount;
                            return sum;
                        }, 0);
                    }

                    return {
                        ...p, 
                        [activeStoreId]: {
                            ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                            wallet: newWallet
                        }
                    };
                });
            }
        },
        setTreasury: (updater: any) => {
             if(activeStoreId) {
                setAllStoresData(p => {
                    const currentTreasury = p[activeStoreId]?.treasury || { accounts: [{ id: '1', name: 'الخزينة الرئيسية', type: 'safe', balance: 0, currency: 'EGP' }, { id: '2', name: 'فودافون كاش', type: 'wallet', balance: 0, currency: 'EGP' }, { id: '3', name: 'الحساب البنكي', type: 'bank', balance: 0, currency: 'EGP' }], transactions: [] };
                    const newTreasury = typeof updater === 'function' ? updater(currentTreasury) : updater;
                    
                    if (currentTreasury === newTreasury) return p;

                    return {
                        ...p,
                        [activeStoreId]: {
                            ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                            treasury: newTreasury
                        }
                    };
                });
            }
        },
        setCart: (updater: any) => {
            if(activeStoreId) {
                setAllStoresData(p => {
                    const currentCart = p[activeStoreId]?.cart || [];
                    const newCart = typeof updater === 'function' ? updater(currentCart) : updater;
                    
                    if (currentCart === newCart) return p;

                    return {
                        ...p, 
                        [activeStoreId]: {
                            ...(p[activeStoreId] || { orders: [], settings: INITIAL_SETTINGS, wallet: { balance: 0, transactions: [] }, cart: [], customers: [] }),
                            cart: newCart
                        }
                    };
                });
            }
        },
        onSave: forceSync,
    };

    const getNextOrderNumber = (orders: Order[]) => {
        const nums = orders
            .map(o => {
                const match = (o.orderNumber || '').match(/\d+/);
                return match ? parseInt(match[0]) : null;
            })
            .filter((n): n is number => n !== null);
        return nums.length > 0 ? Math.max(...nums) + 1 : 1;
    };

    const handlePlaceOrder = (orderData: any) => {
        if (!activeStoreId) return '123';
        const nextNum = getNextOrderNumber(pageProps.orders);
        const newOrder: Order = {
            id: `order-${Date.now()}`,
            orderNumber: `${nextNum}`,
            customerName: orderData.customerName,
            customerPhone: orderData.customerPhone,
            customerEmail: orderData.customerEmail,
            customerAddress: orderData.customerAddress,
            buildingNumber: orderData.buildingNumber,
            floorNumber: orderData.floorNumber,
            apartmentNumber: orderData.apartmentNumber,
            shippingCompany: orderData.shippingCompany,
            shippingArea: orderData.shippingArea,
            shippingFee: orderData.shippingFee,
            notes: orderData.notes,
            status: 'في_انتظار_المكالمة',
            date: new Date().toISOString(),
            items: pageProps.cart.map((item: any) => ({
                productId: item.productId || item.id,
                name: item.name,
                quantity: item.quantity,
                price: item.price,
                cost: item.cost || 0,
                weight: item.weight || 0,
            })),
            productPrice: (pageProps.cart || []).reduce((sum: number, item: any) => sum + ((item.price || 0) * (item.quantity || 1)), 0),
            productCost: (pageProps.cart || []).reduce((sum: number, item: any) => sum + ((item.cost || 0) * (item.quantity || 1)), 0),
            weight: (pageProps.cart || []).reduce((sum: number, item: any) => sum + ((item.weight || 0) * (item.quantity || 1)), 0),
            discount: orderData.discount || 0,
            orderType: 'standard',
            paymentMethod: orderData.paymentMethod || 'cash_on_delivery',
            productName: pageProps.cart.map((i: any) => i.name).join(', '),
            includeInspectionFee: false,
            isInsured: false,
            paymentStatus: 'بانتظار الدفع',
            preparationStatus: 'بانتظار التجهيز',
        };
        
        pageProps.setOrders((prev: Order[]) => [newOrder, ...prev]);
        knownOrderIdsRef.current.add(newOrder.id);

        // 🔔 Trigger Web Notification & In-App Alert Window for new pending order
        showOrderWebNotification(newOrder, {
            storeName: activeStore?.name || pageProps.settings?.storeName || 'متجري'
        });

        // Auto-register or update customer in store CRM
        if (orderData.customerPhone) {
            const normalizedPhone = normalizePhone(orderData.customerPhone);
            pageProps.setCustomers((prev: CustomerProfile[]) => {
                const exists = prev.find(c => normalizePhone(c.phone) === normalizedPhone);
                if (exists) {
                    return prev.map(c => normalizePhone(c.phone) === normalizedPhone ? {
                        ...c,
                        email: orderData.customerEmail || c.email,
                        totalOrders: (c.totalOrders || 0) + 1,
                        lastOrderDate: new Date().toISOString(),
                        loyaltyPoints: (c.loyaltyPoints || 0) + 10
                    } : c);
                }
                const newProfile: CustomerProfile = {
                    id: normalizedPhone,
                    name: orderData.customerName || 'عميل المتجر',
                    phone: orderData.customerPhone,
                    email: orderData.customerEmail || '',
                    address: orderData.customerAddress || '',
                    governorate: orderData.shippingArea || '',
                    city: '',
                    totalOrders: 1,
                    successfulOrders: 0,
                    returnedOrders: 0,
                    totalSpent: (newOrder.productPrice || 0) + (newOrder.shippingFee || 0) - (newOrder.discount || 0),
                    lastOrderDate: new Date().toISOString(),
                    firstOrderDate: new Date().toISOString(),
                    averageOrderValue: newOrder.productPrice || 0,
                    loyaltyPoints: 10
                };
                return [newProfile, ...prev];
            });
        }

        pageProps.setCart([]); // Clear cart
        try { localStorage.removeItem('storefront_cart'); } catch (e) {}
        triggerWebhooks(newOrder, pageProps.settings);
        return newOrder.id;
    };

    const handleAddToCart = (product: any, quantity: number = 1) => {
        const qtyToAdd = Math.max(1, Number(quantity) || 1);
        pageProps.setCart((prev: any[]) => {
            const existing = prev.find(item => (item.productId || item.id) === product.id);
            if (existing) {
                return prev.map(item => (item.productId || item.id) === product.id ? { ...item, quantity: (item.quantity || 1) + qtyToAdd } : item);
            }
            const newItem: OrderItem = {
                productId: product.id,
                name: product.name,
                price: product.price,
                cost: product.costPrice || 0,
                weight: product.weight || 0,
                thumbnail: product.thumbnail,
                quantity: qtyToAdd
            };
            return [...prev, newItem];
        });
    };

    const handleUpdateCartQuantity = (productId: string, quantity: number) => {
        if (quantity < 1) {
            handleRemoveFromCart(productId);
            return;
        }
        pageProps.setCart((prev: any[]) => prev.map(item => (item.productId || item.id) === productId ? { ...item, quantity } : item));
    };

    const handleRemoveFromCart = (productId: string) => {
        pageProps.setCart((prev: any[]) => prev.filter(item => (item.productId || item.id) !== productId));
    };

    if (isStoreNotFound) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-slate-100/70 text-slate-800" dir="rtl">
                <div className="text-center space-y-4">
                    <h1 className="text-4xl font-bold">404</h1>
                    <p className="text-lg">هذا المتجر غير موجود أو غير مفعل.</p>
                </div>
            </div>
        );
    }

    if (isStandaloneStorefront) {
        if (!activeStoreId || isInitialLoad) return <WelcomeLoader userName="" />;
        
        return (
            <Suspense fallback={<WelcomeLoader userName="" />}>
                <Routes>
                    <Route path="/" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                    <Route path="/store" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                    <Route path="/products" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                    <Route path="/product/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                    <Route path="/products/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                    <Route path="/p/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                    <Route path="/cart" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                    <Route path="/checkout" element={<CheckoutPage {...pageProps} onPlaceOrder={handlePlaceOrder} />} />
                    <Route path="/order-success/:orderId" element={<OrderSuccessPage {...pageProps} />} />
                    <Route path="/track-order" element={<OrderTrackingPage orders={pageProps.orders} settings={pageProps.settings} />} />
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </Suspense>
        );
    }

    return (
        <Suspense fallback={<GlobalLoader />}>
            <Routes>
                <Route path="/owner-login" element={<SignUpPage onPasswordSuccess={(user, password) => startOtpFlow(user, null, password)} users={users} setUsers={setUsers} />} />
                <Route path="/employee-login" element={<EmployeeLoginPage allStoresData={allStoresData} users={users} onLoginAttempt={handleEmployeeLogin} onRegisterRequest={handleEmployeeRegisterRequest} />} />
                <Route path="/auth/action" element={<FirebaseActionPage />} />
                <Route path="/auth/action/" element={<FirebaseActionPage />} />
                <Route path="/track-order" element={<OrderTrackingPage orders={pageProps.orders} settings={pageProps.settings} />} />
                <Route path="/order-action" element={<CustomerOrderActionPage orders={pageProps.orders} allStoresData={allStoresData} activeStore={pageProps.activeStore} setOrders={pageProps.setOrders} setAllStoresData={setAllStoresData} />} />
                <Route path="/order-action/" element={<CustomerOrderActionPage orders={pageProps.orders} allStoresData={allStoresData} activeStore={pageProps.activeStore} setOrders={pageProps.setOrders} setAllStoresData={setAllStoresData} />} />
                <Route path="/confirm-order/:id" element={<CustomerOrderActionPage orders={pageProps.orders} allStoresData={allStoresData} activeStore={pageProps.activeStore} setOrders={pageProps.setOrders} setAllStoresData={setAllStoresData} />} />
                <Route path="/cancel-order/:id" element={<CustomerOrderActionPage orders={pageProps.orders} allStoresData={allStoresData} activeStore={pageProps.activeStore} setOrders={pageProps.setOrders} setAllStoresData={setAllStoresData} />} />
                <Route path="/shared-report/:id" element={<SharedReportView />} />
                <Route path="/shared-audit/:auditId" element={<WarehouseSubmitPage />} />
                <Route path="/quote-approval/:id" element={<CustomerQuoteApprovalPage allStoresData={allStoresData} setAllStoresData={setAllStoresData} forceSync={forceSync} />} />
                <Route path="/quote-approval" element={<CustomerQuoteApprovalPage allStoresData={allStoresData} setAllStoresData={setAllStoresData} forceSync={forceSync} />} />
                <Route path="/welcome" element={<WelcomeLandingPage />} />
                <Route path="/landing" element={<WelcomeLandingPage />} />
                
                <Route path="/admin" element={<AdminLayout currentUser={currentUser} handleLogout={handleLogout} theme={theme} setTheme={setTheme} isInitialLoad={isInitialLoad} />}>
                    <Route index element={<AdminPage {...pageProps} onImpersonate={handleImpersonate} currentUser={currentUser as User} />} />
                    <Route path="select-store" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="manage-stores" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="projects" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="account-settings" element={<AccountSettingsPage currentUser={currentUser} setCurrentUser={setCurrentUser} users={users} setUsers={setUsers} />} />
                </Route>

                <Route path="/employee" element={
                    <EmployeeLayoutWrapper 
                        currentUser={currentUser} onLogout={handleLogout}
                        isEmployeeSession={isEmployeeSession}
                        storeOwner={users.find(u => u.stores?.some(s => s.id === activeStoreId))}
                        activeStoreId={activeStoreId}
                        theme={theme} setTheme={setTheme}
                        allStoresData={allStoresData} users={users}
                        handleSetActiveStore={handleSetActiveStore}
                        installPrompt={installPrompt} onInstall={() => installPrompt?.prompt()}
                        isStandalone={isStandalone} isIos={isIos}
                    >
                        <Outlet/>
                    </EmployeeLayoutWrapper>
                }>
                    <Route index element={<EmployeeDashboardPage currentUser={currentUser} orders={pageProps.orders} setOrders={pageProps.setOrders} settings={pageProps.settings} activeStore={pageProps.activeStore} />} />
                    <Route path="dashboard" element={<EmployeeDashboardPage currentUser={currentUser} orders={pageProps.orders} setOrders={pageProps.setOrders} settings={pageProps.settings} activeStore={pageProps.activeStore} />} />
                    <Route path="confirmation-queue" element={
                        <EmployeePermissionRoute currentUser={currentUser} permission="ORDERS_MANAGE">
                            <ConfirmationQueuePage currentUser={currentUser} orders={pageProps.orders} setOrders={pageProps.setOrders} settings={pageProps.settings} setSettings={pageProps.setSettings} activeStore={pageProps.activeStore} onRefresh={() => pageProps.activeStore?.id && refreshStoreData(pageProps.activeStore.id)} forceSync={pageProps.forceSync} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} />
                        </EmployeePermissionRoute>
                    } />
                    <Route path="pos" element={
                        <EmployeePermissionRoute currentUser={currentUser} permission="POS_VIEW">
                            <POSPage settings={pageProps.settings} updateSettings={pageProps.setSettings} orders={pageProps.orders} wallet={pageProps.wallet} treasury={pageProps.treasury} updateStoreData={(data) => setAllStoresData(p => ({ ...p, [activeStoreId!]: { ...p[activeStoreId!], ...data } }))} currentUser={currentUser} activeStore={pageProps.activeStore} customers={pageProps.customers} />
                        </EmployeePermissionRoute>
                    } />
                    <Route path="quotations" element={<QuotationsPage {...pageProps} />} />
                    <Route path="my-activity" element={<EmployeeActivityPage currentUser={currentUser} orders={pageProps.orders} />} />
                    <Route path="customers" element={
                        <EmployeePermissionRoute currentUser={currentUser} permission="CUSTOMERS_VIEW">
                            <CustomersPage 
                                orders={pageProps.orders} 
                                loyaltyData={{}} 
                                customers={pageProps.customers}
                                settings={pageProps.settings}
                                onUpdateCustomer={pageProps.onUpdateCustomer}
                            />
                        </EmployeePermissionRoute>
                    } />
                    <Route path="account-settings" element={<EmployeeAccountSettingsPage currentUser={currentUser} setCurrentUser={setCurrentUser} users={users} setUsers={setUsers} />} />
                </Route>

                <Route path="/" element={
                    <OwnerLayoutWrapper
                        currentUser={currentUser}
                        isEmployeeSession={isEmployeeSession}
                        welcomeScreenShown={welcomeScreenShown}
                        setWelcomeScreenShown={setWelcomeScreenShown}
                        handleLogout={handleLogout}
                        isSidebarOpen={isSidebarOpen}
                        setIsSidebarOpen={setIsSidebarOpen}
                        activeStore={activeStore}
                        activeStoreId={activeStoreId}
                        handleSetActiveStore={handleSetActiveStore}
                        settings={pageProps.settings}
                        orders={pageProps.orders}
                        theme={theme}
                        setTheme={setTheme}
                        dbSyncMode={dbSyncMode}
                        setDbSyncMode={setDbSyncMode}
                        forceSync={forceSync}
                        forcePullFromCloud={forcePullFromCloud}
                        saveStatus={saveStatus}
                        saveMessage={saveMessage}
                        unsavedChanges={getUnsavedChanges()}
                        isShippingCalculatorOpen={isShippingCalculatorOpen}
                        setIsShippingCalculatorOpen={setIsShippingCalculatorOpen}
                        isInitialLoad={isInitialLoad}
                    />
                }>
                    <Route index element={
                        (currentUser?.defaultStoreId && currentUser.stores?.some(s => s.id === currentUser.defaultStoreId))
                            ? <Navigate to={`/store/${currentUser.defaultStoreId}/dashboard`} replace />
                            : (currentUser?.stores && currentUser.stores.length === 1)
                                ? <Navigate to={`/store/${currentUser.stores[0].id}/dashboard`} replace />
                                : <Navigate to="/select-store" replace />
                    } />
                    <Route path="select-store" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="manage-stores" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="projects" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="create-store" element={<CreateStorePage currentUser={currentUser} onStoreCreated={handleStoreCreated} />} />
                    <Route path="account-settings" element={<AccountSettingsPage currentUser={currentUser} setCurrentUser={setCurrentUser} users={users} setUsers={setUsers} />} />
                </Route>

                <Route path="/store/:storeId" element={
                    <OwnerLayoutWrapper
                        currentUser={currentUser}
                        isEmployeeSession={isEmployeeSession}
                        welcomeScreenShown={welcomeScreenShown}
                        setWelcomeScreenShown={setWelcomeScreenShown}
                        handleLogout={handleLogout}
                        isSidebarOpen={isSidebarOpen}
                        setIsSidebarOpen={setIsSidebarOpen}
                        activeStore={activeStore}
                        activeStoreId={activeStoreId}
                        handleSetActiveStore={handleSetActiveStore}
                        settings={pageProps.settings}
                        orders={pageProps.orders}
                        theme={theme}
                        setTheme={setTheme}
                        dbSyncMode={dbSyncMode}
                        setDbSyncMode={setDbSyncMode}
                        forceSync={forceSync}
                        forcePullFromCloud={forcePullFromCloud}
                        saveStatus={saveStatus}
                        saveMessage={saveMessage}
                        unsavedChanges={getUnsavedChanges()}
                        isShippingCalculatorOpen={isShippingCalculatorOpen}
                        setIsShippingCalculatorOpen={setIsShippingCalculatorOpen}
                        isInitialLoad={isInitialLoad}
                    />
                }>
                    <Route index element={<Navigate to="dashboard" replace />} />
                    <Route path="dashboard" element={<Dashboard {...pageProps} />} />
                    <Route path="maintenance" element={<MaintenancePage currentStoreId={activeStoreId!} settings={pageProps.settings} setSettings={pageProps.setSettings} customers={pageProps.customers} setCustomers={pageProps.setCustomers} products={pageProps.products} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} setOrders={pageProps.setOrders} />} />
                    <Route path="confirmation-queue" element={<ConfirmationQueuePage currentUser={currentUser} orders={pageProps.orders} setOrders={pageProps.setOrders} settings={pageProps.settings} setSettings={pageProps.setSettings} activeStore={pageProps.activeStore} onRefresh={() => pageProps.activeStore?.id && refreshStoreData(pageProps.activeStore.id)} forceSync={pageProps.forceSync} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} />} />
                    <Route path="orders" element={<OrdersList {...pageProps} currentUser={currentUser} addLoyaltyPointsForOrder={() => {}} />} />
                    <Route path="quotations" element={<QuotationsPage {...pageProps} />} />
                    <Route path="dropshipping" element={<DropshippingPage orders={pageProps.orders} settings={pageProps.settings} activeStore={pageProps.activeStore} setOrders={pageProps.setOrders} />} />
                    <Route path="merchant-settlement" element={<MerchantSettlementPage storeId={activeStoreId} orders={pageProps.orders} setOrders={pageProps.setOrders} settings={pageProps.settings} updateSettings={pageProps.setSettings} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} customers={pageProps.customers} currentUser={currentUser} />} />
                    <Route path="merchant-portal" element={
                        <MerchantPortal 
                            allStoresData={allStoresData} 
                            updateSettings={(newSettings) => {
                                setAllStoresData(p => {
                                    const draft = { ...p };
                                    return draft;
                                });
                            }} 
                            showToast={(msg, type) => {}} 
                        />
                    } />
                    <Route path="merchant-portal/:tab" element={
                        <MerchantPortal 
                            allStoresData={allStoresData} 
                            updateSettings={(newSettings) => {
                                setAllStoresData(p => {
                                    const draft = { ...p };
                                    return draft;
                                });
                            }} 
                            showToast={(msg, type) => {}} 
                        />
                    } />
                    <Route path="partner-portal" element={
                        <PartnerPortal 
                            allStoresData={allStoresData} 
                            portalMode="partner"
                            updateSettings={(newSettings) => {
                                setAllStoresData(p => {
                                    const draft = { ...p };
                                    return draft;
                                });
                            }} 
                            showToast={(msg, type) => {}} 
                        />
                    } />
                    <Route path="partner-portal/:tab" element={
                        <PartnerPortal 
                            allStoresData={allStoresData} 
                            portalMode="partner"
                            updateSettings={(newSettings) => {
                                setAllStoresData(p => {
                                    const draft = { ...p };
                                    return draft;
                                });
                            }} 
                            showToast={(msg, type) => {}} 
                        />
                    } />
                    <Route path="dropshipping/new" element={<CreateDropshippingOrderPage {...pageProps} />} />
                    <Route path="returns" element={<OrderReturnsPage settings={pageProps.settings} updateSettings={pageProps.setSettings} orders={pageProps.orders} updateStoreData={(data) => setAllStoresData(p => ({ ...p, [activeStoreId!]: { ...p[activeStoreId!], ...data } }))} currentUser={currentUser} />} />
                    <Route path="pos" element={<POSPage settings={pageProps.settings} updateSettings={pageProps.setSettings} orders={pageProps.orders} wallet={pageProps.wallet} treasury={pageProps.treasury} updateStoreData={(data) => setAllStoresData(p => ({ ...p, [activeStoreId!]: { ...p[activeStoreId!], ...data } }))} currentUser={currentUser} activeStore={pageProps.activeStore} customers={pageProps.customers} />} />
                    <Route path="cash-management" element={<CashManagement settings={pageProps.settings} updateSettings={pageProps.setSettings} currentUser={currentUser} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} wallet={pageProps.wallet} setWallet={pageProps.setWallet} orders={pageProps.orders} />} />
                    <Route path="purchase-returns" element={<PurchaseReturnsPage settings={pageProps.settings} updateSettings={pageProps.setSettings} currentUser={currentUser} />} />
                    <Route path="orders/new" element={<CreateOrderPage {...pageProps} />} />
                    <Route path="orders/edit/:id" element={<EditOrderPage {...pageProps} />} />
                    <Route path="create-order" element={<Navigate to="../orders/new" replace />} />
                    <Route path="products" element={<ProductsPage {...pageProps} orders={pageProps.orders} />} />
                    <Route path="inventory-transfers" element={<InventoryTransfers settings={pageProps.settings} updateSettings={pageProps.setSettings} currentUser={currentUser} />} />
                    <Route path="customers" element={
                      <CustomersPage 
                        orders={pageProps.orders} 
                        loyaltyData={{}} 
                        customers={pageProps.customers}
                        settings={pageProps.settings}
                        onUpdateCustomer={pageProps.onUpdateCustomer}
                      />
                    } />
                    <Route path="wallet" element={<WalletPage {...pageProps} />} />
                    <Route path="settings" element={<SettingsPage {...pageProps} onManualSave={currentUser?.isAdmin ? handleManualMigration : undefined} />} />
                    <Route path="customize-store" element={<StoreCustomizationPage {...pageProps} initialSection="colors" />} />
                    <Route path="shipping" element={<ShippingPage {...pageProps} />} />
                    <Route path="failed-delivery-compensation" element={<FailedDeliveryCompensationPage orders={pageProps.orders} setOrders={pageProps.setOrders} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} settings={pageProps.settings} updateSettings={pageProps.setSettings} forceSync={pageProps.forceSync} wallet={pageProps.wallet} setWallet={pageProps.setWallet} customers={pageProps.customers} />} />
                    <Route path="abandoned-carts" element={<AbandonedCartsPage {...pageProps} />} />
                    <Route path="discounts" element={<DiscountsPage {...pageProps} />} />
                    <Route path="reviews" element={<ReviewsPage {...pageProps} />} />
                    <Route path="collections" element={<CollectionsPage {...pageProps} />} />
                    <Route path="product-options" element={<ProductOptionsPage {...pageProps} />} />
                    <Route path="expenses" element={<ExpensesPage {...pageProps} settings={pageProps.settings} updateSettings={pageProps.setSettings} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} />} />
                    <Route path="marketing" element={<MarketingPage {...pageProps} />} />
                    <Route path="ai-assistant" element={<ChatBot {...pageProps} />} />
                    <Route path="reports" element={<AnalyticsPage {...pageProps} />} />
                    <Route path="standard-reports" element={<ReportsPage {...pageProps} />} />
                    <Route path="collections-report" element={<CollectionsReportPage {...pageProps} />} />
                    <Route path="activity-logs" element={<ActivityLogsPage logs={pageProps.settings?.activityLogs || []} />} />
                    <Route path="suppliers" element={<SuppliersPage {...pageProps} orders={pageProps.orders} />} />
                    <Route path="merchants" element={<MerchantsPage settings={pageProps.settings} updateSettings={pageProps.setSettings} wallet={pageProps.wallet} setWallet={pageProps.setWallet} orders={pageProps.orders} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} />} />
                    <Route path="partners" element={<PartnersPage settings={pageProps.settings} updateSettings={pageProps.setSettings} wallet={pageProps.wallet} setWallet={pageProps.setWallet} orders={pageProps.orders} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} />} />
                    <Route path="partners/:partnerId" element={<PartnerProfilePage settings={pageProps.settings} updateSettings={pageProps.setSettings} wallet={pageProps.wallet} setWallet={pageProps.setWallet} orders={pageProps.orders} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} />} />
                    <Route path="suppliers/:supplierId" element={<MerchantProfilePage settings={pageProps.settings} updateSettings={pageProps.setSettings} orders={pageProps.orders} setOrders={pageProps.setOrders} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} customers={pageProps.customers} currentUser={currentUser} />} />
                    <Route path="reconciliation" element={<ExcelReconciliationPage allStoresData={allStoresData} updateStoreData={(id, updater) => { setAllStoresData(p => { const draft = { ...p }; if(draft[id]) { const cloned = JSON.parse(JSON.stringify(draft[id])); updater(cloned); draft[id] = cloned; } return draft; }); }} showToast={(msg, type) => {}} />} />
                    <Route path="pages" element={<PagesManager {...pageProps} />} />
                    <Route path="settings/payment" element={<PaymentSettingsPage {...pageProps} />} />
                    <Route path="settings/employees" element={<EmployeesPage {...pageProps} activeStoreId={activeStoreId} />} />
                    <Route path="employees-payroll" element={<EmployeesPayrollPage {...pageProps} />} />
                    <Route path="team-chat" element={<TeamChatPage {...pageProps} activeStoreId={activeStoreId} />} />
                    <Route path="whatsapp" element={<WhatsAppPage {...pageProps} onRefresh={() => activeStoreId ? refreshStoreData(activeStoreId) : Promise.resolve()} />} />
                    <Route path="treasury" element={<TreasuryPage settings={pageProps.settings} treasury={pageProps.treasury} setTreasury={pageProps.setTreasury} wallet={pageProps.wallet} setWallet={pageProps.setWallet} orders={pageProps.orders} />} />
                    
                    {/* Coming Soon Routes */}
                    <Route path="product-attributes" element={<ComingSoonPage />} />
                    <Route path="withdrawals" element={<ComingSoonPage />} />
                    <Route path="design-templates" element={<StoreCustomizationPage {...pageProps} initialSection="templates" />} />
                    <Route path="domain" element={<DomainSettingsPage activeStoreId={activeStoreId} storeData={allStoresData[activeStoreId] || null} settings={pageProps.settings} setSettings={pageProps.setSettings} users={users} />} />
                    <Route path="legal-pages" element={<ComingSoonPage />} />
                    <Route path="apps" element={<AppsPage storeId={activeStoreId} storeData={allStoresData[activeStoreId] || null} onUpdateSettings={pageProps.setSettings} onUpdateOrders={pageProps.setOrders} onRefresh={pageProps.onRefresh} hostUrl={pageProps.settings.customAppDomain || window.location.origin} />} />
                    <Route path="settings/tax" element={<ComingSoonPage />} />
                    <Route path="settings/developer" element={
                        <DeveloperSettingsPage 
                            settings={pageProps.settings} 
                            setSettings={pageProps.setSettings} 
                            activeStoreId={activeStoreId} 
                            activeStore={activeStore}
                            hostUrl={pageProps.settings.customAppDomain || window.location.origin}
                            dbSyncMode={dbSyncMode}
                            setDbSyncMode={setDbSyncMode}
                            forcePullFromCloud={pageProps.forcePullFromCloud}
                            forceSync={pageProps.forceSync}
                            saveStatus={saveStatus}
                            saveMessage={saveMessage}
                            allStoresData={allStoresData}
                            setAllStoresData={setAllStoresData}
                        />
                    } />
                    <Route path="webhook-monitor" element={<WebhookMonitorPage />} />
                    <Route path="docs" element={<ApiDocsPage activeStore={activeStore} settings={pageProps.settings} currentUser={currentUser} />} />
                    <Route path="api-docs" element={<ApiDocsPage activeStore={activeStore} settings={pageProps.settings} currentUser={currentUser} />} />
                    <Route path="tracking" element={<OrderTrackingPage orders={pageProps.orders} settings={pageProps.settings} />} />
                    <Route path="track-order" element={<OrderTrackingPage orders={pageProps.orders} settings={pageProps.settings} />} />
                    <Route path="select-store" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="manage-stores" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="projects" element={<ManageSitesPage ownedStores={currentUser?.stores || []} collaboratingStores={[]} setActiveStoreId={handleSetActiveStore} currentUser={currentUser} setCurrentUser={setCurrentUser} {...pageProps} />} />
                    <Route path="account-settings" element={<AccountSettingsPage currentUser={currentUser} setCurrentUser={setCurrentUser} users={users} setUsers={setUsers} />} />
                    <Route path="admin" element={<Navigate to="/admin" replace />} />
                </Route>

                {/* Standalone Public Docs Route */}
                <Route path="/docs" element={<ApiDocsPage activeStore={activeStore} settings={allStoresData[activeStoreId || '']?.settings || INITIAL_SETTINGS} currentUser={currentUser} />} />
                <Route path="/api-docs" element={<ApiDocsPage activeStore={activeStore} settings={allStoresData[activeStoreId || '']?.settings || INITIAL_SETTINGS} currentUser={currentUser} />} />

                <Route path="/store/:storeId/partner-portal" element={
                    <PartnerPortal 
                        allStoresData={allStoresData} 
                        portalMode="partner"
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/store/:storeId/partner-portal/:tab" element={
                    <PartnerPortal 
                        allStoresData={allStoresData} 
                        portalMode="partner"
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/store/:storeId/merchant-portal" element={
                    <MerchantPortal 
                        allStoresData={allStoresData} 
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/store/:storeId/merchant-portal/:tab" element={
                    <MerchantPortal 
                        allStoresData={allStoresData} 
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/merchant-portal" element={
                    <MerchantPortal 
                        allStoresData={allStoresData} 
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/merchant-portal/:tab" element={
                    <MerchantPortal 
                        allStoresData={allStoresData} 
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/partner-portal" element={
                    <PartnerPortal 
                        allStoresData={allStoresData} 
                        portalMode="partner"
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />
                <Route path="/partner-portal/:tab" element={
                    <PartnerPortal 
                        allStoresData={allStoresData} 
                        portalMode="partner"
                        updateSettings={(newSettings) => {
                            setAllStoresData(p => {
                                const draft = { ...p };
                                return draft;
                            });
                        }} 
                        showToast={(msg, type) => {}} 
                    />
                } />

                <Route path="store" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                <Route path="products" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                <Route path="product/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="products/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="p/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="cart" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                <Route path="checkout" element={<CheckoutPage {...pageProps} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="order-success/:orderId" element={<OrderSuccessPage {...pageProps} />} />

                {/* Path with store ID */}
                <Route path="/store/:storeId/store" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                <Route path="/store/:storeId/products" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                <Route path="/store/:storeId/product/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="/store/:storeId/products/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="/store/:storeId/p/:slug" element={<ProductDetailPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="/store/:storeId/cart" element={<StorefrontPage {...pageProps} onAddToCart={handleAddToCart} onUpdateCartQuantity={handleUpdateCartQuantity} onRemoveFromCart={handleRemoveFromCart} />} />
                <Route path="/store/:storeId/checkout" element={<CheckoutPage {...pageProps} onPlaceOrder={handlePlaceOrder} />} />
                <Route path="/store/:storeId/order-success/:orderId" element={<OrderSuccessPage {...pageProps} />} />
                <Route path="*" element={<CatchAllRedirect currentUser={currentUser} isEmployeeSession={isEmployeeSession} activeStoreId={activeStoreId} />} />
            </Routes>
            {showCongratsModal && (
                <CongratsModal 
                    isOpen={showCongratsModal}
                    onClose={() => setShowCongratsModal(false)}
                    title="تهانينا!"
                    message="تم تفعيل المتجر الخاص بك بنجاح. يمكنك الآن البدء في استقبال الطلبات وإدارة منتجاتك بسهولة."
                />
            )}
            <UniversalInstallPrompt 
                installPrompt={installPrompt} 
                onInstall={() => installPrompt?.prompt()} 
                isStandalone={isStandalone} 
                isIos={isIos} 
            />
            {currentUser && !isStandaloneStorefront && (
                <SmartUpdatesWidget isAdminView={true} primaryColor="#6366f1" />
            )}
            <InAppAlertSystem />
            <NewOrderAlertModal 
                activeStoreId={activeStoreId}
                storeName={activeStore?.name}
                onUpdateOrderStatus={(orderId, newStatus) => {
                    pageProps.setOrders((prev: Order[]) =>
                        prev.map(o => o.id === orderId ? { ...o, status: newStatus as any } : o)
                    );
                }}
                onNavigateToOrder={(orderId) => {
                    if (activeStoreId) {
                        navigate(`/store/${activeStoreId}/orders?search=${encodeURIComponent(orderId)}`);
                    } else if (isEmployeeSession) {
                        navigate('/employee/confirmation-queue');
                    }
                }}
            />
        </Suspense>
    );
};

export const AppWrapper = () => (
    <BrowserRouter future={{ v7_relativeSplatPath: true, v7_startTransition: true }}>
        <Suspense fallback={<GlobalLoader />}>
            <AppComponent />
        </Suspense>
    </BrowserRouter>
);

export default AppWrapper;
