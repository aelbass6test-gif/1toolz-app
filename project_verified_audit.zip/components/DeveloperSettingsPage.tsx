import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { audioSynth } from '../utils/audioSynth';
import { Settings, WebhookIntegration, Store } from '../types';
import { Code, Webhook, Key, Trash, Plus, Save, Server, Shield, ShoppingCart, Copy, CheckCircle2, Database, RefreshCw, AlertCircle, Check, ExternalLink, ShieldAlert, History, Sparkles, Wifi, WifiOff, Layers, Cloud, CloudUpload, Download, Eye, Activity, Search, Wrench, CheckSquare, Square, Mail, Send } from 'lucide-react';
import { getSupabaseRestrictedStatus, setSupabaseRestricted, isSupabaseActive, verifySupabaseConnection, getLocal, saveLocal, saveStoreData } from '../services/databaseService';
import ApiKeysManager from './ApiKeysManager';
import WebhooksManager from './WebhooksManager';

const SupabaseIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-[#3ECF8E]">
    <path d="M13.35 21.05C12.45 21.95 11 21.31 11 20.04V15H5.43C4.08 15 3.4 13.37 4.35 12.42L10.65 6.12C11.55 5.22 13 5.86 13 7.13V12.17H18.57C19.92 12.17 20.6 13.8 19.65 14.75L13.35 21.05Z" fill="currentColor"/>
  </svg>
);

const SQL_SCHEMA_SCRIPT = `-- =========================================================================
-- السكربت الشامل والمتكامل لإنشاء وضبط جميع جداول وأعمدة قاعدة بيانات Supabase
-- يتضمن 38 جدولاً متكاملاً مع جميع الأعمدة بصيغتي CamelCase و snake_case
-- وتعطيل RLS وتعيين الصلاحيات لضمان أقصى سرعة ومزامنة سلسة 100%
-- =========================================================================

-- 1. STORES_DATA (قاعدة بيانات المتاجر والإعدادات)
CREATE TABLE IF NOT EXISTS stores_data (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    settings JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 2. USERS (المستخدمون والمدراء)
CREATE TABLE IF NOT EXISTS users (
    phone TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    fullName TEXT,
    password TEXT NOT NULL,
    email TEXT,
    stores JSONB DEFAULT '[]'::jsonb,
    sites JSONB DEFAULT '[]'::jsonb,
    is_admin BOOLEAN DEFAULT false,
    isAdmin BOOLEAN DEFAULT false,
    is_banned BOOLEAN DEFAULT false,
    isBanned BOOLEAN DEFAULT false,
    join_date TEXT,
    joinDate TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 3. PRODUCTS (المنتجات والمخزون)
CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    sku TEXT,
    description TEXT,
    price NUMERIC NOT NULL DEFAULT 0,
    cost_price NUMERIC DEFAULT 0,
    costPrice NUMERIC DEFAULT 0,
    base_price NUMERIC DEFAULT 0,
    basePrice NUMERIC DEFAULT 0,
    stock_quantity NUMERIC DEFAULT 0,
    stockQuantity NUMERIC DEFAULT 0,
    stock NUMERIC DEFAULT 0,
    min_stock_level NUMERIC DEFAULT 0,
    minStockLevel NUMERIC DEFAULT 0,
    stock_threshold NUMERIC DEFAULT 0,
    stockThreshold NUMERIC DEFAULT 0,
    last_audited JSONB DEFAULT '{}'::jsonb,
    lastAudited JSONB DEFAULT '{}'::jsonb,
    warehouse_stock JSONB DEFAULT '{}'::jsonb,
    warehouseStock JSONB DEFAULT '{}'::jsonb,
    details JSONB DEFAULT '{}'::jsonb,
    expiry_date TEXT,
    expiryDate TEXT,
    profit_mode TEXT DEFAULT 'manual',
    profitMode TEXT DEFAULT 'manual',
    profit_percentage NUMERIC DEFAULT 0,
    profitPercentage NUMERIC DEFAULT 0,
    commission_percentage NUMERIC DEFAULT 0,
    commissionPercentage NUMERIC DEFAULT 0,
    use_profit_percentage BOOLEAN DEFAULT false,
    useProfitPercentage BOOLEAN DEFAULT false,
    weight NUMERIC DEFAULT 0,
    thumbnail TEXT,
    images JSONB DEFAULT '[]'::jsonb,
    in_stock BOOLEAN DEFAULT true,
    inStock BOOLEAN DEFAULT true,
    has_variants BOOLEAN DEFAULT false,
    hasVariants BOOLEAN DEFAULT false,
    options JSONB DEFAULT '[]'::jsonb,
    variants JSONB DEFAULT '[]'::jsonb,
    collection_id TEXT,
    collectionId TEXT,
    category_id TEXT,
    categoryId TEXT,
    barcode TEXT,
    supplier_id TEXT,
    supplierId TEXT,
    is_archived BOOLEAN DEFAULT false,
    isArchived BOOLEAN DEFAULT false,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 4. ORDERS (الطلبات والأوردرات)
CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    order_number TEXT NOT NULL,
    orderNumber TEXT,
    reference_number TEXT,
    referenceNumber TEXT,
    waybill_number TEXT,
    waybillNumber TEXT,
    tracking_url TEXT,
    trackingUrl TEXT,
    platform_order_id TEXT,
    platformOrderId TEXT,
    customer_name TEXT NOT NULL,
    customerName TEXT,
    customer_phone TEXT,
    customerPhone TEXT,
    customer_phone2 TEXT,
    customerPhone2 TEXT,
    customer_address TEXT,
    customerAddress TEXT,
    city TEXT,
    governorate TEXT,
    shipping_area TEXT,
    shippingArea TEXT,
    shipping_company TEXT,
    shippingCompany TEXT,
    status TEXT NOT NULL DEFAULT 'قيد_المراجعة',
    date TEXT NOT NULL,
    total_price NUMERIC NOT NULL DEFAULT 0,
    totalPrice NUMERIC DEFAULT 0,
    shipping_fee NUMERIC DEFAULT 0,
    shippingFee NUMERIC DEFAULT 0,
    flex_ship_fee NUMERIC DEFAULT 0,
    flexShipFee NUMERIC DEFAULT 0,
    flex_ship_company_fee NUMERIC DEFAULT 0,
    flexShipCompanyFee NUMERIC DEFAULT 0,
    enable_flex_ship BOOLEAN DEFAULT false,
    enableFlexShip BOOLEAN DEFAULT false,
    flex_ship_fee_paid_by_customer BOOLEAN DEFAULT false,
    flexShipFeePaidByCustomer BOOLEAN DEFAULT false,
    channel TEXT DEFAULT 'online',
    warehouse_id TEXT,
    warehouseId TEXT,
    payment_method TEXT,
    paymentMethod TEXT,
    payment_status TEXT,
    paymentStatus TEXT,
    preparation_status TEXT,
    preparationStatus TEXT,
    classification TEXT,
    notes TEXT,
    items JSONB DEFAULT '[]'::jsonb,
    details JSONB DEFAULT '{}'::jsonb,
    discount NUMERIC DEFAULT 0,
    tax NUMERIC DEFAULT 0,
    admin_fee NUMERIC DEFAULT 0,
    adminFee NUMERIC DEFAULT 0,
    insurance_fee NUMERIC DEFAULT 0,
    insuranceFee NUMERIC DEFAULT 0,
    inspection_fee NUMERIC DEFAULT 0,
    inspectionFee NUMERIC DEFAULT 0,
    weight NUMERIC DEFAULT 0,
    is_insured BOOLEAN DEFAULT false,
    isInsured BOOLEAN DEFAULT false,
    include_inspection_fee BOOLEAN DEFAULT false,
    includeInspectionFee BOOLEAN DEFAULT false,
    inspection_fee_paid_by_customer BOOLEAN DEFAULT false,
    inspectionFeePaidByCustomer BOOLEAN DEFAULT false,
    recorded_as_debt BOOLEAN DEFAULT false,
    recordedAsDebt BOOLEAN DEFAULT false,
    defer_payment_to_return BOOLEAN DEFAULT false,
    deferPaymentToReturn BOOLEAN DEFAULT false,
    return_cash_to_customer BOOLEAN DEFAULT false,
    returnCashToCustomer BOOLEAN DEFAULT false,
    cash_to_return_amount NUMERIC DEFAULT 0,
    cashToReturnAmount NUMERIC DEFAULT 0,
    credit_amount NUMERIC DEFAULT 0,
    creditAmount NUMERIC DEFAULT 0,
    total_amount_override NUMERIC,
    totalAmountOverride NUMERIC,
    total_amount_override_reason TEXT,
    totalAmountOverrideReason TEXT,
    order_type TEXT DEFAULT 'standard',
    orderType TEXT DEFAULT 'standard',
    shipment_type TEXT DEFAULT 'delivery',
    shipmentType TEXT DEFAULT 'delivery',
    original_order_id TEXT,
    originalOrderId TEXT,
    "advancePayment" NUMERIC DEFAULT 0,
    "advancePaymentPartnerId" TEXT,
    "advancePaymentTreasuryId" TEXT,
    "advancePaymentEmployeeId" TEXT,
    "advancePaymentRecipientPhone" TEXT,
    "advancePaymentSenderDetails" TEXT,
    "advancePaymentHistory" JSONB DEFAULT '[]'::jsonb,
    "createdBy" TEXT,
    "source" TEXT,
    "vatOnStandardShipping" BOOLEAN DEFAULT false,
    "confirmationLogs" JSONB DEFAULT '[]'::jsonb,
    "cancellationReason" TEXT,
    "followUpReminder" TEXT,
    "auditLogs" JSONB DEFAULT '[]'::jsonb,
    audit_logs JSONB DEFAULT '[]'::jsonb,
    "callAttempts" JSONB DEFAULT '[]'::jsonb,
    call_attempts JSONB DEFAULT '[]'::jsonb,
    "whatsappLogs" JSONB DEFAULT '[]'::jsonb,
    whatsapp_logs JSONB DEFAULT '[]'::jsonb,
    "whatsappStatus" TEXT,
    whatsapp_status TEXT,
    referral JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 5. TRANSACTIONS (الحركات المالية والمحفظة)
CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    type TEXT NOT NULL,
    amount NUMERIC NOT NULL DEFAULT 0,
    date TEXT NOT NULL,
    category TEXT,
    status TEXT DEFAULT 'completed',
    note TEXT,
    details JSONB DEFAULT '{}'::jsonb,
    fees NUMERIC DEFAULT 0,
    "orderId" TEXT,
    order_id TEXT,
    "orderNumber" TEXT,
    order_number TEXT,
    service TEXT,
    "treasuryAccountId" TEXT,
    treasury_account_id TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 6. SUPPLIERS (الموردين)
CREATE TABLE IF NOT EXISTS suppliers (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    notes TEXT,
    balance NUMERIC DEFAULT 0,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 7. SUPPLY_ORDERS (أوردرات الإمداد والمخزون)
CREATE TABLE IF NOT EXISTS supply_orders (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    supplier_id TEXT,
    supplierId TEXT,
    order_number TEXT,
    orderNumber TEXT,
    reference_number TEXT,
    referenceNumber TEXT,
    total_cost NUMERIC NOT NULL DEFAULT 0,
    totalCost NUMERIC DEFAULT 0,
    total_paid NUMERIC DEFAULT 0,
    totalPaid NUMERIC DEFAULT 0,
    discount NUMERIC DEFAULT 0,
    shipping_fees NUMERIC DEFAULT 0,
    shippingFees NUMERIC DEFAULT 0,
    other_fees NUMERIC DEFAULT 0,
    otherFees NUMERIC DEFAULT 0,
    tax_rate NUMERIC DEFAULT 0,
    taxRate NUMERIC DEFAULT 0,
    tax_amount NUMERIC DEFAULT 0,
    taxAmount NUMERIC DEFAULT 0,
    grand_total NUMERIC DEFAULT 0,
    grandTotal NUMERIC DEFAULT 0,
    date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'مكتمل',
    items JSONB DEFAULT '[]'::jsonb,
    notes TEXT,
    details JSONB DEFAULT '{}'::jsonb,
    attachment_url TEXT,
    attachmentUrl TEXT,
    treasury_account_id TEXT,
    treasuryAccountId TEXT,
    warehouse_id TEXT,
    warehouseId TEXT,
    partner_id TEXT,
    partnerId TEXT,
    payment_method TEXT,
    paymentMethod TEXT,
    "treasuryPayments" JSONB DEFAULT '[]'::jsonb,
    "custodyPayments" JSONB DEFAULT '[]'::jsonb,
    "partnerPayments" JSONB DEFAULT '[]'::jsonb,
    "distributeExpensesEqually" BOOLEAN DEFAULT false,
    "recordExpensesFormally" BOOLEAN DEFAULT false,
    "shippingFeesNote" TEXT,
    "otherFeesNote" TEXT,
    "expensePaidBy" TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 8. REVIEWS (مراجعات وآراء العملاء)
CREATE TABLE IF NOT EXISTS reviews (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    product_id TEXT,
    productId TEXT,
    customer_name TEXT,
    customerName TEXT,
    rating NUMERIC DEFAULT 5,
    comment TEXT,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 9. ABANDONED_CARTS (السلات المتروكة)
CREATE TABLE IF NOT EXISTS abandoned_carts (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    customer_name TEXT,
    customerName TEXT,
    customer_phone TEXT,
    customerPhone TEXT,
    total_value NUMERIC DEFAULT 0,
    totalValue NUMERIC DEFAULT 0,
    date TEXT,
    items JSONB DEFAULT '[]'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 10. ACTIVITY_LOGS (سجل الحركات العام)
CREATE TABLE IF NOT EXISTS activity_logs (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    "user" TEXT,
    user_name TEXT,
    userName TEXT,
    action TEXT NOT NULL,
    details TEXT,
    timestamp NUMERIC,
    date TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 11. EMPLOYEES (الموظفون وصلاحياتهم)
CREATE TABLE IF NOT EXISTS employees (
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    phone TEXT NOT NULL,
    name TEXT,
    email TEXT,
    permissions JSONB DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT,
    PRIMARY KEY (store_id, phone)
);

-- 12. DISCOUNT_CODES (أكواد الخصم)
CREATE TABLE IF NOT EXISTS discount_codes (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    code TEXT NOT NULL,
    discount_type TEXT NOT NULL DEFAULT 'percentage',
    discountType TEXT DEFAULT 'percentage',
    value NUMERIC NOT NULL DEFAULT 0,
    usage_limit NUMERIC,
    usageLimit TEXT,
    usage_count NUMERIC DEFAULT 0,
    usageCount NUMERIC DEFAULT 0,
    expiration_date TEXT,
    expirationDate TEXT,
    is_active BOOLEAN DEFAULT true,
    isActive BOOLEAN DEFAULT true,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 13. COLLECTIONS (التصنيفات والمجموعات)
CREATE TABLE IF NOT EXISTS collections (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    description TEXT,
    image_url TEXT,
    imageUrl TEXT,
    is_active BOOLEAN DEFAULT true,
    isActive BOOLEAN DEFAULT true,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 14. CUSTOM_PAGES (الصفحات المخصصة)
CREATE TABLE IF NOT EXISTS custom_pages (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL,
    content TEXT,
    is_active BOOLEAN DEFAULT true,
    isActive BOOLEAN DEFAULT true,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 15. PAYMENT_METHODS (طرق الدفع المفعلة)
CREATE TABLE IF NOT EXISTS payment_methods (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    logo_url TEXT,
    logoUrl TEXT,
    is_active BOOLEAN DEFAULT true,
    isActive BOOLEAN DEFAULT true,
    details JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 16. CUSTOMERS (بيانات العملاء وتقييمات الولاء)
CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT,
    city TEXT,
    governorate TEXT,
    loyalty_points NUMERIC DEFAULT 0,
    loyaltyPoints NUMERIC DEFAULT 0,
    total_spent NUMERIC DEFAULT 0,
    totalSpent NUMERIC DEFAULT 0,
    total_orders NUMERIC DEFAULT 0,
    totalOrders NUMERIC DEFAULT 0,
    successful_orders NUMERIC DEFAULT 0,
    successfulOrders NUMERIC DEFAULT 0,
    returned_orders NUMERIC DEFAULT 0,
    returnedOrders NUMERIC DEFAULT 0,
    average_order_value NUMERIC DEFAULT 0,
    averageOrderValue NUMERIC DEFAULT 0,
    shipping_fee NUMERIC DEFAULT 0,
    shippingFee NUMERIC DEFAULT 0,
    first_order_date TEXT,
    firstOrderDate TEXT,
    last_order_date TEXT,
    lastOrderDate TEXT,
    notes TEXT,
    debt_balance NUMERIC DEFAULT 0,
    debtBalance NUMERIC DEFAULT 0,
    debt_history JSONB DEFAULT '[]'::jsonb,
    debtHistory JSONB DEFAULT '[]'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 17. GLOBAL_OPTIONS (خيارات الضبط العام للمتجر)
CREATE TABLE IF NOT EXISTS global_options (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    key TEXT NOT NULL,
    value TEXT,
    is_active BOOLEAN DEFAULT true,
    isActive BOOLEAN DEFAULT true,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 18. SHIPPING_INTEGRATIONS (تكاملات شركات الشحن والدليفري)
CREATE TABLE IF NOT EXISTS shipping_integrations (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    provider TEXT NOT NULL,
    api_key TEXT,
    apiKey TEXT,
    api_secret TEXT,
    apiSecret TEXT,
    account_number TEXT,
    accountNumber TEXT,
    is_connected BOOLEAN DEFAULT false,
    isConnected BOOLEAN DEFAULT false,
    details JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 19. DOCUMENTS (أرشيف المستندات والفواتير)
CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    content JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 20. TREASURY_ACCOUNTS (خزائن وحسابات السيولة المالية)
CREATE TABLE IF NOT EXISTS treasury_accounts (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'safe',
    balance NUMERIC DEFAULT 0,
    currency TEXT DEFAULT 'EGP',
    account_number TEXT,
    accountNumber TEXT,
    beneficiary_name TEXT,
    beneficiaryName TEXT,
    bank_name TEXT,
    bankName TEXT,
    wallet_number TEXT,
    walletNumber TEXT,
    wallet_name TEXT,
    walletName TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 21. TREASURY_TRANSACTIONS (الحركات المالية للخزينة)
CREATE TABLE IF NOT EXISTS treasury_transactions (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    date TEXT NOT NULL,
    from_account_id TEXT,
    fromAccountId TEXT,
    to_account_id TEXT,
    toAccountId TEXT,
    amount NUMERIC NOT NULL DEFAULT 0,
    type TEXT NOT NULL,
    description TEXT,
    reference TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 22. PARTNERS (بيانات الشركاء وحصص رأس المال)
CREATE TABLE IF NOT EXISTS partners (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    passcode TEXT,
    password TEXT,
    require_email_otp BOOLEAN DEFAULT false,
    "requireEmailOtp" BOOLEAN DEFAULT false,
    is_email_verified BOOLEAN DEFAULT false,
    "isEmailVerified" BOOLEAN DEFAULT false,
    email_verified_at TEXT,
    "emailVerifiedAt" TEXT,
    last_login_at TEXT,
    "lastLoginAt" TEXT,
    notes TEXT,
    balance NUMERIC DEFAULT 0,
    profit_ratio NUMERIC DEFAULT 0,
    profitRatio NUMERIC DEFAULT 0,
    capital NUMERIC DEFAULT 0,
    initial_capital NUMERIC DEFAULT 0,
    initialCapital NUMERIC DEFAULT 0,
    details JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 23. PARTNER_TRANSACTIONS (الحركات والمسحوبات مع الشركاء)
CREATE TABLE IF NOT EXISTS partner_transactions (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    partner_id TEXT,
    partnerId TEXT,
    partner_name TEXT,
    partnerName TEXT,
    treasury_account_id TEXT,
    treasuryAccountId TEXT,
    order_id TEXT,
    orderId TEXT,
    order_number TEXT,
    orderNumber TEXT,
    type TEXT NOT NULL,
    amount NUMERIC NOT NULL DEFAULT 0,
    date TEXT NOT NULL,
    note TEXT,
    notes TEXT,
    description TEXT,
    category TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 24. CHAT_MESSAGES (سجل المحادثات ورسائل الدعم)
CREATE TABLE IF NOT EXISTS chat_messages (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    sender_id TEXT NOT NULL,
    senderId TEXT,
    receiver_id TEXT NOT NULL,
    receiverId TEXT,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    isRead BOOLEAN DEFAULT false,
    is_file BOOLEAN DEFAULT false,
    isFile BOOLEAN DEFAULT false,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 25. WAREHOUSES (المخازن والمستودعات)
CREATE TABLE IF NOT EXISTS warehouses (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    name TEXT NOT NULL,
    location TEXT,
    is_default BOOLEAN DEFAULT false,
    isDefault BOOLEAN DEFAULT false,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 26. INVENTORY_AUDITS (جلسات جرد المخزون)
CREATE TABLE IF NOT EXISTS inventory_audits (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    performed_by TEXT,
    performedBy TEXT,
    scope TEXT,
    warehouse_id TEXT,
    warehouseId TEXT,
    total_system_qty NUMERIC DEFAULT 0,
    totalSystemQty NUMERIC DEFAULT 0,
    total_actual_qty NUMERIC DEFAULT 0,
    totalActualQty NUMERIC DEFAULT 0,
    total_variance_qty NUMERIC DEFAULT 0,
    totalVarianceQty NUMERIC DEFAULT 0,
    total_variance_value NUMERIC DEFAULT 0,
    totalVarianceValue NUMERIC DEFAULT 0,
    total_items_audited NUMERIC DEFAULT 0,
    totalItemsAudited NUMERIC DEFAULT 0,
    timestamp BIGINT,
    discrepancies JSONB DEFAULT '[]'::jsonb,
    notes TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 27. STOCK_TRANSFERS (تحويلات المخزون بين المستودعات)
CREATE TABLE IF NOT EXISTS stock_transfers (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    transfer_number TEXT NOT NULL,
    transferNumber TEXT,
    date TEXT NOT NULL,
    source_warehouse_id TEXT,
    sourceWarehouseId TEXT,
    destination_warehouse_id TEXT,
    destinationWarehouseId TEXT,
    items JSONB DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'مكتمل',
    notes TEXT,
    performed_by TEXT,
    performedBy TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 28. ORDER_RETURNS (مرتجعات طلبات البيع)
CREATE TABLE IF NOT EXISTS order_returns (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    return_number TEXT NOT NULL,
    returnNumber TEXT,
    order_id TEXT,
    orderId TEXT,
    order_number TEXT,
    orderNumber TEXT,
    date TEXT NOT NULL,
    items JSONB DEFAULT '[]'::jsonb,
    total_refund NUMERIC DEFAULT 0,
    totalRefund NUMERIC DEFAULT 0,
    reason TEXT,
    warehouse_id TEXT,
    warehouseId TEXT,
    restock_items BOOLEAN DEFAULT true,
    restockItems BOOLEAN DEFAULT true,
    status TEXT NOT NULL DEFAULT 'مكتمل',
    performed_by TEXT,
    performedBy TEXT,
    notes TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 29. PURCHASE_RETURNS (مرتجعات طلبات الشراء من الموردين)
CREATE TABLE IF NOT EXISTS purchase_returns (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    return_number TEXT NOT NULL,
    returnNumber TEXT,
    supplier_id TEXT,
    supplierId TEXT,
    supplier_name TEXT,
    supplierName TEXT,
    date TEXT NOT NULL,
    items JSONB DEFAULT '[]'::jsonb,
    total_refund_amount NUMERIC DEFAULT 0,
    totalRefundAmount NUMERIC DEFAULT 0,
    warehouse_id TEXT,
    warehouseId TEXT,
    status TEXT NOT NULL DEFAULT 'مكتمل',
    notes TEXT,
    performed_by TEXT,
    performedBy TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 30. POS_SALES (مبيعات الكاشير ونقاط البيع)
CREATE TABLE IF NOT EXISTS pos_sales (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    sale_number TEXT NOT NULL,
    saleNumber TEXT,
    date TEXT NOT NULL,
    items JSONB DEFAULT '[]'::jsonb,
    total_amount NUMERIC DEFAULT 0,
    totalAmount NUMERIC DEFAULT 0,
    payment_method TEXT,
    paymentMethod TEXT,
    warehouse_id TEXT,
    warehouseId TEXT,
    customer_phone TEXT,
    customerPhone TEXT,
    customer_name TEXT,
    customerName TEXT,
    customer_address TEXT,
    customerAddress TEXT,
    performed_by TEXT,
    performedBy TEXT,
    cash_holder_id TEXT,
    cashHolderId TEXT,
    cash_holder_name TEXT,
    cashHolderName TEXT,
    notes TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 31. CASH_HOLDERS (عهد الكاشير والمناديب)
CREATE TABLE IF NOT EXISTS cash_holders (
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    user_id TEXT NOT NULL,
    userId TEXT,
    user_name TEXT,
    userName TEXT,
    current_balance NUMERIC DEFAULT 0,
    currentBalance NUMERIC DEFAULT 0,
    last_updated TEXT,
    lastUpdated TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT,
    PRIMARY KEY (store_id, user_id)
);

-- 32. CASH_HANDOVERS (تسليمات العهد النقدية)
CREATE TABLE IF NOT EXISTS cash_handovers (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    from_user_id TEXT,
    fromUserId TEXT,
    from_user_name TEXT,
    fromUserName TEXT,
    to_user_id TEXT,
    toUserId TEXT,
    to_user_name TEXT,
    toUserName TEXT,
    amount NUMERIC NOT NULL DEFAULT 0,
    date TEXT NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'approved',
    is_virtual BOOLEAN DEFAULT FALSE,
    isVirtual BOOLEAN DEFAULT FALSE,
    order_number TEXT,
    orderNumber TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 33. WHATSAPP_TEMPLATES (قوالب رسائل الواتساب)
CREATE TABLE IF NOT EXISTS whatsapp_templates (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    label TEXT NOT NULL,
    text TEXT NOT NULL,
    footer TEXT,
    buttons JSONB DEFAULT '[]'::jsonb,
    details JSONB DEFAULT '{}'::jsonb,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 33b. WEBHOOK_LOGS (سجلات استقبال الواتساب والويب هوك)
CREATE TABLE IF NOT EXISTS webhook_logs (
    id TEXT PRIMARY KEY,
    store_id TEXT,
    storeId TEXT,
    source TEXT,
    event TEXT,
    payload JSONB DEFAULT '{}'::jsonb,
    status TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 34. CALL_SCRIPTS (قوالب سيناريو المكالمات)
CREATE TABLE IF NOT EXISTS call_scripts (
    id TEXT PRIMARY KEY,
    store_id TEXT REFERENCES stores_data(id) ON DELETE CASCADE,
    storeId TEXT,
    title TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 35. CUSTOMER_TRANSACTIONS (سجل حركات مديونيات العملاء)
CREATE TABLE IF NOT EXISTS customer_transactions (
    id TEXT PRIMARY KEY,
    store_id TEXT,
    storeId TEXT,
    customer_id TEXT,
    customerId TEXT,
    date TEXT,
    amount NUMERIC DEFAULT 0,
    type TEXT,
    note TEXT,
    order_id TEXT,
    orderId TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 36. SUPPLIER_TRANSACTIONS (سجل حركات مديونيات الموردين)
CREATE TABLE IF NOT EXISTS supplier_transactions (
    id TEXT PRIMARY KEY,
    store_id TEXT,
    storeId TEXT,
    supplier_id TEXT,
    supplierId TEXT,
    date TEXT,
    amount NUMERIC DEFAULT 0,
    type TEXT,
    note TEXT,
    order_id TEXT,
    orderId TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 37. SHARED_AUDITS (جلسات الجرد السحابي المشترك)
CREATE TABLE IF NOT EXISTS shared_audits (
    id TEXT PRIMARY KEY,
    store_id TEXT,
    storeId TEXT,
    title TEXT,
    warehouse_id TEXT,
    warehouseId TEXT,
    warehouse_name TEXT,
    warehouseName TEXT,
    protocol TEXT,
    is_protocol_locked BOOLEAN DEFAULT false,
    isProtocolLocked BOOLEAN DEFAULT false,
    status TEXT,
    passcode TEXT,
    manager_name TEXT,
    managerName TEXT,
    manager_id TEXT,
    managerId TEXT,
    items JSONB DEFAULT '[]'::jsonb,
    logs JSONB DEFAULT '[]'::jsonb,
    assignments JSONB DEFAULT '[]'::jsonb,
    presence JSONB DEFAULT '{}'::jsonb,
    conflicts JSONB DEFAULT '[]'::jsonb,
    draft_counts JSONB DEFAULT '{}'::jsonb,
    draftCounts JSONB DEFAULT '{}'::jsonb,
    draft_notes JSONB DEFAULT '{}'::jsonb,
    draftNotes JSONB DEFAULT '{}'::jsonb,
    locks JSONB DEFAULT '{}'::jsonb,
    last_saved_at TEXT,
    lastSavedAt TEXT,
    unlock_reason TEXT,
    unlockReason TEXT,
    unlocked_by TEXT,
    unlockedBy TEXT,
    unlocked_at TEXT,
    unlockedAt TEXT,
    notes TEXT,
    signature_data TEXT,
    signatureData TEXT,
    is_blind_count BOOLEAN DEFAULT false,
    isBlindCount BOOLEAN DEFAULT false,
    worker_signature TEXT,
    workerSignature TEXT,
    manager_signature TEXT,
    managerSignature TEXT,
    reject_reason TEXT,
    rejectReason TEXT,
    progress NUMERIC,
    accuracy_score NUMERIC,
    accuracyScore NUMERIC,
    health_score NUMERIC,
    healthScore NUMERIC,
    submitted_at TEXT,
    submittedAt TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 38. WITHDRAWAL_REQUESTS (طلبات سحب الرصيد والسيولة)
CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id TEXT PRIMARY KEY,
    store_id TEXT,
    storeId TEXT,
    amount NUMERIC NOT NULL DEFAULT 0,
    date TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    method TEXT,
    details TEXT,
    fee NUMERIC DEFAULT 0,
    net_amount NUMERIC,
    netAmount NUMERIC,
    is_same_day BOOLEAN DEFAULT false,
    isSameDay BOOLEAN DEFAULT false,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- 39. QUOTATIONS (عروض الأسعار)
CREATE TABLE IF NOT EXISTS quotations (
    id TEXT PRIMARY KEY,
    store_id TEXT,
    storeId TEXT,
    quotation_number TEXT,
    quotationNumber TEXT,
    customer_name TEXT,
    customerName TEXT,
    customer_phone TEXT,
    customerPhone TEXT,
    customer_phone2 TEXT,
    customerPhone2 TEXT,
    customer_email TEXT,
    customerEmail TEXT,
    customer_address TEXT,
    customerAddress TEXT,
    governorate TEXT,
    city TEXT,
    building_number TEXT,
    buildingNumber TEXT,
    floor_number TEXT,
    floorNumber TEXT,
    apartment_number TEXT,
    apartmentNumber TEXT,
    items JSONB DEFAULT '[]'::jsonb,
    subtotal NUMERIC DEFAULT 0,
    discount NUMERIC DEFAULT 0,
    shipping_fee NUMERIC DEFAULT 0,
    shippingFee NUMERIC DEFAULT 0,
    tax NUMERIC DEFAULT 0,
    total NUMERIC DEFAULT 0,
    advance_payment NUMERIC DEFAULT 0,
    advancePayment NUMERIC DEFAULT 0,
    remaining_amount NUMERIC DEFAULT 0,
    remainingAmount NUMERIC DEFAULT 0,
    shipping_company TEXT,
    shippingCompany TEXT,
    shipping_area TEXT,
    shippingArea TEXT,
    include_inspection_fee BOOLEAN DEFAULT false,
    includeInspectionFee BOOLEAN DEFAULT false,
    status TEXT DEFAULT 'مسودة',
    notes TEXT,
    terms TEXT,
    valid_until TEXT,
    validUntil TEXT,
    created_at TEXT,
    createdAt TEXT,
    updated_at TEXT,
    updatedAt TEXT
);

-- =========================================================================
-- تعطيل نظام الحماية RLS لجميع الجداول (لتسهيل وسرعة المزامنة بدون أخطاء)
-- =========================================================================
ALTER TABLE stores_data DISABLE ROW LEVEL SECURITY;
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE products DISABLE ROW LEVEL SECURITY;
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers DISABLE ROW LEVEL SECURITY;
ALTER TABLE supply_orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE reviews DISABLE ROW LEVEL SECURITY;
ALTER TABLE abandoned_carts DISABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs DISABLE ROW LEVEL SECURITY;
ALTER TABLE employees DISABLE ROW LEVEL SECURITY;
ALTER TABLE discount_codes DISABLE ROW LEVEL SECURITY;
ALTER TABLE collections DISABLE ROW LEVEL SECURITY;
ALTER TABLE custom_pages DISABLE ROW LEVEL SECURITY;
ALTER TABLE payment_methods DISABLE ROW LEVEL SECURITY;
ALTER TABLE customers DISABLE ROW LEVEL SECURITY;
ALTER TABLE global_options DISABLE ROW LEVEL SECURITY;
ALTER TABLE shipping_integrations DISABLE ROW LEVEL SECURITY;
ALTER TABLE documents DISABLE ROW LEVEL SECURITY;
ALTER TABLE treasury_accounts DISABLE ROW LEVEL SECURITY;
ALTER TABLE treasury_transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE partners DISABLE ROW LEVEL SECURITY;
ALTER TABLE partner_transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE warehouses DISABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_audits DISABLE ROW LEVEL SECURITY;
ALTER TABLE stock_transfers DISABLE ROW LEVEL SECURITY;
ALTER TABLE order_returns DISABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_returns DISABLE ROW LEVEL SECURITY;
ALTER TABLE pos_sales DISABLE ROW LEVEL SECURITY;
ALTER TABLE cash_holders DISABLE ROW LEVEL SECURITY;
ALTER TABLE cash_handovers DISABLE ROW LEVEL SECURITY;
ALTER TABLE whatsapp_templates DISABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_logs DISABLE ROW LEVEL SECURITY;
ALTER TABLE call_scripts DISABLE ROW LEVEL SECURITY;
ALTER TABLE customer_transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE supplier_transactions DISABLE ROW LEVEL SECURITY;
ALTER TABLE shared_audits DISABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawal_requests DISABLE ROW LEVEL SECURITY;
ALTER TABLE quotations DISABLE ROW LEVEL SECURITY;

-- منح كامل الصلاحيات لجميع المفاتيح (anon, authenticated, service_role)
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated, service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated, service_role;
`;

interface DeveloperSettingsPageProps {
  settings: Settings;
  setSettings: React.Dispatch<React.SetStateAction<Settings>>;
  activeStoreId?: string | null;
  activeStore?: Store;
  hostUrl?: string;
  forcePullFromCloud?: () => Promise<{ success: boolean; error?: string }>;
  forceSync?: () => Promise<void>;
  saveStatus?: string;
  saveMessage?: string;
  allStoresData: any;
  setAllStoresData: (updater: any) => void;
}

const DeveloperSettingsPage: React.FC<DeveloperSettingsPageProps> = ({ 
  settings, 
  setSettings, 
  activeStoreId, 
  activeStore,
  hostUrl,
  forcePullFromCloud,
  forceSync,
  saveStatus,
  saveMessage,
  allStoresData,
  setAllStoresData
}) => {
  const [integrations, setIntegrations] = useState<WebhookIntegration[]>(settings.webhookIntegrations || []);
  const [dbSyncMode, setDbSyncMode] = useState<string>(() => localStorage.getItem('dbSyncMode') || 'auto');
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [log, setLog] = useState<string>('');
  const [syncPreview, setSyncPreview] = useState<{
    customers: any[];
    treasury: any[];
    wallet: any[];
    storeId: string;
  } | null>(null);
  const [activeTab, setActiveTab] = useState<'database' | 'security' | 'mail' | 'webhooks' | 'apikeys' | 'logs' | 'platforms'>('database');

  // Central Mail Configuration State
  const [mailProvider, setMailProvider] = useState<'resend' | 'brevo' | 'gmail' | 'smtp'>('resend');
  const [mailFrom, setMailFrom] = useState('onboarding@resend.dev');
  const [mailResendKey, setMailResendKey] = useState('');
  const [mailBrevoKey, setMailBrevoKey] = useState('');
  const [mailSmtpHost, setMailSmtpHost] = useState('smtp.gmail.com');
  const [mailSmtpPort, setMailSmtpPort] = useState('587');
  const [mailSmtpUser, setMailSmtpUser] = useState('');
  const [mailSmtpPass, setMailSmtpPass] = useState('');
  const [isSavingMail, setIsSavingMail] = useState(false);
  const [mailStatusMsg, setMailStatusMsg] = useState<{ text: string; isError: boolean } | null>(null);
  const [testEmailRecipient, setTestEmailRecipient] = useState('');
  const [isSendingTestMail, setIsSendingTestMail] = useState(false);
  const [testMailResult, setTestMailResult] = useState<{ text: string; isError: boolean } | null>(null);
  const [isMailConfigured, setIsMailConfigured] = useState(false);

  useEffect(() => {
    fetch('/api/smtp-config')
      .then(res => res.json())
      .then(data => {
        if (data) {
          if (data.provider) setMailProvider(data.provider);
          if (data.from) setMailFrom(data.from);
          if (data.configured) setIsMailConfigured(true);
        }
      })
      .catch(() => {});
  }, []);

  const handleSaveMailConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingMail(true);
    setMailStatusMsg(null);
    try {
      const payload: any = {
        provider: mailProvider,
        from: mailFrom.trim(),
        user: mailSmtpUser.trim() || mailFrom.trim()
      };

      if (mailProvider === 'resend') {
        payload.resendApiKey = mailResendKey.trim();
      } else if (mailProvider === 'brevo') {
        payload.brevoApiKey = mailBrevoKey.trim();
      } else if (mailProvider === 'gmail') {
        payload.host = 'smtp.gmail.com';
        payload.port = 587;
        payload.pass = mailSmtpPass.trim();
      } else {
        payload.host = mailSmtpHost.trim();
        payload.port = Number(mailSmtpPort) || 587;
        payload.pass = mailSmtpPass.trim();
      }

      const res = await fetch('/api/save-smtp-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setIsMailConfigured(true);
        setMailStatusMsg({ text: 'تم حفظ وتفعيل خادم البريد المركزي للنظام بنجاح!', isError: false });
      } else {
        setMailStatusMsg({ text: data.error || 'فشل حفظ إعدادات البريد.', isError: true });
      }
    } catch (err: any) {
      setMailStatusMsg({ text: err?.message || 'خطأ في الاتصال بالخادم.', isError: true });
    } finally {
      setIsSavingMail(false);
    }
  };

  const handleSendTestMail = async () => {
    if (!testEmailRecipient || !testEmailRecipient.includes('@')) {
      setTestMailResult({ text: 'يرجى إدخال بريد إلكتروني صالح للتجربة.', isError: true });
      return;
    }
    setIsSendingTestMail(true);
    setTestMailResult(null);
    try {
      const res = await fetch('/api/send-account-activation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: testEmailRecipient.trim(),
          userName: 'تجربة خادم البريد',
          activationCode: '123456'
        })
      });
      const data = await res.json();
      if (data.success || data.delivered) {
        setTestMailResult({ 
          text: `تم إرسال رسالة الاختبار بنجاح إلى (${data.recipient || testEmailRecipient})! ${data.note || ''}`, 
          isError: false 
        });
      } else {
        setTestMailResult({ text: data.error || 'فشل إرسال رسالة الاختبار. يرجى مراجعة بيانات الاعتماد.', isError: true });
      }
    } catch (err: any) {
      setTestMailResult({ text: err.message || 'خطأ أثناء الإرسال.', isError: true });
    } finally {
      setIsSendingTestMail(false);
    }
  };

  const handleFixFlexShipSchema = () => {
    const shippingFixSql = `
-- ==========================================================
-- كود مخصص لإصلاح وتحديث جميع أعمدة شركات الشحن (بوسطة، flexShip، وغيرها)
-- يشمل إصلاح أعمدة apiKey, isConnected, apiSecret, accountNumber
-- ==========================================================

-- 1. جدول تكاملات الشحن (shipping_integrations)
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "apiKey" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS api_key TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "apiSecret" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS api_secret TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "accountNumber" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS account_number TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "isConnected" BOOLEAN DEFAULT false;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS is_connected BOOLEAN DEFAULT false;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS provider TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "created_at" TEXT;

-- 2. جدول الطلبات (orders) - إضافة جميع أعمدة الشحن و flexShip
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shippingCompany" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shipping_company" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shippingFee" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shipping_fee" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "flexShipFee" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "flexShipCompanyFee" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "enableFlexShip" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "flexShipFeePaidByCustomer" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "vatOnStandardShipping" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shippingArea" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shipmentType" TEXT DEFAULT 'delivery';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerAddress" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "city" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "governorate" TEXT;

-- تعطيل حماية RLS لضمان المزامنة السريعة
ALTER TABLE shipping_integrations DISABLE ROW LEVEL SECURITY;
`;
    navigator.clipboard.writeText(shippingFixSql.trim());
    triggerAlarm("🚀 تم نسخ كود SQL لإصلاح أعمدة شركات الشحن (apiKey, isConnected, flexShip) بنجاح! الصقه في Supabase SQL Editor واضغط Run لحل المشكلة فوراً.", 'success', 'إصلاح أعمدة الشحن وبوسطة');
  };

  const handleApplySync = () => {
    if (!syncPreview) return;
    const { storeId, customers, treasury, wallet } = syncPreview;
    const storeData = allStoresData[storeId];
    if (!storeData) return;

    const selectedCustomersCount = customers.filter(c => c.selected).length;
    const selectedTreasuryCount = treasury.filter(t => t.selected).length;
    const selectedWalletCount = wallet.filter(w => w.selected).length;

    if (selectedCustomersCount === 0 && selectedTreasuryCount === 0 && selectedWalletCount === 0) {
      alert('يرجى اختيار تغيير واحد على الأقل لتطبيقه.');
      return;
    }

    // Apply customer changes
    const updatedCustomers = (storeData.customers || []).map((c: any) => {
      const change = customers.find(ch => ch.id === c.id && ch.selected);
      if (change) {
        return { ...c, debtBalance: change.newBalance };
      }
      return c;
    });

    // Apply treasury changes
    const originalTreasury = storeData.treasury || { accounts: [], transactions: [] };
    const updatedAccounts = originalTreasury.accounts.map((acc: any) => {
      const change = treasury.find(ch => ch.id === acc.id && ch.selected);
      if (change) {
        return { ...acc, balance: change.newBalance };
      }
      return acc;
    });

    // Apply wallet changes
    let originalWallet = storeData.wallet || { balance: 0, transactions: [] };
    let updatedWalletBalance = originalWallet.balance;
    let updatedWalletTxs = [...(originalWallet.transactions || [])];

    // Handle wallet balance fix
    const balanceFix = wallet.find(w => w.id === 'wallet_balance' && w.selected);
    if (balanceFix) {
      updatedWalletBalance = balanceFix.newBalance;
    }

    // Handle transaction removals (sort by index descending to avoid index shifts)
    const txRemovals = wallet
      .filter(w => w.type === 'tx_remove' && w.selected)
      .sort((a, b) => b.txIndex - a.txIndex);
    
    txRemovals.forEach(rem => {
      updatedWalletTxs.splice(rem.txIndex, 1);
    });

    setAllStoresData((prev: any) => ({
      ...prev,
      [storeId]: {
        ...prev[storeId],
        customers: updatedCustomers,
        treasury: { ...originalTreasury, accounts: updatedAccounts },
        wallet: { ...originalWallet, balance: updatedWalletBalance, transactions: updatedWalletTxs }
      }
    }));

    setLog(prev => prev + `✅ تمت معالجة ${selectedCustomersCount + selectedTreasuryCount + selectedWalletCount} تغيير مختار بنجاح.\n`);
    setSyncPreview(null);
  };

  const handleFixDBSchema = () => {
    const instructions = `
-- انسخ هذا الكود والصقه في SQL Editor في Supabase
-- لإصلاح وإضافة جميع الأعمدة المفقودة في جميع الجداول لضمان عدم ضياع أو اختفاء أي بيانات

-- 1. جدول الطلبات (orders) - إضافة جميع الأعمدة المفقودة وحل مشكلة اختفاء المنتجات والبيانات
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "items" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePayment" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePaymentPartnerId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePaymentTreasuryId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePaymentEmployeeId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePaymentRecipientPhone" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePaymentSenderDetails" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "advancePaymentHistory" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "createdBy" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "source" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "vatOnStandardShipping" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerPhone" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customer_phone" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerPhone2" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shippingCompany" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shipping_company" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shippingFee" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shipping_fee" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "flexShipFee" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "flexShipCompanyFee" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "enableFlexShip" BOOLEAN;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "flexShipFeePaidByCustomer" BOOLEAN;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "channel" TEXT DEFAULT 'online';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "warehouseId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "warehouse_id" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "customerAddress" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "city" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "governorate" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shippingArea" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "paymentMethod" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "paymentStatus" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "discount" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "isInsured" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "includeInspectionFee" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "inspectionFeePaidByCustomer" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "recordedAsDebt" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "deferPaymentToReturn" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "returnCashToCustomer" BOOLEAN DEFAULT false;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "cashToReturnAmount" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "creditAmount" NUMERIC DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "totalAmountOverride" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "totalAmountOverrideReason" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "orderType" TEXT DEFAULT 'standard';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "shipmentType" TEXT DEFAULT 'delivery';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "maintenanceCost" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "maintenanceItemDescription" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "maintenanceItemSerial" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "maintenanceItemValue" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "maintenanceTechnicalReport" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "maintenanceStatus" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "originalOrderId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "exchangeDifference" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "returnProductValue" NUMERIC;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "returnTrackingNumber" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "whatsappLogs" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "whatsapp_logs" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "whatsappStatus" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "whatsapp_status" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "auditLogs" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "audit_logs" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "callAttempts" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "call_attempts" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "referral" JSONB DEFAULT '{}'::jsonb;

-- 2. جدول المنتجات (products)
ALTER TABLE products ADD COLUMN IF NOT EXISTS "min_stock_level" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "minStockLevel" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "stock_quantity" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "stockQuantity" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "last_audited" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "lastAudited" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "expiry_date" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "expiryDate" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "warehouseStock" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "profitMode" TEXT DEFAULT 'manual';
ALTER TABLE products ADD COLUMN IF NOT EXISTS "basePrice" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "profitPercentage" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "commissionPercentage" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "stockThreshold" NUMERIC DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "sku" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "storeId" TEXT;

-- 3. جدول المستخدمين (users)
ALTER TABLE users ADD COLUMN IF NOT EXISTS "full_name" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "fullName" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "is_admin" BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "isAdmin" BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "is_banned" BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "isBanned" BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "join_date" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "joinDate" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "email" TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "stores" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS "sites" JSONB DEFAULT '[]'::jsonb;

-- 4. جدول الموظفين (employees)
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "name" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "email" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "permissions" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "status" TEXT;

-- 5. جدول أوامر الإمداد (supply_orders)
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "distributeExpensesEqually" BOOLEAN DEFAULT false;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "recordExpensesFormally" BOOLEAN DEFAULT false;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "shippingFeesNote" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "otherFeesNote" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "expensePaidBy" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "supplier_id" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "supplierId" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "total_cost" NUMERIC;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "totalCost" NUMERIC;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "status" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "date" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "items" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "storeId" TEXT;

-- 6. جدول العملاء (customers)
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "debtBalance" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "debtHistory" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "balance" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "loyalty_points" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "loyaltyPoints" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "total_spent" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "totalSpent" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "first_order_date" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "firstOrderDate" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "last_order_date" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "lastOrderDate" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "address" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "email" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "tags" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "storeId" TEXT;

-- 6.1 جدول الموردين (suppliers)
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "name" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "phone" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "address" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "balance" NUMERIC DEFAULT 0;

-- 10. جدول أوامر التوريد المفقودة (supply_orders)
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "orderNumber" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "referenceNumber" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "partnerId" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "partnerPayments" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "treasuryPayments" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "custodyPayments" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "paymentMethod" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "shippingFees" NUMERIC DEFAULT 0;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "otherFees" NUMERIC DEFAULT 0;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "discount" NUMERIC DEFAULT 0;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "taxRate" NUMERIC DEFAULT 0;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "taxAmount" NUMERIC DEFAULT 0;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "grandTotal" NUMERIC DEFAULT 0;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "attachmentUrl" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "cashHolderId" TEXT;

ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "category" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "creditLimit" NUMERIC DEFAULT 0;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "taxNumber" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "bankAccount" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "rating" NUMERIC;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "tier" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "storeId" TEXT;

-- 7. جدول مبيعات الكاشير (pos_sales)
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "cashHolderId" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "cashHolderName" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "cash_holder_id" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "cash_holder_name" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "sale_number" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "saleNumber" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "total_amount" NUMERIC;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "totalAmount" NUMERIC;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "payment_method" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "paymentMethod" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "warehouse_id" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "warehouseId" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customer_phone" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customerPhone" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customer_name" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customerName" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customer_address" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customerAddress" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "performed_by" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "performedBy" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "storeId" TEXT;

-- 8. جدول تسليمات العهد (cash_handovers)
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "fromUserId" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "from_user_id" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "fromUserName" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "from_user_name" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "toUserId" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "to_user_id" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "toUserName" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "to_user_name" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "amount" NUMERIC;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "date" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "status" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "isVirtual" BOOLEAN DEFAULT FALSE;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "is_virtual" BOOLEAN DEFAULT FALSE;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "orderNumber" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "order_number" TEXT;

-- 9. جداول الحركات والمديونيات الجديدة
CREATE TABLE IF NOT EXISTS customer_transactions (
    id TEXT PRIMARY KEY,
    customerId TEXT,
    customer_id TEXT,
    date TEXT,
    amount NUMERIC,
    type TEXT,
    note TEXT,
    orderId TEXT,
    order_id TEXT,
    storeId TEXT,
    store_id TEXT
);

CREATE TABLE IF NOT EXISTS supplier_transactions (
    id TEXT PRIMARY KEY,
    supplierId TEXT,
    supplier_id TEXT,
    date TEXT,
    amount NUMERIC,
    type TEXT,
    note TEXT,
    orderId TEXT,
    order_id TEXT,
    storeId TEXT,
    store_id TEXT
);

CREATE TABLE IF NOT EXISTS shared_audits (
    id TEXT PRIMARY KEY,
    storeId TEXT,
    store_id TEXT,
    title TEXT,
    warehouseId TEXT,
    warehouse_id TEXT,
    warehouseName TEXT,
    protocol TEXT,
    isProtocolLocked BOOLEAN DEFAULT false,
    status TEXT,
    createdAt TEXT,
    submittedAt TEXT,
    passcode TEXT,
    managerName TEXT,
    managerId TEXT,
    items JSONB DEFAULT '[]'::jsonb,
    logs JSONB DEFAULT '[]'::jsonb,
    assignments JSONB DEFAULT '[]'::jsonb,
    presence JSONB DEFAULT '{}'::jsonb,
    conflicts JSONB DEFAULT '[]'::jsonb,
    draftCounts JSONB DEFAULT '{}'::jsonb,
    draftNotes JSONB DEFAULT '{}'::jsonb,
    locks JSONB DEFAULT '{}'::jsonb,
    lastSavedAt TEXT,
    unlockReason TEXT,
    unlockedBy TEXT,
    unlockedAt TEXT,
    notes TEXT,
    signatureData TEXT,
    isBlindCount BOOLEAN DEFAULT false,
    workerSignature TEXT,
    managerSignature TEXT,
    rejectReason TEXT,
    progress NUMERIC,
    accuracyScore NUMERIC,
    healthScore NUMERIC
);

CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id TEXT PRIMARY KEY,
    storeId TEXT,
    store_id TEXT,
    amount NUMERIC NOT NULL,
    date TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    method TEXT,
    details TEXT,
    fee NUMERIC DEFAULT 0,
    netAmount NUMERIC,
    isSameDay BOOLEAN DEFAULT false
);

ALTER TABLE customers ADD COLUMN IF NOT EXISTS "debtBalance" NUMERIC DEFAULT 0;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "debtHistory" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "balance" NUMERIC DEFAULT 0;

-- 9. حركات الشركاء والخزائن والشركاء وسجل النشاط والأعمدة والتواريخ
ALTER TABLE call_scripts ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE call_scripts ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE call_scripts ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE call_scripts ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE call_scripts ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE call_scripts ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE partners ADD COLUMN IF NOT EXISTS "capital" NUMERIC DEFAULT 0;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "initialCapital" NUMERIC DEFAULT 0;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "initial_capital" NUMERIC DEFAULT 0;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "profitRatio" NUMERIC DEFAULT 0;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "profit_ratio" NUMERIC DEFAULT 0;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "email" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "passcode" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "password" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "requireEmailOtp" BOOLEAN DEFAULT false;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "require_email_otp" BOOLEAN DEFAULT false;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "isEmailVerified" BOOLEAN DEFAULT false;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "is_email_verified" BOOLEAN DEFAULT false;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "emailVerifiedAt" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "email_verified_at" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "lastLoginAt" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "last_login_at" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE partners ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS "isDefault" BOOLEAN DEFAULT false;

ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "footer" TEXT;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "buttons" JSONB DEFAULT '[]'::jsonb;
ALTER TABLE whatsapp_templates ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;

ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "notes" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "note" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "partnerName" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "partner_name" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "partnerId" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "partner_id" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "treasuryAccountId" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "treasury_account_id" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "orderId" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "order_id" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "orderNumber" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "order_number" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "description" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "category" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE partner_transactions ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "performedBy" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "warehouseId" TEXT;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "totalSystemQty" NUMERIC DEFAULT 0;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "totalActualQty" NUMERIC DEFAULT 0;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "totalVarianceQty" NUMERIC DEFAULT 0;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "totalVarianceValue" NUMERIC DEFAULT 0;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "totalItemsAudited" NUMERIC DEFAULT 0;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "total_items_audited" NUMERIC DEFAULT 0;
ALTER TABLE inventory_audits ADD COLUMN IF NOT EXISTS "timestamp" BIGINT;

ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "transferNumber" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "sourceWarehouseId" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "destinationWarehouseId" TEXT;
ALTER TABLE stock_transfers ADD COLUMN IF NOT EXISTS "performedBy" TEXT;

ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "returnNumber" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "orderId" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "orderNumber" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "totalRefund" NUMERIC DEFAULT 0;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "warehouseId" TEXT;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "restockItems" BOOLEAN DEFAULT true;
ALTER TABLE order_returns ADD COLUMN IF NOT EXISTS "performedBy" TEXT;

ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "returnNumber" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "supplierId" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "supplierName" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "totalRefundAmount" NUMERIC DEFAULT 0;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "warehouseId" TEXT;
ALTER TABLE purchase_returns ADD COLUMN IF NOT EXISTS "performedBy" TEXT;

ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "saleNumber" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "totalAmount" NUMERIC DEFAULT 0;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "paymentMethod" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "warehouseId" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customerPhone" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customerName" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "customerAddress" TEXT;
ALTER TABLE pos_sales ADD COLUMN IF NOT EXISTS "performedBy" TEXT;

ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "userId" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "userName" TEXT;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "currentBalance" NUMERIC DEFAULT 0;
ALTER TABLE cash_holders ADD COLUMN IF NOT EXISTS "lastUpdated" TEXT;

ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "fromUserId" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "fromUserName" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "toUserId" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "toUserName" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "isVirtual" BOOLEAN DEFAULT FALSE;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "is_virtual" BOOLEAN DEFAULT FALSE;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "orderNumber" TEXT;
ALTER TABLE cash_handovers ADD COLUMN IF NOT EXISTS "order_number" TEXT;

ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS store_id TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "user" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "userName" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "action" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "details" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "date" TEXT;
ALTER TABLE activity_logs ADD COLUMN IF NOT EXISTS "timestamp" NUMERIC;

ALTER TABLE transactions ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE treasury_accounts ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE treasury_accounts ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE treasury_accounts ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE treasury_accounts ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE treasury_accounts ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE treasury_accounts ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "orderId" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "order_id" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "orderNumber" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "order_number" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE treasury_transactions ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE custom_pages ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE payment_methods ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "apiKey" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS api_key TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "apiSecret" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS api_secret TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "accountNumber" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS account_number TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "isConnected" BOOLEAN DEFAULT false;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS is_connected BOOLEAN DEFAULT false;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS provider TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "details" JSONB DEFAULT '{}'::jsonb;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE shipping_integrations ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE global_options ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE global_options ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE global_options ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE global_options ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE global_options ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE global_options ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE reviews ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE abandoned_carts ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE abandoned_carts ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE abandoned_carts ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE abandoned_carts ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE abandoned_carts ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE abandoned_carts ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE discount_codes ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE collections ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE collections ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE collections ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE collections ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE collections ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE collections ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE customer_transactions ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE customer_transactions ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE customer_transactions ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE customer_transactions ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE customer_transactions ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE customer_transactions ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE supplier_transactions ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE supplier_transactions ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE supplier_transactions ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE supplier_transactions ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE supplier_transactions ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE supplier_transactions ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE supply_orders ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE employees ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE customers ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS store_id TEXT;

ALTER TABLE products ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS "created_at" TEXT;

ALTER TABLE orders ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS "created_at" TEXT;

ALTER TABLE documents ADD COLUMN IF NOT EXISTS "updatedAt" TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS "updated_at" TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS "createdAt" TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS "created_at" TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS "storeId" TEXT;
ALTER TABLE documents ADD COLUMN IF NOT EXISTS store_id TEXT;
`;
    navigator.clipboard.writeText(instructions);
    triggerAlarm("✅ تم نسخ كود التحديث الشامل لجميع الأعمدة المفقودة! قم بلصقه وتشغيله في Supabase SQL Editor لإصلاح جميع الجداول ومنع اختفاء أي بيانات.", 'success', 'إصلاح شامل لقاعدة البيانات');
  };
  
  // Custom Database Credentials States
  const [customCloudUrl, setCustomCloudUrl] = useState(
    () => localStorage.getItem('custom_cloud_url') || (import.meta as any).env?.VITE_SUPABASE_URL || ''
  );
  const [customCloudAnonKey, setCustomCloudAnonKey] = useState(
    () => localStorage.getItem('custom_cloud_anon_key') || (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || ''
  );
  const [isRestricted, setIsRestricted] = useState(getSupabaseRestrictedStatus());
  const [showSqlSchema, setShowSqlSchema] = useState(false);

  useEffect(() => {
    const storedUrl = localStorage.getItem('custom_cloud_url');
    const storedKey = localStorage.getItem('custom_cloud_anon_key');
    if (storedUrl) {
      setCustomCloudUrl(storedUrl);
    } else if (settings.supabaseUrl !== undefined) {
      setCustomCloudUrl(settings.supabaseUrl || '');
    }

    if (storedKey) {
      setCustomCloudAnonKey(storedKey);
    } else if (settings.supabaseAnonKey !== undefined) {
      setCustomCloudAnonKey(settings.supabaseAnonKey || '');
    }
  }, [settings.supabaseUrl, settings.supabaseAnonKey]);

  // Sync Conflict Strategy State
  const [syncConflictStrategy, setSyncConflictStrategy] = useState(
    localStorage.getItem('syncConflictStrategy') || 'last_write_wins'
  );
  
  const [isManualSyncing, setIsManualSyncing] = useState(false);
  const [isPullingRemote, setIsPullingRemote] = useState(false);

  // In-app Custom alarm / alert system state
  const [alarm, setAlarm] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: 'success' | 'warning' | 'error' | 'info';
    onConfirm?: () => void;
    showCancel?: boolean;
    cancelText?: string;
    confirmText?: string;
  } | null>(null);

  const playAlarmSound = (type: 'success' | 'warning' | 'error' | 'info') => {
    try {
      audioSynth.playTone(type);
    } catch (e) {
      console.error("Audio beep failed:", e);
    }
  };

  const triggerAlarm = (
    message: string, 
    type: 'success' | 'warning' | 'error' | 'info' = 'info', 
    title: string = 'تنبيه النظام', 
    options?: { onConfirm?: () => void; showCancel?: boolean; cancelText?: string; confirmText?: string }
  ) => {
    playAlarmSound(type);
    setAlarm({
      show: true,
      title,
      message,
      type,
      onConfirm: options?.onConfirm,
      showCancel: options?.showCancel,
      cancelText: options?.cancelText || 'إلغاء',
      confirmText: options?.confirmText || 'موافق'
    });
  };

  const handleSaveConflictStrategy = (strategy: string) => {
    localStorage.setItem('syncConflictStrategy', strategy);
    setSyncConflictStrategy(strategy);
    triggerAlarm("🚀 تم تعديل سياسة حل التعارض وتأمين المزامنة تلقائياً للفروع والديسك توب!", 'success', 'مزامنة حل التعارض');
  };

  const triggerManualSync = async () => {
    if (!forceSync) return;
    setIsManualSyncing(true);
    try {
      await forceSync();
      triggerAlarm("✅ تم دفع المزامنة السحابية وبدء الرفع بنجاح!", 'success', 'مكتمل');
    } catch (e: any) {
      console.error(e);
      triggerAlarm(`❌ فشلت عملية المزامنة: ${e.message || String(e)}`, 'error', 'خطأ مزامنة');
    } finally {
      setIsManualSyncing(false);
    }
  };

  const triggerCloudPull = async () => {
    if (!forcePullFromCloud) return;
    triggerAlarm(
      "⚠️ هل أنت متأكد من رغبتك في سحب واستيراد البيانات من السحابة؟ هذا قد يستبدل أي بيانات محلية لم يتم رفعها بعد على خوادم قاعدة البيانات.",
      'warning',
      'تأكيد استرداد البيانات',
      {
        showCancel: true,
        confirmText: 'نعم، استرد الآن',
        cancelText: 'إلغاء',
        onConfirm: async () => {
          setIsPullingRemote(true);
          try {
            const res = await forcePullFromCloud();
            if (res && res.success) {
              triggerAlarm("✅ تم استيراد وسحب البيانات من السحابة وتحديث الذاكرة المحلية بنجاح!", 'success', 'مكتمل');
            } else if (res && res.error) {
              triggerAlarm(`❌ فشل استرداد البيانات: ${res.error}`, 'error', 'فشل الاسترداد');
            }
          } catch (e: any) {
            console.error(e);
            triggerAlarm(`❌ فشل استيراد البيانات: ${e.message || String(e)}`, 'error', 'فشل الاسترداد');
          } finally {
            setIsPullingRemote(false);
          }
        }
      }
    );
  };

  const handleCopy = (text: string) => {
      navigator.clipboard.writeText(text);
      setCopiedLink(text);
      setTimeout(() => setCopiedLink(null), 2000);
  };

  const [isVerifying, setIsVerifying] = useState(false);

  const performSaveDatabaseCredentials = async (url: string, key: string) => {
    localStorage.setItem('custom_cloud_url', url);
    localStorage.setItem('custom_cloud_anon_key', key);
    
    setSettings(prev => ({
        ...prev,
        supabaseUrl: url,
        supabaseAnonKey: key
    }));
    setSupabaseRestricted(false);
    setIsRestricted(false);

    if (activeStore?.id) {
      const localData = await getLocal(activeStore.id);
      const updatedStoreData = localData ? {
        ...localData,
        settings: {
          ...(localData.settings || {}),
          supabaseUrl: url,
          supabaseAnonKey: key
        }
      } : {
        settings: {
          ...settings,
          supabaseUrl: url,
          supabaseAnonKey: key
        }
      };
      await saveLocal(activeStore.id, updatedStoreData);
      if (forceSync) {
        await forceSync();
      }
    } else if (forceSync) {
      await forceSync();
    }

    window.location.reload();
  };

  const handleSaveDatabaseCredentials = async () => {
    const url = customCloudUrl.trim();
    const key = customCloudAnonKey.trim();

    if (url && !url.startsWith('http')) {
      triggerAlarm("يرجى إدخال رابط Cloud URL صحيح يبدأ بـ http:// أو https://", 'warning', 'رابط غير صالح');
      return;
    }

    if (url && key) {
      setIsVerifying(true);
      try {
        const verification = await verifySupabaseConnection(url, key);
        
        if (!verification.success) {
          triggerAlarm(
            `⚠️ فشل التحقق من الاتصال بقاعدة البيانات: ${verification.error}\n\nهل تريد حفظ الإعدادات على أي حال والاستمرار؟`,
            'warning',
            'فشل الاتصال',
            {
              showCancel: true,
              confirmText: 'حفظ على أي حال',
              cancelText: 'إلغاء',
              onConfirm: async () => {
                await performSaveDatabaseCredentials(url, key);
              }
            }
          );
          return;
        }

        triggerAlarm("✅ تم التحقق وحفظ إعدادات قاعدة البيانات المخصصة بنجاح! سيتم إعادة تحميل التطبيق للاتصال بالخادم المخصص.", 'success', 'ربط ناجح', {
          onConfirm: async () => { 
            await performSaveDatabaseCredentials(url, key);
          }
        });
      } catch (e: any) {
        triggerAlarm("خطأ أثناء التحقق: " + e.message, 'error', 'خطأ التحقق');
      } finally {
        setIsVerifying(false);
      }
    } else if (!url && !key) {
      handleRestoreDefaultDatabase();
    } else {
      triggerAlarm("يرجى ملء كلا الحقلين (الرابط ومفتاح Api Key) أو تركهما فارغين لاستعادة الافتراضي.", 'warning', 'حقول ناقصة');
    }
  };

  const handleRestoreDefaultDatabase = () => {
    localStorage.removeItem('custom_cloud_url');
    localStorage.removeItem('custom_cloud_anon_key');
    setSettings(prev => {
        const newSettings = { ...prev };
        delete newSettings.supabaseUrl;
        delete newSettings.supabaseAnonKey;
        return newSettings;
    });
    setSupabaseRestricted(false);
    setIsRestricted(false);
    setCustomCloudUrl('');
    setCustomCloudAnonKey('');
    triggerAlarm("تمت استعادة قاعدة البيانات السحابية الافتراضية بنجاح! سيتم إعادة تحميل الصفحة لتطبيق التغييرات.", 'success', 'استعادة الافتراضي', {
      onConfirm: async () => { 
          if (forceSync) await forceSync();
          window.location.reload(); 
      }
    });
  };

  const handleReactivateCloudSync = () => {
    setSupabaseRestricted(false);
    setIsRestricted(false);
    triggerAlarm("تم تنشيط الاتصال السحابي وإلغاء وضع الطوارئ المحلي. سيقوم النظام الآن بمحاولة المزامنة مع خوادم قاعدة البيانات.", 'success', 'تنشيط الاتصال', {
      onConfirm: () => { window.location.reload(); }
    });
  };

  const addIntegration = () => {
    setIntegrations([...integrations, {
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
      storeUrl: '',
      webhookUrl: '',
      secretKey: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
      isActive: true
    }]);
  };

  const removeIntegration = (id: string) => {
    setIntegrations(integrations.filter(i => i.id !== id));
  };

  const updateIntegration = (id: string, field: keyof WebhookIntegration, value: any) => {
    setIntegrations(integrations.map(i => i.id === id ? { ...i, [field]: value } : i));
  };

  const saveSettings = () => {
    setSettings(prev => ({ ...prev, webhookIntegrations: integrations }));
    triggerAlarm("تم حفظ الإعدادات والربط الخارجي بنجاح", 'success', 'مكتمل');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12 px-4">
      <div className="flex justify-between items-end mb-8 bg-gradient-to-r from-slate-900 to-slate-800 p-8 rounded-3xl shadow-xl shadow-slate-900/20 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[100px] rounded-full pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-500/20 blur-[80px] rounded-full pointer-events-none"></div>
        <div className="relative z-10">
          <h1 className="text-3xl font-black mb-2 flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center backdrop-blur-md border border-white/20">
              <Code size={24} className="text-white" />
            </div>
            أدوات المطورين
          </h1>
          <p className="text-slate-300 font-medium">لوحة التحكم المتقدمة بإعدادات التكامل وربط المنصات</p>
        </div>
        <button 
          onClick={saveSettings}
          className="relative z-10 btn bg-white text-slate-900 hover:bg-slate-100 shadow-lg shadow-white/10 flex items-center gap-2 font-bold px-6 py-2.5 rounded-xl transition-all hover:scale-105 active:scale-95"
        >
          <Save size={18} />
          حفظ التغييرات
        </button>
      </div>

      
      {/* Modern Tabs */}
      <div className="flex overflow-x-auto hide-scrollbar gap-2 mb-6 border-b border-slate-200 dark:border-slate-800 pb-4">
        {[
          { id: 'database', label: 'قاعدة البيانات', icon: <Database size={16} /> },
          { id: 'security', label: 'الأمان والمزامنة', icon: <ShieldAlert size={16} /> },
          { id: 'mail', label: 'خادم البريد المركزي (SMTP)', icon: <Mail size={16} /> },
          { id: 'webhooks', label: 'Webhooks', icon: <Webhook size={16} /> },
          { id: 'apikeys', label: 'مفاتيح الربط (API Keys)', icon: <Key size={16} /> },
          { id: 'logs', label: 'سجل النشاط', icon: <History size={16} /> },
          { id: 'platforms', label: 'المنصات', icon: <ShoppingCart size={16} /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap ${
              activeTab === tab.id 
                ? 'bg-primary text-white shadow-md shadow-primary/20' 
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>
      
      <AnimatePresence mode="wait">

        {activeTab === 'database' && (
          <motion.div
            key="database"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <div id="custom-database-settings"  className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl shadow-slate-200/40 dark:shadow-slate-900/40 border border-slate-200/60 dark:border-slate-800/60 overflow-hidden">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold">
                 <Database size={20} />
              </div>
              <div className="text-right">
                <h2 className="text-lg font-bold text-slate-800 dark:text-white">إعدادات الربط السحابي وقاعدة البيانات</h2>
                <p className="text-sm text-slate-500">تمتع بحرية تامة وتزامن سحابي كامل من خلال إعدادات الربط المخصصة.</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {isRestricted ? (
                <span className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 text-xs font-bold rounded-xl border border-amber-200/50 dark:border-amber-900/40 animate-pulse">
                  <AlertCircle size={14} />
                  <span>وضع الطوارئ (تخزين محلي فقط)</span>
                </span>
              ) : isSupabaseActive() ? (
                <span className="flex items-center gap-1.5 px-3 py-1 bg-green-50 dark:bg-green-950/40 text-green-600 dark:text-green-400 text-xs font-bold rounded-xl border border-green-200/50 dark:border-green-900/30">
                  <Check size={14} />
                  <span>قاعدة البيانات المخصصة (Supabase) متصلة ونشطة</span>
                </span>
              ) : (
                <span className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 text-xs font-bold rounded-xl border border-blue-200/50 dark:border-blue-900/30">
                  <Check size={14} />
                  <span>قاعدة البيانات الافتراضية (Firebase) متصلة</span>
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6 text-right">
          <div className="bg-blue-50/50 dark:bg-blue-950/25 border border-blue-100 dark:border-blue-900/30 rounded-xl p-4 text-sm text-slate-600 dark:text-slate-300 space-y-3 leading-relaxed">
            <h3 className="font-bold text-blue-900 dark:text-blue-400 flex items-center gap-2 justify-start">
              <Shield size={16} /> <span>دليل هيكلية البيانات والمزامنة الشاملة 🌐</span>
            </h3>
            <p className="text-xs text-slate-700 dark:text-slate-300">
                يعتمد النظام على هندسة برمجية متطورة تضمن توافق البيانات بين الأجهزة المختلفة محلياً وسحابياً. يمكنك استخدام كود الـ SQL بالأسفل لإعادة بناء هيكل البيانات إذا كنت ترغب في تصدير مشروعك لمنظومة خارجية أو لإجراء عمليات فحص تقنية متقدمة.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5 text-right">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1 justify-start">
                <SupabaseIcon />
                <span>رابط Supabase URL / Cloud Endpoint المخصص</span>
              </label>
              <input 
                type="text" 
                placeholder="https://xyz.supabase.co"
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm font-mono focus:ring-2 focus:ring-primary/50 outline-none transition-all dark:text-white text-left"
                value={customCloudUrl}
                onChange={(e) => setCustomCloudUrl(e.target.value)}
                dir="ltr"
              />
            </div>
            
            <div className="space-y-1.5 text-right">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1 justify-start">
                <Key size={14} className="text-emerald-500" />
                <span>مفتاح Supabase Anon Key / API Key الخاص بالربط</span>
              </label>
              <input 
                type="text" 
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-sm font-mono focus:ring-2 focus:ring-primary/50 outline-none transition-all dark:text-white text-left"
                value={customCloudAnonKey}
                onChange={(e) => setCustomCloudAnonKey(e.target.value)}
                dir="ltr"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex flex-wrap gap-2.5">
              <button 
                onClick={handleSaveDatabaseCredentials}
                disabled={isVerifying}
                className="bg-primary hover:bg-primary/90 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-primary/20 hover:shadow-primary/30 transition flex items-center gap-2 disabled:opacity-50"
              >
                {isVerifying ? (
                  <RefreshCw size={16} className="animate-spin" />
                ) : (
                  <Save size={16} />
                )}
                {isVerifying ? "جاري التحقق..." : "حفظ وتشغيل الاتصال السحابي المخصص"}
              </button>

              <button
                onClick={() => {
                  const data = JSON.stringify(settings);
                  const blob = new Blob([data], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `data_export_${new Date().toISOString()}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/30 transition flex items-center gap-2"
              >
                <Download size={16} />
                تنزيل البيانات
              </button>

              <button
                onClick={async () => {
                  try {
                    setLog(`جاري البدء في فحص وتحليل البيانات المالية...\n`);
                    const results: string[] = [];
                    
                    const storeId = activeStoreId;
                    if (!storeId) {
                      setLog(prev => prev + `⚠️ تنبيه: لم يتم اكتشاف متجر نشط حالياً لفحصه. يرجى اختيار متجر أولاً.\n`);
                      return;
                    }

                    const storeData = allStoresData[storeId];
                    if (!storeData) return;

                    // Check for 600 specific values
                    const treasury = storeData.treasury || { accounts: [], transactions: [] };
                    const treasuryMatch = treasury.accounts.filter((a: any) => a.balance === 600 || a.initialBalance === 600);
                    if (treasuryMatch.length > 0) {
                      results.push(`🚩 تم العثور على حسابات في الخزينة برصيد أو رصيد افتتاحي 600: ${treasuryMatch.map((a: any) => a.name).join(', ')}`);
                    }

                    const wallet = storeData.wallet || { balance: 0, transactions: [] };
                    if (wallet.balance === 600) results.push(`🚩 رصيد المحفظة الإجمالي هو 600 بالضبط`);
                    
                    const walletTxMatch = (wallet.transactions || []).filter((t: any) => t.amount === 600);
                    if (walletTxMatch.length > 0) {
                      results.push(`🚩 تم العثور على ${walletTxMatch.length} عملية في المحفظة بقيمة 600`);
                    }

                    const customersMatch = (storeData.customers || []).filter((c: any) => c.debtBalance === 600);
                    if (customersMatch.length > 0) {
                      results.push(`🚩 تم العثور على ${customersMatch.length} عملاء مديونيتهم 600`);
                    }

                    // Deep Debt Check
                    const posSales = storeData.settings?.posSales || [];
                    const creditSales = posSales.filter((s: any) => s.cashHolderId === 'credit');
                    
                    (storeData.customers || []).forEach((c: any) => {
                      const customerCreditSales = creditSales.filter((s: any) => s.customerPhone === c.phone);
                      const totalCredit = customerCreditSales.reduce((sum: number, s: any) => sum + s.totalAmount, 0);
                      if (totalCredit !== (c.debtBalance || 0)) {
                        results.push(`❗ فرق مديونية للعميل ${c.name} (${c.phone}): المسجل ${c.debtBalance}، المحسوب من السجلات ${totalCredit}`);
                      }
                    });

                    // Treasury Integrity Check
                    treasury.accounts.forEach((acc: any) => {
                      const accTxs = (treasury.transactions || []).filter((t: any) => t.fromAccountId === acc.id || t.toAccountId === acc.id);
                      const calculatedBalance = accTxs.reduce((sum: number, t: any) => {
                        if (t.toAccountId === acc.id) return sum + t.amount;
                        if (t.fromAccountId === acc.id) return sum - t.amount;
                        return sum;
                      }, acc.initialBalance || 0);

                      if (calculatedBalance !== acc.balance) {
                        results.push(`❗ فرق رصيد في الخزينة ${acc.name}: المسجل ${acc.balance}، المحسوب من العمليات ${calculatedBalance}`);
                      }
                    });

                    if (results.length === 0) {
                      setLog(prev => prev + `✅ لم يتم العثور على أي فروقات أو أخطاء في توازن الحسابات.\n`);
                    } else {
                      setLog(prev => prev + `⚠️ تم العثور على الملاحظات التالية:\n\n` + results.join('\n') + `\n\n💡 نصيحة: يمكنك استخدام زر "إعادة المزامنة" لتصحيح هذه الفروقات آلياً بناءً على سجلات العمليات.`);
                    }
                  } catch (err: any) {
                    setLog(prev => prev + `❌ خطأ في الفحص: ${err.message}\n`);
                  }
                }}
                className="bg-amber-600 hover:bg-amber-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-amber-500/20 transition flex items-center gap-2"
              >
                <Search size={16} />
                فحص وتحليل الفروقات المالية (Audit)
              </button>

              <button
                onClick={async () => {
                  try {
                    setLog(`جاري تحليل السجلات لحساب الفروقات...\n`);
                    const storeId = activeStoreId;
                    if (!storeId) {
                      setLog(prev => prev + `⚠️ تنبيه: لم يتم اكتشاف متجر نشط حالياً للمزامنة. يرجى اختيار متجر أولاً.\n`);
                      return;
                    }

                    const storeData = allStoresData[storeId];
                    if (!storeData) return;

                    const posSales = storeData.settings?.posSales || [];
                    const creditSales = posSales.filter((s: any) => s.cashHolderId === 'credit');
                    
                    const customerChanges: any[] = [];
                    (storeData.customers || []).forEach((c: any) => {
                      const customerCreditSales = creditSales.filter((s: any) => s.customerPhone === c.phone);
                      const totalCredit = customerCreditSales.reduce((sum: number, s: any) => sum + s.totalAmount, 0);
                      if (totalCredit !== (c.debtBalance || 0)) {
                        customerChanges.push({
                          id: c.id,
                          phone: c.phone,
                          name: c.name,
                          oldBalance: c.debtBalance || 0,
                          newBalance: totalCredit,
                          description: "مديونية العميل الحالية لا تطابق مجموع فواتير الآجل المسجلة له. سيتم تصحيح المديونية بناءً على السجلات.",
                          selected: true
                        });
                      }
                    });

                    const treasury = storeData.treasury || { accounts: [], transactions: [] };
                    const treasuryChanges: any[] = [];
                    treasury.accounts.forEach((acc: any) => {
                      const accTxs = (treasury.transactions || []).filter((t: any) => t.fromAccountId === acc.id || t.toAccountId === acc.id);
                      const calculatedBalance = accTxs.reduce((sum: number, t: any) => {
                        if (t.toAccountId === acc.id) return sum + t.amount;
                        if (t.fromAccountId === acc.id) return sum - t.amount;
                        return sum;
                      }, acc.initialBalance || 0);
                      
                      if (calculatedBalance !== acc.balance) {
                        treasuryChanges.push({
                          id: acc.id,
                          name: acc.name,
                          oldBalance: acc.balance,
                          newBalance: calculatedBalance,
                          description: "رصيد الحساب المسجل يختلف عن ناتج العمليات. سيتم إعادة حساب الرصيد بدقة من واقع حركة الخزينة.",
                          selected: true
                        });
                      }
                    });

                    const wallet = storeData.wallet || { balance: 0, transactions: [] };
                    const walletChanges: any[] = [];
                    const walletTxs = wallet.transactions || [];
                    const calculatedWalletBalance = walletTxs.reduce((sum: number, t: any) => sum + (t.type === 'deposit' ? t.amount : -t.amount), 0);
                    
                    if (calculatedWalletBalance !== wallet.balance) {
                      walletChanges.push({
                        id: 'wallet_balance',
                        name: 'رصيد المحفظة الإجمالي',
                        oldBalance: wallet.balance,
                        newBalance: calculatedWalletBalance,
                        type: 'balance_fix',
                        description: "الرصيد الظاهر لا يطابق مجموع عمليات الإيداع والسحب. سيتم تصحيح الرصيد ليعبر عن حقيقة السجلات.",
                        selected: true
                      });
                    }

                    if (customerChanges.length === 0 && treasuryChanges.length === 0 && walletChanges.length === 0) {
                      setLog(prev => prev + `✅ البيانات مطابقة تماماً للسجلات، لا توجد فروقات للمزامنة.\n`);
                      return;
                    }

                    setSyncPreview({
                      customers: customerChanges,
                      treasury: treasuryChanges,
                      wallet: walletChanges,
                      storeId
                    });
                    setLog(prev => prev + `🔍 تم العثور على ${customerChanges.length + treasuryChanges.length + walletChanges.length} فرق مالي. يرجى مراجعتها أدناه.\n`);
                  } catch (err: any) {
                    setLog(prev => prev + `❌ خطأ في التحليل: ${err.message}\n`);
                  }
                }}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-500/20 transition flex items-center gap-2"
              >
                <Wrench size={16} />
                إعادة مزامنة المديونيات والخزينة من السجلات
              </button>

              {log && (
                <button
                  onClick={() => setLog('')}
                  className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-300 transition"
                >
                  مسح السجل
                </button>
              )}

              {(localStorage.getItem('custom_cloud_url') || localStorage.getItem('custom_cloud_anon_key')) && (
                <button 
                  onClick={handleRestoreDefaultDatabase}
                  className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-red-600 dark:text-red-400 px-4 py-2.5 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition"
                >
                  استعادة الافتراضي
                </button>
              )}
            </div>

            {isRestricted && (
              <button 
                onClick={handleReactivateCloudSync}
                className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2.5 rounded-xl text-sm font-bold shadow-md hover:shadow-lg transition flex items-center gap-2 animate-pulse"
              >
                <RefreshCw size={16} className="animate-spin" />
                إلغاء وضع الطوارئ والاتصال فوراً
              </button>
            )}
          </div>

          {syncPreview && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-6 bg-white dark:bg-slate-900 rounded-3xl border-2 border-indigo-500 shadow-2xl shadow-indigo-500/10 overflow-hidden mb-6"
              dir="rtl"
            >
              <div className="flex items-center justify-between mb-6 border-b border-slate-200 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl text-indigo-600 dark:text-indigo-400">
                    <Wrench size={20} />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-white">مراجعة التغييرات المقترحة</h3>
                    <p className="text-xs text-slate-500 mt-1">راجع الفروقات المكتشفة واشِر إلى ما تريد تحديثه</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSyncPreview(null)}
                  className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition text-slate-400"
                >
                  <Trash size={18} />
                </button>
              </div>

              <div className="space-y-6 max-h-[500px] overflow-auto px-1">
                {syncPreview.customers.length > 0 && (
                  <div>
                    <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                      <ShoppingCart size={16} className="text-indigo-500" />
                      مديونيات العملاء ({syncPreview.customers.length})
                    </h4>
                    <div className="space-y-2">
                      {syncPreview.customers.map((c) => (
                        <div key={c.id} className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                          <div className="flex items-center gap-3">
                            <button 
                              onClick={() => setSyncPreview({
                                ...syncPreview,
                                customers: syncPreview.customers.map(item => item.id === c.id ? { ...item, selected: !item.selected } : item)
                              })}
                              className={`transition-colors ${c.selected ? 'text-indigo-600' : 'text-slate-300'}`}
                            >
                              {c.selected ? <CheckSquare size={20} /> : <Square size={20} />}
                            </button>
                            <div>
                              <p className="text-sm font-bold text-slate-900 dark:text-white">{c.name}</p>
                              <p className="text-[10px] text-slate-500 mb-1">{c.phone}</p>
                              <p className="text-[10px] text-indigo-500 font-bold leading-tight max-w-[200px]">
                                {c.description}
                              </p>
                            </div>
                          </div>
                          <div className="text-left font-mono">
                            <span className="text-xs text-rose-500 line-through decoration-rose-500/30">{(c.oldBalance ?? 0).toLocaleString()}</span>
                            <span className="mx-2 text-slate-400">→</span>
                            <span className="text-sm font-bold text-emerald-500">{(c.newBalance ?? 0).toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400 mr-1">ج.م</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {syncPreview.treasury.length > 0 && (
                  <div>
                    <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                      <Database size={16} className="text-indigo-500" />
                      أرصدة الخزينة ({syncPreview.treasury.length})
                    </h4>
                    <div className="space-y-2">
                      {syncPreview.treasury.map((acc) => (
                        <div key={acc.id} className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                          <div className="flex items-center gap-3">
                            <button 
                              onClick={() => setSyncPreview({
                                ...syncPreview,
                                treasury: syncPreview.treasury.map(item => item.id === acc.id ? { ...item, selected: !item.selected } : item)
                              })}
                              className={`transition-colors ${acc.selected ? 'text-indigo-600' : 'text-slate-300'}`}
                            >
                              {acc.selected ? <CheckSquare size={20} /> : <Square size={20} />}
                            </button>
                            <div>
                              <p className="text-sm font-bold text-slate-900 dark:text-white">{acc.name}</p>
                              <p className="text-[10px] text-indigo-500 font-bold leading-tight max-w-[200px] mt-1">
                                {acc.description}
                              </p>
                            </div>
                          </div>
                          <div className="text-left font-mono">
                            <span className="text-xs text-rose-500 line-through decoration-rose-500/30">{(acc.oldBalance ?? 0).toLocaleString()}</span>
                            <span className="mx-2 text-slate-400">→</span>
                            <span className="text-sm font-bold text-emerald-500">{(acc.newBalance ?? 0).toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400 mr-1">ج.م</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {syncPreview.wallet.length > 0 && (
                  <div>
                    <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                      <Key size={16} className="text-indigo-500" />
                      المحفظة وتوازن العمليات ({syncPreview.wallet.length})
                    </h4>
                    <div className="space-y-2">
                      {syncPreview.wallet.map((w) => (
                        <div key={w.id} className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                          <div className="flex items-center gap-3">
                            <button 
                              onClick={() => setSyncPreview({
                                ...syncPreview,
                                wallet: syncPreview.wallet.map(item => item.id === w.id ? { ...item, selected: !item.selected } : item)
                              })}
                              className={`transition-colors ${w.selected ? 'text-indigo-600' : 'text-slate-300'}`}
                            >
                              {w.selected ? <CheckSquare size={20} /> : <Square size={20} />}
                            </button>
                            <div>
                              <p className="text-sm font-bold text-slate-900 dark:text-white">{w.name}</p>
                              <p className="text-[10px] text-indigo-500 font-bold leading-tight max-w-[200px] mt-1">
                                {w.description}
                              </p>
                            </div>
                          </div>
                          <div className="text-left font-mono">
                            <span className="text-xs text-rose-500 line-through decoration-rose-500/30">{(w.oldBalance ?? 0).toLocaleString()}</span>
                            <span className="mx-2 text-slate-400">→</span>
                            <span className="text-sm font-bold text-emerald-500">{(w.newBalance ?? 0).toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400 mr-1">ج.م</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3">
                <button 
                  onClick={handleApplySync}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-2xl font-black text-sm shadow-xl shadow-indigo-500/20 transition flex items-center justify-center gap-2"
                >
                  <CheckCircle2 size={18} />
                  اعتماد وتطبيق التغييرات المختارة
                </button>
                <button 
                  onClick={() => setSyncPreview(null)}
                  className="px-6 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl font-bold text-sm hover:bg-slate-200 transition"
                >
                  إلغاء
                </button>
              </div>
            </motion.div>
          )}

          {log && (
            <div className="mt-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 font-mono text-xs text-emerald-400 overflow-auto max-h-[300px] whitespace-pre-wrap" dir="ltr">
              <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-800">
                <span className="text-slate-400 font-bold">نتائج الفحص والمزامنة:</span>
                <div className="flex gap-2">
                  <button onClick={() => setLog('')} className="text-rose-400 hover:text-rose-300">إغلاق</button>
                </div>
              </div>
              {log}
            </div>
          )}

          {isSupabaseActive() && (
            <div className="w-full mt-4 p-5 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-3xl border border-indigo-200/50 dark:border-indigo-900/30">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-6 text-right">
                <div className="flex-1">
                  <h4 className="text-sm font-black text-indigo-700 dark:text-indigo-400 flex items-center gap-2">
                    <Sparkles size={16} />
                    نقل البيانات الحالية إلى قاعدتك الجديدة (Migration)
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
                    بما أنك قمت للتو بربط Supabase، فإن الجداول هناك ستكون فارغة. 
                    اضغط على الزر أدناه لرفع كافة طلباتك ومنتجاتك الحالية من هذا الجهاز إلى السحابة فوراً لتظهر في جميع أجهزتك.
                  </p>
                </div>
                <button 
                  onClick={async (e) => {
                    e.stopPropagation();
                    const btn = e.currentTarget as HTMLButtonElement;
                    
                    triggerAlarm(
                      "⚠️ هل أنت متأكد؟ سيتم رفع كافة البيانات المحلية من هذا الجهاز واستبدال ما هو موجود على قاعدة البيانات السحابية (Supabase) بها بالكامل.",
                      'warning',
                      'تأكيد المزامنة والرفع للسحابة',
                      {
                        showCancel: true,
                        confirmText: 'نعم، ابدأ الرفع',
                        cancelText: 'إلغاء',
                        onConfirm: async () => {
                          btn.disabled = true;
                          const originalContent = btn.innerHTML;
                          btn.innerHTML = '<span class="animate-spin">🔄</span> جاري الرفع...';
                          
                          try {
                            const storeId = activeStoreId || localStorage.getItem('lastActiveStoreId');
                            const store = activeStore;
                            
                            if (!storeId || !store) throw new Error("لم يتم اختيار متجر");
                            
                            const localData = await getLocal(storeId);
                            if (!localData) throw new Error("لا توجد بيانات محلية للرفع");
                            
                            const res = await saveStoreData(store, localData);
                            
                            if (res.success) {
                              triggerAlarm("✅ تمت المزامنة والرفع بنجاح! جداول قاعدة البيانات السحابية أصبحت تحتوي على بياناتك الآن.", 'success', 'مزامنة ناجحة');
                            } else {
                              throw new Error(res.error);
                            }
                          } catch (e: any) {
                            triggerAlarm("❌ فشل الرفع المباشر: " + e.message, 'error', 'خطأ مزامنة');
                          } finally {
                            btn.disabled = false;
                            btn.innerHTML = originalContent;
                          }
                        }
                      }
                    );
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl text-xs font-black shadow-xl shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2 whitespace-nowrap"
                >
                  <CloudUpload size={18} />
                  ابدأ مزامنة ورفع البيانات الآن
                </button>

                <button 
                  onClick={handleFixDBSchema}
                  className="bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-2xl text-xs font-black shadow-xl shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2 whitespace-nowrap"
                >
                  <RefreshCw size={18} />
                  ⚡ إصلاح وتحديث شامل لجميع الأعمدة المفقودة (شامل لحل اختفاء المنتجات والبيانات)
                </button>
                <button 
                  onClick={handleFixFlexShipSchema}
                  className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-2xl text-xs font-black shadow-xl shadow-teal-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-2 whitespace-nowrap"
                >
                  <RefreshCw size={18} />
                  🚚 إصلاح أعمدة شركات الشحن وبوسطة (apiKey / isConnected / flexShip)
                </button>
              </div>
            </div>
          )}

          <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-right">
            <button 
              type="button"
              onClick={() => setShowSqlSchema(!showSqlSchema)}
              className="w-full flex items-center justify-between px-5 py-3.5 bg-slate-50 dark:bg-slate-800/30 text-right font-bold text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition"
            >
              <div className="flex items-center gap-2">
                <Code size={16} className="text-indigo-500" />
                <span>إظهار كود SQL لإنشاء وتجهيز جميع الجداول والأعمدة تلقائياً (نسخ سريع) ⚡</span>
              </div>
              <span className="text-xs text-slate-400">{showSqlSchema ? 'إخفاء' : 'عرض كود المزامنة'}</span>
            </button>

            {showSqlSchema && (
              <div className="p-4 bg-slate-950 text-slate-200 font-mono text-xs overflow-hidden relative">
                <div className="absolute top-3 left-3 z-10">
                  <button 
                    onClick={() => handleCopy(SQL_SCHEMA_SCRIPT)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold border border-slate-700 transition active:scale-95"
                  >
                    {copiedLink === SQL_SCHEMA_SCRIPT ? (
                      <>
                        <Check size={14} className="text-green-400" />
                        <span>تم النسخ!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={14} />
                        <span>نسخ الكود بالكامل</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="max-h-72 overflow-y-auto pt-8 text-left dir-ltr" style={{ direction: 'ltr' }}>
                  {SQL_SCHEMA_SCRIPT}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
          </motion.div>
        )}

        {activeTab === 'security' && (
          <motion.div
            key="security"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl shadow-slate-200/40 dark:shadow-slate-900/40 border border-slate-200/60 dark:border-slate-800/60 overflow-hidden mb-8">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3 text-right">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
               <ShieldAlert size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800 dark:text-white">أمان المزامنة والوقاية من تعارض وتضارب البيانات 🔐</h2>
              <p className="text-sm text-slate-500">حماية المعاملات الحسابية والفواتير والطلبات عند العمل بأكثر من جهاز أو دون اتصال بالإنترنت.</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6 text-right">
          <div className="p-4 bg-indigo-50/40 dark:bg-indigo-950/20 border border-indigo-100/50 dark:border-indigo-900/30 rounded-xl text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            💬 يواجه أصحاب المتاجر أحياناً مشكلة تداخل البيانات وتضاربها إذا قام الكاشير بالاقتصاص بدون إنترنت ثم حدث تعديل لطلب من هاتف المدير سحابياً. يقوم هذا النظام المتكامل بمقارنة الحقول تلقائياً وتطبيق استراتيجيات دقيقة جداً مع ميزة 
            <strong className="text-indigo-600 dark:text-indigo-400 mx-1">مزامنة CDC الرقمية</strong> لحماية أرباحك وتجنب أي تعويضات أو ضياع للعمليات المالية.
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5 justify-start">
              <Layers size={16} className="text-indigo-500" />
              <span>اختر سياسة المزامنة وحل الخلافات (Conflict Strategy)</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div 
                onClick={() => handleSaveConflictStrategy('last_write_wins')}
                className={`border rounded-xl p-4 cursor-pointer transition-all duration-200 relative ${
                  syncConflictStrategy === 'last_write_wins'
                    ? 'border-indigo-600 bg-indigo-50/10 dark:bg-indigo-950/10 ring-2 ring-indigo-500/10'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    syncConflictStrategy === 'last_write_wins' 
                      ? 'border-indigo-600 bg-indigo-600' 
                      : 'border-slate-300'
                  }`}>
                    {syncConflictStrategy === 'last_write_wins' && <span className="w-1.5 h-1.5 bg-white rounded-full" />}
                  </span>
                  <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded-full">الافتراضي والأقوى</span>
                </div>
                <h4 className="font-bold text-sm text-slate-800 dark:text-white mb-1.5">الأحدث فوزاً (Last-Write)</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  مقارنة البصمة الزمنية الفريدة <code className="font-mono bg-slate-100 dark:bg-black px-1 rounded">updatedAt</code> محلياً وسحابياً وحفظ التعديل الأحدث دائماً لمنع ضياع الفواتير المنقحة.
                </p>
              </div>

              <div 
                onClick={() => handleSaveConflictStrategy('local_wins')}
                className={`border rounded-xl p-4 cursor-pointer transition-all duration-200 relative ${
                  syncConflictStrategy === 'local_wins'
                    ? 'border-blue-600 bg-blue-50/10 dark:bg-blue-950/10 ring-2 ring-blue-500/10'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    syncConflictStrategy === 'local_wins' 
                      ? 'border-blue-600 bg-blue-600' 
                      : 'border-slate-300'
                  }`}>
                    {syncConflictStrategy === 'local_wins' && <span className="w-1.5 h-1.5 bg-white rounded-full" />}
                  </span>
                  <span className="text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-full">محلي يفوق</span>
                </div>
                <h4 className="font-bold text-sm text-slate-800 dark:text-white mb-1.5">النسخ المحلي يفرض (Local Wins)</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  تحديث السحابة فوراً بأي تغيير في هذا الجهاز، ممتاز للغاية عند الرغبة باعتماد بيانات الحاسوب المكتبي (الرئيسي) كمرجع دائم فوق أي تعديل خارجي.
                </p>
              </div>

              <div 
                onClick={() => handleSaveConflictStrategy('cloud_wins')}
                className={`border rounded-xl p-4 cursor-pointer transition-all duration-200 relative ${
                  syncConflictStrategy === 'cloud_wins'
                    ? 'border-orange-600 bg-orange-50/10 dark:bg-orange-950/10 ring-2 ring-orange-500/10'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                    syncConflictStrategy === 'cloud_wins' 
                      ? 'border-orange-600 bg-orange-600' 
                      : 'border-slate-300'
                  }`}>
                    {syncConflictStrategy === 'cloud_wins' && <span className="w-1.5 h-1.5 bg-white rounded-full" />}
                  </span>
                  <span className="text-xs font-bold text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/60 px-2 py-0.5 rounded-full">سحابي حاسم</span>
                </div>
                <h4 className="font-bold text-sm text-slate-800 dark:text-white mb-1.5">السحابة مهيمنة (Cloud Wins)</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                  تجاهل وإهمال المزامنة لأي بند محلي لو كان موجوداً وصالحاً مسبقاً في قواعد البيانات لتجنب أي تلاعب من الأجهزة الفرعية للعمال دون إذن.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5 justify-start mb-4">
              <History size={16} className="text-indigo-500" />
              <span>التحكم اليدوي ومؤشرات الأمان الفورية ⚙️</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-800/50 flex items-center justify-between">
                <div className="text-right">
                  <p className="text-xs text-slate-500">حالة الاتصال والبيئة</p>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mt-0.5">
                    {dbSyncMode === 'auto' ? (
                      <>
                        <Wifi size={14} className="text-green-500 animate-pulse" />
                        <span className="text-green-600">تزامن تلقائي فوري مفعّل</span>
                      </>
                    ) : (
                      <>
                        <WifiOff size={14} className="text-amber-500" />
                        <span className="text-amber-600 font-bold">وضع العمل محلياً (ديسك توب)</span>
                      </>
                    )}
                  </p>
                </div>
                <button 
                  onClick={() => {
                    const nextMode = dbSyncMode === 'auto' ? 'manual' : 'auto';
                    if (setDbSyncMode) {
                      setDbSyncMode(nextMode);
                      localStorage.setItem('dbSyncMode', nextMode);
                      alert(`🔄 تم التحويل إلى وضع: ${nextMode === 'auto' ? 'التزامن التلقائي السحابي' : 'العمل دون إنترنت محلياً (ديسك توب)'}`);
                    }
                  }}
                  className="bg-white dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-xs font-bold transition"
                >
                  تغيير الوضع
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-800/50">
                <p className="text-xs text-slate-500">حماية وسلامة العمليات المالية</p>
                <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400 mt-1 flex items-center gap-1">
                  <Sparkles size={14} />
                  <span>محصنة تلقائياً من التداخلات المزدوجة</span>
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">يقوم خادم CDC المدمج والمنفذ بحرص بمراجعة كل المعاملات.</p>
              </div>

              <div className="flex flex-col gap-2 justify-center">
                <button 
                  onClick={triggerManualSync}
                  disabled={isManualSyncing}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-white disabled:opacity-50 px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 border border-slate-700 shadow-sm"
                >
                  <RefreshCw size={14} className={isManualSyncing ? "animate-spin" : ""} />
                  {isManualSyncing ? "جاري دفع المزامنة السحابية..." : "دفع المزامنة السحابية الآن (رفع) 📤"}
                </button>

                <button 
                  onClick={triggerCloudPull}
                  disabled={isPullingRemote}
                  className="w-full bg-indigo-50 hover:bg-indigo-100/80 dark:bg-indigo-950/40 dark:hover:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 border border-indigo-200/50 dark:border-indigo-900/30"
                >
                  <RefreshCw size={14} className={isPullingRemote ? "animate-spin" : ""} />
                  {isPullingRemote ? "جاري الاسترداد كلياً..." : "استرداد البيانات سحابياً (تنزيل) 📥"}
                </button>
              </div>
            </div>

            {(saveStatus === 'saving' || saveStatus === 'success' || saveStatus === 'error') && (
              <div className={`mt-3 p-3 rounded-lg text-xs font-bold text-center flex items-center justify-center gap-2 transition ${
                saveStatus === 'saving' ? 'bg-indigo-50 text-indigo-600' :
                saveStatus === 'success' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
              }`}>
                <span>{saveMessage}</span>
              </div>
            )}
          </div>
        </div>
      </div>
          </motion.div>
        )}

        {activeTab === 'webhooks' && (
          <motion.div
            key="webhooks"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <WebhooksManager
              settings={settings}
              setSettings={setSettings}
              activeStoreId={activeStoreId || undefined}
              hostUrl={hostUrl}
              storeData={activeStoreId && allStoresData ? allStoresData[activeStoreId] : undefined}
              orders={activeStoreId && allStoresData ? allStoresData[activeStoreId]?.orders : undefined}
              customers={activeStoreId && allStoresData ? allStoresData[activeStoreId]?.customers : undefined}
              products={activeStoreId && allStoresData ? allStoresData[activeStoreId]?.settings?.products : undefined}
            />
          </motion.div>
        )}

        {activeTab === 'apikeys' && (
          <motion.div
            key="apikeys"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
            <ApiKeysManager 
              settings={settings} 
              setSettings={setSettings} 
              activeStoreId={activeStoreId} 
              hostUrl={hostUrl} 
            />
          </motion.div>
        )}

        {activeTab === 'logs' && (
          <motion.div
            key="logs"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
      <div id="activity-movements" className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden mt-8">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <History size={20} />
            </div>
            <div className="text-right">
              <h2 className="text-lg font-bold text-slate-800 dark:text-white">سجل التحركات والنشاط</h2>
              <p className="text-sm text-slate-500">مراقبة كافة العمليات والتحركات التي تتم في النظام.</p>
            </div>
          </div>
          <button 
            onClick={() => window.location.href = `/store/${activeStoreId}/activity-logs`}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-2"
          >
            <Eye size={16} />
            فتح السجل الكامل
          </button>
        </div>
        <div className="p-6">
          <div className="overflow-hidden border border-slate-200 dark:border-slate-800 rounded-xl">
            <table className="w-full text-right text-[11px]">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-black">
                <tr>
                  <th className="px-4 py-3">الموظف</th>
                  <th className="px-4 py-3">الإجراء</th>
                  <th className="px-4 py-3">التفاصيل</th>
                  <th className="px-4 py-3">التوقيت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {(settings.activityLogs || []).slice(0, 5).map((log: any) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-300">{log.user}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded text-[10px] font-black">{log.action}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">{log.details}</td>
                    <td className="px-4 py-3 text-slate-400 font-mono text-[10px]">{log.date}</td>
                  </tr>
                ))}
                {(settings.activityLogs || []).length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-4 py-12 text-center text-slate-400 italic">لا توجد تحركات مسجلة حالياً.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
          </motion.div>
        )}

        {activeTab === 'mail' && (
          <motion.div
            key="mail"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6 mt-4"
          >
            {/* Header info card */}
            <div className="bg-gradient-to-r from-emerald-900/30 to-teal-900/20 border border-emerald-500/30 rounded-2xl p-6 relative overflow-hidden">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                    <Mail size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-black text-slate-900 dark:text-white">خادم البريد المركزي للمنصة (Platform Global Mailer)</h2>
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-black border ${
                        isMailConfigured 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                      }`}>
                        {isMailConfigured ? '🟢 نشط ومفعل مركزياً' : '🟡 يعمل بالوضع التلقائي'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 max-w-2xl leading-relaxed">
                      يتم حفظ هذه الإعدادات مركزياً على مستوى الخادم لخدمة <strong>جميع التجار والمستخدمين تلقائياً</strong> (رسائل تفعيل الحسابات، رموز 2FA OTP، والإشعارات)، دون أن يطلب النظام أي بيانات بريد من التجار أو المستخدمين مطلقاً.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Config Form & Test Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Form Card (2 Columns) */}
              <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                  <Server size={18} className="text-emerald-500" />
                  <span>تكوين خادم الإرسال المركزي</span>
                </h3>

                <form onSubmit={handleSaveMailConfig} className="space-y-4">
                  
                  {/* Provider Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                      مزود خدمة البريد الأساسي:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'resend', label: 'Resend API (موصى به)' },
                        { id: 'brevo', label: 'Brevo (Sendinblue)' },
                        { id: 'gmail', label: 'Gmail SMTP' },
                        { id: 'smtp', label: 'SMTP مخصص' }
                      ].map(p => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => setMailProvider(p.id as any)}
                          className={`p-3 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                            mailProvider === p.id 
                              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 shadow-sm' 
                              : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100'
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sender Email (From) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      عنوان البريد المرسل (From Address):
                    </label>
                    <input 
                      type="text"
                      value={mailFrom}
                      onChange={e => setMailFrom(e.target.value)}
                      placeholder={mailProvider === 'resend' ? 'onboarding@resend.dev أو info@yourdomain.com' : 'no-reply@yourdomain.com'}
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                    />
                    <p className="text-[11px] text-slate-400 mt-1">
                      الاسم أو البريد الذي سيظهر للمستلم في ترويسة الرسائل.
                    </p>
                  </div>

                  {/* Resend Fields */}
                  {mailProvider === 'resend' && (
                    <div className="space-y-2">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                            مفتاح Resend API Key:
                          </label>
                          <a 
                            href="https://resend.com/api-keys" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-[11px] text-emerald-500 hover:underline inline-flex items-center gap-1"
                          >
                            <span>إنشاء مفتاح من Resend Console</span>
                            <ExternalLink size={10} />
                          </a>
                        </div>
                        <input 
                          type="password"
                          value={mailResendKey}
                          onChange={e => setMailResendKey(e.target.value)}
                          placeholder="re_xxxxxxxxxxxxxxxxxxxx"
                          className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                        />
                      </div>
                      <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
                        <p className="font-bold text-slate-700 dark:text-slate-300">💡 تعليمات Resend الرسمية:</p>
                        <ul className="list-disc list-inside space-y-0.5">
                          <li>للتجربة السريعة، استخدم <code>onboarding@resend.dev</code> في حقل البريد المرسل (From).</li>
                          <li>للإرسال لأي بريد خارجي بدون قيود Sandbox، أضف نطاقك المخصص عبر <a href="https://resend.com/domains" target="_blank" rel="noopener noreferrer" className="text-emerald-500 underline font-bold">Resend Domains</a>.</li>
                        </ul>
                      </div>
                    </div>
                  )}

                  {/* Brevo Fields */}
                  {mailProvider === 'brevo' && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        مفتاح Brevo API Key (v3):
                      </label>
                      <input 
                        type="password"
                        value={mailBrevoKey}
                        onChange={e => setMailBrevoKey(e.target.value)}
                        placeholder="xkeysib-xxxxxxxxxxxxxxxxxxxx"
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                      />
                    </div>
                  )}

                  {/* Gmail & SMTP Fields */}
                  {(mailProvider === 'gmail' || mailProvider === 'smtp') && (
                    <>
                      {mailProvider === 'smtp' && (
                        <div className="grid grid-cols-3 gap-3">
                          <div className="col-span-2">
                            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                              مضيف SMTP (Host):
                            </label>
                            <input 
                              type="text"
                              value={mailSmtpHost}
                              onChange={e => setMailSmtpHost(e.target.value)}
                              placeholder="smtp.mailgun.org"
                              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                              المنفذ (Port):
                            </label>
                            <input 
                              type="text"
                              value={mailSmtpPort}
                              onChange={e => setMailSmtpPort(e.target.value)}
                              placeholder="587"
                              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                            />
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                            {mailProvider === 'gmail' ? 'بريد Gmail المركزي:' : 'اسم المستخدم (User):'}
                          </label>
                          <input 
                            type="text"
                            value={mailSmtpUser}
                            onChange={e => setMailSmtpUser(e.target.value)}
                            placeholder="myplatform@gmail.com"
                            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                            {mailProvider === 'gmail' ? 'كلمة مرور التطبيقات (App Password):' : 'كلمة المرور (Password):'}
                          </label>
                          <input 
                            type="password"
                            value={mailSmtpPass}
                            onChange={e => setMailSmtpPass(e.target.value)}
                            placeholder="••••••••••••"
                            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-emerald-500 dir-ltr text-right"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {mailStatusMsg && (
                    <div className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
                      mailStatusMsg.isError ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 border border-rose-200' : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 border border-emerald-200'
                    }`}>
                      {mailStatusMsg.isError ? <AlertCircle size={15} /> : <Check size={15} />}
                      <span>{mailStatusMsg.text}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSavingMail}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSavingMail ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                    <span>حفظ وتطبيق إعدادات الخادم المركزي</span>
                  </button>
                </form>
              </div>

              {/* Test Email Box (1 Column) */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                    <Send size={18} className="text-indigo-500" />
                    <span>اختبار الإرسال المباشر</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 leading-relaxed">
                    أرسل رسالة تجريبية فورية للتحقق من كفاءة التوصيل دون الحاجة لتسجيل مستخدم جديد.
                  </p>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        البريد المستلم للتجربة:
                      </label>
                      <input 
                        type="email"
                        value={testEmailRecipient}
                        onChange={e => setTestEmailRecipient(e.target.value)}
                        placeholder="your-email@example.com"
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:border-indigo-500 dir-ltr text-right"
                      />
                    </div>

                    {testMailResult && (
                      <div className={`p-3 rounded-xl text-xs font-bold flex items-start gap-2 ${
                        testMailResult.isError ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 border border-rose-200' : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 border border-emerald-200'
                      }`}>
                        {testMailResult.isError ? <AlertCircle size={15} className="shrink-0 mt-0.5" /> : <Check size={15} className="shrink-0 mt-0.5" />}
                        <span>{testMailResult.text}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={handleSendTestMail}
                    disabled={isSendingTestMail || !testEmailRecipient.trim()}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSendingTestMail ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
                    <span>إرسال بريد تجريبي الآن</span>
                  </button>
                </div>
              </div>

            </div>
          </motion.div>
        )}

        {activeTab === 'platforms' && (
          <motion.div
            key="platforms"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
          >
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl shadow-slate-200/40 dark:shadow-slate-900/40 border border-slate-200/60 dark:border-slate-800/60 overflow-hidden mt-8">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-500/20 flex items-center justify-center text-purple-600 dark:text-purple-400">
               <ShoppingCart size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800 dark:text-white">تكامل منصات التجارة الإلكترونية</h2>
              <p className="text-sm text-slate-500">استخدم هذه الروابط لربط متجرك بمنصات مثل ويلت (Wuilt) وغيرها.</p>
            </div>
          </div>
        </div>
        
        <div className="p-6 space-y-6">
          <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-5 relative bg-slate-50/50 dark:bg-slate-800/20">
             <h3 className="font-bold text-slate-800 dark:text-white text-md mb-2 flex items-center gap-2">
               منصة ويلت (Wuilt)
             </h3>
             <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 leading-relaxed max-w-2xl text-right">
               قم بنسخ الرابط التالي وإضافته في إعدادات متجرك على ويلت (قسم Webhooks) لاختيار الأحداث مثل (Order Created) لكي تنزل الطلبات تلقائياً هنا.
             </p>

             <div className="space-y-1.5 font-sans text-right">
                <label className="text-xs font-bold text-slate-500 flex items-center gap-1 justify-end"><Webhook size={14} /> رابط Webhook Cloud Function المشفر</label>
                <div className="flex gap-2 items-center font-sans">
                  <input 
                    type="text" 
                    readOnly
                    className="w-full bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2 text-sm text-slate-600 dark:text-slate-400 font-mono outline-none text-left"
                    value={`https://cloud-functions.abdomedi.com/webhook?storeId=${activeStoreId || 'YOUR_STORE_ID'}&platform=wuilt`}
                    dir="ltr"
                  />
                  <button 
                    onClick={() => handleCopy(`https://cloud-functions.abdomedi.com/webhook?storeId=${activeStoreId || 'YOUR_STORE_ID'}&platform=wuilt`)} 
                    className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 p-2 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition"
                    title="نسخ الرابط"
                  >
                     {copiedLink === `https://cloud-functions.abdomedi.com/webhook?storeId=${activeStoreId || 'YOUR_STORE_ID'}&platform=wuilt` ? <CheckCircle2 size={18} className="text-green-500" /> : <Copy size={18} />}
                  </button>
                </div>
             </div>
          </div>

          <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-5 relative bg-slate-50/50 dark:bg-slate-800/20 opacity-70">
             <h3 className="font-bold text-slate-800 dark:text-white text-md mb-2 flex items-center gap-2 justify-end">
               منصات أخرى قريباً (Salla, Zid, Shopify)
             </h3>
             <p className="text-xs text-slate-500 dark:text-slate-400 mb-2 leading-relaxed max-w-2xl text-right">
               سيتم إضافة تكاملات مخصصة لهذه المنصات في المستقبل القريب لضمان أعلى سرعة في المزامنة وأمان لبياناتك.
             </p>
          </div>
        </div>
      </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Custom Alarm / Prompt Sound Alert Modal */}
      <AnimatePresence>
        {alarm && alarm.show && (
          <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (!alarm.showCancel) setAlarm(null);
              }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            
            {/* Alarm Dialog Card */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200/80 dark:border-slate-800/80 overflow-hidden text-right font-sans"
            >
              {/* Sound Ring Pulse Decorator */}
              <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
              
              <div className="flex flex-col items-center text-center mt-3">
                {/* Visual Icon based on Alarm TYPE */}
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-lg ${
                  alarm.type === 'success' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400' :
                  alarm.type === 'error' ? 'bg-red-100 text-red-600 dark:bg-red-950/40 dark:text-red-400' :
                  alarm.type === 'warning' ? 'bg-amber-100 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400 font-bold' :
                  'bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400'
                }`}>
                  {alarm.type === 'success' && <CheckCircle2 size={32} />}
                  {alarm.type === 'error' && <ShieldAlert size={32} />}
                  {alarm.type === 'warning' && <AlertCircle size={32} />}
                  {alarm.type === 'info' && <Database size={32} />}
                </div>

                {/* Alarm Ringing Animation Indicator */}
                <div className="flex items-center gap-1.5 mb-2 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-500 dark:text-slate-400 font-bold tracking-wider animate-bounce">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
                  <span>تنبيه داخلي نشط 🔔</span>
                </div>

                <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1 leading-tight">
                  {alarm.title}
                </h3>
                
                <p className="text-sm text-slate-600 dark:text-slate-450 mt-3 leading-relaxed whitespace-pre-line text-center px-2">
                  {alarm.message}
                </p>
              </div>

              {/* Confirm / Cancel Actions */}
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    const onConf = alarm.onConfirm;
                    setAlarm(null);
                    if (onConf) onConf();
                  }}
                  className={`flex-1 px-5 py-3 rounded-2xl text-xs font-black text-white hover:scale-[1.02] active:scale-[0.98] transition-all shadow-md cursor-pointer ${
                    alarm.type === 'success' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/10' :
                    alarm.type === 'error' ? 'bg-red-600 hover:bg-red-700 shadow-red-500/10' :
                    alarm.type === 'warning' ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/10' :
                    'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/10'
                  }`}
                >
                  {alarm.confirmText}
                </button>
                
                {alarm.showCancel && (
                  <button
                    onClick={() => setAlarm(null)}
                    className="flex-1 px-5 py-3 rounded-2xl text-xs font-black bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 cursor-pointer"
                  >
                    {alarm.cancelText}
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default DeveloperSettingsPage;
