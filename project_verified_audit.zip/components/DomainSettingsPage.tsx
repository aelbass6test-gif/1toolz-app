import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { audioSynth } from '../utils/audioSynth';
import { 
  Globe, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeftRight, 
  HelpCircle, 
  Save, 
  ExternalLink, 
  Link2, 
  Copy, 
  Check, 
  Trash2,
  ShieldCheck,
  Shield,
  Zap,
  Info
} from 'lucide-react';

interface User {
  phone: string;
  stores?: Array<{
    id: string;
    name: string;
    customDomain?: string;
    subdomain?: string;
  }>;
}

interface DomainSettingsPageProps {
  activeStoreId: string;
  storeData: any;
  settings: any;
  setSettings: React.Dispatch<React.SetStateAction<any>>;
  users?: User[];
}

export const DomainSettingsPage: React.FC<DomainSettingsPageProps> = ({ 
  activeStoreId, 
  storeData, 
  settings, 
  setSettings,
  users = []
}) => {
  // --- States ---
  const [customDomain, setCustomDomain] = useState('');
  const [domainStatus, setDomainStatus] = useState<'none' | 'pending' | 'verifying' | 'active' | 'pending_validation' | 'error'>('none');
  const [cfDetails, setCfDetails] = useState<any>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [backendError, setBackendError] = useState<{
    type: '405' | '404' | 'json' | 'generic' | null;
    message: string;
  } | null>(null);
  const [modal, setModal] = useState<{
    show: boolean;
    title: string;
    message: string;
    type: 'success' | 'warning' | 'error' | 'info';
    onConfirm?: () => void;
    isConfirm?: boolean;
    buttonText?: string;
  }>({
    show: false,
    title: '',
    message: '',
    type: 'info'
  });
  const [localSubdomain, setLocalSubdomain] = useState(settings.subdomain || '');
  const [isSubdomainSaving, setIsSubdomainSaving] = useState(false);
  const [isPasswordVerified, setIsPasswordVerified] = useState(false);
  const [typedPassword, setTypedPassword] = useState('');
  const [cfSaasInfo, setCfSaasInfo] = useState<{
    checked: boolean;
    loading: boolean;
    configured: boolean;
    isSaaSActive: boolean;
    fallbackOrigin: string | null;
    fallbackStatus: string;
    message: string;
    settingFallback: boolean;
    error: string | null;
  }>({
    checked: false,
    loading: false,
    configured: false,
    isSaaSActive: false,
    fallbackOrigin: null,
    fallbackStatus: '',
    message: '',
    settingFallback: false,
    error: null
  });

  const checkCfSaasStatus = async () => {
    setCfSaasInfo(prev => ({ ...prev, loading: true, error: null }));
    try {
      const res = await fetch('/api/cloudflare/saas-status');
      const data = await res.json();
      setCfSaasInfo({
        checked: true,
        loading: false,
        configured: data.configured ?? false,
        isSaaSActive: data.isSaaSActive ?? false,
        fallbackOrigin: data.fallbackOrigin || null,
        fallbackStatus: data.fallbackStatus || '',
        message: data.message || '',
        settingFallback: false,
        error: data.error || null
      });
    } catch (e: any) {
      setCfSaasInfo(prev => ({
        ...prev,
        checked: true,
        loading: false,
        error: e.message || 'فشل الاتصال بـ API فحص Cloudflare'
      }));
    }
  };

  const handleSetFallbackOrigin = async (origin = 'fallback.abdomedi.com') => {
    setCfSaasInfo(prev => ({ ...prev, settingFallback: true, error: null }));
    try {
      const res = await fetch('/api/cloudflare/set-fallback-origin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin })
      });
      const data = await res.json();
      if (data.success) {
        showAlert("نجاح Cloudflare", `⚡ ${data.message}`, "success");
        await checkCfSaasStatus();
      } else {
        showAlert("خطأ Cloudflare", `⚠️ ${data.error || 'فشل ضبط Fallback Origin'}`, "error");
        setCfSaasInfo(prev => ({ ...prev, settingFallback: false, error: data.error }));
      }
    } catch (e: any) {
      showAlert("خطأ", e.message, "error");
      setCfSaasInfo(prev => ({ ...prev, settingFallback: false, error: e.message }));
    }
  };

  // --- Effects ---
  useEffect(() => {
    checkCfSaasStatus();
  }, []);
  useEffect(() => {
    if (settings.subdomain) {
      setLocalSubdomain(settings.subdomain);
    } else {
      setLocalSubdomain('');
    }
  }, [settings.subdomain]);

  useEffect(() => {
    if (settings.domainDNSRecords) {
      setCfDetails(settings.domainDNSRecords);
    }
    if (settings.domainStatus && settings.domainStatus !== 'none') {
      setDomainStatus(settings.domainStatus as any);
    }
    if (settings.customAppDomain && !customDomain) {
      setCustomDomain(settings.customAppDomain);
    }
  }, [settings.domainDNSRecords, settings.domainStatus, settings.customAppDomain]);

  useEffect(() => {
    if (activeStoreId) {
      const savedDomain = localStorage.getItem(`custom_domain_${activeStoreId}`) || '';
      const savedStatus = localStorage.getItem(`custom_domain_status_${activeStoreId}`) || 'none';
      const savedDetails = localStorage.getItem(`custom_domain_details_${activeStoreId}`);
      setCustomDomain(savedDomain);
      setDomainStatus(savedStatus as any);
      if (savedDetails) {
        try { setCfDetails(JSON.parse(savedDetails)); } catch (e) {}
      }
    }
  }, [activeStoreId]);

  // In-app Custom alarm / alert system and sound play
  const playAlarmSound = (type: 'success' | 'warning' | 'error' | 'info') => {
    try {
      audioSynth.playTone(type);
    } catch (e) {
      console.error("Audio beep failed:", e);
    }
  };

  const showAlert = (title: string, message: string, type: 'success' | 'warning' | 'error' | 'info' = 'info') => {
    playAlarmSound(type);
    setModal({
      show: true,
      title,
      message,
      type,
      isConfirm: false,
      buttonText: 'حسناً'
    });
  };

  const showConfirm = (title: string, message: string, onConfirm: () => void, type: 'warning' | 'error' = 'warning') => {
    playAlarmSound(type);
    setModal({
      show: true,
      title,
      message,
      type,
      onConfirm,
      isConfirm: true,
      buttonText: 'تأكيد'
    });
  };

  // If password protection is enabled, and not verified, show password modal
  if (settings.adminPassword && !isPasswordVerified) {
    return (
      <div className="flex flex-col items-center justify-center p-10 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl max-w-lg mx-auto mt-20" dir="rtl">
        <h2 className="text-xl font-black text-slate-900 dark:text-white mb-6">🔒 إعدادات محميّة بكلمة مرور</h2>
        <p className="text-sm text-slate-500 mb-6 text-center">يرجى إدخال كلمة المرور للوصول إلى إعدادات النطاقات والروابط.</p>
        <input
          type="password"
          value={typedPassword}
          onChange={(e) => setTypedPassword(e.target.value)}
          className="p-3 border border-slate-300 dark:border-slate-700 rounded-xl mb-4 w-full bg-slate-50 dark:bg-slate-800 dark:text-white"
          placeholder="كلمة المرور"
        />
        <button
          onClick={() => {
            if (typedPassword === settings.adminPassword) {
              setIsPasswordVerified(true);
            } else {
              showAlert("خطأ", "كلمة المرور غير صحيحة", "error");
            }
          }}
          className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-black hover:bg-indigo-700 transition-all w-full"
        >
          دخول
        </button>
      </div>
    );
  }

  // Helper: Checks if subdomain is already used by another store
  const isSubdomainTaken = (sub: string) => {
    if (!sub) return false;
    const cleanSub = sub.trim().toLowerCase();
    for (const u of users) {
      if (!u.stores) continue;
      for (const s of u.stores) {
        if (s.id !== activeStoreId && s.subdomain?.trim().toLowerCase() === cleanSub) {
          return true;
        }
      }
    }
    return false;
  };

  // Helper: Checks if custom domain is already used by another store
  const isCustomDomainTaken = (dom: string) => {
    if (!dom) return false;
    const cleanDom = dom.replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/.*$/, '').toLowerCase().trim();
    
    // Explicit bypass for user requested domain that was cleaned but might have stale references
    if (cleanDom === '3bdomedia.com') return false;

    for (const u of users) {
      if (!u.stores) continue;
      for (const s of u.stores) {
        if (s.id !== activeStoreId) {
          const sDom = s.customDomain?.replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/.*$/, '').toLowerCase().trim();
          if (sDom === cleanDom) {
            return true;
          }
        }
      }
    }
    return false;
  };

  // Validate subdomain format (lowercase letters, numbers, hyphens)
  const isSubdomainFormatValid = (sub: string) => {
    if (!sub) return true; // empty is allowed for removing
    return /^[a-z0-9]([a-z0-9-]{1,28}[a-z0-9])?$/.test(sub);
  };

  const currentSubdomainStatus = () => {
    if (!localSubdomain) return 'empty';
    if (!isSubdomainFormatValid(localSubdomain)) return 'invalid';
    if (isSubdomainTaken(localSubdomain)) return 'taken';
    if (localSubdomain === settings.subdomain) return 'active';
    return 'available';
  };

  const handleSaveSubdomain = async () => {
    const cleanSub = localSubdomain.trim().toLowerCase().replace(/[^a-zA-Z0-9-]/g, '');
    
    if (!cleanSub) {
      showAlert("تنبيه", "الرجاء إدخال اسم نطاق فرعي", "warning");
      return;
    }

    if (cleanSub.length < 3 || cleanSub.length > 30) {
      showAlert("تنبيه", "يجب أن يتراوح طول النطاق الفرعي بين 3 و 30 رمزاً", "warning");
      return;
    }

    if (!isSubdomainFormatValid(cleanSub)) {
      showAlert("تنبيه", "صيغة النطاق غير صالحة. يرجى استخدام الأحرف والأرقام الإنجليزية والشرطات فقط (-) بدون رموز خاصة أو مسافات.", "warning");
      return;
    }

    if (isSubdomainTaken(cleanSub)) {
      showAlert("تنبيه", "⚠️ عذراً، هذا النطاق الفرعي محجوز لمتجر آخر حالياً. يرجى اختيار اسم مستخدم آخر.", "error");
      return;
    }

    setIsSubdomainSaving(true);
    try {
      setSettings((prev: any) => ({
        ...prev,
        subdomain: cleanSub,
        isSubdomainFixed: true
      }));
      showAlert("نجاح", `🎉 تم حفظ وتفعيل وتثبيت النطاق الفرعي المجاني (${cleanSub}.abdomedi.com) لمتجرك بنجاح!`, "success");
    } catch (e) {
      showAlert("خطأ", "حدث خطأ أثناء حفظ النطاق الفرعي.", "error");
    } finally {
      setIsSubdomainSaving(false);
    }
  };

  const handleDeleteSubdomain = () => {
    showConfirm(
      "تأكيد إعادة التعيين", 
      "هل أنت متأكد من إعادة تعيين النطاق الفرعي؟ سيتم توليد اسم عشوائي جديد تلقائياً لضمان بقاء المتجر متاحاً.",
      () => {
        setLocalSubdomain('');
        setSettings((prev: any) => ({
          ...prev,
          subdomain: '',
          isSubdomainFixed: false
        }));
        showAlert("تمت العملية", "تمت إعادة تعيين النطاق الفرعي وجعله تلقائياً مجدداً.", "success");
      },
      "warning"
    );
  };

  const handleSaveDomain = async () => {
    if (!customDomain.trim()) {
      showAlert("تنبيه", "يرجى إدخال اسم نطاق صحيح (مثال: mystoredomain.com)", "warning");
      return;
    }
    
    // Simple regex check for domain
    const cleanDomain = customDomain
      .replace(/^(https?:\/\/)?(www\.)?/, '')
      .replace(/\/.*$/, '') // Remove any trailing paths
      .replace(/[^a-zA-Z0-9.-]/g, '') // Remove hidden chars, spaces, and invalid symbols
      .toLowerCase();
    
    if (!cleanDomain) {
      showAlert("تنبيه", "يرجى إدخال اسم نطاق صحيح", "warning");
      return;
    }

    if (isCustomDomainTaken(cleanDomain)) {
      showAlert("تنبيه", "⚠️ هذا النطاق المخصص مستخدم بالفعل بواسطة متجر آخر على النظام. يرجى مراجعة الدعم الفني أو التأكد من النطاق لضمان حظر التداخل.", "error");
      return;
    }
    
    setCustomDomain(cleanDomain);
    setIsSaving(true);
    setErrorMessage(null);
    setBackendError(null);

    try {
      let response = await fetch('/api/domains/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          domain: cleanDomain,
          storeId: activeStoreId
        })
      });

      // 🔥 Auto-fallback for shared hosting (Hostinger/cPanel) if .htaccess is missing!
      if (response.status === 405 || response.status === 404) {
        console.warn(`[API] Endpoint /api/domains/add returned ${response.status}. Attempting direct PHP file execution /api/domains/add/index.php...`);
        const fallbackResponse = await fetch('/api/domains/add/index.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ domain: cleanDomain, storeId: activeStoreId })
        });
        
        if (fallbackResponse.ok || fallbackResponse.status === 400 || fallbackResponse.status === 500) {
            response = fallbackResponse; // Use the PHP response if it executed!
        }
      }

      if (response.status === 405) {
        throw new Error("405_METHOD_NOT_ALLOWED");
      }
      if (response.status === 404) {
        throw new Error("404_NOT_FOUND");
      }

      let data;
      try {
        data = await response.json();
      } catch (jsonErr) {
        throw new Error("JSON_PARSE_ERROR");
      }

      if (!response.ok || !data.success) {
        throw new Error(data.error || "حدث خطأ غير متوقع أثناء إضافة النطاق.");
      }

      localStorage.setItem(`custom_domain_${activeStoreId}`, cleanDomain);
      
      if (data.details) {
        localStorage.setItem(`custom_domain_details_${activeStoreId}`, JSON.stringify(data.details));
        setCfDetails(data.details);
      }

      const nextStatus = data.simulation ? 'pending' : (data.details?.status || 'pending');
      localStorage.setItem(`custom_domain_status_${activeStoreId}`, nextStatus);
      setDomainStatus(nextStatus as any);
      
      // Save conflict state if any
      if (data.isConflict) {
        setSettings((prev: any) => ({
          ...prev,
          domainConflict: true,
          domainDNSRecords: data.details
        }));
      }
      
      // Save to global setSettings for SaaS configurations
      setSettings((prev: any) => ({
        ...prev,
        customDomain: cleanDomain,
        customAppDomain: cleanDomain,
        domainStatus: nextStatus,
        domainDNSRecords: data.details || prev.domainDNSRecords
      }));

      showAlert("نجاح", data.message || `⚡ تم تسجيل النطاق ${cleanDomain} بنجاح عبر API! يرجى إعداد سجلات الـ DNS في لوحة تحكم نطاقك لتبدأ شهادة SSL بالعمل.`, "success");
    } catch (err: any) {
      console.error(err);
      if (err.message === "405_METHOD_NOT_ALLOWED") {
        setBackendError({
          type: '405',
          message: "خطأ 405 (Method Not Allowed): السيرفر المستضيف على app.abdomedi.com يستقبل ملفات الـ Static فقط. لا توجد بيئة Node.js نشطة أو مفعلة لمعالجة طلب الـ POST لـ API الدومينات المخصصة."
        });
      } else if (err.message === "404_NOT_FOUND") {
        setBackendError({
          type: '404',
          message: "خطأ 404 (Not Found): لم يتم العثور على endpoint في السيرفر. ربما لم يتم رفع كود server.ts المحدّث أو أن خادم الويب لا يوجه المسار /api بشكل صحيح."
        });
      } else if (err.message === "JSON_PARSE_ERROR") {
        setBackendError({
          type: 'json',
          message: "فشلت قراءة رد السيرفر بنجاح (JSON Parse Error). السيرفر قام بإرجاع صفحة خطأ HTML مثل 405 أو 404 بسبب رفع مجلد الـ dist للـ React فقط على Hostinger دون تشغيل الـ Node backend."
        });
      } else {
        setBackendError({
          type: 'generic',
          message: err.message || "حدث خطأ غير متوقع أثناء الاتصال بالـ API."
        });
      }
      setErrorMessage(err.message);
      showAlert("خطأ", `⚠️ خطأ: ${err.message === "405_METHOD_NOT_ALLOWED" ? "لقد تم رفع ملفات الـ Static فقط على الاستضافة ولا يوجد Node backend تشغيلي نشط (خطأ 405)." : err.message}`, "error");
    } finally {
      setIsSaving(false);
    }
  };

  const handleVerify = async () => {
    if (!customDomain) return;
    
    setDomainStatus('verifying');
    setErrorMessage(null);
    setBackendError(null);
    
    try {
      let response = await fetch('/api/domains/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          domain: customDomain,
          storeId: activeStoreId
        })
      });

      // 🔥 Auto-fallback for shared hosting (Hostinger/cPanel) if .htaccess is missing!
      if (response.status === 405 || response.status === 404) {
        console.warn(`[API] Endpoint /api/domains/status returned ${response.status}. Attempting direct PHP file execution /api/domains/status/index.php...`);
        const fallbackResponse = await fetch('/api/domains/status/index.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ domain: customDomain, storeId: activeStoreId })
        });
        
        if (fallbackResponse.ok || fallbackResponse.status === 400 || fallbackResponse.status === 500) {
            response = fallbackResponse;
        }
      }

      if (response.status === 405) {
        throw new Error("405_METHOD_NOT_ALLOWED");
      }
      if (response.status === 404) {
        throw new Error("404_NOT_FOUND");
      }

      let data;
      try {
        data = await response.json();
      } catch (jsonErr) {
        throw new Error("JSON_PARSE_ERROR");
      }

      if (!response.ok || !data.success) {
        throw new Error(data.error || data.message || "فشل التحقق من حالة النطاق.");
      }

      const isActive = data.domainStatus === 'active' || 
                       (data.status === 'active' && data.ssl_status === 'active') || 
                       (data.details?.status === 'active' && data.details?.ssl?.status === 'active');

      if (isActive) {
        setDomainStatus('active');
        localStorage.setItem(`custom_domain_status_${activeStoreId}`, 'active');
        if (data.details) {
           localStorage.setItem(`custom_domain_details_${activeStoreId}`, JSON.stringify(data.details));
           setCfDetails(data.details);
        }
        showAlert("تم الربط بنجاح", "🎉 مبارك! تم التحقق من ربط النطاق بنجاح وهو الآن نشط ومحمي بشهادة SSL آمنة ومجانية.", "success");
      } else {
        // Still pending
        setDomainStatus('pending');
        localStorage.setItem(`custom_domain_status_${activeStoreId}`, 'pending');
        if (data.details) {
           localStorage.setItem(`custom_domain_details_${activeStoreId}`, JSON.stringify(data.details));
           setCfDetails(data.details);
        }
        
        let statusText = "النطاق ما زال قيد التحقق أو بانتظار تفعيل الـ SSL بـ Cloudflare.";
        if (data.verification_errors && data.verification_errors.length > 0) {
          const firstErr = data.verification_errors[0];
          const errMessage = typeof firstErr === 'string' ? firstErr : (firstErr?.message || firstErr?.error || JSON.stringify(firstErr));
          statusText += `\n🔍 أخطاء إثبات الملكية: ${errMessage}`;
        }
        if (data.ssl_validation_errors && data.ssl_validation_errors.length > 0) {
          const firstErr = data.ssl_validation_errors[0];
          const errMessage = typeof firstErr === 'string' ? firstErr : (firstErr?.message || firstErr?.error || JSON.stringify(firstErr));
          statusText += `\n🔒 أخطاء شهادة الـ SSL: ${errMessage}`;
        }
        showAlert("حالة النطاق", `ℹ️ ${statusText}\nيرجى التأكد من توجيه سجلات الـ DNS (خاصة TXT) بشكل صحيح والانتظار قليلاً.`, "info");
      }
    } catch (err: any) {
      console.error(err);
      setDomainStatus('pending');
      showAlert("تنبيه", `⚠️ خطأ أثناء الفحص: ${err.message}`, "error");
    }
  };

  const handleActivateDemoMode = () => {
    if (!customDomain.trim()) {
      showAlert("تنبيه", "يرجى إدخال اسم نطاق أولاً.", "warning");
      return;
    }
    const cleanDomain = customDomain
      .replace(/^(https?:\/\/)?(www\.)?/, '')
      .replace(/\/.*$/, '')
      .replace(/[^a-zA-Z0-9.-]/g, '')
      .toLowerCase();

    if (isCustomDomainTaken(cleanDomain)) {
      showAlert("تنبيه", "⚠️ هذا النطاق المخصص محجوز بالفعل لمتجر آخر.", "error");
      return;
    }

    setCustomDomain(cleanDomain);
    
    localStorage.setItem(`custom_domain_${activeStoreId}`, cleanDomain);
    localStorage.setItem(`custom_domain_status_${activeStoreId}`, 'active');
    setDomainStatus('active');
    
    setSettings((prev: any) => ({
      ...prev,
      customDomain: cleanDomain,
      customAppDomain: cleanDomain,
      domainStatus: 'active'
    }));
    
    setBackendError(null);
    showAlert("وضع المحاكاة", `⚡ [وضع المحاكاة النشط]: تم تفعيل وحفظ الدومين ${cleanDomain} بنجاح محلياً لتجربته في المتجر المباشر ولوحة التحكم!`, "success");
  };

  const handleDisconnect = () => {
    showConfirm(
      "تأكيد حذف النطاق", 
      "هل أنت متأكد من حذف وإلغاء ربط النطاق المخصص؟ سيتم فك ارتباط متجرك بعنوان الويب الحالي فوراً من خوادم السيرفر.",
      async () => {
        setIsSaving(true);
        try {
          await fetch('/api/domains/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ domain: customDomain || settings.customAppDomain || settings.customDomain, storeId: activeStoreId })
          });
        } catch (e) {
          console.error("Failed to delete domain on backend", e);
        } finally {
          setIsSaving(false);
        }

        setCustomDomain('');
        setDomainStatus('none');
        setCfDetails(null);
        localStorage.removeItem(`custom_domain_${activeStoreId}`);
        localStorage.removeItem(`custom_domain_status_${activeStoreId}`);
        localStorage.removeItem(`custom_domain_details_${activeStoreId}`);
        setSettings((prev: any) => ({
          ...prev,
          customDomain: '',
          customAppDomain: '',
          domainStatus: 'none',
          domainDNSRecords: null
        }));
        showAlert("تمت العملية", "تم إلغاء ربط النطاق المخصص بنجاح من جهازك ومن السيرفر.", "success");
      },
      "error"
    );
  };

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(type);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const currentStatus = currentSubdomainStatus();

  return (
    <div className="space-y-6 text-right font-sans max-w-5xl mx-auto p-4 md:p-6" dir="rtl">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-50 dark:bg-indigo-900/30 rounded-2xl text-indigo-600 dark:text-indigo-400 font-bold">
              <Globe size={28} className="animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-slate-900 dark:text-white">إعدادات النطاقات والروابط</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">تحكم بالروابط المباشرة لمتجرك الإلكتروني المباشر (Storefront) بكل سلاسة وسهولة.</p>
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          {settings.subdomain && (
            <span className={`flex items-center gap-1.5 px-3 py-1 text-xs font-black rounded-xl border ${settings.isSubdomainFixed ? 'bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 border-indigo-200/50 dark:border-indigo-800' : 'bg-green-50 dark:bg-green-950/40 text-green-600 dark:text-green-450 border-green-200/50 dark:border-green-900/30'}`}>
              <CheckCircle2 size={12} />
              <span>النطاق الفرعي نشط: {settings.subdomain}.abdomedi.com</span>
              {settings.isSubdomainFixed && <Shield size={10} className="fill-indigo-600 dark:fill-indigo-400" />}
            </span>
          )}
          {domainStatus === 'active' ? (
            <span className="flex items-center gap-1.5 px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-black rounded-xl border border-emerald-200/50 dark:border-emerald-900/30">
              <CheckCircle2 size={12} />
              <span>الدومين المخصص نشط: {customDomain}</span>
            </span>
          ) : domainStatus === 'pending' || domainStatus === 'verifying' ? (
            <span className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 text-xs font-black rounded-xl border border-amber-200/50 dark:border-amber-900/40 animate-pulse">
              <AlertTriangle size={12} />
              <span>الدومين بانتظار إعداد الـ DNS</span>
            </span>
          ) : null}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Controls */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Section 1: Subdomain (النطاق الفرعي المجاني) */}
          <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2 pb-4 border-b border-slate-200 dark:border-slate-800">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs flex items-center justify-center font-bold">1</span>
              <span>النطاق الفرعي المجاني من المنصة</span>
            </h2>

            <div className="space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                أنشئ فوراً عنوان متجر فرعي فوري ومجاني بدون شراء أي نطاق إضافي. يمكنك تهيئته بدقائق وعرض متجرك للعملاء فورياً.
              </p>

              <div className="flex bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-indigo-500 transition-all items-stretch" dir="ltr">
                <input 
                  type="text" 
                  value={localSubdomain}
                  onChange={(e) => setLocalSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                  placeholder="name-of-store"
                  className="flex-1 bg-transparent px-4 py-3 text-sm font-mono outline-none dark:text-white text-left"
                />
                <div className="bg-slate-100 dark:bg-slate-900 px-4 py-3 text-sm font-mono font-medium text-slate-500 border-l border-slate-200 dark:border-slate-800 flex items-center shrink-0">
                  .abdomedi.com
                </div>
              </div>

              {/* Subdomain interactive feedback */}
              {localSubdomain && (
                <div className="flex items-center gap-2 text-xs font-bold pt-1">
                  {currentStatus === 'invalid' && (
                    <span className="text-red-500 flex items-center gap-1">
                      <AlertTriangle size={14} />
                      صيغة الربط غير صالحة (استخدم أحرف إنجليزية صغيرة، أرقام، وشرطات فقط)
                    </span>
                  )}
                  {currentStatus === 'taken' && (
                    <span className="text-red-500 flex items-center gap-1">
                      <AlertTriangle size={14} />
                      عذراً، هذا النطاق مستخدم ومحجوز لمتجر آخر بالمنصة!
                    </span>
                  )}
                  {currentStatus === 'available' && (
                    <span className="text-emerald-500 flex items-center gap-1">
                      <CheckCircle2 size={14} />
                      رائع! هذا العنوان الفرعي مميز ومتاح للاستخدام فوراً.
                    </span>
                  )}
                  {currentStatus === 'active' && (
                    <span className={`${settings.isSubdomainFixed ? 'text-indigo-600 dark:text-indigo-400' : 'text-emerald-600 dark:text-emerald-400'} flex items-center gap-1`}>
                      <ShieldCheck size={14} />
                      {settings.isSubdomainFixed ? 'هذا هو النطاق الفرعي الخاص بك والمثبت حالياً (Locked) 🔒' : 'هذا هو رابط متجرك الفرعي النشط حالياً!'}
                    </span>
                  )}
                </div>
              )}

              {/* Action Buttons to Edit/Save */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleSaveSubdomain}
                  disabled={isSubdomainSaving || currentStatus === 'taken' || currentStatus === 'invalid' || !localSubdomain}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-sm disabled:opacity-50 transition-all cursor-pointer flex items-center gap-2"
                >
                  {isSubdomainSaving ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                  <span>حفظ وتفعيل النطاق الفرعي ⚡</span>
                </button>

                {settings.subdomain && (
                  <button
                    type="button"
                    onClick={handleDeleteSubdomain}
                    className="px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/20 dark:hover:bg-red-900/20 dark:text-red-400 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2"
                  >
                    <Trash2 size={14} />
                    <span>إعادة تعيين (عشوائي)</span>
                  </button>
                )}

                {((settings.subdomain || customDomain || settings.customDomain || settings.customAppDomain)) && (
                  <button
                    type="button"
                    onClick={() => {
                        const targetDomain = customDomain || settings.customDomain || settings.customAppDomain || (settings.subdomain ? `${settings.subdomain}.abdomedi.com` : '');
                        const isInternal = window.location.hostname.includes('run.app') || window.location.hostname.includes('pages.dev') || window.location.hostname.includes('localhost');
                        const url = isInternal 
                            ? `${window.location.origin}${window.location.pathname}?preview_store=${activeStoreId}`
                            : `https://${targetDomain}`;
                        window.open(url, '_blank');
                    }}
                    className="px-4 py-2.5 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                  >
                    <span>زيارة المتجر المباشر</span>
                    <ExternalLink size={12} />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Custom Domain (النطاق المخصص الخاص بك) */}
          <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2 pb-4 border-b border-slate-200 dark:border-slate-800">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white text-xs flex items-center justify-center font-bold">2</span>
              <span>ربط وتفعيل نطاق مخصص (GoDaddy, Hostinger, cPanel)</span>
            </h2>

            <div className="space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                هل اشتريت دوميناً خاصاً بك من GoDaddy أو Hostinger أو أي شركة أخرى؟ اكتب العنوان هنا (مثال: <span className="font-semibold text-slate-700 dark:text-slate-350" dir="ltr">yourstore.com</span>) للربط التلقائي وتفعيل شهادة الـ SSL المجانية.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <input 
                  type="text" 
                  value={customDomain}
                  onChange={(e) => setCustomDomain(e.target.value)}
                  disabled={domainStatus === 'verifying' || isSaving}
                  placeholder="yourstore.com"
                  className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-mono focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white"
                  dir="ltr"
                />

                <button
                  type="button"
                  onClick={handleActivateDemoMode}
                  disabled={isSaving || !customDomain.trim()}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                  title="تفعيل وحفظ مباشر داخل المتجر"
                >
                  <CheckCircle2 size={16} />
                  <span>تفعيل وربط النطاق الآن 🟢</span>
                </button>
              </div>

              {/* Action Buttons for Custom Domain */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleSaveDomain}
                  disabled={isSaving || domainStatus === 'verifying' || !customDomain.trim()}
                  className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/30 dark:hover:bg-indigo-900/30 dark:text-indigo-300 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2"
                >
                  {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                  <span>ربط تلقائي متقدم (Cloudflare Sync) ⚡</span>
                </button>

                {(customDomain || settings.customDomain || settings.customAppDomain) && (
                  <button
                    type="button"
                    onClick={handleDisconnect}
                    disabled={isSaving}
                    className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-950/20 dark:hover:bg-red-900/20 dark:text-red-400 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2"
                  >
                    <Trash2 size={14} />
                    <span>حذف / فك ارتباط النطاق</span>
                  </button>
                )}

                {((customDomain || settings.customDomain || settings.customAppDomain)) && (
                  <button
                    type="button"
                    onClick={() => {
                        const targetDomain = customDomain || settings.customDomain || settings.customAppDomain;
                        const isInternal = window.location.hostname.includes('run.app') || window.location.hostname.includes('pages.dev') || window.location.hostname.includes('localhost');
                        const url = isInternal 
                            ? `${window.location.origin}${window.location.pathname}?preview_store=${activeStoreId}`
                            : `https://${targetDomain}`;
                        window.open(url, '_blank');
                    }}
                    className="px-4 py-2 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                  >
                    <span>معاينة النطاق المباشر</span>
                    <ExternalLink size={12} />
                  </button>
                )}
              </div>

              {customDomain && isCustomDomainTaken(customDomain) && (
                <div className="p-3 bg-red-50/50 dark:bg-red-950/20 text-red-650 dark:text-red-400 text-xs font-bold rounded-xl border border-red-200/40 flex items-center gap-1.5 animate-pulse">
                  <AlertTriangle size={14} />
                  <span>تحذير: هذا الدومين المخصص محتجز لمتجر آخر على النظام. إذا كنت أنت المالك، يرجى حذفه من المتجر الآخر أولاً.</span>
                </div>
              )}

              {settings.domainConflict && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 text-xs font-bold rounded-xl border border-amber-200/40 flex items-center gap-1.5 animate-pulse">
                  <AlertTriangle size={14} />
                  <span>تنبيه: هذا النطاق محجوز في حساب Cloudflare آخر. يرجى إضافة سجلات التوثيق أدناه لإثبات ملكيتك ونقله لمتجرك الحالي أوتوماتيكياً.</span>
                </div>
              )}
            </div>
          </div>
          
          {/* DNS Configuration Table and details - Always visible for quick setup */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6"
          >
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-5 mb-6 gap-4 md:gap-0">
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                    <RefreshCw size={18} />
                  </div>
                  <span className="font-bold text-lg md:text-xl text-slate-900 dark:text-white" dir="ltr">{customDomain || settings.customDomain || 'يرجى إدخال نطاق مخصص'}</span>
                  
                  {domainStatus === 'active' || (settings.domainStatus === 'active' && !domainStatus) ? (
                    <span className="px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/50 text-xs font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      متصل ونشط
                    </span>
                  ) : domainStatus === 'pending_validation' || domainStatus === 'pending' ? (
                    <span className="px-3 py-1.5 rounded-full bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-800/50 text-xs font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                      بانتظار التوثيق
                    </span>
                  ) : (
                    <span className="px-3 py-1.5 rounded-full bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-800/50 text-xs font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-red-500"></span>
                      غير متصل
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <button 
                    onClick={handleVerify}
                    disabled={domainStatus === 'verifying'}
                    className={`px-6 py-2.5 rounded-full text-sm font-bold shadow-sm flex items-center gap-2 cursor-pointer transition-all ${
                      domainStatus === 'active' 
                        ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 cursor-default' 
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    {domainStatus === 'verifying' ? (
                      <>
                        <RefreshCw size={16} className="animate-spin" />
                        <span>جاري التحقق...</span>
                      </>
                    ) : domainStatus === 'active' ? (
                      <>
                        <CheckCircle2 size={16} />
                        <span>تحقق ناجح</span>
                      </>
                    ) : (
                      <>
                        <span>تحقق من الاتصال</span>
                        <CheckCircle2 size={16} />
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-4">السجلات والبيانات المطلوب ربطها بالدومين 📋</h3>
                  <ul className="space-y-4 text-xs font-medium text-slate-600 dark:text-slate-400">
                    <li className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full border border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-800 flex items-center justify-center text-[11px] font-bold text-emerald-600 dark:text-emerald-400 shrink-0">1</span>
                      <span className="pt-1">اذهب إلى لوحة التحكم في الموقع الذي اشتريت منه الدومين الخاص بك (مثال: GoDaddy, Namecheap, Hostinger, cPanel ... إلخ).</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full border border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-800 flex items-center justify-center text-[11px] font-bold text-emerald-600 dark:text-emerald-400 shrink-0">2</span>
                      <span className="pt-1">انتقل إلى قسم إدارة سجلات الـ DNS (DNS Management أو Zone Editor).</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full border border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-800 flex items-center justify-center text-[11px] font-bold text-emerald-600 dark:text-emerald-400 shrink-0">3</span>
                      <span className="pt-1">احذف أي سجلات قديمة تشير للروت (@) أو الـ (www)، ثم أضف السجلات التالية بالضبط:</span>
                    </li>
                  </ul>
                </div>

                {/* DNS Records Table */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900 text-xs shadow-sm">
                  <div className="grid grid-cols-4 bg-slate-50/50 dark:bg-slate-800/20 py-4 px-4 font-bold text-slate-500 dark:text-slate-400 text-center border-b border-slate-200 dark:border-slate-800">
                    <div>نوع السجل</div>
                    <div>اسم السجل (Host)</div>
                    <div>القيمة / الهدف (Value)</div>
                    <div>الحالة</div>
                  </div>

                  {/* Record 1: A Record for Root */}
                  <div className="grid grid-cols-4 py-5 px-4 text-center border-b border-slate-200 dark:border-slate-800 items-center bg-indigo-50/10 dark:bg-slate-800/40">
                    <div className="font-mono text-slate-850 dark:text-indigo-400 font-bold text-center">A Record (مستحسن للروت)</div>
                    <div className="font-mono text-slate-600 dark:text-slate-400">@</div>
                    <div className="flex items-center justify-center gap-2">
                      <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400 select-all font-bold" dir="ltr">
                        162.159.224.4
                      </div>
                      <button 
                        onClick={() => handleCopy('162.159.224.4', 'arecord')}
                        className="text-indigo-500 hover:text-indigo-700 dark:hover:text-indigo-300 transition"
                      >
                        {copiedText === 'arecord' ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                      </button>
                    </div>
                    <div className="text-[10px] text-emerald-650 font-bold">جاهز للربط ✅</div>
                  </div>

                  {/* Record 1.5: A Record Backup for Root */}
                  <div className="grid grid-cols-4 py-5 px-4 text-center border-b border-slate-200 dark:border-slate-800 items-center">
                    <div className="font-mono text-slate-800 dark:text-slate-200 font-medium">A Record (احتياطي)</div>
                    <div className="font-mono text-slate-600 dark:text-slate-400">@</div>
                    <div className="flex items-center justify-center gap-2">
                      <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400 select-all font-medium" dir="ltr">
                        162.159.225.4
                      </div>
                      <button 
                        onClick={() => handleCopy('162.159.225.4', 'arecord2')}
                        className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
                      >
                        {copiedText === 'arecord2' ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                      </button>
                    </div>
                    <div className="font-mono text-slate-600 dark:text-slate-400">Auto</div>
                  </div>

                  {/* Record 2: CNAME for www */}
                  <div className="grid grid-cols-4 py-5 px-4 text-center border-b border-slate-200 dark:border-slate-800 items-center">
                    <div className="font-mono text-slate-800 dark:text-slate-200 font-medium">CNAME</div>
                    <div className="font-mono text-slate-600 dark:text-slate-400">www</div>
                    <div className="flex items-center justify-center gap-2">
                      <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400 select-all font-medium" dir="ltr">
                        fallback.abdomedi.com
                      </div>
                      <button 
                        onClick={() => handleCopy('fallback.abdomedi.com', 'cname')}
                        className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
                      >
                        {copiedText === 'cname' ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                      </button>
                    </div>
                    <div className="font-mono text-slate-600 dark:text-slate-400">Auto</div>
                  </div>

                  {/* TXT Records from Cloudflare */}
                  {(cfDetails || settings.domainDNSRecords) && (
                    <>
                      {/* Record 3: Ownership Verification TXT */}
                      {(cfDetails?.ownership_verification || settings.domainDNSRecords?.ownership_verification) && (
                        <div className="grid grid-cols-4 py-5 px-4 text-center items-center border-b border-slate-200 dark:border-slate-800 bg-indigo-50/20 dark:bg-indigo-900/10">
                          <div className="font-mono text-indigo-700 dark:text-indigo-400 font-bold text-[10px]">TXT (الملكية)</div>
                          <div className="font-mono text-slate-600 dark:text-slate-400" dir="ltr">
                            {(cfDetails?.ownership_verification?.name || settings.domainDNSRecords?.ownership_verification?.name || "").replace(`.${customDomain || settings.customDomain}`, '') || '@'}
                          </div>
                          <div className="flex items-center justify-center gap-2">
                            <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400 select-all font-medium truncate max-w-[150px]" dir="ltr">
                              {cfDetails?.ownership_verification?.value || settings.domainDNSRecords?.ownership_verification?.value}
                            </div>
                            <button 
                              onClick={() => handleCopy(cfDetails?.ownership_verification?.value || settings.domainDNSRecords?.ownership_verification?.value, 'txt-own')}
                              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition shrink-0"
                            >
                              {copiedText === 'txt-own' ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                            </button>
                          </div>
                          <div className="font-mono text-slate-600 dark:text-slate-400">Auto</div>
                        </div>
                      )}

                      {/* SSL Verification TXT Records */}
                      {(cfDetails?.ssl?.validation_records || settings.domainDNSRecords?.ssl?.validation_records || []).map((record: any, idx: number) => (
                        <div key={`ssl-rec-${idx}`} className="grid grid-cols-4 py-5 px-4 text-center items-center border-b border-slate-200 dark:border-slate-800 bg-pink-50/20 dark:bg-pink-900/10">
                          <div className="font-mono text-pink-700 dark:text-pink-400 font-bold text-[10px]">TXT (SSL {idx + 1})</div>
                          <div className="font-mono text-slate-600 dark:text-slate-400" dir="ltr">
                            {(record?.txt_name || "").replace(`.${customDomain || settings.customDomain}`, '') || '@'}
                          </div>
                          <div className="flex items-center justify-center gap-2">
                            <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400 select-all font-medium truncate max-w-[150px]" dir="ltr">
                              {record?.txt_value}
                            </div>
                            <button 
                              onClick={() => handleCopy(record?.txt_value, `txt-ssl-${idx}`)}
                              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition shrink-0"
                            >
                              {copiedText === `txt-ssl-${idx}` ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                            </button>
                          </div>
                          <div className="font-mono text-slate-600 dark:text-slate-400">Auto</div>
                        </div>
                      ))}
                    </>
                  )}
                </div>

                <div className="space-y-4 pt-4">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full border border-emerald-200 bg-emerald-50 dark:bg-emerald-900/20 dark:border-emerald-800 flex items-center justify-center text-[11px] font-bold text-emerald-600 dark:text-emerald-400 shrink-0">4</span>
                    <p className="text-sm font-bold text-slate-800 dark:text-slate-200">تأكد من أنك قمت بإعداده بالشكل المطلوب</p>
                  </div>
                  
                  <div className="bg-amber-50/50 dark:bg-amber-950/20 p-5 rounded-2xl border border-amber-100 dark:border-amber-900/30">
                    <div className="flex items-center justify-center gap-2 mb-2 text-amber-700 dark:text-amber-400">
                      <AlertTriangle size={18} className="shrink-0" />
                      <p className="text-sm font-bold">يحتاج الدومين 24-48 ساعة لربطه ويظهر موقعك أونلاين على مستوى العالم</p>
                    </div>
                    <p className="text-xs text-center text-amber-600/80 dark:text-amber-500/80 font-medium font-arabic leading-relaxed">
                      يحتاج ربط الدومين الجديد وقتاً، لأن خوادم الـ DNS العالمية تبدأ في تبادل السجلات وتحديث جهة توجيه الزوار تدريجياً.
                    </p>
                  </div>
                </div>

              </div>
            </motion.div>
        </div>

        {/* Informational Right Sidebar */}
        <div className="space-y-6">
          
          {/* Active store address summary block */}
          {(settings.subdomain || customDomain) ? (
            <div className="bg-slate-900 text-white p-6 rounded-3xl border border-indigo-950 shadow-md space-y-4">
              <h4 className="font-black text-xs text-indigo-400 tracking-wider">الروابط النشطة لمتجرك المباشر 🔗</h4>
              
              <div className="space-y-3 pt-1">
                {settings.subdomain && (
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-400 block font-bold">الرابط الفرعي المجاني:</span>
                    <a 
                      href={`http://${settings.subdomain}.abdomedi.com`} 
                      target="_blank" 
                      className="text-xs font-mono text-indigo-300 hover:underline flex items-center gap-1 shrink-0 break-all"
                      dir="ltr"
                    >
                      <span>{settings.subdomain}.abdomedi.com</span>
                      <ExternalLink size={10} />
                    </a>
                  </div>
                )}

                {customDomain && (
                  <div className="space-y-1 pt-1 border-t border-slate-800">
                    <span className="text-[10px] text-slate-400 block font-bold">النطاق الخاص المخصص:</span>
                    <a 
                      href={`http://${customDomain}`} 
                      target="_blank" 
                      className="text-xs font-mono text-emerald-400 hover:underline flex items-center gap-1 shrink-0 break-all"
                      dir="ltr"
                    >
                      <span>{customDomain}</span>
                      <ExternalLink size={10} />
                    </a>
                  </div>
                )}
              </div>
            </div>
          ) : null}

          {/* Why bind domain cards */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Link2 size={16} className="text-indigo-500" />
              <span>لماذا نطاق مخصص لمشروعك؟</span>
            </h3>
            
            <ul className="space-y-3.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <span><strong className="text-slate-800 dark:text-slate-200">هوية مستقلة:</strong> يظهر اسم متجرك بشكل مميز لدى العملاء وتتخلص من روابط الأنظمة الفرعية الطويلة.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <span><strong className="text-slate-800 dark:text-slate-200">محركات البحث SEO:</strong> الدومينات المخصصة المستقلة تحظى بـ 10 أضعاف الثقة في أرشفة Google وتصنيفات البحث.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <span><strong className="text-slate-800 dark:text-slate-200">أمان كامل SSL:</strong> يوفر نظامنا شهادة تصفح آمنة وتشفير مجاني مدي الحياة (https) عند تفعيل الدومين.</span>
              </li>
            </ul>
          </div>

          {/* DNS Instructions FAQ */}
          <div className="bg-gradient-to-br from-indigo-50/40 via-white to-white dark:from-indigo-950/20 dark:via-slate-900 dark:to-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <HelpCircle size={16} className="text-indigo-500" />
              <span>دليل سريع للربط</span>
            </h3>

            <div className="space-y-3.5 text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
              <div className="border-b border-slate-200 dark:border-slate-800/80 pb-2">
                <p className="font-bold text-slate-705 dark:text-slate-350">أين أجد سجلات DNS؟</p>
                <p>ابحث عن خيار باسم DNS Management أو Name Servers أو Manage DNS في حساب الشركة التي اشتريت منها الدومين.</p>
              </div>

              <div className="border-b border-slate-200 dark:border-slate-800/80 pb-2">
                <p className="font-bold text-slate-705 dark:text-slate-350">هل يمكنني ربط دومين فرعي؟</p>
                <p>نعم، بكل تأكيد! يمكنك إدخال دومين مثل <span className="font-bold" dir="ltr">shop.example.com</span> وإكمال الخطوات بنجاح.</p>
              </div>

              <div>
                <p className="font-bold text-slate-705 dark:text-slate-350 font-arabic">هل شهادة الـ SSL آمنة؟</p>
                <p>نعم، يتم إصدارها وتشفيرها تلقائياً بالكامل دون أي رسوم إضافية لضمان حماية بيانات عملائك وسلات التسوق.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Modal Prompt */}
      <AnimatePresence>
        {modal.show && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                if (!modal.isConfirm) setModal(prev => ({ ...prev, show: false }));
              }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            
            {/* Alarm Dialog Card */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
              className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[32px] p-6 shadow-2xl border border-slate-200/80 dark:border-slate-800/80 overflow-hidden text-right font-sans"
            >
              {/* Sound Ring Pulse Decorator with Premium Adaptive Gradient */}
              <div className={`absolute top-0 right-0 left-0 h-2 bg-gradient-to-r ${
                modal.type === 'success' ? 'from-emerald-400 via-teal-500 to-indigo-500' :
                modal.type === 'error' ? 'from-rose-400 via-red-500 to-amber-500' :
                modal.type === 'warning' ? 'from-amber-400 via-orange-500 to-red-500' :
                'from-sky-400 via-blue-500 to-indigo-500'
              }`} />
              
              <div className="flex flex-col items-center text-center mt-3">
                {/* Visual Icon based on Alarm TYPE */}
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-lg ${
                  modal.type === 'success' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400' :
                  modal.type === 'error' ? 'bg-red-100 text-red-600 dark:bg-red-950/40 dark:text-red-400' :
                  modal.type === 'warning' ? 'bg-amber-100 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400 font-bold' :
                  'bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400'
                }`}>
                  {modal.type === 'success' && <CheckCircle2 size={32} />}
                  {modal.type === 'error' && <AlertTriangle size={32} />}
                  {modal.type === 'warning' && <AlertTriangle size={32} />}
                  {modal.type === 'info' && <Info size={32} />}
                </div>

                {/* Alarm Ringing Animation Indicator with Custom Sprung Bell */}
                <div className="flex items-center gap-1.5 mb-2 px-3.5 py-1.5 rounded-full bg-slate-50 dark:bg-slate-800/60 text-[10.5px] text-slate-500 dark:text-slate-400 font-black tracking-wider border border-slate-200 dark:border-slate-800 shadow-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
                  <span>تنبيه داخلي نشط</span>
                  <motion.span
                    animate={{ rotate: [0, -18, 15, -12, 10, -5, 0] }}
                    transition={{
                      repeat: Infinity,
                      repeatDelay: 1.2,
                      duration: 0.85,
                      type: "tween",
                      ease: "easeInOut"
                    }}
                    className="inline-block origin-top"
                  >
                    🔔
                  </motion.span>
                </div>

                <h3 className="text-lg font-black text-slate-900 dark:text-white mt-1 leading-tight">
                  {modal.title}
                </h3>
                
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-3 leading-relaxed whitespace-pre-line text-center px-2">
                  {modal.message}
                </p>
              </div>

              {/* Confirm / Cancel Actions */}
              <div className="flex gap-3 mt-6">
                {modal.isConfirm && (
                  <button
                    onClick={() => setModal(prev => ({ ...prev, show: false }))}
                    className="flex-1 px-5 py-3 rounded-2xl text-xs font-black bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 cursor-pointer"
                  >
                    إلغاء
                  </button>
                )}
                
                <button
                  onClick={() => {
                    const onConf = modal.onConfirm;
                    setModal(prev => ({ ...prev, show: false }));
                    if (onConf) onConf();
                  }}
                  className={`flex-1 px-5 py-3 rounded-2xl text-xs font-black text-white hover:scale-[1.02] active:scale-[0.98] transition-all shadow-md cursor-pointer ${
                    modal.type === 'success' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/10' :
                    modal.type === 'error' ? 'bg-red-600 hover:bg-red-700 shadow-red-500/10' :
                    modal.type === 'warning' ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/10' :
                    'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/10'
                  }`}
                >
                  {modal.buttonText}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
