import React from 'react';
import { Order, Settings } from '../types';
import { calculateInsuranceFee, getStandardShippingFee, getAdvancePaymentCustodyName, calculateCodFee } from '../utils/financials';
import { generateInvoiceHTML } from '../utils/invoiceGenerator';
import { printHTMLDirectly } from '../utils/printHelper';
import { generateShippingLabelHTML } from '../utils/shippingLabelGenerator';
import { whatsappService, normalizeWhatsAppPhone } from '../utils/whatsappService';
import { CheckCircle, Printer, FileDown, MessageCircle, AlertCircle } from 'lucide-react';

interface OrderConfirmationSummaryProps {
    order: Order;
    settings: Settings;
    onClose: () => void;
    storeName: string;
}

export const OrderConfirmationSummary: React.FC<OrderConfirmationSummaryProps> = ({ order, settings, onClose, storeName }) => {
    const compFees = settings?.companySpecificFees?.[order.shippingCompany];
    const inspectionFee = (order.includeInspectionFee !== false && order.allowOpenShipment !== false) ? (compFees?.useCustomFees ? compFees.inspectionFee : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
    
    // Insurance
    const insuranceRate = order.isInsured ? (compFees?.useCustomFees ? compFees.insuranceFeePercent : (settings?.enableInsurance ? settings.insuranceFeePercent : 0)) : 0;
    const insuranceFee = calculateInsuranceFee(order, insuranceRate, settings);
    
    // VAT (Logistics)
    const useCustomFees = compFees?.useCustomFees ?? false;
    const vatRate = useCustomFees ? (compFees?.shippingVatRate ?? 0.14) : (settings.shippingVatRate ?? 0.14);
    const isVatEnabled = compFees?.enableVat !== false;
    const vatBasis = useCustomFees ? (compFees?.vatBasis || 'shipping_only') : 'shipping_only';
    const useStandard = order.vatOnStandardShipping === true;
    const standardShippingFee = useStandard ? getStandardShippingFee(order, settings) : (order.shippingFee || 0);
    const insuranceValueForVat = (vatBasis === 'shipping_and_insurance' || vatBasis === 'shipping_insurance_and_cod') ? insuranceFee : 0;
    const codValueForVat = vatBasis === 'shipping_insurance_and_cod' ? calculateCodFee(order, settings) : 0;
    const taxableBase = standardShippingFee + inspectionFee + insuranceValueForVat + codValueForVat;
    const vatAmount = (isVatEnabled && vatRate > 0) ? Math.round(taxableBase * vatRate * 100) / 100 : 0;
    
    const safeAdvance = Number(order.advancePayment) || 0;
    const credit = (order as any).creditAmount || 0;
    
    // Total calculation
    let total = order.productPrice + order.shippingFee + inspectionFee + insuranceFee + vatAmount - (order.discount || 0) - safeAdvance - credit;
    
    if (order.returnCashToCustomer && (order as any).cashToReturnAmount) {
        total -= Number((order as any).cashToReturnAmount);
    }
    
    const finalTotal = order.totalAmountOverride !== undefined && order.totalAmountOverride !== null
        ? Math.max(0, Math.round(Number(order.totalAmountOverride) - safeAdvance - credit))
        : Math.max(0, Math.round(total));

    // Prepare Direct WhatsApp Link
    const template = (settings.whatsappTemplates || []).find(t => t.id === 'new_order_interactive' || t.id === 'confirm' || t.label?.includes('تأكيد') || t.label?.includes('جديد'));
    const textToUse = template?.text || "مرحباً بك {customerName} 🌸\nنشكرك على طلبك من متجر {storeName}! 🎉\n\n📦 تفاصيل الطلب: رقم #{orderNumber}\n🛍️ المنتجات المطلوبة:\n{products}\n\n💰 إجمالي المبلغ: {totalPrice} {currency}\n📍 عنوان التوصيل: {address} - {city}\n\nنرجو تأكيد الطلب لمباشرة التجهيز والشحن فوراً 🚚";
    const formattedWaMsg = whatsappService.formatMessage(textToUse, order, settings, undefined, template?.footer || `خدمة عملاء ${storeName}`, storeName);
    const cleanPhone = normalizeWhatsAppPhone(order.customerPhone || '');
    const directWaUrl = cleanPhone ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(formattedWaMsg)}` : '';

    const lastWaLog = Array.isArray((order as any).whatsappLogs) && (order as any).whatsappLogs.length > 0
        ? (order as any).whatsappLogs[(order as any).whatsappLogs.length - 1]
        : null;
    const autoSendFailed = lastWaLog?.status === 'failed';
    
    return (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200">
            <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-[32px] shadow-2xl p-7 text-center animate-in zoom-in-95 duration-300 border border-slate-200/80 dark:border-slate-800 relative overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600" />
                
                <div className="w-20 h-20 bg-gradient-to-tr from-emerald-100 to-teal-100 dark:from-emerald-950/60 dark:to-teal-950/40 text-emerald-600 dark:text-emerald-400 rounded-3xl flex items-center justify-center mx-auto mb-4 border border-emerald-200/60 dark:border-emerald-800/60 shadow-lg shadow-emerald-500/10">
                    <CheckCircle size={42} className="animate-bounce" />
                </div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">تم إنشاء الطلب بنجاح!</h2>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mb-5">
                    ملخص الطلب المالي للعميل <span className="font-black text-slate-800 dark:text-slate-100">{order.customerName}</span>
                </p>

                {autoSendFailed && (
                    <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-2xl text-right flex items-start gap-2.5">
                        <AlertCircle size={18} className="text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                        <div className="text-[11px] font-bold text-amber-800 dark:text-amber-300 leading-relaxed">
                            لم يتم الإرسال التلقائي عبر مزود UltraMsg بسبب توقف الاشتراك الخارجي. يمكنك إرسال رسالة التأكيد للعميل فوراً عبر الزر المباشر المجاني بالأسفل، أو تحويل المزود إلى <strong>«الربط المباشر المجاني»</strong> من إعدادات الواتساب.
                        </div>
                    </div>
                )}

                {order.merchantBrandName?.trim() && (
                    <div className="mb-4 p-3.5 bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/60 rounded-2xl text-right flex items-center justify-between">
                        <div>
                            <span className="text-[10px] font-extrabold text-amber-800 dark:text-amber-400 block">شحن لحساب براند خارجي (White Label):</span>
                            <span className="text-xs font-black text-amber-950 dark:text-amber-200">{order.merchantBrandName} {order.merchantBrandPhone ? `(${order.merchantBrandPhone})` : ''}</span>
                        </div>
                        <span className="px-2.5 py-1 bg-amber-200/80 dark:bg-amber-800 text-amber-900 dark:text-amber-100 rounded-xl text-[10px] font-black">
                            الراسل المطبوع
                        </span>
                    </div>
                )}
                
                <div className="space-y-3 text-right bg-slate-50/80 dark:bg-slate-800/40 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 divide-y divide-slate-200/60 dark:divide-slate-700/60 text-xs sm:text-sm">
                    <div className="flex justify-between items-center pb-2">
                        <span className="font-bold text-slate-500 dark:text-slate-400">إجمالي المنتجات:</span>
                        <span className="font-black text-slate-800 dark:text-slate-100 font-mono">{(order.productPrice ?? 0).toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between items-center pt-2.5">
                        <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-500 dark:text-slate-400">مصاريف الشحن والتوصيل:</span>
                            {(order.weight || 0) > 0 && (
                                <span className="text-[10px] text-slate-400 font-mono">(الوزن: {order.weight.toFixed(2)} كجم)</span>
                            )}
                        </div>
                        <span className="font-black text-slate-800 dark:text-slate-100 font-mono">{(order.shippingFee ?? 0).toLocaleString()} ج.م</span>
                    </div>
                    {inspectionFee > 0 && (
                        <div className="flex justify-between items-center pt-2.5">
                            <span className="font-bold text-slate-500 dark:text-slate-400">رسوم المعاينة:</span>
                            <span className="font-black text-slate-800 dark:text-slate-100 font-mono">{(inspectionFee ?? 0).toLocaleString()} ج.م</span>
                        </div>
                    )}
                    {insuranceFee > 0 && (
                        <div className="flex justify-between items-center pt-2.5">
                            <span className="font-bold text-slate-500 dark:text-slate-400">رسوم التأمين ({insuranceRate}%):</span>
                            <span className="font-black text-slate-800 dark:text-slate-100 font-mono">{(insuranceFee ?? 0).toLocaleString()} ج.م</span>
                        </div>
                    )}
                    {vatAmount > 0 && (
                        <div className="flex justify-between items-center pt-2.5 text-blue-600 dark:text-blue-400">
                            <span className="font-bold">ضريبة القيمة المضافة ({Math.round(vatRate * 100)}%):</span>
                            <span className="font-black font-mono">{(vatAmount ?? 0).toLocaleString()} ج.م</span>
                        </div>
                    )}
                    {(order as any).creditAmount > 0 && (
                        <div className="flex justify-between items-center pt-2.5 text-amber-600 dark:text-amber-400">
                             <span className="font-bold">رصيد مستخدم مخصوم:</span>
                             <span className="font-black font-mono">-{Number((order as any).creditAmount).toLocaleString()} ج.م</span>
                        </div>
                    )}
                    {safeAdvance > 0 && (
                        <div className="flex flex-col gap-1 py-2 px-3 bg-teal-50 dark:bg-teal-950/30 rounded-xl my-1 border border-teal-200/60 dark:border-teal-800/40">
                            <div className="flex justify-between items-center text-teal-800 dark:text-teal-300">
                                <span className="font-bold">العربون المقدم المدفوع:</span>
                                <span className="font-black font-mono">-{(safeAdvance ?? 0).toLocaleString()} ج.م</span>
                            </div>
                            <div className="flex justify-between items-center text-xs text-teal-600 dark:text-teal-400 border-t border-teal-200/50 dark:border-teal-800/40 pt-1">
                                <span>العهدة / جهة الاستلام:</span>
                                <span className="font-black">{getAdvancePaymentCustodyName(order, settings)}</span>
                            </div>
                        </div>
                    )}
                    {order.discount > 0 && (
                        <div className="flex justify-between items-center pt-2.5 text-emerald-600 dark:text-emerald-400">
                            <span className="font-bold">الخصم الممنوح:</span>
                            <span className="font-black font-mono">-{(order.discount ?? 0).toLocaleString()} ج.م</span>
                        </div>
                    )}
                    <div className="flex justify-between items-center pt-3 text-base sm:text-lg">
                        <span className="font-black text-indigo-600 dark:text-indigo-400">المطلوب تحصيله (COD):</span>
                        <span className="font-black text-indigo-600 dark:text-indigo-400 font-mono text-xl sm:text-2xl">{(finalTotal ?? 0).toLocaleString()} ج.م</span>
                    </div>
                    {order.totalAmountOverride !== undefined && order.totalAmountOverrideReason && (
                        <div className="mt-3 text-right pt-2">
                            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block uppercase tracking-wider mb-1">سبب تعديل الإجمالي</span>
                            <p className="text-xs text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 italic">
                                "{order.totalAmountOverrideReason}"
                            </p>
                        </div>
                    )}
                </div>

                <div className="flex flex-col gap-2.5 mt-6">
                    {directWaUrl && (
                        <a
                            href={directWaUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-full py-3.5 bg-[#008060] hover:bg-[#006e52] text-white rounded-2xl font-black transition-all shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2.5 cursor-pointer text-sm active:scale-95"
                        >
                            <MessageCircle size={18} />
                            <span>إرسال تأكيد الطلب عبر واتساب مباشر (مجاني)</span>
                        </a>
                    )}
                    <button 
                        onClick={() => {
                            const html = generateInvoiceHTML(order, settings, storeName);
                            printHTMLDirectly(html);
                        }}
                        className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white rounded-2xl font-black transition-all shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2.5 cursor-pointer text-sm active:scale-95"
                    >
                        <Printer size={18} />
                        <span>طباعة الفاتورة</span>
                    </button>
                    <button 
                        onClick={() => {
                            const html = generateShippingLabelHTML(order, storeName, settings);
                            printHTMLDirectly(html);
                        }}
                        className="w-full py-3.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-2xl font-black hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center justify-center gap-2.5 cursor-pointer text-sm"
                    >
                        <FileDown size={18} />
                        <span>طباعة بوليصة الشحن</span>
                    </button>
                    <button 
                        onClick={onClose} 
                        className="w-full py-2.5 text-slate-500 dark:text-slate-400 font-extrabold hover:text-slate-800 dark:hover:text-white transition-all text-xs cursor-pointer"
                    >
                        إغلاق ومتابعة الطلبات
                    </button>
                </div>
            </div>
        </div>
    );
};
