import React, { useState, useMemo, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import * as db from '../services/databaseService';
import { Settings, Partner, PartnerTransaction, Wallet, Transaction, Order } from '../types';
import { User, ArrowLeft, TrendingUp, DollarSign, ArrowDownRight, ArrowUpLeft, History, PieChart, Activity, Calendar, Download, Check, Package as PackageIcon, Truck, Coins, Trash2, Printer, Wallet as WalletIcon, PlusCircle, RefreshCw, CheckCircle2, Clock, Eye, Search, Lock, Share2, Copy, Sparkles, X } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { printHTMLDirectly } from '../utils/printHelper';
import { calculateOrderProfitLoss, calculateWalletLiveBalance, getVirtualOrderHandovers } from '../utils/financials';
import { PartnerStatementModal } from './PartnerStatementModal';
import { generateSafeId } from '../utils/idUtils';

import { Treasury } from '../types';

interface PartnerProfilePageProps {
  settings: Settings;
  updateSettings: (newSettings: Settings) => void;
  wallet: Wallet;
  setWallet: React.Dispatch<React.SetStateAction<Wallet>>;
  orders: Order[];
  treasury?: Treasury;
  setTreasury?: (updater: any) => void;
}

const normalizeName = (name: string): string => {
  if (!name) return '';
  let normalized = name.trim().replace(/\s+/g, ' ');
  normalized = normalized.replace(/\s*\((شريك|موظف|المدير|شريكه|partner|employee|admin|أنت|انت)\)/gi, '');
  normalized = normalized.replace(/\s+(شريك|موظف|المدير|شريكه|partner|employee|admin)$/gi, '');
  normalized = normalized
    .replace(/أ/g, 'ا')
    .replace(/إ/g, 'ا')
    .replace(/آ/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .toLowerCase()
    .trim();
  if (/^(زهره)/.test(normalized)) {
      return 'زهره';
  }
  return normalized;
};

const PartnerProfilePage: React.FC<PartnerProfilePageProps> = ({ settings, updateSettings, wallet, setWallet, orders, treasury, setTreasury }) => {
  const { storeId, partnerId } = useParams<{ storeId: string; partnerId: string }>();
  const walletBalance = useMemo(() => calculateWalletLiveBalance(wallet), [wallet]);
  const navigate = useNavigate();
  const [selectedTreasuryId, setSelectedTreasuryId] = useState('');
  
  const [custodyAmount, setCustodyAmount] = useState('');
  const [custodyType, setCustodyType] = useState<'give' | 'receive'>('give');
  const [custodyTreasuryId, setCustodyTreasuryId] = useState('');
  const [custodyNotes, setCustodyNotes] = useState('');
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [profileTxSearch, setProfileTxSearch] = useState('');
  const [profileTxFilter, setProfileTxFilter] = useState<'all' | 'positive' | 'negative' | 'custody'>('all');

  // PIN Management & Portal Sharing State
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [partnerPinInput, setPartnerPinInput] = useState('');

  const partner = useMemo(() => settings.partners?.find(p => p.id === partnerId), [settings.partners, partnerId]);

  const [cloudRequests, setCloudRequests] = useState<db.PartnerPortalRequest[]>([]);

  useEffect(() => {
    if (!storeId) return;
    db.getPartnerRequests(storeId).then(reqs => setCloudRequests(reqs));
  }, [storeId]);

  const allPartnerRequests = useMemo(() => {
    const fromSettings = (settings as any).partnerRequests || [];
    const map = new Map<string, any>();
    cloudRequests.forEach(r => map.set(r.id, r));
    fromSettings.forEach((r: any) => {
      if (!map.has(r.id)) map.set(r.id, r);
    });
    return Array.from(map.values());
  }, [cloudRequests, settings]);

  const openPinModal = () => {
    setPartnerPinInput(partner?.passcode || '0000');
    setIsPinModalOpen(true);
  };

  const handleSavePartnerPin = () => {
    if (!partner) return;
    const cleanCode = partnerPinInput.trim().replace(/\D/g, '') || '0000';
    updateSettings({
      ...settings,
      partners: (settings.partners || []).map(p => p.id === partner.id ? { ...p, passcode: cleanCode } : p)
    });
    alert(`تم تعيين وتحديث رمز PIN للشريك (${partner.name}) بنجاح: ${cleanCode}`);
    setIsPinModalOpen(false);
  };

  const copyPortalLink = () => {
    if (!partner) return;
    const link = `${window.location.origin}/store/${storeId}/partner-portal?p=${partner.id}`;
    navigator.clipboard.writeText(link);
    alert(`تم نسخ رابط الدخول المباشر لبوابة الشريك (${partner.name}) بنجاح!`);
  };

  const shareWhatsApp = () => {
    if (!partner) return;
    const link = `${window.location.origin}/store/${storeId}/partner-portal?p=${partner.id}`;
    const code = partner.passcode || '0000';
    const storeTitle = settings.storeName || 'عبده ميديا';
    const text = `مرحباً بك يا ${partner.name} 🌟\nإليك رابط بوابتك المالية المباشرة لمتابعة حساباتك وتفاصيل أرباحك في متجر ${storeTitle}:\n🔗 ${link}\n🔑 رمز المرور السري (PIN): ${code}\n\nتحياتنا، إدارة المتجر.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };
  const transactions = useMemo(() => (settings.partnerTransactions || []).filter(t => t.partnerId === partnerId && t.type !== 'pos_collection'), [settings.partnerTransactions, partnerId]);

  const handoversForPartner = useMemo(() => {
    if (!partner) return [];
    const holderId = `part_${partner.id}`;
    const partnerHolders = (settings.cashHolders || []).filter((h: any) => 
        h.userId === holderId || 
        h.userId === partner.id || 
        normalizeName(h.userName) === normalizeName(partner.name)
    );
    const partnerUserIds = [holderId, partner.id, ...partnerHolders.map(h => h.userId)];

    const allHandovers = [
      ...(settings.cashHandovers || []),
      ...getVirtualOrderHandovers(orders, settings, treasury)
    ];

    return allHandovers
      .filter(h => 
        partnerUserIds.includes(h.fromUserId) || 
        partnerUserIds.includes(h.toUserId) || 
        h.toUserId === partner.id || 
        h.toUserId === holderId || 
        h.fromUserId === partner.id || 
        h.fromUserId === holderId || 
        normalizeName(h.toUserName || '').includes(normalizeName(partner.name)) || 
        normalizeName(h.fromUserName || '').includes(normalizeName(partner.name))
      )
      .map(h => {
        const isGive = partnerUserIds.includes(h.toUserId) || h.toUserId === partner.id || h.toUserId === holderId || normalizeName(h.toUserName || '').includes(normalizeName(partner.name));
        return {
          id: h.id,
          partnerId: partner.id,
          type: isGive ? 'custody_give' : 'custody_receive',
          amount: Number(h.amount) || 0,
          date: h.date,
          note: h.notes || (isGive ? 'تسليم عهدة تشغيلية للشريك' : 'تسوية واسترداد عهدة من الشريك'),
        } as any;
      });
  }, [settings.cashHandovers, settings.cashHolders, partner, orders, treasury, settings]);

  const mergedTransactions = useMemo(() => {
    const list = [...transactions, ...handoversForPartner];
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, handoversForPartner]);

  const partnerCustody = useMemo(() => {
    if (!partner) return 0;
    const holderId = `part_${partner.id}`;
    const partnerHolders = (settings.cashHolders || []).filter((h: any) => 
        h.userId === holderId || 
        h.userId === partner.id || 
        normalizeName(h.userName) === normalizeName(partner.name)
    );
    const settlements = handoversForPartner.filter((h: any) => 
        (h.toUserId && (h.toUserId === 'admin_deduction' || h.toUserId === 'admin_manual')) ||
        (h.toUserName && (h.toUserName.includes('خصم') || h.toUserName.includes('تصفية') || h.toUserName.includes('تسوية'))) ||
        (h.notes && (h.notes.includes('خصم') || h.notes.includes('تصفية') || h.notes.includes('تسوية') || h.notes.includes('تبين عدم رد'))) ||
        (h.note && (h.note.includes('خصم') || h.note.includes('تصفية') || h.note.includes('تسوية') || h.note.includes('تبين عدم رد')))
    );
    const hasSettlement = settlements.length > 0;
    let holderSum = partnerHolders.reduce((sum: number, h: any) => sum + (h.currentBalance || 0), 0);

    if (hasSettlement) {
        const lastSettlement = settlements.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
        const activeHandovers = handoversForPartner.filter((h: any) => new Date(h.date).getTime() > new Date(lastSettlement.date).getTime());
        const activeHandoverSum = activeHandovers.reduce((sum: number, h: any) => {
            if (h.type === 'custody_give') return sum + (Number(h.amount) || 0);
            if (h.type === 'custody_receive') return sum - (Number(h.amount) || 0);
            return sum;
        }, 0);
        return Math.max(0, holderSum) + Math.max(0, activeHandoverSum);
    }

    let handoverSum = handoversForPartner.reduce((sum: number, h: any) => {
      if (h.type === 'custody_give') return sum + (Number(h.amount) || 0);
      if (h.type === 'custody_receive') return sum - (Number(h.amount) || 0);
      return sum;
    }, 0);
    
    let sum = Math.max(holderSum, Math.max(0, handoverSum));
    if (sum <= 0 && holderSum > 0) sum = holderSum;
    return Math.max(0, sum);
  }, [settings.cashHolders, partner, handoversForPartner]);

  const effectiveHiddenAmount = useMemo(() => {
    if (!settings.enableHiddenWalletAmount) return 0;
    const autoClosingDiff = settings.enableAutoClosingDifference 
        ? Math.abs(orders
            .filter(o => ['تم_توصيلها', 'تم_التوصيل', 'تم_التحصيل', 'مدفوعة', 'مرتجع_جزئي'].includes(o.status))
            .reduce((sum, o) => sum + (calculateOrderProfitLoss(o, settings).closingDifference || 0), 0))
        : (settings.hiddenWalletAmount || 0);
    return autoClosingDiff;
  }, [settings.enableHiddenWalletAmount, settings.enableAutoClosingDifference, settings.hiddenWalletAmount, orders, settings]);

  const executeCustodyTx = () => {
     const amount = parseFloat(custodyAmount);
     if (!amount || isNaN(amount) || amount <= 0) {
        alert('برجاء إدخال مبلغ صحيح');
        return;
     }
     if (!custodyTreasuryId) {
        alert('برجاء تحديد الخزينة/الحساب المالي المستخدم');
        return;
     }

     const isCentralWallet = custodyTreasuryId === 'central_wallet';
     const walletBalance = Math.round(calculateWalletLiveBalance(wallet, treasury) * 100) / 100;
     const isCentralWalletBalance = Math.max(0, walletBalance - effectiveHiddenAmount);
     
     const selectedAccount = isCentralWallet 
        ? { id: 'central_wallet', name: 'المحفظة الماليّة المركزيّة (الرصيد الأساسي)', balance: isCentralWalletBalance }
        : treasury?.accounts?.find((a: any) => a.id === custodyTreasuryId);

     if (!selectedAccount) return;

     let warningMsg = '';
     if (custodyType === 'give' && selectedAccount.balance < amount) {
        warningMsg = ' (تنبيه: رصيد الخزينة المختار أصبح بالسالب مؤقتاً)';
     }

     const partnerHolderId = `part_${partner?.id}`;
     const partnerHolderName = partner?.name || 'الشريك';
     const dateStr = new Date().toISOString();
     const handoverId = `HND-${Date.now()}`;

     let currentHolders = [...(settings.cashHolders || [])];
     const partnerIdx = currentHolders.findIndex(h => h.userId === partnerHolderId || h.userId === partner?.id);
     
     const fromUserId = custodyType === 'give' ? 'admin' : partnerHolderId;
     const fromUserName = custodyType === 'give' ? 'الادارة' : partnerHolderName;
     const toUserId = custodyType === 'give' ? partnerHolderId : `treasury_${custodyTreasuryId}`;
     const toUserName = custodyType === 'give' ? partnerHolderName : `الخزينة: ${selectedAccount.name}`;

     const handoverData: any = {
        id: handoverId,
        fromUserId,
        fromUserName,
        toUserId,
        toUserName,
        amount,
        date: dateStr,
        notes: custodyNotes || (custodyType === 'give' ? 'تسليم عهدة نقدية للشريك لشراء مخزون أو سداد مصروفات' : 'استلام واسترداد عهدة الشريك للخزينة ومطابقتها'),
        status: 'completed'
     };

     if (partnerIdx > -1) {
        const currentBal = Number(currentHolders[partnerIdx].currentBalance ?? 0);
        const nextBal = custodyType === 'give' ? currentBal + amount : currentBal - amount;
        currentHolders[partnerIdx] = {
           ...currentHolders[partnerIdx],
           currentBalance: nextBal,
           lastUpdated: dateStr
        };
     } else {
        const initialBal = custodyType === 'give' ? amount : -amount;
        currentHolders.push({
           userId: partnerHolderId,
           userName: partnerHolderName,
           currentBalance: initialBal,
           lastUpdated: dateStr
        });
     }

     if (isCentralWallet) {
        setWallet(prev => {
           const isGive = custodyType === 'give';
           const amountNum = amount;
           
           const walletTx: Transaction = {
              id: `W-CUST-${Date.now()}`,
              type: isGive ? 'سحب' : 'إيداع',
              amount: amountNum,
              date: dateStr,
              note: isGive 
                 ? `صرف عهدة نقدية للشريك ${partnerHolderName} من المحفظة المركزية: ${custodyNotes || 'عهدة جديدة'}`
                 : `تسوية واسترداد عهدة من الشريك ${partnerHolderName} للمحفظة المركزية: ${custodyNotes || 'توريد للمحفظة'}`,
              category: isGive ? 'manual_withdrawal' : 'manual_deposit',
              status: 'completed'
           } as Transaction;

           return {
              ...prev,
              balance: isGive ? prev.balance - amountNum : prev.balance + amountNum,
              transactions: [walletTx, ...(prev.transactions || [])]
           };
        });
     } else if (setTreasury && treasury) {
        setTreasury((prev: any) => {
           if (!prev) return prev;
           const updatedAccs = prev.accounts.map((acc: any) => {
              if (acc.id === custodyTreasuryId) {
                 return {
                    ...acc,
                    balance: custodyType === 'give' ? acc.balance - amount : acc.balance + amount
                 };
              }
              return acc;
           });

           const treasuryTx = {
              id: `T-CUST-PART-${Date.now()}`,
              date: dateStr,
              type: custodyType === 'give' ? 'withdrawal' : 'deposit',
              amount,
              description: custodyType === 'give' 
                 ? `صرف عهدة نقدية للشريك ${partnerHolderName}: ${custodyNotes || 'عهدة جديدة لدعم العمليات'}`
                 : `تسوية كاش واسترداد عهدة من الشريك ${partnerHolderName}: ${custodyNotes || 'توريد للخزينة'}`,
              toAccountId: custodyType === 'give' ? undefined : custodyTreasuryId,
              fromAccountId: custodyType === 'give' ? custodyTreasuryId : undefined,
              reference: handoverId
           };

           return {
              ...prev,
              accounts: updatedAccs,
              transactions: [treasuryTx, ...(prev.transactions || [])]
           };
        });
     }

     updateSettings({
        ...settings,
        cashHolders: currentHolders,
        cashHandovers: [handoverData, ...(settings.cashHandovers || [])],
        activityLogs: [
           {
              id: `log-${Date.now()}`,
              user: 'الادارة',
              action: custodyType === 'give' ? 'صرف عهدة للشريك' : 'تسوية عهدة الشريك',
              details: custodyType === 'give'
                 ? `تم صرف عهدة نقدية للشريك ${partnerHolderName} بقيمة ${amount.toLocaleString()} ج.م من حساب ${selectedAccount.name}`
                 : `تم استرداد عهدة نقدية من الشريك ${partnerHolderName} بقيمة ${amount.toLocaleString()} ج.م وتوريدها لحساب ${selectedAccount.name}`,
              date: new Date().toLocaleString('ar-EG'),
              timestamp: Date.now()
           },
           ...(settings.activityLogs || [])
        ]
     });

     setCustodyAmount('');
     setCustodyNotes('');
     alert('تم تسجيل عملية العهدة بنجاح وتحديث كشفي الحساب والخزائن.' + warningMsg);
  };

  const deleteCustodyTx = (h: any) => {
      setDialog({
          isOpen: true,
          title: 'تأكيد الحذف',
          message: 'هل أنت متأكد من مسح حركة العهدة؟ سيتم التراجع عن كل التغييرات المالية المتعلقة بها على الخزينة وحساب الشريك.',
          onConfirm: () => {
              const amount = h.amount;
              const holderId = `part_${partner?.id}`;
              const partnerHolders = (settings.cashHolders || []).filter((holder: any) => 
                  holder.userId === holderId || 
                  holder.userId === partner?.id || 
                  normalizeName(holder.userName) === normalizeName(partner?.name || '')
              );
              const partnerUserIds = partnerHolders.map(holder => holder.userId);
              if (partner && !partnerUserIds.includes(partner.id)) partnerUserIds.push(partner.id);
              if (!partnerUserIds.includes(holderId)) partnerUserIds.push(holderId);

              const isGive = partnerUserIds.includes(h.toUserId);
              const tRef = h.id;

              const newHandovers = (settings.cashHandovers || []).filter((tx: any) => tx.id !== h.id);

              let currentHolders = [...(settings.cashHolders || [])];
              const activeHolderId = isGive ? h.toUserId : h.fromUserId;
              const partnerIdx = currentHolders.findIndex((holder: any) => holder.userId === activeHolderId);
              
              if (partnerIdx > -1) {
                  const currentBal = Number(currentHolders[partnerIdx].currentBalance ?? 0);
                  // Reverse the operation
                  const nextBal = isGive ? currentBal - amount : currentBal + amount;
                  currentHolders[partnerIdx] = {
                      ...currentHolders[partnerIdx],
                      currentBalance: nextBal,
                      lastUpdated: new Date().toISOString()
                  };
              }

              if (setTreasury && treasury) {
                  setTreasury((prev: any) => {
                      if (!prev) return prev;
                      
                      const linkedTreasuryTx = (prev.transactions || []).find((tx: any) => tx.reference === tRef);
                      let updatedAccounts = prev.accounts;
                      let updatedTxs = prev.transactions;
                      
                      if (linkedTreasuryTx) {
                          const accId = linkedTreasuryTx.toAccountId || linkedTreasuryTx.fromAccountId;
                          if (accId) {
                              updatedAccounts = prev.accounts.map((acc: any) => {
                                  if (acc.id === accId) {
                                      // If it was a deposit, we subtract to reverse it. If it was withdrawal, we add.
                                      const isDeposit = linkedTreasuryTx.toAccountId === accId;
                                      return {
                                          ...acc,
                                          balance: isDeposit ? acc.balance - amount : acc.balance + amount
                                      };
                                  }
                                  return acc;
                              });
                              updatedTxs = prev.transactions.filter((tx: any) => tx.reference !== tRef);
                          }
                      }

                      return {
                          ...prev,
                          accounts: updatedAccounts,
                          transactions: updatedTxs
                      };
                  });
              }

              updateSettings({
                  ...settings,
                  cashHandovers: newHandovers,
                  cashHolders: currentHolders
              });

              setDialog(null);
          }
      });
  };

  const [dialog, setDialog] = useState<{isOpen: boolean, title: string, message: string, onConfirm: () => void, isWarning?: boolean} | null>(null);

  const handleDeductPartnerCustodyDirectly = () => {
    if (!partner || partnerCustody <= 0) return;
    
    setDialog({
        isOpen: true,
        title: 'تأكيد تصفية العهدة من الرصيد',
        message: `هل أنت متأكد من خصم مبلغ العهدة القائمة (${partnerCustody.toLocaleString()} ج.م) مباشرة من رصيد الشريك الجاري؟ سيؤدي ذلك لتصفير العهدة واعتبارها مسحوبات شخصية من رأس المال.`,
        onConfirm: () => {
            const amount = partnerCustody;
            const dateStr = new Date().toISOString();
            
            // 1. Create Partner Transaction (Withdrawal)
            const newTx: PartnerTransaction = {
                id: `settle_${Date.now()}`,
                partnerId: partner.id,
                amount: amount,
                type: 'profit_withdrawal',
                date: dateStr,
                note: `تسوية وتصفية العهدة المعلقة خصماً من الرصيد الجاري (تصفير العهدة)`
            };

            // 2. Create Handover (Receive)
            const handoverId = `HND-SETTLE-${Date.now()}`;
            const holderId = `part_${partner.id}`;
            const handoverData: any = {
                id: handoverId,
                fromUserId: holderId,
                fromUserName: partner.name,
                toUserId: 'admin_deduction',
                toUserName: 'تسوية رصيد (خصم من الشريك)',
                amount: amount,
                date: dateStr,
                notes: `تصفية العهدة المعلقة (${amount.toLocaleString()} ج.م) وتحويلها لمسحوبات من رصيد الشريك`,
                status: 'completed'
            };

            // 3. Update Holders
            let currentHolders = [...(settings.cashHolders || [])];
            let foundHolder = false;
            currentHolders = currentHolders.map(h => {
                const normH = normalizeName(h.userName);
                const normP = normalizeName(partner.name);
                if (h.userId === holderId || h.userId === partner.id || normH === normP) {
                    foundHolder = true;
                    return { ...h, currentBalance: 0, lastUpdated: dateStr };
                }
                return h;
            });
            if (!foundHolder) {
                currentHolders.push({
                    userId: holderId,
                    userName: `${partner.name} (شريك)`,
                    currentBalance: 0,
                    lastUpdated: dateStr,
                    originalIds: [holderId, partner.id]
                } as any);
            }

            // 4. Update Partner Balance
            const newPartners = (settings.partners || []).map(p => 
                p.id === partner.id ? { ...p, balance: p.balance - amount } : p
            );

            updateSettings({
                ...settings,
                partners: newPartners,
                partnerTransactions: [newTx, ...(settings.partnerTransactions || [])],
                cashHolders: currentHolders,
                cashHandovers: [handoverData, ...(settings.cashHandovers || [])],
                activityLogs: [
                    {
                        id: `log-${Date.now()}`,
                        user: 'الادارة',
                        action: 'تصفية عهدة من الرصيد',
                        details: `تمت تسوية وتصفية عهدة الشريك ${partner.name} بقيمة ${amount.toLocaleString()} ج.م وخصمها من رصيده الجاري.`,
                        date: new Date().toLocaleString('ar-EG'),
                        timestamp: Date.now()
                    },
                    ...(settings.activityLogs || [])
                ]
            });

            setDialog(null);
            alert('تمت تسوية العهدة بنجاح وخصمها من رصيد الشريك.');
        }
    });
  };

  const handleConvertLoanToWithdrawal = (t: PartnerTransaction) => {
    if (t.type !== 'loan') return;
    
    setDialog({
        isOpen: true,
        title: 'تحويل السلفة لمسحوبات من رأس المال',
        message: `هل أنت متأكد من تحويل هذه السلفة بقيمة (${t.amount.toLocaleString()} ج.م) لتكون مسحوبات شخصية من رأس المال؟ سيؤدي ذلك لتصفير مديونية السلفة في كشوف الحساب واعتبارها سحباً نهائياً.`,
        onConfirm: () => {
            const updatedTransactions = (settings.partnerTransactions || []).map(tx => {
                if (tx.id === t.id) {
                    return {
                        ...tx,
                        type: 'profit_withdrawal' as const,
                        note: `${tx.note || ''} (تم تحويلها من سلفة لمسحوبات من رأس المال بناء على طلب الشريك للتصفير)`
                    };
                }
                return tx;
            });

            updateSettings({
                ...settings,
                partnerTransactions: updatedTransactions,
                activityLogs: [
                    {
                        id: `log-${Date.now()}`,
                        user: 'الادارة',
                        action: 'تحويل سلفة لمسحوبات',
                        details: `تم تحويل سلفة الشريك ${partner?.name} بقيمة ${t.amount.toLocaleString()} ج.م إلى مسحوبات شخصية من رأس المال.`,
                        date: new Date().toLocaleString('ar-EG'),
                        timestamp: Date.now()
                    },
                    ...(settings.activityLogs || [])
                ]
            });

            setDialog(null);
            alert('تم تحويل السلفة بنجاح.');
        }
    });
  };

  const deleteTransaction = (t: PartnerTransaction) => {
    // Check if it's explicitly linked to a system document
    const isLinkedExpense = t.id.endsWith('pt');
    const isSupplyOrder = t.id.startsWith('supply_pt_');

    if (isLinkedExpense || isSupplyOrder) {
       setDialog({
        isOpen: true,
        title: 'لا يمكن حذف المعاملة',
        message: isSupplyOrder 
          ? 'هذه المعاملة مرتبطة بفاتورة شراء أو مرتجع. يرجى تعديلها أو حذفها من قسم "الموردين وفواتير الشراء".'
          : 'هذه المعاملة مرتبطة بمصروف مسجل. يرجى حذفها من قسم "المصروفات والإيرادات" لضمان مزامنة الخزينة.',
        onConfirm: () => setDialog(null),
        isWarning: true
       });
       return;
    }

    setDialog({
      isOpen: true,
      title: 'تأكيد عكس المعاملة',
      message: 'سيتم تسجيل حركة عكسية مع الاحتفاظ بالمعاملة الأصلية للمراجعة. هل تريد المتابعة؟',
      onConfirm: () => {
        let currentBalance = partner?.balance || 0;
        const isAddition = ['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage'].includes(t.type);
        
        // Reverse the effect
        if (isAddition) {
            currentBalance -= t.amount;
        } else {
            currentBalance += t.amount;
        }

        const newPartners = (settings.partners || []).map(p => 
            p.id === partnerId ? { ...p, balance: currentBalance } : p
        );
        const reversalType: PartnerTransaction['type'] = isAddition
          ? (t.type === 'capital_addition' ? 'capital_withdrawal' : 'loan')
          : 'repayment';
        const reversalTransaction: PartnerTransaction = {
          id: generateSafeId('pt_reversal'),
          partnerId: partnerId || '',
          type: reversalType,
          amount: Number(t.amount) || 0,
          date: new Date().toISOString(),
          note: `عكس محاسبي للمعاملة ${t.id} بدل حذفها: ${t.note || ''}`
        };
        const newPartnerTransactions = [
          ...(settings.partnerTransactions || []),
          reversalTransaction
        ];

        updateSettings({
            ...settings,
            partners: newPartners,
            partnerTransactions: newPartnerTransactions
        });

        // Revert Treasury transaction
        if (setTreasury && treasury) {
          const tRef = `pt_${t.id}`;
          const linkedTreasuryTx = (treasury.transactions || []).find((tx: any) => tx.reference === tRef);
          if (linkedTreasuryTx) {
            const accId = linkedTreasuryTx.toAccountId || linkedTreasuryTx.fromAccountId;
            if (accId) {
              setTreasury((prev: any) => {
                if (!prev) return prev;
                const updatedAccounts = prev.accounts.map((acc: any) => {
                  if (acc.id === accId) {
                    const isDeposit = linkedTreasuryTx.toAccountId === accId;
                    return {
                      ...acc,
                      balance: isDeposit ? acc.balance - t.amount : acc.balance + t.amount
                    };
                  }
                  return acc;
                });
                const updatedTxs = [
                  ...(prev.transactions || []),
                  {
                    id: generateSafeId('t_reversal'),
                    date: new Date().toISOString(),
                    type: linkedTreasuryTx.type === 'withdrawal' ? 'deposit' : 'withdrawal',
                    amount: t.amount,
                    description: `عكس محاسبي للمعاملة ${t.id}`,
                    reference: `${tRef}_reversal`,
                    toAccountId: linkedTreasuryTx.fromAccountId,
                    fromAccountId: linkedTreasuryTx.toAccountId
                  }
                ];
                return {
                  ...prev,
                  accounts: updatedAccounts,
                  transactions: updatedTxs
                };
              });
            }
          }
        }

        // Revert global Wallet transaction and balance
        if (setWallet && t.type !== 'profit_distribution') {
          setWallet((prev: any) => {
            if (!prev) return prev;
            const updatedTransactions = [
              ...(prev.transactions || []),
              {
                id: generateSafeId('wtx_reversal'),
                type: t.type === 'loan' || t.type === 'profit_withdrawal' || t.type === 'expense_repayment' ? 'إيداع' : 'سحب',
                amount: t.amount,
                note: `عكس محاسبي للمعاملة ${t.id}`,
                date: new Date().toISOString(),
                category: 'partner_reversal',
                status: 'completed'
              }
            ];
            
            const isWithdrawal = t.type === 'loan' || t.type === 'profit_withdrawal' || t.type === 'expense_repayment' || t.type === 'capital_withdrawal';
            const isSupplyFunding = t.type === 'supply_funding';
            
            let newBalance = prev.balance;
            
            newBalance = isWithdrawal ? newBalance + t.amount : newBalance - t.amount;
            
            return {
              ...prev,
              balance: newBalance,
              transactions: updatedTransactions
            };
          });
        }

        setDialog(null);
      }
    });
  };

    const stats = useMemo(() => {
    if (!partner) return { totalInvested: 0, totalDividends: 0, totalWithdrawn: 0, totalLoans: 0, totalAdvances: 0, totalRepaid: 0 };
    
    const pOrderAdvances = orders.filter(o => {
        const safeAdvance = Number(o.advancePayment) || 0;
        if (safeAdvance <= 0) return false;
        if (o.advancePaymentTreasuryId || (o.cashHolderId && o.cashHolderId.startsWith('treas_'))) return false;
        const empId = o.advancePaymentEmployeeId || (o.cashHolderId && o.cashHolderId.startsWith('emp_') ? o.cashHolderId.substring(4) : null);
        if (empId) {
            const isPt = (settings.partners || []).some((pt) => String(pt.id) === String(empId));
            if (!isPt) return false;
        }
        if (empId && String(empId) === String(partner.id)) return true;
        if (o.advancePaymentPartnerId === partner.id || o.cashHolderId === `part_${partner.id}`) return true;
        if (Array.isArray(o.advancePaymentHistory) && o.advancePaymentHistory.some((h: any) => h.recipientId === partner.id || (h.recipientType === 'partner' && (h.recipientName === partner.name || h.recipientId === partner.id)))) return true;
        const partnersCount = settings.cashHolders?.filter((h: any) => h.userId.startsWith('part_')).length || 1;
        if (partnersCount === 1) return true;
        return false;
    });

    const advancesSum = pOrderAdvances.reduce((sum, o) => sum + (Number(o.advancePayment) || 0), 0);

    let totalInvested = 0;
    let totalDividends = 0;
    let totalWithdrawn = 0;
    let totalLoans = 0;
    let totalAdvances = advancesSum;
    let totalRepaid = 0;

    transactions.forEach(t => {
        if (t.type === 'capital_addition') totalInvested += t.amount;
        if (t.type === 'profit_distribution') totalDividends += t.amount;
        if (t.type === 'profit_withdrawal') totalWithdrawn += t.amount;
        if (t.type === 'loan') totalLoans += t.amount;
        if (t.type === 'repayment') totalRepaid += t.amount;
    });

    return { totalInvested, totalDividends, totalWithdrawn, totalLoans, totalAdvances, totalRepaid };
  }, [transactions, partner, orders, settings.cashHolders, settings.partners]);

  const chartData = useMemo(() => {
    if (!partner) return [];
    let currentBalance = 0;
    return transactions
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .map(t => {
            if (['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage', 'internal_transfer_in'].includes(t.type)) {
                currentBalance += t.amount;
            } else if (t.type !== 'pos_collection') {
                currentBalance -= t.amount;
            }
            return {
                date: new Date(t.date).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' }),
                balance: currentBalance,
                amount: t.amount,
                type: t.type
            };
        });
  }, [transactions, partner]);

  const handlePrintStatement = () => {
    if (!partner) return;
    
    // Sort transactions chronologically 
    const sortedTxs = [...mergedTransactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    const getTxTypeName = (type: string, note?: string) => {
      const n = (note || '').toLowerCase();
      if (n.includes('خصم عهدة') || n.includes('تسوية عهدة') || n.includes('تحويلها كمسحوبات')) {
        return 'تسوية عهدة معلقة (خصم من الرصيد)';
      }
      switch (type) {
        case 'loan': return 'سلفة نقدية / مسحوبات شخصية';
        case 'customer_advance': return 'عربون محصل من عميل';
        case 'capital_addition': return 'إيداع رأس مال استثماري';
        case 'shipping_funding': return 'تمويل مصاريف الشحن';
        case 'profit_withdrawal': return 'سحب من حصة الأرباح المستحقة';
        case 'profit_distribution': return 'توزيع أرباح دورية معتمدة';
        case 'supply_funding': return 'تمويل شراء بضاعة ومخزون';
        case 'expense_coverage': return 'سداد مصروفات تشغيلية';
        case 'expense_repayment': return 'استرداد مصروفات مدفوعة للشريك';
        case 'pos_collection': return 'استلام عهدة كاشير';
        case 'repayment': return 'سداد مديونية / رد سلفة';
        case 'custody_give': return 'تسليم عهدة نقدية للشريك';
        case 'custody_receive': return 'تسوية واسترداد عهدة من الشريك';
        case 'internal_transfer_in': return 'تحويل مالي وارد';
        case 'internal_transfer_out': return 'تحويل مالي صادر';
        default: return 'معاملة مالية معتمدة';
      }
    };

    const isAddition = (type: string) => 
      ['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage', 'internal_transfer_in', 'custody_receive'].includes(type);

    let rowsHtml = '';
    let runningBalance = 0;

    sortedTxs.forEach((t) => {
      const typeLabel = getTxTypeName(t.type, t.note);
      const isAdd = isAddition(t.type);
      const val = Number(t.amount) || 0;
      
      if (t.type === 'pos_collection') {
        // POS is balance neutral in partner balance
      } else if (isAdd) {
        runningBalance += val;
      } else {
        runningBalance -= val;
      }

      rowsHtml += `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 13px;">
          <td style="padding: 12px; text-align: right; color: #475569;">${new Date(t.date).toLocaleDateString('ar-EG')}</td>
          <td style="padding: 12px; text-align: right; font-weight: bold; color: #1e293b;">${typeLabel}</td>
          <td style="padding: 12px; text-align: right; color: #64748b; max-width: 250px;">${t.note || '-'}</td>
          <td style="padding: 12px; text-align: left; font-weight: bold; color: ${isAdd ? '#10b981' : '#f43f5e'}">
            ${isAdd ? '+' : '-'}${val.toLocaleString()} ج.م
          </td>
          <td style="padding: 12px; text-align: left; font-weight: 900; color: #334155;">
            ${runningBalance.toLocaleString()} ج.م
          </td>
        </tr>
      `;
    });

    const html = `
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>كشف حساب الشريك - ${partner.name}</title>
        <style>
          body {
            font-family: system-ui, -apple-system, sans-serif;
            background-color: #ffffff;
            color: #1e293b;
            margin: 0;
            padding: 40px;
          }
          .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px double #e2e8f0;
            padding-bottom: 20px;
            margin-bottom: 30px;
          }
          .title-area h1 {
            margin: 0 0 5px 0;
            font-size: 24px;
            font-weight: 900;
            color: #4f46e5;
          }
          .title-area p {
            margin: 0;
            font-size: 13px;
            color: #64748b;
          }
          .info-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 15px;
            margin-bottom: 40px;
            background: #f8fafc;
            padding: 20px;
            border-radius: 20px;
            border: 1px solid #e2e8f0;
          }
          .info-card {
            display: flex;
            flex-direction: column;
          }
          .info-card .label {
            font-size: 11px;
            color: #94a3b8;
            font-weight: 700;
            margin-bottom: 5px;
            text-transform: uppercase;
          }
          .info-card .value {
            font-size: 16px;
            font-weight: 950;
            color: #1e293b;
          }
          .table-container {
            width: 100%;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            text-align: right;
          }
          th {
            background-color: #f1f5f9;
            color: #475569;
            font-weight: 800;
            padding: 12px;
            font-size: 12px;
            border-bottom: 2px solid #cbd5e1;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="title-area">
            <h1>كشف الحساب المالي للشركاء</h1>
            <p>الشريك: ${partner.name} | نسبة الأرباح الشاملة: ${partner.profitRatio}%</p>
          </div>
          <div style="text-align: left;">
            <p style="margin: 0; font-weight: 950; color: #1e293b; font-size: 16px;">عبده ميديا برايم | AbdoMedia Prime</p>
            <p style="margin: 5px 0 0 0; color: #64748b; font-size: 12px;">تاريخ استخراج المستند: ${new Date().toLocaleDateString('ar-EG')} ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</p>
          </div>
        </div>

        <div class="info-grid">
          <div class="info-card">
            <span class="label">الرصيد الجاري المستحق</span>
            <span class="value" style="color: ${partner.balance >= 0 ? '#10b981' : '#f43f5e'}">${partner.balance.toLocaleString()} ج.م</span>
          </div>
          <div class="info-card">
            <span class="label">مجموع عمليات رأس المال والتمويل</span>
            <span class="value">${stats.totalInvested.toLocaleString()} ج.م</span>
          </div>
          <div class="info-card">
            <span class="label">صافي المعاملات المدينة والسلف</span>
            <span class="value">${Math.max(0, stats.totalLoans - stats.totalRepaid).toLocaleString()} ج.م</span>
          </div>
          <div class="info-card">
            <span class="label">المسحوبات الشخصية والأرباح</span>
            <span class="value">${stats.totalWithdrawn.toLocaleString()} ج.م</span>
          </div>
          <div class="info-card">
            <span class="label">العهدة والنقدية طرفه</span>
            <span class="value" style="color: #4f46e5">${partnerCustody.toLocaleString()} ج.م</span>
          </div>
        </div>

        <div class="table-container">
          <h3 style="font-weight: 900; font-size: 15px; margin-bottom: 12px; color: #334155;">سجل الحركات المالية المصدقة</h3>
          <table>
            <thead>
              <tr>
                <th style="text-align: right; width: 15%;">التاريخ</th>
                <th style="text-align: right; width: 25%;">نوع المعاملة</th>
                <th style="text-align: right; width: 30%;">ملاحظات التفاصيل والبيان</th>
                <th style="text-align: left; width: 15%;">القيمة المعنية</th>
                <th style="text-align: left; width: 15%;">الرصيد التراكمي</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml || `<tr><td colspan="5" style="text-align: center; padding: 30px; color: #94a3b8; font-weight: bold;">لا توجد معاملات جارية مسجلة.</td></tr>`}
            </tbody>
          </table>
        </div>
        
        <div style="margin-top: 65px; display: flex; justify-content: space-between; font-size: 12px; color: #94a3b8; border-top: 1px dashed #e2e8f0; padding-top: 20px;">
          <p>توقيع الإدارة المالية والتدقيق: ____________________</p>
          <p>توقيع ومصادقة الشريك: ____________________</p>
        </div>
      </body>
      </html>
    `;

    printHTMLDirectly(html);
  };

  if (!partner) {
    return (
      <div className="p-12 text-center space-y-4">
        <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
           <User size={40} />
        </div>
        <h2 className="text-2xl font-black text-slate-800">الشريك غير موجود</h2>
        <button onClick={() => navigate(`/store/${storeId}/partners`)} className="text-indigo-600 font-bold hover:underline">العودة للشركاء</button>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 space-y-8 bg-slate-50/30 dark:bg-slate-900/10 min-h-screen">
      {dialog && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-800 w-full max-w-sm rounded-3xl shadow-xl p-6 text-right" dir="rtl">
                <h3 className="text-xl font-black text-slate-800 dark:text-white mb-2">{dialog.title}</h3>
                <p className="text-slate-500 font-bold text-sm mb-6 leading-relaxed">{dialog.message}</p>
                <div className="flex gap-3">
                    {dialog.isWarning ? (
                        <button 
                            onClick={dialog.onConfirm}
                            className="flex-1 px-4 py-3 bg-indigo-600 text-white font-black rounded-xl hover:bg-indigo-700 transition-colors"
                        >
                            حسناً
                        </button>
                    ) : (
                        <>
                            <button 
                                onClick={dialog.onConfirm}
                                className="flex-1 px-4 py-3 bg-rose-600 text-white font-black rounded-xl hover:bg-rose-700 transition-colors"
                            >
                                تأكيد الحذف
                            </button>
                            <button 
                                onClick={() => setDialog(null)}
                                className="flex-1 px-4 py-3 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-black rounded-xl hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
                            >
                                إلغاء
                            </button>
                        </>
                    )}
                </div>
            </div>
        </div>
      )}
      <div className="flex items-center justify-between">
        <button 
          onClick={() => navigate(`/store/${storeId}/partners`)} 
          className="group flex items-center gap-2 text-slate-500 font-bold hover:text-indigo-600 transition-colors"
        >
          <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center shadow-sm group-hover:bg-indigo-50 transition-colors">
            <ArrowLeft size={20} />
          </div>
          العودة للشركاء
        </button>

        <div className="flex gap-2">
            <button 
                onClick={() => setShowPrintModal(true)}
                className="flex items-center gap-2 px-4 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black transition-all shadow-md shadow-indigo-600/10 cursor-pointer"
                title="معاينة كشف الحساب وتخصيص الفترات والطباعة"
            >
                <Eye size={18} />
                <span className="text-xs font-black">معاينة وطباعة كشف الحساب</span>
            </button>
            <button 
                onClick={handlePrintStatement}
                className="hidden sm:flex items-center gap-2 px-3.5 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl font-black transition-all cursor-pointer"
                title="طباعة فورية مباشرة"
            >
                <Printer size={18} />
                <span className="text-xs font-black">طباعة سريعة</span>
            </button>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center gap-6 sm:gap-8 justify-between relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full -mr-32 -mt-32 blur-3xl"></div>
        
        <div className="flex items-center gap-4 sm:gap-6 relative z-10 w-full sm:w-auto">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-indigo-600 text-white rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-500/30 flex-shrink-0">
                <User size={40} className="sm:hidden" />
                <User size={48} className="hidden sm:block" />
            </div>
            <div className="space-y-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                  <h1 className="text-2xl sm:text-3xl font-black text-slate-800 dark:text-white truncate max-w-[150px] sm:max-w-none">{partner.name}</h1>
                  <span className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-[10px] font-black px-3 py-1 rounded-full uppercase">نشط</span>
                </div>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium flex items-center gap-2">
                    <PieChart size={14} className="sm:hidden" />
                    <PieChart size={16} className="hidden sm:block" />
                    <span className="hidden sm:inline">نسبة المشاركة في الأرباح:</span>
                    <span className="sm:hidden">أرباح:</span>
                    <span className="text-indigo-600 font-black">{partner.profitRatio}%</span>
                  </p>

                  <button
                    onClick={openPinModal}
                    className="text-[10px] font-black bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/30 dark:hover:bg-amber-900/50 text-amber-700 dark:text-amber-400 px-2.5 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition-colors border border-amber-300/40"
                    title="انقر لتغيير أو تعيين رمز PIN"
                  >
                    <Lock size={10} /> PIN: {partner.passcode || '0000'}
                    <span className="text-[9px] underline mr-1 text-amber-800 dark:text-amber-300">تعديل الرمز</span>
                  </button>

                  <button
                    onClick={copyPortalLink}
                    className="text-[10px] font-black bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200/50 dark:border-indigo-800/50 px-2.5 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition-colors"
                    title="نسخ رابط الدخول المباشر للبوابة"
                  >
                    <Share2 size={10} /> نسخ الرابط
                  </button>

                  <button
                    onClick={shareWhatsApp}
                    className="text-[10px] font-black bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50 px-2.5 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition-colors"
                    title="مشاركة رابط البوابة ورمز PIN للشريك عبر واتساب"
                  >
                    <span>📲 واتساب</span>
                  </button>
                </div>
            </div>
        </div>

        <div className="text-center md:text-left relative z-10 w-full sm:w-auto mt-4 sm:mt-0">
            <p className="text-[10px] sm:text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">صافي الرصيد الحالي</p>
            <p className={`text-3xl sm:text-5xl font-black tracking-tighter ${partner.balance >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                {partner.balance.toLocaleString()} 
                <span className="text-lg sm:text-xl font-bold ml-2 text-slate-300">ج.م</span>
            </p>
        </div>
      </motion.div>

      {/* 🔔 طلبات الشريك المعلقة الواردة من البوابة */}
      {(() => {
        const partnerPendingRequests = allPartnerRequests.filter(
          (r: any) => {
            const isMatch = r.partnerId === partner?.id || normalizeName(r.partnerName) === normalizeName(partner?.name || '');
            const isMerchant = r.id?.startsWith('REQ-M-') || 
                               r.isMerchantRequest === true || 
                               (r.typeArabic && r.typeArabic.includes('الموكل')) ||
                               (r.partnerId && (r.partnerId.startsWith('m_') || r.partnerId.startsWith('sup_')));
            return isMatch && !isMerchant && r.status === 'pending';
          }
        );
        if (partnerPendingRequests.length === 0) return null;

        return (
          <div className="bg-amber-500/10 border-2 border-amber-500/30 rounded-3xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-500 text-white rounded-xl shadow-md">
                <Clock size={20} className="animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-800 dark:text-white">
                  طلبات معلقة من الشريك ({partnerPendingRequests.length})
                </h3>
                <p className="text-xs text-slate-500">
                  قدم هذا الشريك طلبات من خلال بوابته المالية وهي بانتظار مراجعتك واعتمادها.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {partnerPendingRequests.map((req: any) => (
                <div key={req.id} className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-amber-200 dark:border-amber-900/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shadow-sm">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">{req.typeArabic || req.type}</span>
                      {req.amount > 0 && (
                        <span className="text-sm font-black text-indigo-600 font-mono">
                          {Number(req.amount).toLocaleString()} ج.م
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400">
                        {new Date(req.date).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                    {req.notes && (
                      <p className="text-xs text-slate-500 mt-1">ملاحظات: {req.notes}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={async () => {
                        const amt = Number(req.amount || 0);
                        if (!storeId || req.status !== 'pending') return;
                        const statusUpdated = await db.updatePartnerRequestStatus(req.id, storeId, 'approved');
                        if (!statusUpdated) return;
                        setCloudRequests(prev => prev.map(r => r.id === req.id ? { ...r, status: 'approved' } : r));
                        const updatedRequests = allPartnerRequests.map((r: any) => r.id === req.id ? { ...r, status: 'approved' } : r);
                        let updatedTxs = settings.partnerTransactions || [];
                        if (req.type === 'withdrawal' && amt > 0) {
                          updatedTxs = [{
                            id: `tx_${Date.now()}`,
                            partnerId: partner?.id || '',
                            partnerName: partner?.name || '',
                            type: 'loan',
                            amount: amt,
                            date: new Date().toISOString(),
                            notes: `اعتماد طلب سحب أرباح من البوابة: ${req.notes || ''}`
                          }, ...updatedTxs];
                        } else if (req.type === 'expense' && amt > 0) {
                          updatedTxs = [{
                            id: `tx_${Date.now()}`,
                            partnerId: partner?.id || '',
                            partnerName: partner?.name || '',
                            type: 'direct_expense',
                            amount: amt,
                            date: new Date().toISOString(),
                            notes: `اعتماد تسجيل مصروف مدفوع من الشريك من البوابة: ${req.notes || ''}`
                          }, ...updatedTxs];
                        }

                        // Deduct from partner's balance
                        const updatedPartners = (settings.partners || []).map(p => {
                          const isMatch = p.id === (partner?.id || req.partnerId) || normalizeName(p.name) === normalizeName(req.partnerName);
                          if (isMatch) {
                            let newBal = Number(p.balance || 0);
                            if (req.type === 'withdrawal') newBal -= amt;
                            else if (req.type === 'expense') newBal += amt;
                            return { ...p, balance: newBal };
                          }
                          return p;
                        });

                        const updatedSettings = {
                          ...settings,
                          partners: updatedPartners,
                          partnerRequests: updatedRequests,
                          partnerTransactions: updatedTxs,
                          activityLogs: [
                            {
                              id: `log_${Date.now()}`,
                              user: 'الإدارة',
                              action: 'اعتماد طلب شريك',
                              details: `تم اعتماد ${req.typeArabic || 'الطلب'} للشريك ${req.partnerName} بمبلغ ${amt.toLocaleString()} ج.م وخصمه من حسابه الجاري`,
                              date: new Date().toISOString(),
                              timestamp: Date.now()
                            },
                            ...(settings.activityLogs || [])
                          ]
                        };

                        updateSettings(updatedSettings);

                        if (storeId) {
                          try {
                            const curStore = await db.getStoreData(storeId);
                            if (curStore) {
                              await db.saveStoreData({ id: storeId, name: settings.storeName || 'المتجر' } as any, {
                                ...curStore,
                                settings: updatedSettings
                              });
                            }
                          } catch (e) {
                            console.warn('Error saving approved partner data to cloud:', e);
                          }
                        }
                      }}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer transition-all"
                    >
                      اعتماد
                    </button>
                    <button
                      onClick={async () => {
                        if (!storeId || !(await db.updatePartnerRequestStatus(req.id, storeId, 'rejected'))) return;
                        setCloudRequests(prev => prev.map(r => r.id === req.id ? { ...r, status: 'rejected' } : r));
                        const updatedRequests = allPartnerRequests.map((r: any) => r.id === req.id ? { ...r, status: 'rejected' } : r);
                        updateSettings({
                          ...settings,
                          partnerRequests: updatedRequests
                        });
                      }}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl border border-rose-200 cursor-pointer transition-all"
                    >
                      رفض
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })()}

      {/* 💡 شريط توزيع مستحقات الشريك بين البضاعة والسيولة */}
      {(() => {
        const inventoryVal = (settings.products || []).reduce((sum, p) => {
          const stock = Number(p.stockQuantity) || 0;
          const cost = Number(p.costPrice) || 0;
          return sum + (stock * cost);
        }, 0);
        const partnerInventoryShare = (inventoryVal * (partner.profitRatio || 0)) / 100;
        const totalNetWorth = Math.max(0, partner.balance) + partnerInventoryShare;
        const invPercent = totalNetWorth > 0 ? Math.round((partnerInventoryShare / totalNetWorth) * 100) : 0;
        const cashPercent = 100 - invPercent;

        return (
          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-700/60 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center font-black">
                  <PackageIcon size={18} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-800 dark:text-white">أين تتركز أموال وحصة الشريك ({partner.name}) حالياً؟</h3>
                  <p className="text-[10px] font-bold text-slate-400">توزيع إجمالي مستحقات الشريك بين بضاعة المخزن العينية والسيولة المتاحة</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-black">
                <span className="text-slate-400">إجمالي القيمة التقديرية لحصته:</span>
                <span className="text-indigo-600 dark:text-indigo-400 text-sm">{(partner.balance + partnerInventoryShare).toLocaleString()} ج.م</span>
              </div>
            </div>

            {/* Progress bar */}
            <div className="space-y-1.5">
              <div className="h-3 w-full bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden flex">
                <div 
                  className="bg-amber-500 transition-all" 
                  style={{ width: `${Math.min(100, Math.max(5, invPercent))}%` }}
                  title={`حصة بضاعة بالمخزن: ${partnerInventoryShare.toLocaleString()} ج.م`}
                ></div>
                <div 
                  className="bg-emerald-500 transition-all" 
                  style={{ width: `${Math.max(0, cashPercent)}%` }}
                  title={`رصيد جاري وسيولة: ${partner.balance.toLocaleString()} ج.م`}
                ></div>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold text-slate-500">
                <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                  <span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>
                  بضاعة بالمخزن: {partnerInventoryShare.toLocaleString()} ج.م ({invPercent}%)
                </span>
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                  رصيد جاري وسيولة: {partner.balance.toLocaleString()} ج.م ({cashPercent}%)
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
              <div className="p-3 bg-amber-50/60 dark:bg-amber-950/20 rounded-2xl border border-amber-100 dark:border-amber-900/30">
                <p className="text-[10px] font-bold text-amber-800 dark:text-amber-300 leading-relaxed">
                  📦 <strong>البضاعة:</strong> حصتك التقديرية من بضاعة المخزن الحالية البالغة {inventoryVal.toLocaleString()} ج.م هي <strong className="underline">{partnerInventoryShare.toLocaleString()} ج.م</strong> بناءً على نسبة حصتك ({partner.profitRatio}%).
                </p>
              </div>
              <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                <p className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 leading-relaxed">
                  💰 <strong>الرصيد الدفتري (صافي الحقوق):</strong> رصيدك الجاري المتبقي بالمتجر هو <strong className="underline">{partner.balance.toLocaleString()} ج.م</strong>، ويمثل حقك المالي بعد احتساب رأس المال المودع وأي مدفوعات شخصية + الأرباح الموزعة وخصم المسحوبات.
                </p>
              </div>
            </div>

            {/* دليل الدورة المحاسبية لرأس المال والأرباح */}
            <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-900/40 rounded-2xl border border-slate-200 dark:border-slate-800 text-[10px] leading-relaxed space-y-2">
              <div className="flex items-center gap-1.5 font-black text-slate-800 dark:text-slate-200">
                <span>🔄</span>
                <span>الدورة المحاسبية لحقوق الشريك والمدفوعات والمبيعات:</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-2 text-slate-600 dark:text-slate-400">
                <div className="bg-white dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                  <strong className="text-indigo-600 dark:text-indigo-400 block mb-0.5">1. شراء بضاعة من الجيب:</strong>
                  المبلغ يزيد رأس مال الشريك كحق دائن ثابت، وتدخل البضاعة للمخزن كأصل عيني مشترك وتُسترد قيمتها كاش عند بيعها.
                </div>
                <div className="bg-white dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                  <strong className="text-amber-600 dark:text-amber-400 block mb-0.5">2. مصاريف وتغليف من الجيب:</strong>
                  تزيد رأس مال الشريك الذي دفع، وتُخصم كمصروف من إجمالي أرباح المبيعات المشتركة فيتحمل الشريكان تكلفتها مناصفة.
                </div>
                <div className="bg-white dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                  <strong className="text-emerald-600 dark:text-emerald-400 block mb-0.5">3. الأرباح الصافية المتبقية:</strong>
                  الفائض بعد تصفية كافة التكاليف والمصاريف والخسائر هو الربح الصافي، ويُقسم بنسبة ({partner.profitRatio}%) ويُضاف لخانة "الأرباح الموزعة".
                </div>
                <div className="bg-white dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                  <strong className="text-rose-600 dark:text-rose-400 block mb-0.5">4. المسحوبات والرصيد:</strong>
                  أي مسحوبات كاش تُخصم من رصيد الشريك، والرصيد النهائي = (رأس المال + مساهمات الجيب + الأرباح) - المسحوبات.
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4 sm:gap-6">
          {[
            { label: 'إجمالي رأس المال المضاف', value: stats.totalInvested, color: 'text-blue-600', bg: 'bg-blue-100 dark:bg-blue-900/20', icon: ArrowUpLeft },
            { label: 'الأرباح الموزعة له', value: stats.totalDividends, color: 'text-emerald-600', bg: 'bg-emerald-100 dark:bg-emerald-900/20', icon: TrendingUp },
            { label: 'الأرباح المسحوبة', value: stats.totalWithdrawn, color: 'text-amber-600', bg: 'bg-amber-100 dark:bg-amber-900/20', icon: DollarSign },
            { label: 'إجمالي السلف الشخصية', value: stats.totalLoans, color: 'text-rose-600', bg: 'bg-rose-100 dark:bg-rose-900/20', icon: ArrowDownRight },
            { label: 'العهد التشغيلية طرفه', value: partnerCustody, color: 'text-indigo-600', bg: 'bg-indigo-100 dark:bg-indigo-900/20', icon: WalletIcon },
            { label: 'صافي مديونية السلف', value: Math.max(0, stats.totalLoans - stats.totalRepaid), color: 'text-slate-700 dark:text-slate-300', bg: 'bg-slate-100 dark:bg-slate-700/20', icon: History },
          ].map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm"
            >
               <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2 sm:mb-3">
                  <div className={`w-7 h-7 sm:w-8 sm:h-8 ${stat.bg} ${stat.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <stat.icon size={14} className="sm:hidden" />
                    <stat.icon size={16} className="hidden sm:block" />
                  </div>
                  <span className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase line-clamp-1">{stat.label}</span>
               </div>
               <p className={`text-lg sm:text-2xl font-black ${stat.color} dark:text-white tracking-tight`}>
                  {stat.value.toLocaleString()} 
                  <span className="text-[10px] sm:text-xs font-bold ml-1 opacity-50">ج.م</span>
               </p>
            </motion.div>
          ))}
      </div>

      <div className="bg-indigo-50/80 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/40 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-bold text-slate-700 dark:text-slate-300">
        <div className="flex items-center gap-2">
           <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse"></span>
           <span>💡 <strong>قاعدة الرصيد الصافي للشريك:</strong> (الأرباح الموزعة + رأس المال والإيداعات) - (المسحوبات الشخصية والسلف المالية). الرصيد الأخضر يعني مستحقات للشريك، والأحمر يعني سلف زائدة.</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-3">
                  <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-xl"><Activity size={20}/></div>
                  منحنى المحفظة المالية
              </h2>
              <div className="flex gap-2">
                 <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400"><div className="w-2 h-2 rounded-full bg-indigo-600"></div>الرصيد</span>
              </div>
            </div>
            <div className="h-[350px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                        <defs>
                          <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis 
                          dataKey="date" 
                          axisLine={false} 
                          tickLine={false}
                          tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
                          dy={10}
                        />
                        <YAxis 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
                          tickFormatter={(val) => val.toLocaleString()}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            borderRadius: '16px', 
                            border: 'none', 
                            boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                            fontWeight: 800,
                            direction: 'rtl'
                          }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="balance" 
                          stroke="#4f46e5" 
                          strokeWidth={4} 
                          fillOpacity={1} 
                          fill="url(#colorBalance)" 
                        />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
          </div>

          {/* بطاقة العهدة والتحصيلات للشركاء */}
          <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 text-right" dir="rtl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-50 dark:border-slate-800 pb-5">
                  <div className="flex items-center gap-3.5">
                      <div className="p-3.5 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-2xl">
                          <Coins size={28} />
                      </div>
                      <div>
                          <h2 className="text-lg font-black text-slate-800 dark:text-white">بطاقة العهدة والتحصيلات المدينة</h2>
                          <p className="text-slate-400 font-bold text-xs mt-0.5">مراقبة وتسلم وتصفية الأموال السائلة طرف الشريك</p>
                      </div>
                  </div>
                  <div className="flex flex-col items-end">
                      <span className="text-[10px] font-black text-slate-400 mb-1 uppercase tracking-widest">إجمالي العهدة المالية طرف الشريك</span>
                      <span className={`text-2xl font-black ${partnerCustody > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400'}`}>
                          {partnerCustody.toLocaleString()} <span className="text-xs font-bold">ج.م</span>
                      </span>
                  </div>
              </div>

              {partnerCustody > 0 ? (
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="flex-1 p-4 bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30 rounded-2xl flex items-center gap-3 text-amber-800 dark:text-amber-300">
                        <Coins size={18} className="flex-shrink-0" />
                        <p className="text-xs font-bold leading-relaxed">
                            تنبيه: يوجد مبالغ نقدية متبقية كعهدة طرف الشريك بقيمة <strong>{partnerCustody.toLocaleString()} ج.م</strong>. يرجى تسوية المبالغ أو توريدها للخزينة عند تحصيلها.
                        </p>
                    </div>
                    <button 
                        onClick={handleDeductPartnerCustodyDirectly}
                        className="flex items-center justify-center gap-2 px-6 py-4 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-black transition-all shadow-lg shadow-rose-600/20 active:scale-95 cursor-pointer"
                    >
                        <RefreshCw size={18} />
                        تصفية العهدة من رصيد الشريك (تصفير)
                    </button>
                  </div>
              ) : (
                  <div className="p-4 bg-slate-50 dark:bg-slate-900/30 rounded-2xl flex items-center gap-3 text-slate-500">
                      <Check size={18} className="flex-shrink-0 text-emerald-500" />
                      <p className="text-xs font-bold">الحساب النقدي مطابق ولا يوجد عهد مالية معلقة ومفتوحة طرف الشريك حالياً.</p>
                  </div>
              )}

              {/* Custody Action Form */}
              <div className="bg-slate-50 dark:bg-slate-900/20 p-5 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-4">
                  <h4 className="text-sm font-black text-slate-700 dark:text-slate-300">إجراء حركة عهدة جديدة مسجلة على ذمة الشريك:</h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Custody Type */}
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-2">نوع الحركة المالية</label>
                          <div className="grid grid-cols-2 gap-2">
                              <button 
                                  type="button"
                                  onClick={() => setCustodyType('give')}
                                  className={`py-2.5 px-3 rounded-xl font-bold text-xs transition-all ${
                                      custodyType === 'give' 
                                          ? 'bg-indigo-600 text-white shadow-md' 
                                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                                  }`}
                              >
                                  تسليم عهدة للشريك (-)
                              </button>
                              <button 
                                  type="button"
                                  onClick={() => setCustodyType('receive')}
                                  className={`py-2.5 px-3 rounded-xl font-bold text-xs transition-all ${
                                      custodyType === 'receive' 
                                          ? 'bg-emerald-600 text-white shadow-md' 
                                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                                  }`}
                              >
                                  تسوية/استلام عهدة (+)
                              </button>
                          </div>
                      </div>

                      {/* Select Treasury */}
                      <div>
                          <label className="block text-xs font-bold text-slate-400 mb-2">الخزينة أو الحساب النقدي المرتبط</label>
                          <select 
                              value={custodyTreasuryId}
                              onChange={(e) => setCustodyTreasuryId(e.target.value)}
                              className="w-full bg-white dark:bg-slate-800 outline-none border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs font-bold dark:text-white"
                          >
                              <option value="">-- اختر حساباً مالياً --</option>
                              <option value="central_wallet" className="text-indigo-600 font-black">
                                 💳 المحفظة الماليّة المركزيّة (الرصيد الأساسي) — (الرصيد: {Math.max(0, walletBalance - effectiveHiddenAmount).toLocaleString()} ج.م)
                              </option>
                              {treasury?.accounts?.map((acc: any) => (
                                  <option key={acc.id} value={acc.id}>
                                      {acc.name} (المتاح: {acc.balance.toLocaleString()} ج.م)
                                  </option>
                              ))}
                          </select>
                      </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {/* Amount */}
                      <div className="sm:col-span-1">
                          <label className="block text-xs font-bold text-slate-400 mb-2 font-black">المبلغ المطلوب (ج.م)</label>
                          <input 
                              type="number"
                              placeholder="0.00"
                              value={custodyAmount}
                              onChange={(e) => setCustodyAmount(e.target.value)}
                              className="w-full bg-white dark:bg-slate-800 outline-none border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 text-xs font-black dark:text-white"
                          />
                      </div>

                      {/* Notes */}
                      <div className="sm:col-span-2">
                          <label className="block text-xs font-bold text-slate-400 mb-2">ملاحظات توضيحية للعملية</label>
                          <input 
                              type="text"
                              placeholder="مثال: عهدة نقدية لدفع مصاريف الشحن أو لشراء دفعة بضاعة جديدة"
                              value={custodyNotes}
                              onChange={(e) => setCustodyNotes(e.target.value)}
                              className="w-full bg-white dark:bg-slate-800 outline-none border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 text-xs font-bold dark:text-white"
                          />
                      </div>
                  </div>

                  <button 
                      type="button"
                      onClick={executeCustodyTx}
                      className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white dark:bg-indigo-600 dark:hover:bg-indigo-500 font-black text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
                  >
                      {custodyType === 'give' ? 'تسجيل صرف عهدة مالية للشريك' : 'تسجيل تحصيل واسترداد عهدة للخزينة'}
                  </button>
              </div>

              {/* Custody History */}
              <div className="bg-slate-50 dark:bg-slate-900/20 p-5 rounded-2xl border border-slate-200 dark:border-slate-800/80 space-y-4">
                  <h4 className="text-sm font-black text-slate-700 dark:text-slate-300">سجل حركات العهدة الخاصة بالشريك:</h4>
                  <div className="space-y-3 max-h-60 overflow-y-auto custom-scrollbar pr-2">
                    {(() => {
                        const holderId = `part_${partner?.id}`;
                        const partnerHolders = (settings.cashHolders || []).filter((h: any) => 
                            h.userId === holderId || 
                            h.userId === partner?.id || 
                            normalizeName(h.userName) === normalizeName(partner?.name || '')
                        );
                        const partnerUserIds = partnerHolders.map(h => h.userId);
                        if (partner && !partnerUserIds.includes(partner.id)) partnerUserIds.push(partner.id);
                        if (!partnerUserIds.includes(holderId)) partnerUserIds.push(holderId);

                        const handovers = (settings.cashHandovers || []).filter(h => 
                            partnerUserIds.includes(h.fromUserId) || partnerUserIds.includes(h.toUserId)
                        );
                        
                        if (handovers.length === 0) {
                            return <p className="text-xs text-slate-500 text-center py-4">لا توجد حركات مسجلة</p>;
                        }

                        return handovers.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(h => {
                            const isGive = partnerUserIds.includes(h.toUserId); // partner receives money
                            return (
                                <div key={h.id} className="flex justify-between items-center p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm group">
                                    <div className="flex flex-col gap-1">
                                        <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                                            {isGive ? 'تسليم عهدة للشريك' : 'تسوية عهدة من الشريك'}
                                        </p>
                                        <p className="text-[10px] text-slate-400">{new Date(h.date).toLocaleString('ar-EG')}</p>
                                        {h.notes && <p className="text-[10px] text-slate-500 mt-1">{h.notes}</p>}
                                    </div>
                                    <div className="flex flex-col items-end gap-2">
                                        <p className={`text-sm font-black ${isGive ? 'text-indigo-600 dark:text-indigo-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                                            {isGive ? '+' : '-'}{h.amount.toLocaleString()} ج.م
                                        </p>
                                        <button 
                                            onClick={() => deleteCustodyTx(h)}
                                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                                            title="حذف حركة العهدة"
                                        >
                                            <Trash2 size={14} />
                                        </button>
                                    </div>
                                </div>
                            );
                        });
                    })()}
                  </div>
              </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
          <div className="p-6 border-b border-slate-50 dark:border-slate-700/50 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-3">
                <div className="p-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl"><History size={18}/></div>
                سجل المعاملات
              </h2>
              <span className="text-xs font-black text-slate-400 bg-slate-100 dark:bg-slate-900/60 px-3 py-1 rounded-full">
                {mergedTransactions.length} حركة
              </span>
            </div>

            {/* Quick search and filter */}
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="بحث في سجل المعاملات..."
                  value={profileTxSearch}
                  onChange={(e) => setProfileTxSearch(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs font-bold text-slate-700 dark:text-white outline-none"
                />
                <Search size={14} className="absolute right-3 top-2.5 text-slate-400" />
              </div>
              <div className="flex gap-1 overflow-x-auto pb-1 sm:pb-0">
                <button
                  onClick={() => setProfileTxFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    profileTxFilter === 'all'
                      ? 'bg-slate-800 dark:bg-slate-700 text-white'
                      : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  الكل
                </button>
                <button
                  onClick={() => setProfileTxFilter('positive')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    profileTxFilter === 'positive'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  إيداعات ومستحقات (+)
                </button>
                <button
                  onClick={() => setProfileTxFilter('negative')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    profileTxFilter === 'negative'
                      ? 'bg-rose-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  سلف ومسحوبات (-)
                </button>
                <button
                  onClick={() => setProfileTxFilter('custody')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    profileTxFilter === 'custody'
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  عهد نقدية
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto max-h-[600px] p-6 space-y-8 custom-scrollbar">
            {Object.entries(
              mergedTransactions
                .filter(t => {
                  const isPositive = ['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage', 'internal_transfer_in', 'custody_receive'].includes(t.type);
                  const isCustody = t.type === 'custody_give' || t.type === 'custody_receive';
                  if (profileTxFilter === 'positive' && !isPositive) return false;
                  if (profileTxFilter === 'negative' && isPositive) return false;
                  if (profileTxFilter === 'custody' && !isCustody) return false;
                  if (profileTxSearch.trim()) {
                    const q = profileTxSearch.toLowerCase();
                    const note = (t.note || '').toLowerCase();
                    if (!note.includes(q)) return false;
                  }
                  return true;
                })
                .reduce((groups: Record<string, any[]>, t) => {
                  const date = new Date(t.date).toLocaleDateString('ar-EG', { month: 'long', year: 'numeric', day: 'numeric' });
                  if (!groups[date]) groups[date] = [];
                  groups[date].push(t);
                  return groups;
                }, {})
            ).map(([date, group], groupIdx) => (
              <div key={date} className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="h-px flex-1 bg-slate-100 dark:bg-slate-700/50"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 dark:bg-slate-900/50 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-800">
                    {date}
                  </span>
                  <div className="h-px flex-1 bg-slate-100 dark:bg-slate-700/50"></div>
                </div>

                <div className="space-y-3">
                  {(group as any[]).map((t, idx) => {
                    const isPositive = ['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage', 'internal_transfer_in', 'custody_receive'].includes(t.type);
                    const isCustody = t.type === 'custody_give' || t.type === 'custody_receive';
                    
                    return (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: (groupIdx * 0.1) + (idx * 0.05) }}
                        key={t.id} 
                        className="group relative flex flex-col p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:border-indigo-500/50 dark:hover:border-indigo-500/50 hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-300"
                      >
                        {/* Type Indicator Bar */}
                        <div className={`absolute right-0 top-4 bottom-4 w-1 rounded-l-full ${isPositive ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>

                        <div className="flex justify-between items-start gap-4 pr-3">
                          <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 duration-300 ${
                              isPositive 
                                ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600' 
                                : 'bg-rose-50 dark:bg-rose-500/10 text-rose-600'
                            }`}>
                              {t.type === 'loan' ? <ArrowDownRight size={20}/> : 
                               t.type === 'internal_transfer_in' ? <ArrowUpLeft size={20}/> : 
                               t.type === 'internal_transfer_out' ? <ArrowDownRight size={20}/> : 
                               t.type === 'customer_advance' ? <User size={20}/> : 
                               t.type === 'capital_addition' ? <PlusCircle size={20}/> : 
                               t.type === 'shipping_funding' ? <Truck size={20}/> : 
                               t.type === 'profit_withdrawal' ? <ArrowDownRight size={20}/> : 
                               t.type === 'profit_distribution' ? <TrendingUp size={20}/> : 
                               t.type === 'supply_funding' ? <PackageIcon size={20}/> : 
                               t.type === 'expense_coverage' ? <DollarSign size={20}/> :
                               t.type === 'expense_repayment' ? <RefreshCw size={20}/> :
                               t.type === 'repayment' ? <CheckCircle2 size={20}/> :
                               isCustody ? <Coins size={20}/> : <DollarSign size={20}/>}
                            </div>

                            <div className="flex flex-col">
                              <h3 className="font-black text-slate-900 dark:text-white text-sm leading-tight">
                                {t.type === 'loan' ? 'سلفة مالية / سحب نقدي' : 
                                 (t.note?.includes('عهدة') || t.note?.includes('عهده') || t.note?.includes('تسوية') || t.notes?.includes('عهدة')) ? 'تسوية عهدة مستقطعة' :
                                 t.type === 'internal_transfer_in' ? 'تحويل مالي وارد (داخلي)' :
                                 t.type === 'internal_transfer_out' ? 'تحويل مالي صادر (داخلي)' :
                                 t.type === 'customer_advance' ? 'عربون محصل من عميل' :
                                 t.type === 'capital_addition' ? 'زيادة رأس المال المضاف' : 
                                 t.type === 'shipping_funding' ? 'تغطية ميزانية الشحن' : 
                                 t.type === 'profit_withdrawal' ? 'سحب من مستحقات الأرباح' : 
                                 t.type === 'profit_distribution' ? 'توزيع أرباح دورية' : 
                                 t.type === 'supply_funding' ? 'تمويل شراء مخزون' : 
                                 t.type === 'expense_coverage' ? (t.note?.includes('توريد') ? 'تغطية مصاريف توريد' : 'تغطية مصروفات تشغيلية') :
                                 t.type === 'pos_collection' ? 'استلام إيراد نقطة بيع' :
                                 t.type === 'expense_repayment' ? 'استرداد عهدة مصروفات' :
                                 t.type === 'custody_give' ? 'تسليم عهدة تشغيلية للشريك' :
                                 t.type === 'custody_receive' ? 'تسوية واسترداد عهدة من الشريك' :
                                 t.type === 'repayment' ? 'سداد مديونية / سلفة' : 'معاملة مالية'}
                              </h3>
                              <div className="flex items-center gap-3 mt-1.5">
                                <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                                  <Clock size={10} />
                                  {new Date(t.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                                </span>
                                {t.treasuryAccountId && (
                                  <span className="text-[10px] font-black text-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 px-1.5 py-0.5 rounded-md">
                                    عبر الخزينة
                                  </span>
                                )}
                                {isCustody && (
                                  <span className="text-[10px] font-black text-amber-500 bg-amber-50 dark:bg-amber-500/10 px-1.5 py-0.5 rounded-md">
                                    حركة عهدة تشغيلية
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                            <div className="flex flex-col items-end shrink-0">
                            <div className={`text-lg font-black tabular-nums tracking-tighter ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {isPositive ? '+' : '-'}{t.amount.toLocaleString()} 
                              <span className="text-[10px] font-bold mr-1 opacity-70">ج.م</span>
                            </div>
                            {!isCustody && (
                              <div className="flex items-center gap-1 mt-2">
                                {t.type === 'loan' && (
                                  <button 
                                      onClick={() => handleConvertLoanToWithdrawal(t)}
                                      className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition-all opacity-0 group-hover:opacity-100 flex items-center gap-1 border border-transparent hover:border-indigo-100"
                                      title="تحويل لسحب من رأس المال"
                                  >
                                      <RefreshCw size={12} />
                                      <span className="text-[9px] font-black whitespace-nowrap">تحويل لسحب من رأس المال</span>
                                  </button>
                                )}
                                <button 
                                    onClick={() => deleteTransaction(t)}
                                    className="p-1.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                                    title="حذف المعاملة"
                                >
                                    <Trash2 size={14} />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>

                        {t.note && (
                          <div className="mt-3 mr-16 ml-2 p-3 bg-slate-50 dark:bg-slate-950/50 rounded-xl border border-slate-200 dark:border-slate-800/50 text-[11px] font-medium text-slate-600 dark:text-slate-400 leading-relaxed italic">
                            <span className="text-slate-400 not-italic block mb-1 font-black uppercase text-[9px]">ملاحظات:</span>
                            {t.note}
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            ))}

            {mergedTransactions.length === 0 && (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-24 h-24 bg-slate-50 dark:bg-slate-900 rounded-full flex items-center justify-center mb-6">
                  <History size={40} className="text-slate-200 dark:text-slate-700" />
                </div>
                <h3 className="text-slate-400 font-black text-sm">لا توجد حركات مالية مسجلة</h3>
                <p className="text-slate-300 dark:text-slate-600 text-xs mt-1 max-w-[200px]">سيتم عرض سجل الإيداعات والسحوبات هنا فور إضافتها</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Partner Statement & Print Preview Modal */}
      {showPrintModal && partner && (
        <PartnerStatementModal
          partner={partner}
          settings={settings}
          wallet={wallet}
          orders={orders}
          treasury={treasury}
          onClose={() => setShowPrintModal(false)}
        />
      )}

      {/* Dedicated Partner PIN Management Modal */}
      <AnimatePresence>
        {isPinModalOpen && partner && (
          <div className="fixed inset-0 z-[120] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 text-right"
              dir="rtl"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-2xl flex items-center justify-center">
                    <Lock size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-800 dark:text-white">تعيين رمز PIN للبوابة</h3>
                    <p className="text-xs font-bold text-slate-400">{partner.name}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPinModalOpen(false)}
                  className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-xs font-black text-slate-600 dark:text-slate-300">
                    رمز المرور السري (PIN) للشريك
                  </label>
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input
                        type="text"
                        maxLength={6}
                        value={partnerPinInput}
                        onChange={(e) => setPartnerPinInput(e.target.value.replace(/\D/g, ''))}
                        placeholder="أدخل 4-6 أرقام..."
                        className="w-full pr-12 pl-4 py-3.5 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500/30 rounded-2xl outline-none font-black text-center text-xl tracking-widest text-slate-800 dark:text-white"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setPartnerPinInput(Math.floor(1000 + Math.random() * 9000).toString())}
                      className="px-3.5 py-3.5 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 rounded-2xl text-xs font-black transition-colors flex items-center gap-1 cursor-pointer border border-amber-300/40"
                      title="توليد رمز PIN عشوائي جديد"
                    >
                      <Sparkles size={14} className="text-amber-500" />
                      <span>توليد تلقائي</span>
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400 font-bold">
                    * هذا الرمز يُطلب من الشريك عند الدخول إلى رابط بوابته المالية المخصصة لحماية خصوصية الحساب.
                  </p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-3">
                  <span className="text-xs font-black text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                    <Share2 size={14} className="text-indigo-600" /> خيارات مشاركة الرابط المباشر:
                  </span>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={copyPortalLink}
                      className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Copy size={13} />
                      <span>نسخ الرابط</span>
                    </button>

                    <button
                      onClick={shareWhatsApp}
                      className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <span>📲 واتساب</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={handleSavePartnerPin}
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-3.5 rounded-2xl font-black text-xs transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check size={16} /> حفظ وتحديث رمز PIN
                </button>
                <button
                  onClick={() => setIsPinModalOpen(false)}
                  className="px-5 py-3.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PartnerProfilePage;
