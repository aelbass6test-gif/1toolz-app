import React, { useState, useMemo, useEffect, useCallback } from 'react';
import * as db from '../services/databaseService';

const normalizeName = (name: string): string => {
  if (!name) return '';
  let normalized = name.trim().replace(/\s+/g, ' ');
  normalized = normalized.replace(/\s*\((شريك|موظف|المدير|شريكه|partner|employee|admin|أنت|انت)\)/gi, '');
  normalized = normalized.replace(/\s+(شريك|موظف|المدير|شريكه|partner|employee|admin)$/gi, '');
  normalized = normalized
    .replace(/أ/g, 'ا')
    .replace(/إ/g, 'ا')
    .replace(/آ/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .toLowerCase()
    .trim();
  if (/^(زهره)/.test(normalized)) {
      return 'زهره';
  }
  return normalized;
};
import { Link, useParams } from 'react-router-dom';
import { Settings, Partner, PartnerTransaction, Wallet, Transaction, Order, Treasury } from '../types';
import { Plus, User, DollarSign, ArrowDownRight, ArrowUpLeft, Trash2, Edit2, Check, X, TrendingUp, Wallet as WalletIcon, PieChart, History, Activity, Info, AlertCircle, Package as PackageIcon, Truck, Coins, Calculator, Sparkles, ArrowRightLeft, Percent, Layers, Shield, ShieldCheck, Printer, BookOpen, HelpCircle, ChevronDown, ChevronUp, CheckCircle2, FileText, Search, Filter, Monitor, Users2, Eye, Lock, LogOut, Share2, Copy, Bell, Send, MessageSquare, Mail, Phone } from 'lucide-react';
import { calculateOrderProfitLoss, getOrderProductCost, calculateWalletLiveBalance, getVirtualOrderHandovers } from '../utils/financials';
import { PartnerStatementModal } from './PartnerStatementModal';
import { PartnerExitModal } from './PartnerExitModal';
import { PartnerPermissionsModal } from './PartnerPermissionsModal';
import { generateSafeId } from '../utils/idUtils';
import { PeriodClosingModal } from './PeriodClosingModal';
import { motion, AnimatePresence } from 'motion/react';
import { PieChart as RePieChart, Pie, Cell, ResponsiveContainer, Tooltip as ReTooltip, BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';

interface PartnersPageProps {
  settings: Settings;
  updateSettings: (newSettings: Settings) => void;
  wallet: Wallet;
  setWallet: React.Dispatch<React.SetStateAction<Wallet>>;
  orders: Order[];
  treasury?: Treasury;
  setTreasury?: (updater: any) => void;
}

const PartnersPage: React.FC<PartnersPageProps> = ({ settings, updateSettings, wallet, setWallet, orders, treasury, setTreasury }) => {
  const { storeId } = useParams<{ storeId: string }>();
  const allHandovers = useMemo(() => {
    const base = settings.cashHandovers || [];
    const virtuals = getVirtualOrderHandovers(orders, settings, treasury);
    return [...base, ...virtuals];
  }, [settings.cashHandovers, orders, settings, treasury]);

  const walletBalance = useMemo(() => calculateWalletLiveBalance(wallet), [wallet]);
  const effectiveHiddenAmount = settings.enableHiddenWalletAmount ? (settings.hiddenWalletAmount || 0) : 0;
  const [partnerName, setPartnerName] = useState('');
  const [partnerEmail, setPartnerEmail] = useState('');
  const [partnerPhone, setPartnerPhone] = useState('');
  const [partnerProfitRatio, setPartnerProfitRatio] = useState('');
  const [partnerPasscode, setPartnerPasscode] = useState('');
  const [activePartnerId, setActivePartnerId] = useState<string | null>(null);
  const [selectedPermissionsPartner, setSelectedPermissionsPartner] = useState<Partner | null>(null);
  const [editPartnerId, setEditPartnerId] = useState<string | null>(null);
  const [editPartnerName, setEditPartnerName] = useState('');
  const [editPartnerPasscode, setEditPartnerPasscode] = useState('');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transactionType, setTransactionType] = useState<PartnerTransaction['type']>('loan');
  const [selectedTreasuryId, setSelectedTreasuryId] = useState('');
  const [isProfitPaymentOpen, setIsProfitPaymentOpen] = useState(false);
  const [profitPaymentTreasuryId, setProfitPaymentTreasuryId] = useState('');

  // Advanced Modern Systems States
  const [activeSection, setActiveSection] = useState<'overview' | 'valuation' | 'simulator' | 'analytics' | 'transfers' | 'summary_table' | 'requests'>('overview');
  const [requestsFilterStatus, setRequestsFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [cloudRequests, setCloudRequests] = useState<db.PartnerPortalRequest[]>([]);

  const loadCloudRequests = useCallback(async () => {
    if (!storeId) return;
    try {
      const reqs = await db.getPartnerRequests(storeId);
      setCloudRequests(reqs);
    } catch (_) {}
  }, [storeId]);

  useEffect(() => {
    loadCloudRequests();
    // Poll every 10 seconds to catch incoming requests from partners
    const interval = setInterval(loadCloudRequests, 10000);
    return () => clearInterval(interval);
  }, [loadCloudRequests]);

  const partnerRequests = useMemo(() => {
    const fromSettings = (settings as any).partnerRequests || [];
    const map = new Map<string, any>();
    cloudRequests.forEach(r => map.set(r.id, r));
    fromSettings.forEach((r: any) => {
      if (!map.has(r.id)) map.set(r.id, r);
    });
    const list = Array.from(map.values()).filter((r: any) => {
      // Exclude requests belonging to Merchants / Goods Owners
      const isMerchant = r.id?.startsWith('REQ-M-') || 
                         r.isMerchantRequest === true || 
                         (r.typeArabic && r.typeArabic.includes('الموكل')) ||
                         (r.partnerId && (r.partnerId.startsWith('m_') || r.partnerId.startsWith('sup_')));
      return !isMerchant;
    });
    list.sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
    return list;
  }, [cloudRequests, settings]);

  const pendingRequestsCount = useMemo(() => partnerRequests.filter((r: any) => r.status === 'pending').length, [partnerRequests]);

  const handleApprovePartnerRequest = async (req: any) => {
    if (!storeId || req.status !== 'pending') return;
    const statusUpdated = await db.updatePartnerRequestStatus(req.id, storeId, 'approved');
    if (!statusUpdated) return;
    setCloudRequests(prev => prev.map(r => r.id === req.id ? { ...r, status: 'approved' } : r));

    const updatedRequests = partnerRequests.map((r: any) => r.id === req.id ? { ...r, status: 'approved' } : r);
    let updatedTxs = settings.partnerTransactions || [];

    const amt = Number(req.amount || 0);

    if (req.type === 'withdrawal' && amt > 0) {
      const newTx: PartnerTransaction = {
        id: `tx_${Date.now()}`,
        partnerId: req.partnerId,
        partnerName: req.partnerName,
        type: 'loan',
        amount: amt,
        date: new Date().toISOString(),
        notes: `اعتماد طلب سحب أرباح من البوابة: ${req.notes || ''}`
      };
      updatedTxs = [newTx, ...updatedTxs];
    } else if (req.type === 'expense' && amt > 0) {
      const newTx: PartnerTransaction = {
        id: `tx_${Date.now()}`,
        partnerId: req.partnerId,
        partnerName: req.partnerName,
        type: 'direct_expense',
        amount: amt,
        date: new Date().toISOString(),
        notes: `اعتماد تسجيل مصروف مدفوع من الشريك من البوابة: ${req.notes || ''}`
      };
      updatedTxs = [newTx, ...updatedTxs];
    }

    // Deduct or credit the partner's balance
    const updatedPartners = (settings.partners || []).map(p => {
      const isMatch = p.id === req.partnerId || 
                      (req.partnerId && p.id === req.partnerId.replace('part_', '')) ||
                      normalizeName(p.name) === normalizeName(req.partnerName);
      if (isMatch) {
        let newBalance = Number(p.balance || 0);
        if (req.type === 'withdrawal') {
          newBalance -= amt;
        } else if (req.type === 'expense') {
          newBalance += amt;
        }
        return { ...p, balance: newBalance };
      }
      return p;
    });

    const updatedSettings = {
      ...settings,
      partners: updatedPartners,
      partnerRequests: updatedRequests,
      partnerTransactions: updatedTxs,
      activityLogs: [
        {
          id: `log_${Date.now()}`,
          user: 'الإدارة',
          action: 'اعتماد طلب شريك',
          details: `تم اعتماد ${req.typeArabic || 'الطلب'} للشريك ${req.partnerName} بمبلغ ${amt.toLocaleString()} ج.م وخصمه من حسابه الجاري`,
          date: new Date().toISOString(),
          timestamp: Date.now()
        },
        ...(settings.activityLogs || [])
      ]
    };
    updateSettings(updatedSettings);

    if (storeId) {
      try {
        const curStore = await db.getStoreData(storeId);
        if (curStore) {
          await db.saveStoreData({ id: storeId, name: settings.storeName || 'المتجر' } as any, {
            ...curStore,
            settings: updatedSettings
          });
        }
      } catch (e) {
        console.warn('Error saving approved partner data to cloud:', e);
      }
    }
  };

  const handleRejectPartnerRequest = async (reqId: string) => {
    if (!storeId || !(await db.updatePartnerRequestStatus(reqId, storeId, 'rejected'))) return;
    setCloudRequests(prev => prev.map(r => r.id === reqId ? { ...r, status: 'rejected' } : r));
    const updatedRequests = partnerRequests.map((r: any) => r.id === reqId ? { ...r, status: 'rejected' } : r);
    updateSettings({
      ...settings,
      partnerRequests: updatedRequests
    });
  };

  const handleDeletePartnerRequest = async (reqId: string) => {
    if (storeId) {
      await db.deletePartnerRequestDoc(reqId, storeId);
      setCloudRequests(prev => prev.filter(r => r.id !== reqId));
    }
    const updatedRequests = partnerRequests.filter((r: any) => r.id !== reqId);
    updateSettings({
      ...settings,
      partnerRequests: updatedRequests
    });
  };
  const [showHelpGuide, setShowHelpGuide] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'positive' | 'loan' | 'custody'>('all');
  const [showVisualAnalytics, setShowVisualAnalytics] = useState(true);
  const [txCategoryTab, setTxCategoryTab] = useState<'personal' | 'capital' | 'operations'>('personal');
  const [simProfitAmount, setSimProfitAmount] = useState('');
  const [reserveRatio, setReserveRatio] = useState<number>(10); // default 10% emergency reserve retention
  
  const [fromPartnerId, setFromPartnerId] = useState('');
  const [toPartnerId, setToPartnerId] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferType, setTransferType] = useState<'capital' | 'balance'>('balance');
  const [transferNotes, setTransferNotes] = useState('');
  const [previewPartner, setPreviewPartner] = useState<Partner | null>(null);
  const [isClosingModalOpen, setIsClosingModalOpen] = useState(false);
  const [isExitModalOpen, setIsExitModalOpen] = useState(false);
  const [exitModalPartnerId, setExitModalPartnerId] = useState<string | null>(null);

  // Dedicated Security & PIN Management Modal State
  const [pinModalPartner, setPinModalPartner] = useState<Partner | null>(null);
  const [pinModalCode, setPinModalCode] = useState('');
  const [pinModalEmail, setPinModalEmail] = useState('');
  const [pinModalRequireOtp, setPinModalRequireOtp] = useState<boolean>(true);

  const openPinModal = (partner: Partner) => {
    setPinModalPartner(partner);
    setPinModalCode(partner.passcode || '0000');
    setPinModalEmail(partner.email || '');
    setPinModalRequireOtp(partner.requireEmailOtp ?? true);
  };

  const handleSavePin = () => {
    if (!pinModalPartner) return;
    const cleanCode = pinModalCode.trim().replace(/\D/g, '') || '0000';
    const cleanEmail = pinModalEmail.trim().toLowerCase();
    const updatedPartners = partners.map(p => 
      p.id === pinModalPartner.id ? { 
        ...p, 
        passcode: cleanCode,
        email: cleanEmail || p.email,
        requireEmailOtp: pinModalRequireOtp
      } : p
    );
    const newSettings = {
      ...settings,
      partners: updatedPartners
    };
    updateSettings(newSettings);
    if (storeId) {
      db.getStoreData(storeId).then(cur => {
        if (cur) {
          db.saveStoreData({ id: storeId, name: settings.storeName || 'المتجر' } as any, {
            ...cur,
            settings: newSettings
          });
        }
      }).catch(err => console.warn('Cloud save error:', err));
    }
    showToast(`تم تحديث إعدادات أمان ودخول الشريك (${pinModalPartner.name}) بنجاح`);
    setPinModalPartner(null);
  };

  const generateRandomPin = () => {
    const randomPin = Math.floor(1000 + Math.random() * 9000).toString();
    setPinModalCode(randomPin);
  };

  const copyPartnerPortalLink = (partner: Partner) => {
    const link = `${window.location.origin}/store/${storeId}/partner-portal?p=${partner.id}`;
    navigator.clipboard.writeText(link);
    showToast(`تم نسخ رابط الدخول المباشر للشريك (${partner.name}) بنجاح!`);
  };

  const sharePartnerWhatsApp = (partner: Partner) => {
    const link = `${window.location.origin}/store/${storeId}/partner-portal?p=${partner.id}`;
    const code = partner.passcode || '0000';
    const storeTitle = settings.storeName || 'عبده ميديا';
    const text = `مرحباً بك يا ${partner.name} 🌟\nإليك رابط بوابتك المالية المباشرة لمتابعة حساباتك وتفاصيل أرباحك في متجر ${storeTitle}:\n🔗 ${link}\n🔑 رمز المرور السري (PIN): ${code}\n\nتحياتنا، إدارة المتجر.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleExecuteLiquidationTransaction = (partnerId: string, amount: number, method: string, note: string) => {
    const partner = (settings.partners || []).find(p => p.id === partnerId);
    if (!partner) return;

    const newTx: PartnerTransaction = {
      id: generateSafeId('tx_exit'),
      partnerId: partner.id,
      partnerName: partner.name,
      type: 'profit_withdrawal',
      amount: amount,
      date: new Date().toISOString(),
      note: note || `تصفية وتخارج نهائي للشريك (${partner.name})`
    };

    const updatedTxs = [newTx, ...(settings.partnerTransactions || [])];

    const updatedPartners = (settings.partners || []).map(p => {
      if (p.id === partnerId) {
        return {
          ...p,
          balance: Math.max(0, p.balance - amount),
          notes: `${p.notes || ''} [تم تخارج وتصفية الشريك بتاريخ ${new Date().toLocaleDateString('ar-EG')}]`
        };
      }
      return p;
    });

    if (amount > 0 && method !== 'inventory') {
      setWallet(prev => ({
        ...prev,
        balance: Math.max(0, (prev.balance || 0) - amount),
        transactions: [
          {
            id: generateSafeId('wtx_exit'),
            type: 'سحب',
            amount: amount,
            note: `سحب تصفية وتخارج الشريك: ${partner.name}`,
            date: new Date().toISOString(),
            category: 'تصفية_شراكة' as any,
            status: 'completed'
          },
          ...(prev.transactions || [])
        ]
      }));
    }

    updateSettings({
      ...settings,
      partnerTransactions: updatedTxs,
      partners: updatedPartners
    });

    setIsExitModalOpen(false);
    setExitModalPartnerId(null);
    showToast(`تم تسجيل تصفية وتخارج الشريك (${partner.name}) بنجاح!`, 'success');
  };
  
  // Custom dialog states
  const [dialog, setDialog] = useState<{
      isOpen: boolean;
      title: string;
      message: string;
      onConfirm: () => void;
  } | null>(null);

  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
      setToast({message, type});
      setTimeout(() => setToast(null), 3000);
  };

  const partners = useMemo(() => settings?.partners || [], [settings?.partners]);
  const transactions = useMemo(() => settings?.partnerTransactions || [], [settings?.partnerTransactions]);
  
  // Calculate Profit
  const { 
      totalSuccessfulNetPos,
      totalSuccessfulNetShipping,
      totalExpenses, 
      returnsLosses, 
      adminExpenses,
      allTimeNetProfit,
      undistributedProfit,
      otherIncome,
      availableLiquidity,
      hidden,
      totalCogs,
      totalDeposits,
      shippingDeposits,
      totalStockPurchases,
      inventoryValue
  } = useMemo(() => {
    if (!settings) return { 
        totalSuccessfulNetPos: 0, totalSuccessfulNetShipping: 0, totalExpenses: 0, returnsLosses: 0, adminExpenses: 0, 
        allTimeNetProfit: 0, undistributedProfit: 0, otherIncome: 0, availableLiquidity: 0,
        totalCogs: 0, totalDeposits: 0, shippingDeposits: 0, totalStockPurchases: 0, inventoryValue: 0
    };
    let totalSuccessfulNetPos = 0;
    let totalSuccessfulNetShipping = 0;
    let totalCogs = 0;
    let returnsLosses = 0;

    const inventoryValue = (settings.products || []).reduce((sum, p) => {
        const stock = Number(p.stockQuantity) || 0;
        const cost = Number(p.costPrice) || 0;
        return sum + (stock * cost);
    }, 0);

    orders.forEach(order => {
        const { net, loss } = calculateOrderProfitLoss(order, settings);
        const isPos = order.channel === 'pos' || 
                      order.shippingCompany === 'كاشير - بيع مباشر' || 
                      order.shippingArea === 'نقطة البيع' ||
                      (order.id && order.id.startsWith('POS-'));
        
        const isReturnOrFailed = ['مرتجع', 'فشل_التوصيل', 'تمت_الاعادة_لشركة_الشحن', 'مرتجع_جزئي', 'مرتجع_بعد_الاستلام', 'ملغي'].includes(order.status);
        const isExchange = order.status === 'تم_الاستبدال';
        const hasLoss = loss > 0 || net < 0;

        if (isReturnOrFailed || isExchange || hasLoss) {
            const actualLoss = loss > 0 ? loss : (net < 0 ? Math.abs(net) : 0);
            returnsLosses += actualLoss;
        } else if (order.status === 'تم_التحصيل' || order.status === 'مدفوعة' || order.status === 'تم_توصيلها' || order.status === 'تم_التوصيل') {
            if (isPos) {
                totalSuccessfulNetPos += net;
            } else {
                totalSuccessfulNetShipping += net;
            }
            // Calculate COGS for successful orders
            totalCogs += getOrderProductCost(order, settings);
        }
    });
    
    const isCustodyTx = (t: any) => {
      const note = t.note || t.description || '';
      const id = t.id || '';
      const category = t.category || '';
      return (
        note.includes('عهدة') ||
        note.includes('استرداد') ||
        note.includes('تسوية') ||
        note.includes('توريد') ||
        note.includes('تسليم') ||
        id.includes('CUST') ||
        id.includes('custody') ||
        id.includes('HND') ||
        category === 'pos_collection' ||
        category === 'custody_give' ||
        category === 'custody_receive'
      );
    };

    const adminExpenses = wallet.transactions
      .filter(t => {
        if (isCustodyTx(t)) return false;
        const isExpenseCategory = t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings.expenseCategories || []).includes(t.category || '');
        const isManualWithdrawal = t.category === 'manual_withdrawal';
        const isNotPartnerTx = !t.note?.includes('معاملة شريك');
        
        return t.type === 'سحب' && (isExpenseCategory || isManualWithdrawal) && isNotPartnerTx;
      })
      .reduce((sum, t) => sum + t.amount, 0);

    const otherIncome = wallet.transactions
      .filter(t => {
        if (isCustodyTx(t)) return false;
        const isNotPartnerTx = !t.note?.includes('معاملة شريك');
        const isNotPosTx = !t.note?.includes('مبيعات كاشير');
        return t.type === 'إيداع' && t.category === 'manual_deposit' && isNotPartnerTx && isNotPosTx;
      })
      .reduce((sum, t) => sum + t.amount, 0);
      
    const totalExpenses = returnsLosses + adminExpenses;
    const allTimeNetProfit = totalSuccessfulNetPos + totalSuccessfulNetShipping + otherIncome - totalExpenses;
    
    const distributed = transactions
      .filter(t => t.type === 'profit_distribution')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalDeposits = transactions
      .filter(t => ['capital_addition', 'shipping_funding', 'supply_funding', 'expense_coverage'].includes(t.type))
      .reduce((sum, t) => sum + t.amount, 0);

    const shippingDeposits = transactions
      .filter(t => t.type === 'shipping_funding')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalStockPurchasesWallet = wallet.transactions
      .filter(t => t.type === 'سحب' && (t.note?.includes('شراء بضاعة') || t.category === 'supply_purchase' || t.category === 'supply_deposit'))
      .reduce((sum, t) => sum + t.amount, 0);

    const totalStockPurchasesTreasury = (treasury?.transactions || [])
      .filter(t => t.type === 'withdrawal' && (t.description?.includes('شراء بضاعة') || t.category === 'supply_purchase'))
      .reduce((sum, t) => sum + t.amount, 0);

    const totalStockPurchases = totalStockPurchasesWallet + totalStockPurchasesTreasury;

    const undistributedProfit = Math.max(0, allTimeNetProfit - distributed);
    
    // Calculate Liquidity
    const treasuryTotal = (treasury?.accounts || []).reduce((sum: number, acc: any) => sum + (Number(acc.balance) || 0), 0);
    const walletBalance = Math.round(calculateWalletLiveBalance(wallet, treasury) * 100) / 100;
    
    const autoClosingDiff = settings.enableAutoClosingDifference 
        ? Math.abs(orders
            .filter(o => ['تم_توصيلها', 'تم_التوصيل', 'تم_التحصيل', 'مدفوعة', 'مرتجع_جزئي'].includes(o.status))
            .reduce((sum, o) => sum + (calculateOrderProfitLoss(o, settings).closingDifference || 0), 0))
        : (settings.hiddenWalletAmount || 0);
    const hidden = settings.enableHiddenWalletAmount ? autoClosingDiff : 0;

    const availableLiquidity = Math.max(0, (treasuryTotal + walletBalance) - hidden);
    
    return { 
        totalSuccessfulNetPos,
        totalSuccessfulNetShipping,
        totalExpenses, 
        returnsLosses, 
        adminExpenses,
        allTimeNetProfit,
        undistributedProfit,
        otherIncome,
        availableLiquidity,
        hidden,
        totalCogs,
        totalDeposits,
        shippingDeposits,
        totalStockPurchases,
        inventoryValue
    };
  }, [orders, wallet.transactions, wallet.balance, settings, transactions, treasury]);

  const addPartner = () => {
    if (!partnerName) return;
    const newPartner: Partner = {
      id: generateSafeId('part'),
      name: partnerName.trim(),
      email: partnerEmail.trim().toLowerCase() || undefined,
      phone: partnerPhone.trim() || undefined,
      balance: 0,
      profitRatio: parseFloat(partnerProfitRatio) || 0,
      passcode: partnerPasscode || Math.floor(1000 + Math.random() * 9000).toString(),
      permissions: ['ORDERS_VIEW', 'PRODUCTS_VIEW']
    };
    updateSettings({
      ...settings,
      partners: [...partners, newPartner]
    });
    setPartnerName('');
    setPartnerEmail('');
    setPartnerPhone('');
    setPartnerProfitRatio('');
    setPartnerPasscode('');
    showToast('تم إضافة الشريك وتعيين بياناته بنجاح');
  };

  const totals = useMemo(() => {
     let totalCustody = 0;
     partners.forEach(partner => {
         const holderId = `part_${partner.id}`;
         const partnerHolders = (settings.cashHolders || []).filter((h: any) => 
             h.userId === holderId || 
             h.userId === partner.id || 
             normalizeName(h.userName) === normalizeName(partner.name)
         );
         const partnerUserIds = [holderId, partner.id, ...partnerHolders.map(h => h.userId)];

         const partnerHandovers = allHandovers.filter(h => 
             partnerUserIds.includes(h.fromUserId) || 
             partnerUserIds.includes(h.toUserId) || 
             h.toUserId === partner.id || 
             h.toUserId === holderId || 
             h.fromUserId === partner.id || 
             h.fromUserId === holderId || 
             normalizeName(h.toUserName || '').includes(normalizeName(partner.name)) || 
             normalizeName(h.fromUserName || '').includes(normalizeName(partner.name))
         );

         const settlements = partnerHandovers.filter(h => 
             h.toUserId === 'admin_deduction' || 
             h.toUserId === 'admin_manual' ||
             (h.toUserName && (h.toUserName.includes('خصم') || h.toUserName.includes('تصفية') || h.toUserName.includes('تسوية'))) ||
             (h.notes && (h.notes.includes('خصم') || h.notes.includes('تصفية') || h.notes.includes('تسوية')))
         );
         const hasSettlement = settlements.length > 0;
         let holderSum = partnerHolders.reduce((sum, h) => sum + (h.currentBalance || 0), 0);

         let custodyAmt = 0;
         if (hasSettlement) {
             const lastSettlement = settlements.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
             const activeHandovers = partnerHandovers.filter(h => new Date(h.date).getTime() > new Date(lastSettlement.date).getTime());
             const activeHandoverSum = activeHandovers.reduce((sum, h) => {
                 const isGive = partnerUserIds.includes(h.toUserId) || h.toUserId === partner.id || h.toUserId === holderId || normalizeName(h.toUserName || '').includes(normalizeName(partner.name));
                 return isGive ? sum + (Number(h.amount) || 0) : sum - (Number(h.amount) || 0);
             }, 0);
             custodyAmt = Math.max(0, holderSum) + Math.max(0, activeHandoverSum);
         } else {
             let handoverSum = partnerHandovers.reduce((sum, h) => {
                 const isGive = partnerUserIds.includes(h.toUserId) || h.toUserId === partner.id || h.toUserId === holderId || normalizeName(h.toUserName || '').includes(normalizeName(partner.name));
                 return isGive ? sum + (Number(h.amount) || 0) : sum - (Number(h.amount) || 0);
             }, 0);
             custodyAmt = Math.max(holderSum, Math.max(0, handoverSum));
             if (custodyAmt <= 0 && holderSum > 0) custodyAmt = holderSum;
         }
         custodyAmt = Math.max(0, custodyAmt);
         
         totalCustody += custodyAmt;
     });

     const partnerOrderAdvancesTotal = orders.filter(o => {
         const safeAdvance = Number(o.advancePayment) || 0;
         if (safeAdvance <= 0) return false;
         if (o.advancePaymentTreasuryId || (o.cashHolderId && o.cashHolderId.startsWith('treas_'))) return false;
         // Check if employee ID or cashHolderId actually belongs to a partner
          const empId = o.advancePaymentEmployeeId || (o.cashHolderId && o.cashHolderId.startsWith('emp_') ? o.cashHolderId.substring(4) : null);
          if (empId) {
              const isPt = partners.some(pt => String(pt.id) === String(empId));
              if (!isPt) return false;
          }
          if (empId && partners.some(pt => String(pt.id) === String(empId))) return true;
         return true;
     }).reduce((sum, o) => sum + (Number(o.advancePayment) || 0), 0);

     const txAdvancesTotal = transactions.filter(t => t.type === 'customer_advance').reduce((a, b) => a + b.amount, 0);

     return {
        capital: transactions.filter(t => t.type === 'capital_addition' || t.type === 'supply_funding' || t.type === 'shipping_funding' || t.type === 'expense_coverage' || t.type === 'internal_transfer_in').reduce((a, b) => a + b.amount, 0),
        loans: transactions.filter(t => t.type === 'loan').reduce((a, b) => a + b.amount, 0),
        advances: txAdvancesTotal + partnerOrderAdvancesTotal,
        repayments: transactions.filter(t => t.type === 'repayment').reduce((a, b) => a + b.amount, 0),
        withdrawals: transactions.filter(t => t.type === 'profit_withdrawal').reduce((a, b) => a + b.amount, 0),
        custody: totalCustody
     };
  }, [transactions, settings.cashHolders, allHandovers, partners, orders]);

  const CHART_COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#3b82f6'];

  const filteredPartners = useMemo(() => {
    return partners.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      if (!matchesSearch) return false;
      
      if (filterStatus === 'positive') return p.balance > 0;
      if (filterStatus === 'loan') return p.balance < 0;
      if (filterStatus === 'custody') {
        const holderId = `part_${p.id}`;
        const partnerHolders = (settings.cashHolders || []).filter((h: any) => 
            h.userId === holderId || 
            h.userId === p.id || 
            normalizeName(h.userName) === normalizeName(p.name)
        );
        const holderSum = partnerHolders.reduce((sum, h) => sum + (h.currentBalance || 0), 0);
        return holderSum > 0;
      }
      return true;
    });
  }, [partners, searchQuery, filterStatus, settings.cashHolders]);

  const pieChartData = useMemo(() => {
    return partners.map(p => ({
      name: p.name,
      value: p.profitRatio || 0,
      balance: p.balance
    })).filter(item => item.value > 0);
  }, [partners]);

  const barChartData = useMemo(() => {
    return partners.map(p => {
      const pTxs = transactions.filter(t => t.partnerId === p.id);
      const capital = pTxs.filter(t => ['capital_addition', 'supply_funding', 'shipping_funding', 'expense_coverage', 'internal_transfer_in'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
      const dividends = pTxs.filter(t => t.type === 'profit_distribution').reduce((sum, t) => sum + (t.amount || 0), 0);
      const loans = pTxs.filter(t => t.type === 'loan').reduce((sum, t) => sum + (t.amount || 0), 0);
      const withdrawals = pTxs.filter(t => t.type === 'profit_withdrawal').reduce((sum, t) => sum + (t.amount || 0), 0);
      
      return {
        name: p.name,
        'رأس المال': capital,
        'الأرباح الموزعة': dividends,
        'المسحوبات والسلف': loans + withdrawals,
        'الرصيد الصافي': p.balance
      };
    });
  }, [partners, transactions]);

  const distributeProfit = () => {
    if (undistributedProfit <= 0) {
        showToast('لا يوجد أرباح جديدة متاحة للتوزيع حالياً', 'error');
        return;
    }
    const totalRatios = partners.reduce((sum, p) => sum + (p.profitRatio || 0), 0);
    if (Math.abs(totalRatios - 100) > 0.01) {
        showToast(`خطأ: لتوزيع الأرباح يجب أن يكون مجموع النسب 100% تماماً. (الحالي: ${totalRatios}%) - إذا كان هناك نسبة مستقطعة للشركة، قم بإضافتها كشريك باسم "أرباح محتجزة" أو "الشركة".`, 'error');
        return;
    }

    setDialog({
        isOpen: true,
        title: 'تأكيد توزيع الأرباح',
        message: `سيتم توزيع ${undistributedProfit.toLocaleString()} ج.م (الأرباح الجديدة) على الشركاء بناءً على نسبهم. هل تريد المتابعة؟`,
        onConfirm: () => {
            const newTransactions: PartnerTransaction[] = [];
            const updatedPartners = partners.map(partner => {
                const share = (undistributedProfit * (partner.profitRatio || 0)) / 100;
                if (share <= 0) return partner;
        
                const newTransaction: PartnerTransaction = {
                    id: generateSafeId('pt_profit') + '_' + partner.id,
                    partnerId: partner.id,
                    type: 'profit_distribution', 
                    amount: share,
                    date: new Date().toISOString(),
                    note: `توزيع أرباح تلقائي عن الفترة الحالية ${new Date().toLocaleDateString('ar-EG')}`
                };
                newTransactions.push(newTransaction);
                
                return {
                    ...partner,
                    balance: partner.balance + share
                };
            });
        
            updateSettings({
                ...settings,
                partners: updatedPartners,
                partnerTransactions: [...transactions, ...newTransactions]
            });
            setDialog(null);
            showToast('تم توزيع الأرباح بنجاح');
        }
    });
  };

  const payableProfitTotal = useMemo(() => partners.reduce((sum, partner) => {
    const distributed = transactions.filter(t => t.partnerId === partner.id && t.type === 'profit_distribution').reduce((value, t) => value + (Number(t.amount) || 0), 0);
    const paid = transactions.filter(t => t.partnerId === partner.id && t.type === 'profit_withdrawal').reduce((value, t) => value + (Number(t.amount) || 0), 0);
    return sum + Math.max(0, distributed - paid);
  }, 0), [partners, transactions]);

  const payDistributedProfits = () => {
    if (!profitPaymentTreasuryId) {
      showToast('يرجى اختيار الخزينة التي سيتم الدفع منها', 'error');
      return;
    }
    if (payableProfitTotal <= 0) {
      showToast('لا توجد أرباح موزعة ومستحقة للدفع حالياً', 'error');
      return;
    }
    const selectedBalance = profitPaymentTreasuryId === 'central_wallet'
      ? calculateWalletLiveBalance(wallet, treasury)
      : Number(treasury?.accounts?.find(account => account.id === profitPaymentTreasuryId)?.balance || 0);
    if (selectedBalance < payableProfitTotal) {
      showToast(`رصيد الخزينة المختارة غير كافٍ. المطلوب ${payableProfitTotal.toLocaleString()} ج.م والمتاح ${selectedBalance.toLocaleString()} ج.م`, 'error');
      return;
    }

    const batchId = generateSafeId('profit_payment');
    const paymentTransactions: PartnerTransaction[] = [];
    const updatedPartners = partners.map(partner => {
      const distributed = transactions.filter(t => t.partnerId === partner.id && t.type === 'profit_distribution').reduce((value, t) => value + (Number(t.amount) || 0), 0);
      const paid = transactions.filter(t => t.partnerId === partner.id && t.type === 'profit_withdrawal').reduce((value, t) => value + (Number(t.amount) || 0), 0);
      const amount = Math.max(0, distributed - paid);
      if (amount <= 0) return partner;
      paymentTransactions.push({
        id: `${batchId}_${partner.id}`,
        partnerId: partner.id,
        partnerName: partner.name,
        type: 'profit_withdrawal',
        amount,
        date: new Date().toISOString(),
        treasuryAccountId: profitPaymentTreasuryId,
        note: `دفع أرباح موزعة فعلياً - دفعة ${batchId}`
      });
      return { ...partner, balance: partner.balance - amount };
    });

    updateSettings({ ...settings, partners: updatedPartners, partnerTransactions: [...transactions, ...paymentTransactions] });
    const paymentDate = new Date().toISOString();
    const accountName = profitPaymentTreasuryId === 'central_wallet'
      ? 'المحفظة المركزية'
      : (treasury?.accounts?.find(account => account.id === profitPaymentTreasuryId)?.name || 'الخزينة');
    const treasuryTransaction = {
      id: `${batchId}_treasury`, date: paymentDate, type: 'withdrawal', amount: payableProfitTotal,
      description: `دفع أرباح الشركاء فعلياً من ${accountName}`,
      fromAccountId: profitPaymentTreasuryId === 'central_wallet' ? undefined : profitPaymentTreasuryId,
      reference: batchId, category: 'partner_profit_payment'
    };
    if (profitPaymentTreasuryId === 'central_wallet') {
      setWallet(prev => ({
        ...prev,
        balance: prev.balance - payableProfitTotal,
        transactions: [{ id: `${batchId}_wallet`, type: 'سحب', amount: payableProfitTotal, date: paymentDate, note: `دفع أرباح الشركاء فعلياً - ${batchId}`, category: 'manual_withdrawal', status: 'completed' } as Transaction, ...(prev.transactions || [])]
      }));
    } else if (setTreasury) {
      setTreasury((previous: Treasury | undefined) => previous ? {
        ...previous,
        accounts: previous.accounts.map(account => account.id === profitPaymentTreasuryId ? { ...account, balance: account.balance - payableProfitTotal } : account),
        transactions: [treasuryTransaction, ...(previous.transactions || [])]
      } : previous);
    }
    setProfitPaymentTreasuryId('');
    setIsProfitPaymentOpen(false);
    showToast(`تم دفع ${payableProfitTotal.toLocaleString()} ج.م من ${accountName} وتحديث حسابات الشركاء`);
  };

  const deletePartner = (partnerId: string) => {
    if (transactions.some(t => t.partnerId === partnerId)) {
        showToast('عفواً، لا يمكن حذف شريك له حركات مالية مسجلة. للضرورة، قم بتصفية أرقامه أولاً.', 'error');
        return;
    }
    setDialog({
        isOpen: true,
        title: 'تأكيد الحذف',
        message: 'هل أنت متأكد من حذف هذا الشريك؟ سيتم حذف جميع معاملاته أيضاً.',
        onConfirm: () => {
            updateSettings({
              ...settings,
              partners: partners.filter(p => p.id !== partnerId),
              partnerTransactions: transactions.filter(t => t.partnerId !== partnerId)
            });
            setDialog(null);
            showToast('تم حذف الشريك بنجاح');
        }
    });
  };

  const startEditPartner = (partner: Partner) => {
    setEditPartnerId(partner.id);
    setEditPartnerName(partner.name);
    setEditPartnerPasscode(partner.passcode || '');
  };

  const savePartnerName = () => {
    if (!editPartnerId || !editPartnerName) return;
    updateSettings({
      ...settings,
      partners: partners.map(p => p.id === editPartnerId ? {...p, name: editPartnerName, passcode: editPartnerPasscode} : p)
    });
    setEditPartnerId(null);
    setEditPartnerPasscode('');
    showToast('تم تعديل بيانات الشريك بنجاح');
  };

  const recalculatePartnerBalances = () => {
    setDialog({
        isOpen: true,
        title: 'مزامنة أرصدة الشركاء',
        message: 'هل تريد إعادة حساب ومزامنة الأرصدة الجارية للشركاء بناءً على سجل معاملاتهم المالية؟ سيقوم هذا الإجراء بتصحيح أي خطأ أو تباين في الأرصدة الحالية نتيجة بعض عمليات التعديل أو الحذف السابقة.',
        onConfirm: () => {
            const updatedPartners = partners.map(partner => {
                const partnerTxs = transactions.filter(t => t.partnerId === partner.id);
                const computedBalance = partnerTxs.reduce((sum, t) => {
                    const amount = Number(t.amount) || 0;
                    if (['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage', 'internal_transfer_in'].includes(t.type)) {
                        return sum + amount;
                    } else if (t.type === 'pos_collection') {
                        return sum; // Do not affect partner balance with POS collection transactions as they are tracked via cash holders
                    } else {
                        return sum - amount;
                    }
                }, 0);
                return {
                    ...partner,
                    balance: computedBalance
                };
            });

            updateSettings({
                ...settings,
                partners: updatedPartners
            });
            
            setDialog(null);
            showToast('تمت إعادة مزامنة أرصدة الشركاء من المعاملات بنجاح');
        }
    });
  };

  const getTxTypeDetails = (type: string) => {
    switch (type) {
      case 'loan': return { label: 'سلفة / سحب كاش شخصي', desc: 'سحب الشريك لمبلغ نقدي لاستخدامه الشخصي (يقلل رصيده ويُخصم من الخزينة المحددة).', icon: ArrowDownRight, color: 'text-rose-600 border-rose-200 bg-rose-50' };
      case 'profit_withdrawal': return { label: 'سحب من الأرباح الموزعة', desc: 'سحب الشريك لجزء أو كل أرباحه السابقة الموزعة له من المحل.', icon: DollarSign, color: 'text-amber-600 border-amber-200 bg-amber-50' };
      case 'repayment': return { label: 'سداد سلفة / رد كاش للمحل', desc: 'قيام الشريك برد مبلغ سلفة سابق أو إيداع كاش لحسابه الشخصي (يُضاف للخزينة).', icon: Check, color: 'text-emerald-600 border-emerald-200 bg-emerald-50' };
      case 'capital_addition': return { label: 'إيداع رأس مال / استثمار جديد', desc: 'ضخ سيولة جديدة لتأسيس أو توسيع نشاط المحل (يزيد إجمالي رأس المال المستثمر).', icon: ArrowUpLeft, color: 'text-blue-600 border-blue-200 bg-blue-50' };
      case 'supply_funding': return { label: 'تمويل شراء بضاعة (تمويل البضائع)', desc: 'دفع الشريك من ماله الخاص لشراء بضاعة أو مخزون للمحل (يُضاف لرصيد تمويل البضائع).', icon: PackageIcon, color: 'text-indigo-600 border-indigo-200 bg-indigo-50' };
      case 'shipping_funding': return { label: 'تمويل ودفع مصاريف شحن', desc: 'دفع الشريك لمصاريف شحن وتوصيل الطلبات عن المحل.', icon: Truck, color: 'text-purple-600 border-purple-200 bg-purple-50' };
      case 'expense_coverage': return { label: 'تغطية مصروفات تشغيلية', desc: 'دفع الشريك لفواتير أو مصروفات إدارية وتشغيلية خاصة بالمحل من حسابه.', icon: DollarSign, color: 'text-teal-600 border-teal-200 bg-teal-50' };
      case 'expense_repayment': return { label: 'استرداد مقابل مصروفات مدفوعة', desc: 'قيام المحل برد مبلغ للشريك كان قد دفعه سابقاً كمصروفات تشغيلية عن المحل.', icon: Check, color: 'text-emerald-600 border-emerald-200 bg-emerald-50' };
      default: return { label: 'معاملة مالية', desc: '', icon: History, color: 'text-slate-600' };
    }
  };

  const handleDeductPartnerCustodyDirectly = (partner: Partner, amount: number) => {
    if (amount <= 0) return;

    setDialog({
        isOpen: true,
        title: 'تأكيد تسوية العهدة كمسحوبات شخصية',
        message: `هل أنت متأكد من تسوية العهدة المالية المتبقية طرف الشريك (${partner.name}) بقيمة ${amount.toLocaleString()} ج.م وتحويلها إلى مسحوبات شخصية مستقطعة من حسابه؟\n\n💡 سيقوم هذا الإجراء بخصم المبلغ فوراً من الرصيد الجاري للشريك وتصفير العهدة طرفه دفترياً، وذلك دون التأثير على حسابات الخزينة أو سحب كاش جديد.`,
        onConfirm: () => {
            const dateStr = new Date().toISOString();
            const tId = generateSafeId('pt_deduct');

            const newTransaction: PartnerTransaction = {
                id: tId,
                partnerId: partner.id,
                type: 'profit_withdrawal', 
                amount: amount,
                date: dateStr,
                note: `خصم عهدة مالية معلقة لم تُرَد وتحويلها كمسحوبات شخصية مستقطعة من الرصيد الجاري للشريك`
            };

            const updatedPartners = partners.map(p => {
                if (p.id === partner.id) {
                    return {
                        ...p,
                        balance: p.balance - amount
                    };
                }
                return p;
            });

            let currentHolders = [...(settings.cashHolders || [])];
            const partnerHolderId = `part_${partner.id}`;
            const partnerIdx = currentHolders.findIndex(h => h.userId === partnerHolderId || h.userId === partner.id);
            
            if (partnerIdx > -1) {
                currentHolders[partnerIdx] = {
                    ...currentHolders[partnerIdx],
                    currentBalance: 0,
                    lastUpdated: dateStr
                };
            }

            const handoverId = generateSafeId('hnd_deduct');
            const handoverData: any = {
                id: handoverId,
                fromUserId: partnerHolderId,
                fromUserName: partner.name,
                toUserId: 'admin_deduction',
                toUserName: 'خصم من الرصيد الجاري للشريك',
                amount: amount,
                date: dateStr,
                notes: `تبين عدم رد العهدة النقدية للشريك وتم تسويتها وخصمها دفترياً من رصيده الجاري كمستحقات شخصية مسحوبة`,
                status: 'completed'
            };

            updateSettings({
                ...settings,
                partners: updatedPartners,
                partnerTransactions: [...transactions, newTransaction],
                cashHolders: currentHolders,
                cashHandovers: [handoverData, ...(settings.cashHandovers || [])],
                activityLogs: [
                    {
                        id: generateSafeId('log'),
                        user: 'الادارة',
                        action: 'خصم عهدة الشريك من رصيده',
                        details: `تم خصم عهدة معلقة لم تُرد من الشريك ${partner.name} بقيمة ${amount.toLocaleString()} ج.م من رصيده الجاري وتصفير العهدة.`,
                        date: new Date().toLocaleString('ar-EG'),
                        timestamp: Date.now()
                    },
                    ...(settings.activityLogs || [])
                ]
            });

            setDialog(null);
            showToast('تم تسوية العهدة بنجاح وخصمها كمسحوبات من الحساب الجاري للشريك وتصفير عهدته.');
        }
    });
  };

  const executeTransfer = () => {
    const amount = parseFloat(transferAmount);
    if (!amount || isNaN(amount) || amount <= 0) {
       showToast('يرجى إدخال مبلغ صحيح للتحويل', 'error');
       return;
    }
    if (!fromPartnerId || !toPartnerId) {
        showToast('يرجى اختيار الشريك المحول والمحول إليه', 'error');
        return;
    }
    if (fromPartnerId === toPartnerId) {
        showToast('لا يمكن التحويل لنفس الشريك', 'error');
        return;
    }
    
    // Check if moving capital
    if (transferType === 'capital') {
        const fromPartner = partners.find(p => p.id === fromPartnerId);
        const toPartner = partners.find(p => p.id === toPartnerId);
        if (!fromPartner || !toPartner) return;

        setDialog({
            isOpen: true,
            title: 'تأكيد تحويل الحصص الاستثمارية',
            message: `تحويل حصة بنسبة ${amount}% من ${fromPartner.name} إلى ${toPartner.name}. هل تريد المتابعة؟`,
            onConfirm: () => {
                if ((fromPartner.profitRatio || 0) < amount) {
                    showToast('نسبة الشريك المحول لا تكفي', 'error');
                    setDialog(null);
                    return;
                }
                const updatedPartners = partners.map(p => {
                    if (p.id === fromPartnerId) {
                        return { ...p, profitRatio: (p.profitRatio || 0) - amount };
                    }
                    if (p.id === toPartnerId) {
                        return { ...p, profitRatio: (p.profitRatio || 0) + amount };
                    }
                    return p;
                });
                updateSettings({...settings, partners: updatedPartners});
                setTransferAmount('');
                setDialog(null);
                showToast('تم نقل وتحديث الحصص الاستثمارية بنجاح');
            }
        });
        return;
    }

    // Moving normal balance
    const fromPartner = partners.find(p => p.id === fromPartnerId);

    setDialog({
        isOpen: true,
        title: 'تأكيد التحويل المالي المشترك',
        message: `سيتم تحويل مبلغ ${amount.toLocaleString()} ج.م بين الشركاء المحدداً. تابع ليتم تسجيل حركات مدينة ودائنة تلقائياً.`,
        onConfirm: () => {
            const dateStr = new Date().toISOString();
            const txIdBase = generateSafeId('tx_inter');
            
            const fromTx: PartnerTransaction = {
                id: `T-OUT-${txIdBase}`,
                partnerId: fromPartnerId,
                type: 'internal_transfer_out',
                amount: amount,
                date: dateStr,
                note: `تحويل داخلي صادر إلى الشريك: ${partners.find(p=>p.id===toPartnerId)?.name} ${transferNotes ? `| ملاحظات: ${transferNotes}` : ''}`
            };

            const toTx: PartnerTransaction = {
                id: `T-IN-${txIdBase}`,
                partnerId: toPartnerId,
                type: 'internal_transfer_in',
                amount: amount,
                date: dateStr,
                note: `تحويل داخلي وارد من الشريك: ${partners.find(p=>p.id===fromPartnerId)?.name} ${transferNotes ? `| ملاحظات: ${transferNotes}` : ''}`
            };

            const updatedPartners = partners.map(p => {
                if (p.id === fromPartnerId) {
                    return { ...p, balance: p.balance - amount };
                }
                if (p.id === toPartnerId) {
                    return { ...p, balance: p.balance + amount };
                }
                return p;
            });

            updateSettings({
                ...settings,
                partners: updatedPartners,
                partnerTransactions: [...transactions, fromTx, toTx]
            });
            
            setTransferAmount('');
            setTransferNotes('');
            setDialog(null);
            showToast('تم تنفيذ التحويل الداخلي بنجاح');
        }
    });
  };

  const addTransaction = (partnerId: string) => {
    const amount = parseFloat(transactionAmount);
    if (!amount || isNaN(amount) || amount <= 0) {
        showToast('يرجى إدخال مبلغ صحيح أكبر من الصفر', 'error');
        return;
    }
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;

    let warningNote = '';

    if (transactionType === 'profit_withdrawal') {
        const partnerDistributions = transactions.filter(t => t.partnerId === partnerId && t.type === 'profit_distribution').reduce((a, b) => a + b.amount, 0);
        const partnerWithdrawals = transactions.filter(t => t.partnerId === partnerId && t.type === 'profit_withdrawal').reduce((a, b) => a + b.amount, 0);
        const availableProfit = partnerDistributions - partnerWithdrawals;
        
        if (amount > availableProfit) {
            warningNote += ` (ملاحظة: تم سحب مبلغ يتجاوز الأرباح الموزعة وتم تقييده في حساب الشريك)`;
        }
    }

    const isWithdrawal = ['loan', 'profit_withdrawal', 'expense_repayment', 'capital_withdrawal'].includes(transactionType);
    const isSupplyFunding = transactionType === 'supply_funding';

    if (selectedTreasuryId && isWithdrawal && setTreasury && treasury) {
      const selectedAccount = treasury.accounts.find(a => a.id === selectedTreasuryId);
      if (selectedAccount && selectedAccount.balance < amount) {
         warningNote += ` (تنبيه: رصيد الخزينة المختار أصبح بالسالب مؤقتاً حتى إيداع تحصيلات جديدة)`;
      }
    }

    const tId = generateSafeId('pt_tx');
    const newTransaction: PartnerTransaction = {
      id: tId,
      partnerId,
      type: transactionType,
      amount,
      date: new Date().toISOString(),
      treasuryAccountId: selectedTreasuryId || undefined
    };

    const updatedPartners = partners.map(p => {
        if (p.id === partnerId) {
            let newBalance = p.balance;
            if (['loan', 'profit_withdrawal', 'expense_repayment', 'customer_advance', 'internal_transfer_out', 'capital_withdrawal'].includes(transactionType)) {
                newBalance -= amount;
            } else {
                newBalance += amount;
            }
            return { ...p, balance: newBalance };
        }
        return p;
    });

    const walletTransaction: Transaction = {
        id: `pt_w_${tId}`,
        type: (isWithdrawal) ? 'سحب' : 'إيداع',
        amount: amount,
        date: new Date().toISOString(),
        note: `معاملة شريك: ${partner.name} - ${
            transactionType === 'loan' ? 'سلفة' : 
            transactionType === 'capital_addition' ? 'إيداع رأس مال' : 
            transactionType === 'capital_withdrawal' ? 'سحب من رأس المال' : 
            transactionType === 'profit_withdrawal' ? 'سحب أرباح' : 
            transactionType === 'shipping_funding' ? 'إيداع مصاريف الشحن' :
            transactionType === 'expense_repayment' ? 'رد مصروفات شخصية' :
            transactionType === 'supply_funding' ? 'تمويل شراء بضاعة (إيداع تمويل البضائع)' : 
            transactionType === 'pos_collection' ? 'تحصيل مبيعات نقطة البيع' : 'سداد سلفة'
        }${selectedTreasuryId === 'central_wallet' ? ' (عبر المحفظة المركزية)' : (selectedTreasuryId && treasury ? ` (عبر ${treasury.accounts.find(a => a.id === selectedTreasuryId)?.name || 'الخزينة'})` : '')}`,
        category: isSupplyFunding ? 'supply_deposit' : (isWithdrawal ? 'manual_withdrawal' : 'manual_deposit'),
        status: 'completed'
    } as Transaction;

    updateSettings({
      ...settings,
      partners: updatedPartners,
      partnerTransactions: [...transactions, newTransaction]
    });

    // Handle Treasury Account Balance Integration
    if (selectedTreasuryId === 'central_wallet' && setWallet) {
        setWallet(prev => {
            const amountNum = amount;
            const isGive = isWithdrawal;
            
            return {
                ...prev,
                balance: isGive ? prev.balance - amountNum : prev.balance + amountNum,
                transactions: [walletTransaction, ...(prev.transactions || [])]
            };
        });
    } else if (selectedTreasuryId && setTreasury && treasury) {
       const selectedAccount = treasury.accounts.find(a => a.id === selectedTreasuryId);
       if (selectedAccount) {
         setTreasury((prev: any) => {
           if (!prev) return prev;
           const updatedAccounts = prev.accounts.map((acc: any) => {
             if (acc.id === selectedTreasuryId) {
                return {
                  ...acc,
                  balance: isWithdrawal ? acc.balance - amount : acc.balance + amount
                };
             }
             return acc;
           });
           
           const newTreasuryTx = {
             id: generateSafeId('t_part'),
             date: new Date().toISOString(),
             type: isWithdrawal ? 'withdrawal' : 'deposit',
             amount,
             description: `معاملة متبادلة مع الشريك ${partner.name}: ${
                 transactionType === 'loan' ? 'سحب سلفة أو سلفة نقدية' : 
                 transactionType === 'capital_addition' ? 'إيداع استثماري (رأس مال)' : 
                 transactionType === 'profit_withdrawal' ? 'سحب أرباح نقدية' : 
                 transactionType === 'shipping_funding' ? 'إيداع تمويل شحن' :
                 transactionType === 'expense_repayment' ? 'رد مصروفات نقدية' :
                 transactionType === 'supply_funding' ? 'إيداع لشراء بضاعة ومخزون' : 
                 transactionType === 'pos_collection' ? 'استلام كاش مبيعات الشريك' : 'استلام تسديد سلفة'
             }`,
             toAccountId: isWithdrawal ? undefined : selectedTreasuryId,
             fromAccountId: isWithdrawal ? selectedTreasuryId : undefined,
             reference: `pt_${tId}`
           };
           
           return {
             ...prev,
             accounts: updatedAccounts,
             transactions: [newTreasuryTx, ...(prev.transactions || [])]
           };
         });
       }
    }

    const movesRealMoney = !['profit_distribution', 'customer_advance'].includes(transactionType);
    
    if (movesRealMoney && !selectedTreasuryId) {
        setWallet(prev => ({ 
            ...prev, 
            balance: isSupplyFunding ? prev.balance : prev.balance + (isWithdrawal ? -amount : amount),
            
            transactions: [walletTransaction, ...prev.transactions] 
        }));
    }
    
    setTransactionAmount('');
    setSelectedTreasuryId('');
    showToast('تم إضافة المعاملة وتحديث الخزائن بنجاح' + warningNote);
  };

  return (
    <div data-partners-page="true" dir="rtl" className="partners-page-shell p-4 sm:p-6 lg:p-8 space-y-8 bg-gradient-to-br from-slate-50 via-white to-indigo-50/30 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950/20 min-h-screen">
      <AnimatePresence>
        {isProfitPaymentOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white dark:bg-slate-800 rounded-3xl p-7 max-w-md w-full space-y-5 shadow-2xl">
              <div className="text-center space-y-2">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 flex items-center justify-center"><DollarSign size={28} /></div>
                <h3 className="font-black text-xl dark:text-white">دفع الأرباح فعليًا</h3>
                <p className="text-sm text-slate-500">إجمالي الأرباح الموزعة المستحقة: <strong className="text-emerald-600">{payableProfitTotal.toLocaleString()} ج.م</strong></p>
              </div>
              <label className="block space-y-2">
                <span className="text-xs font-black text-slate-500">اختر الخزينة أو الحساب المالي</span>
                <select value={profitPaymentTreasuryId} onChange={event => setProfitPaymentTreasuryId(event.target.value)} className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-bold">
                  <option value="">-- اختر الحساب --</option>
                  <option value="central_wallet">المحفظة المركزية (الرصيد الأساسي)</option>
                  {(treasury?.accounts || []).map(account => <option key={account.id} value={account.id}>{account.name} — الرصيد {Number(account.balance || 0).toLocaleString()} ج.م</option>)}
                </select>
              </label>
              <p className="text-[11px] text-slate-500 bg-amber-50 dark:bg-amber-900/20 rounded-xl p-3">سيتم تسجيل حركة سحب من الحساب المختار وحركة دفع أرباح لكل شريك، ولن يمكن تكرار دفع نفس الأرباح.</p>
              <div className="flex gap-3">
                <button onClick={() => { setIsProfitPaymentOpen(false); setProfitPaymentTreasuryId(''); }} className="flex-1 py-3 rounded-xl bg-slate-100 dark:bg-slate-700 font-bold">إلغاء</button>
                <button onClick={payDistributedProfits} disabled={!profitPaymentTreasuryId || payableProfitTotal <= 0} className="flex-1 py-3 rounded-xl bg-emerald-600 disabled:bg-slate-300 text-white font-black">تأكيد الدفع</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {dialog && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white dark:bg-slate-800 rounded-3xl p-8 max-w-sm w-full space-y-6 shadow-2xl"
            >
               <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center text-indigo-600 dark:text-indigo-400 mx-auto">
                 <AlertCircle size={32} />
               </div>
               <div className="text-center space-y-2">
                 <h3 className="font-black text-xl dark:text-white">{dialog.title}</h3>
                 <p className="text-slate-500 dark:text-slate-400 leading-relaxed">{dialog.message}</p>
               </div>
               <div className="flex gap-3 pt-2">
                   <button onClick={() => setDialog(null)} className="flex-1 py-3.5 rounded-2xl bg-slate-100 dark:bg-slate-700 font-bold hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">إلغاء</button>
                   <button onClick={dialog.onConfirm} className="flex-1 py-3.5 rounded-2xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/25">تأكيد</button>
               </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
            <motion.div 
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className={`fixed bottom-8 right-8 z-50 px-8 py-4 rounded-2xl shadow-2xl text-white font-bold flex items-center gap-3 backdrop-blur-md ${toast.type === 'success' ? 'bg-emerald-600/90' : 'bg-red-600/90'}`}
            >
                {toast.type === 'success' ? <Check size={20}/> : <X size={20}/>}
                {toast.message}
            </motion.div>
        )}
      </AnimatePresence>
      
      {/* 🚀 Dynamic Executive Partners & Capital Hero Banner */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-slate-900 via-[#0d1b2a] to-indigo-950 text-white p-7 sm:p-9 shadow-xl border border-indigo-500/20">
        <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -translate-x-1/3 -translate-y-1/3" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none translate-x-1/4 translate-y-1/4" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-black border border-indigo-500/30 backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                غرفة العمليات المالية والشركاء
              </span>
              <span className="px-3 py-1 rounded-full bg-white/10 text-slate-200 text-xs font-bold border border-white/10 backdrop-blur-md">
                {partners.length} شركاء مسجلين
              </span>
              {settings?.activePeriodStartDate && (
                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30 backdrop-blur-md flex items-center gap-1.5">
                  <Lock size={12} />
                  دورة محاسبية جارية
                </span>
              )}
            </div>

            <div className="space-y-1">
              <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight flex items-center gap-3">
                <span>إدارة الشركاء ورؤوس الأموال</span>
              </h1>
              <p className="text-xs sm:text-sm font-medium text-slate-300/90 max-w-2xl leading-relaxed">
                متابعة الحصص الرأسمالية، المسحوبات والسلف، توزيع الأرباح تلقائياً، وبوابة الاستعلام المستقلة لكل شريك.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button 
              onClick={() => setIsClosingModalOpen(true)}
              className="group relative inline-flex items-center gap-2.5 px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500/20 via-indigo-600 to-indigo-700 hover:from-amber-500/30 hover:to-indigo-600 text-white font-black text-xs sm:text-sm border border-indigo-400/40 hover:border-amber-400/60 shadow-xl shadow-indigo-950/40 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] cursor-pointer overflow-hidden"
              title="إقفال الدورة المحاسبية وتسوية مقاصة الشركاء وفق بضاعة المخزون"
            >
              <span className="p-1.5 bg-amber-500/30 text-amber-300 rounded-xl border border-amber-400/40 group-hover:rotate-12 transition-transform duration-300 shrink-0 shadow-sm">
                <Lock size={14} className="text-amber-300" />
              </span>
              <span className="tracking-tight text-white font-black">
                إقفال الفترة
              </span>
              <span className="px-2 py-0.5 text-[10px] font-black bg-amber-400/20 text-amber-300 rounded-lg border border-amber-400/40 flex items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                مقاصة
              </span>
            </button>

            <Link 
              to={`/store/${storeId}/partner-portal`}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-bold border border-white/10 transition-all backdrop-blur-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <Users2 size={16} className="text-indigo-300" />
              <span>بوابة الشركاء (PIN)</span>
            </Link>

            <button 
              onClick={() => setShowHelpGuide(!showHelpGuide)}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-bold border border-white/10 transition-all backdrop-blur-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <BookOpen size={16} className="text-amber-300" />
              <span>{showHelpGuide ? 'إخفاء الدليل' : 'دليل الحسابات'}</span>
            </button>

            <button 
              onClick={recalculatePartnerBalances}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-bold border border-white/10 transition-all backdrop-blur-md flex items-center justify-center gap-2 cursor-pointer"
              title="إعادة حساب أرصدة الشركاء الحالية من سجل المعاملات المالية"
            >
              <Coins size={16} className="text-emerald-300" />
              <span>مزامنة الأرصدة</span>
            </button>

            <button 
              onClick={() => window.print()}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-bold border border-white/10 transition-all backdrop-blur-md flex items-center justify-center gap-2 cursor-pointer"
              title="طباعة التقرير العام"
            >
              <Printer size={16} className="text-slate-300" />
              <span>طباعة</span>
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showHelpGuide && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-6"
          >
            <div className="bg-gradient-to-br from-amber-500/10 via-indigo-500/5 to-slate-500/5 dark:from-amber-500/10 dark:via-indigo-500/10 dark:to-slate-900 border-2 border-amber-500/20 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-amber-500/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-amber-500 text-white rounded-2xl shadow-lg shadow-amber-500/20">
                    <BookOpen size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-800 dark:text-white">الدليل المبسط لفهم حسابات الشركاء والمسحوبات</h3>
                    <p className="text-sm font-bold text-slate-500 dark:text-slate-400">شرح سريع لكيفية فصل رأس المال عن المسحوبات اليومية والأرباح</p>
                  </div>
                </div>
                <button onClick={() => setShowHelpGuide(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-2">
                  <X size={20} />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3 shadow-sm">
                  <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-black text-base">
                    <ArrowUpLeft size={20} />
                    <span>1. رأس المال والاستثمار</span>
                  </div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300 leading-relaxed">
                    هي المبالغ الأساسية التي يدفعها الشريك لتأسيس أو توسيع المحل. <strong className="text-blue-600">هذه المبالغ ثابتة</strong> ولا تتأثر بالمسحوبات الشخصية أو السلف اليومية.
                  </p>
                </div>

                <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3 shadow-sm">
                  <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-black text-base">
                    <TrendingUp size={20} />
                    <span>2. الأرباح الموزعة والمستحقة</span>
                  </div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300 leading-relaxed">
                    عند قيامك بالضغط على <strong className="text-indigo-600">"توزيع الأرباح"</strong>، يتم حساب نصيب كل شريك وإضافته لرصيده المتاح كسحب من الأرباح وليس كرأس مال.
                  </p>
                </div>

                <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3 shadow-sm">
                  <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-black text-base">
                    <ArrowDownRight size={20} />
                    <span>3. المسحوبات الشخصية والسلف</span>
                  </div>
                  <p className="text-xs font-bold text-slate-600 dark:text-slate-300 leading-relaxed">
                    أي مبالغ يسحبها الشريك كاش لاستخدامه الخاص (سلف، مصاريف شخصية، سحب من الأرباح). <strong className="text-rose-600">تُخصم مباشرة من رصيده المتاح ومن الخزينة</strong>.
                  </p>
                </div>
              </div>

              <div className="bg-white/80 dark:bg-slate-800/80 p-5 rounded-2xl border border-indigo-500/20 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 rounded-xl">
                    <Info size={20} />
                  </div>
                  <p className="text-xs font-black text-slate-700 dark:text-slate-200">
                    💡 <strong className="text-indigo-600 dark:text-indigo-400">كيف أفهم الرصيد الصافي؟</strong> (الرصيد المتاح = الأرباح الموزعة + الإيداعات - المسحوبات والسلف). إذا كان <span className="text-emerald-600 font-bold">بالموجب (أخضر)</span> يعني للشريك أموال مستحقة في المحل، وإذا كان <span className="text-rose-600 font-bold">بالسالب (أحمر)</span> يعني الشريك عليه سلفة زائدة للمحل.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-wrap bg-white/80 dark:bg-slate-900/80 p-1.5 rounded-2xl w-full mb-2 gap-1 border border-slate-200/70 dark:border-slate-800 shadow-sm sticky top-2 z-20 backdrop-blur-md">
          <button 
            onClick={() => setActiveSection('overview')}
            className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 ${activeSection === 'overview' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'}`}
          ><PieChart size={16}/> نظرة عامة وتوزيع الأرباح</button>
          <button 
            onClick={() => setActiveSection('simulator')}
            className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 ${activeSection === 'simulator' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'}`}
          ><Calculator size={16}/> محاكاة الأرباح والاحتمالات</button>
          <button 
            onClick={() => setActiveSection('transfers')}
            className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 ${activeSection === 'transfers' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'}`}
          ><ArrowRightLeft size={16}/> التحويلات الداخلية بين الشركاء</button>
          <button 
            onClick={() => setActiveSection('valuation')}
            className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 ${activeSection === 'valuation' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'}`}
          ><Sparkles size={16}/> تقييم المشروع وتصفية الحسابات</button>
          <button 
            onClick={() => setActiveSection('summary_table')}
            className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 ${activeSection === 'summary_table' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'}`}
          ><FileText size={16}/> جدول المركز المالي المجمع</button>
          <button 
            onClick={() => setActiveSection('requests')}
            className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 ${activeSection === 'requests' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'}`}
          >
            <Send size={16}/> طلبات واستفسارات الشركاء
            {pendingRequestsCount > 0 && (
              <span className="bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">
                {pendingRequestsCount}
              </span>
            )}
          </button>
          <button 
            onClick={() => {
              setExitModalPartnerId(partners[0]?.id || null);
              setIsExitModalOpen(true);
            }}
            className="px-6 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex items-center gap-2 bg-gradient-to-r from-rose-600 to-indigo-600 text-white shadow-md hover:opacity-95 cursor-pointer"
          ><LogOut size={16}/> 🚪 حاسبة وتصفية التخارج</button>
      </div>

      {pendingRequestsCount > 0 && activeSection !== 'requests' && (
        <div className="mb-6 bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-indigo-500/10 border-2 border-amber-500/30 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-black shadow-md shadow-amber-500/20">
              <Bell size={20} className="animate-bounce" />
            </div>
            <div>
              <h4 className="font-black text-slate-900 dark:text-white text-sm sm:text-base flex items-center gap-2">
                <span>يوجد {pendingRequestsCount} طلب/استفسار معلق وارد من بوابة الشركاء</span>
                <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">جديد</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                قام الشركاء بتقديم طلبات سحب أرباح أو تسجيل مصروفات من خلال البوابة المالية للمراجعة والاعتماد.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveSection('requests')}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-indigo-500/20 flex items-center gap-2 cursor-pointer"
          >
            <span>مراجعة واعتماد الطلبات</span>
            <ArrowDownRight size={14} />
          </button>
        </div>
      )}

      {activeSection === 'overview' && (
        <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
          <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h2 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-3">
              توزيع الأرباح التشغيلية
              <div className="text-[10px] bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full uppercase tracking-wider">حي ومباشر</div>
            </h2>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
               <Info size={14} />
               يتم الحساب بناءً على الأوردرات المكتملة
            </div>
          </div>
          
          <div className="p-8">
             {/* 💡 ملخص السيولة والربح للشركاء */}
             <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-emerald-50/80 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30 p-6 rounded-3xl relative overflow-hidden">
                    <div className="flex justify-between items-start mb-2">
                        <div>
                            <div className="flex items-center gap-1.5 mb-1">
                              <p className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">إجمالي السيولة المتاحة (كاش)</p>
                              <span className="text-[9px] bg-emerald-200/60 dark:bg-emerald-800/60 text-emerald-800 dark:text-emerald-200 px-2 py-0.5 rounded-full font-bold">خزائن وبنوك</span>
                            </div>
                            <h3 className="text-3xl font-black text-slate-900 dark:text-white tabular-nums">{availableLiquidity.toLocaleString()} <span className="text-xs font-normal text-slate-400">ج.م</span></h3>
                        </div>
                        <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl text-emerald-600">
                            <WalletIcon size={24} />
                        </div>
                    </div>
                    <p className="text-[10px] text-slate-500 font-bold">هذا هو المبلغ المتوفر حالياً كسيولة حية في (الخزينة + البنك + المحافظ) ويمكن استخدامه لشراء بضاعة جديدة أو سداد التزامات فورية.</p>
                </div>

                <div className="bg-blue-50/80 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 p-6 rounded-3xl relative overflow-hidden">
                    <div className="flex justify-between items-start mb-2">
                        <div>
                            <div className="flex items-center gap-1.5 mb-1">
                              <p className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest">صـافي الأربـاح المتاحة للتوزيع</p>
                              <span className="text-[9px] bg-blue-200/60 dark:bg-blue-800/60 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded-full font-bold">غير موزعة</span>
                            </div>
                            <h3 className="text-3xl font-black text-slate-900 dark:text-white tabular-nums">{undistributedProfit.toLocaleString()} <span className="text-xs font-normal text-slate-400">ج.م</span></h3>
                        </div>
                        <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-2xl text-blue-600">
                            <TrendingUp size={24} />
                        </div>
                    </div>
                    <p className="text-[10px] text-slate-500 font-bold">هذا هو صافي المكسب الفعلي بعد خصم كل المصاريف والخسائر والمبالغ التي تم توزيعها سابقاً.</p>
                </div>
             </div>

             {/* 💡 بطاقة التوضيح الاسترشادي لتجنب لبس المخزون والسيولة للشركاء */}
             <div className="mb-10 bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-emerald-500/10 border border-amber-200 dark:border-amber-900/40 p-6 rounded-3xl space-y-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                   <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-black">💡</div>
                      <div>
                        <h4 className="text-sm font-black text-slate-800 dark:text-white">دليل الشركاء الاسترشادي: أين توجد أموال المشروع والبضاعة؟</h4>
                        <p className="text-[10px] font-bold text-slate-500">توضيح الفرق المحاسبي بين قيمة البضاعة على الرفوف، السيولة الكاش، ورصيد رأس المال</p>
                      </div>
                   </div>
                   <div className="text-xs font-black bg-white dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                      قيمة المخزون الحالي: <span className="text-amber-600">{inventoryValue.toLocaleString()} ج.م</span>
                   </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-medium">
                   <div className="bg-white/80 dark:bg-slate-800/80 p-4 rounded-2xl border border-amber-100 dark:border-amber-900/30 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-400 font-black text-[11px]">
                         <span>📦 1. بضاعة المخزن (أصول عينية)</span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                         هي تكلفة المنتجات المتوفرة حالياً بالمتجر ({inventoryValue.toLocaleString()} ج.م). هذه أموال <strong className="text-slate-800 dark:text-white">تم استثمارها وشراء بضاعة بها بالفعل</strong> وتنتظر البيع لتحقيق الربح.
                      </p>
                   </div>

                   <div className="bg-white/80 dark:bg-slate-800/80 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-black text-[11px]">
                         <span>💵 2. السيولة الحية (كاش الخزينة)</span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                         هي أموال نقدية حرة ({availableLiquidity.toLocaleString()} ج.م) متوفرة في حسابات البنوك والخزائن، جاهزة لتمويل شحنات جديدة أو سداد التزامات المتجر.
                      </p>
                   </div>

                   <div className="bg-white/80 dark:bg-slate-800/80 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-900/30 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-400 font-black text-[11px]">
                         <span>⚖️ 3. المركز المالي الكلي</span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                         إجمالي أصول المشروع = <strong className="text-indigo-600 dark:text-indigo-400 font-black">{(availableLiquidity + inventoryValue).toLocaleString()} ج.م</strong> (كاش متاح + بضاعة بالمخزن)، ويتم توزيع نصيب الشريك بناءً على رأس ماله ونسبة أرباحه.
                      </p>
                   </div>
                </div>
             </div>

             {/* 📊 تحليل السيولة المالية (أين ذهبت الأموال؟) */}
             <div className="mb-10 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm overflow-hidden relative">
                <div className="absolute top-0 right-0 p-8 opacity-5">
                    <Calculator size={120} />
                </div>
                
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 relative z-10">
                    <div className="flex items-center gap-3">
                        <div className="p-3 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 rounded-2xl">
                            <Calculator size={24} />
                        </div>
                        <div>
                            <h4 className="font-black text-lg text-slate-900 dark:text-white">تحليل السيولة المتاحة (كاش)</h4>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">موازنة التدفقات المالية وتكلفة البضاعة</p>
                        </div>
                    </div>
                    <div className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2">
                        السيولة المتوفرة: {availableLiquidity.toLocaleString()} ج.م
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
                    <div className="space-y-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-200 dark:border-slate-800 pb-2">رأس المال والمدخلات (+)</p>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 font-medium">تكلفة المنتجات (رأس مال مسترد)</span>
                                <span className="text-emerald-600 font-black">+{totalCogs.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 font-medium">مبالغ إيداع شحن الشركاء</span>
                                <span className="text-emerald-600 font-black">+{shippingDeposits.toLocaleString()}</span>
                            </div>
                            { (totalDeposits - shippingDeposits) > 0 && (
                                <div className="flex justify-between items-center text-sm">
                                    <span className="text-slate-500 font-medium">إيداعات رأس مال وتوريد أخرى</span>
                                    <span className="text-emerald-600 font-black">+{(totalDeposits - shippingDeposits).toLocaleString()}</span>
                                </div>
                            )}
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 font-medium">صافي الأرباح (بعد المصاريف)</span>
                                <span className="text-emerald-600 font-black">+{allTimeNetProfit.toLocaleString()}</span>
                            </div>
                            <div className="pt-2 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center text-sm font-black">
                                <span className="text-slate-700 dark:text-slate-300">إجمالي المدخلات</span>
                                <span className="text-emerald-600">+{(totalDeposits + totalCogs + allTimeNetProfit).toLocaleString()}</span>
                            </div>
                        </div>
                        <p className="text-[9px] text-slate-400 italic">ملاحظة: صافي الأرباح محسوب بالفعل بعد خصم المرتجعات والمصاريف الإدارية.</p>
                    </div>

                    <div className="space-y-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-200 dark:border-slate-800 pb-2">المسحوبات والمشتريات (-)</p>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 font-medium">سحب أرباح موزعة</span>
                                <span className="text-red-500 font-black">-{ (allTimeNetProfit - undistributedProfit).toLocaleString() }</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 font-medium">شراء بضاعة ومخزون</span>
                                <span className="text-red-500 font-black">-{totalStockPurchases.toLocaleString()}</span>
                            </div>
                            <div className="pt-2 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center text-sm font-black">
                                <span className="text-slate-700 dark:text-slate-300">إجمالي المخرجات</span>
                                <span className="text-red-500">-{( (allTimeNetProfit - undistributedProfit) + totalStockPurchases ).toLocaleString()}</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-indigo-50/50 dark:bg-indigo-900/10 p-6 rounded-3xl border border-indigo-100 dark:border-indigo-900/30 flex flex-col justify-center text-center">
                        <p className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest mb-2">السيولة المتاحة للاستخدام</p>
                        <h5 className="text-4xl font-black text-slate-900 dark:text-white tabular-nums mb-1">{availableLiquidity.toLocaleString()}</h5>
                        <p className="text-xs font-bold text-slate-400 mb-4">ج.م</p>
                        <div className="space-y-2">
                             <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                <div className="h-full bg-indigo-500 animate-pulse" style={{ width: '100%' }}></div>
                             </div>
                             <p className="text-[9px] text-slate-400 font-bold leading-relaxed">
                                هذه هي المبالغ المتوفرة فعلياً في خزائنك وبنوكك بعد استرداد ثمن البضاعة وإضافة المكسب وخصم كل المصاريف والمشتريات.
                             </p>
                        </div>
                    </div>
                </div>
             </div>

             <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                    <div className="bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 p-6 rounded-3xl group transition-all hover:border-indigo-300">
                        <div className="flex justify-between items-start mb-4">
                          <p className="font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
                              <DollarSign size={18} /> صافي الأرباح (بعد المصاريف التشغيلية)
                          </p>
                          <TrendingUp className="text-indigo-300 dark:text-indigo-700" size={24} />
                        </div>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-sm border-b border-indigo-100 dark:border-indigo-900/10 pb-2">
                                <span className="text-slate-500 font-bold flex items-center gap-2">
                                    <Monitor size={14} className="text-indigo-400" /> مبيعات نقطة البيع (POS)
                                </span>
                                <span className="text-slate-900 dark:text-white font-black">{totalSuccessfulNetPos.toLocaleString()} <span className="text-[10px]">ج.م</span></span>
                            </div>

                            <div className="flex justify-between items-center text-sm border-b border-indigo-100 dark:border-indigo-900/10 pb-2">
                                <span className="text-slate-500 font-bold flex items-center gap-2">
                                    <Truck size={14} className="text-indigo-400" /> مبيعات الشحن (أونلاين)
                                </span>
                                <span className="text-slate-900 dark:text-white font-black">{totalSuccessfulNetShipping.toLocaleString()} <span className="text-[10px]">ج.م</span></span>
                            </div>

                            <div className="flex justify-between items-end border-b border-indigo-100 dark:border-indigo-900/30 pb-3 pt-1">
                                <h3 className="text-3xl font-black text-slate-900 dark:text-white">{(totalSuccessfulNetPos + totalSuccessfulNetShipping).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} <span className="text-sm font-normal text-slate-400">ج.م</span></h3>
                                <p className="text-[10px] text-slate-400 font-bold uppercase">إجمالي الطلبات الناجحة</p>
                            </div>
                            
                            {otherIncome > 0 && (
                                <div className="flex justify-between text-sm text-slate-500 font-medium">
                                    <span>إيرادات إضافية (أخرى)</span>
                                    <span className="text-emerald-600 font-bold">+{otherIncome.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</span>
                                </div>
                            )}
                            <div className="flex justify-between text-sm text-slate-500 font-medium font-black border-t border-indigo-100 dark:border-indigo-900/30 pt-2">
                                <span>صـافـي الأربـاح</span>
                                <span className="text-indigo-600">{(totalSuccessfulNetPos + totalSuccessfulNetShipping + otherIncome).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-rose-50/50 dark:bg-rose-900/10 border border-rose-100 dark:border-rose-900/30 p-6 rounded-3xl transition-all hover:border-rose-300">
                        <div className="flex justify-between items-start mb-4">
                          <p className="font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2">
                              <ArrowDownRight size={18} /> إجمالي الخسائر والمصروفات الإدارية
                          </p>
                          <Activity className="text-rose-300 dark:text-rose-700" size={24} />
                        </div>
                        <div className="space-y-3">
                            <div className="flex justify-between text-sm text-slate-500 font-medium">
                                <span>فشل توصيل ومرتجعات</span>
                                <span className="text-rose-600 font-bold">-{returnsLosses.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</span>
                            </div>
                            <div className="flex justify-between text-sm text-slate-500 font-medium">
                                <span>مصروفات إدارية وتشغيلية</span>
                                <span className="text-rose-600 font-bold">-{adminExpenses.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</span>
                            </div>
                            <div className="flex justify-between text-sm text-slate-500 font-medium font-black border-t border-rose-100 dark:border-rose-900/30 pt-2">
                                <span>صافي المصروفات</span>
                                <span className="text-rose-600">{totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-3xl p-8 flex flex-col justify-center items-center text-center space-y-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full -mr-16 -mt-16 ring-1 ring-indigo-500/10"></div>
                    <div className="absolute bottom-0 left-0 w-24 h-24 bg-rose-500/5 rounded-full -ml-12 -mb-12 ring-1 ring-rose-500/10"></div>
                    
                    <div className="space-y-4 relative z-10 w-full">
                        <div className="space-y-1">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">إجمالي الأرباح التاريخية</p>
                          <p className="text-xl font-black text-slate-700 dark:text-slate-300">
                             {allTimeNetProfit.toLocaleString()} <span className="text-sm">ج.م</span>
                          </p>
                        </div>

                        <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                          <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">الأرباح المتاحة للتوزيع</p>
                          <h4 className="text-5xl font-black text-indigo-600 dark:text-indigo-400">
                            {undistributedProfit.toLocaleString()} 
                            <span className="text-xl font-bold text-slate-400 ml-2">ج.م</span>
                          </h4>
                          <p className="text-[10px] text-slate-400 mt-1 font-bold">بعد خصم {(allTimeNetProfit - undistributedProfit).toLocaleString()} ج.م تم توزيعها سابقاً</p>
                        </div>
                    </div>

                    <p className="text-sm text-slate-500 dark:text-slate-400 max-w-[200px] font-medium leading-relaxed">
                        يتم توزيع المبلغ المتبقي فقط على الشركاء.
                    </p>

                    <button 
                      onClick={distributeProfit} 
                      disabled={undistributedProfit <= 0}
                      className={`w-full group relative overflow-hidden text-white px-8 py-4 rounded-2xl font-black transition-all duration-300 shadow-xl active:scale-95 ${undistributedProfit > 0 ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/25' : 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed shadow-none'}`}
                    >
                        توزيع الأرباح المتبقية
                    </button>
                    <button
                      onClick={() => setIsProfitPaymentOpen(true)}
                      disabled={payableProfitTotal <= 0}
                      className={`w-full px-8 py-3 rounded-2xl font-black transition-all ${payableProfitTotal > 0 ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'}`}
                    >
                      دفع الأرباح المستحقة فعليًا ({payableProfitTotal.toLocaleString()} ج.م)
                    </button>
                </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-emerald-600 group-hover:scale-110 transition-transform"><WalletIcon size={80}/></div>
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-xl flex items-center justify-center"><User size={20}/></div>
                    <h5 className="font-bold text-slate-500 dark:text-slate-400">إجمالي الشركاء</h5>
                  </div>
                  <p className="text-4xl font-black dark:text-white tracking-tight">{partners.length}</p>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-blue-600 group-hover:scale-110 transition-transform"><DollarSign size={80}/></div>
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-xl flex items-center justify-center"><ArrowUpLeft size={20}/></div>
                    <h5 className="font-bold text-slate-500 dark:text-slate-400">إجمالي رأس المال</h5>
                  </div>
                  <p className="text-4xl font-black text-blue-600 dark:text-blue-400 tracking-tight">{totals.capital.toLocaleString()} <span className="text-sm font-bold text-slate-400">ج.م</span></p>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-rose-600 group-hover:scale-110 transition-transform"><History size={80}/></div>
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-rose-100 dark:bg-rose-900/30 text-rose-600 rounded-xl flex items-center justify-center"><ArrowDownRight size={20}/></div>
                    <h5 className="font-bold text-slate-500 dark:text-slate-400">صافي مديونية السلف</h5>
                  </div>
                  <p className="text-4xl font-black text-rose-600 dark:text-rose-400 tracking-tight">{Math.max(0, totals.loans - totals.repayments).toLocaleString()} <span className="text-sm font-bold text-slate-400">ج.م</span></p>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-teal-600 group-hover:scale-110 transition-transform"><Coins size={80}/></div>
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-teal-100 dark:bg-teal-900/30 text-teal-600 rounded-xl flex items-center justify-center"><Coins size={20}/></div>
                    <h5 className="font-bold text-slate-500 dark:text-slate-400">إجمالي العرابين المستلمة</h5>
                  </div>
                  <p className="text-4xl font-black text-teal-600 dark:text-teal-400 tracking-tight">{totals.advances.toLocaleString()} <span className="text-sm font-bold text-slate-400">ج.م</span></p>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 text-indigo-600 group-hover:scale-110 transition-transform"><WalletIcon size={80}/></div>
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-xl flex items-center justify-center"><WalletIcon size={20}/></div>
                    <h5 className="font-bold text-slate-500 dark:text-slate-400">إجمالي عهد الشركاء</h5>
                  </div>
                  <p className="text-4xl font-black text-indigo-600 dark:text-indigo-400 tracking-tight">{totals.custody.toLocaleString()} <span className="text-sm font-bold text-slate-400">ج.م</span></p>
                </div>
            </div>
        </div>
      </div>
      
      <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2">
          <User size={18} className="text-indigo-600" />
          <span>إضافة شريك جديد وتعيين صلاحياته وبيانات الدخول</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
            <div className="relative">
              <User className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                  type="text" 
                  value={partnerName}
                  onChange={(e) => setPartnerName(e.target.value)}
                  placeholder="اسم الشريك..."
                  className="w-full pr-10 py-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 focus:border-indigo-600 rounded-xl outline-none transition-all font-bold text-xs"
              />
            </div>

            <div className="relative">
              <Mail className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                  type="email" 
                  value={partnerEmail}
                  onChange={(e) => setPartnerEmail(e.target.value)}
                  placeholder="البريد الإلكتروني..."
                  className="w-full pr-10 py-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 focus:border-indigo-600 rounded-xl outline-none transition-all font-bold text-xs"
              />
            </div>

            <div className="relative">
              <Phone className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                  type="text" 
                  value={partnerPhone}
                  onChange={(e) => setPartnerPhone(e.target.value)}
                  placeholder="رقم الهاتف..."
                  className="w-full pr-10 py-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 focus:border-indigo-600 rounded-xl outline-none transition-all font-mono font-bold text-xs"
              />
            </div>

            <div className="relative flex items-center gap-1.5">
              <div className="relative flex-1">
                <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                    type="text" 
                    maxLength={6}
                    value={partnerPasscode}
                    onChange={(e) => setPartnerPasscode(e.target.value.replace(/\D/g, ''))}
                    placeholder="PIN (0000)"
                    className="w-full pr-10 pl-2 py-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 focus:border-indigo-600 rounded-xl outline-none transition-all font-bold text-xs"
                />
              </div>
              <button
                type="button"
                onClick={() => setPartnerPasscode(Math.floor(1000 + Math.random() * 9000).toString())}
                className="px-2.5 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 rounded-xl text-[10px] font-black text-slate-700 dark:text-slate-200 cursor-pointer"
                title="توليد PIN"
              >
                توليد
              </button>
            </div>

            <button 
              onClick={addPartner} 
              className="md:col-span-4 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-black transition-all flex items-center justify-center gap-2 text-xs cursor-pointer shadow-sm"
            >
                <Plus size={16} /> إضافة الشريك الجديد وتعيين حسابه
            </button>
        </div>
      </div>

      {/* المستشار الذكي لدليل الشركاء والمسحوبات */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-indigo-500/20 relative overflow-hidden space-y-6 my-6">
        <div className="absolute -left-10 -bottom-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 border-b border-indigo-800/60 pb-5">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-inner">
              <Info size={28} className="animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2 text-white">
                💡 الدليل الذكي لحسابات الشركاء والمسحوبات (نظام التعامل المبسط)
              </h3>
              <p className="text-xs sm:text-sm font-bold text-indigo-200/80 mt-1">
                تم تبسيط النظام بالكامل ليكون واضحاً وسهلاً لأي شخص يتعامل على الخزينة وحسابات الشركاء دون تعقيد محاسبي.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative z-10">
          <div className="bg-white/5 border border-white/10 p-4 rounded-2xl space-y-2 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-2 text-blue-300 font-black text-sm">
              <ArrowUpLeft size={18} className="text-blue-400" />
              <span>1️⃣ إيداعات التمويل ورأس المال (+)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-bold">
              أي مبالغ يضخها الشريك في المحل (سواء لزيادة رأس المال، أو شراء بضاعة، أو دفع مصاريف من جيبه، أو سداد سلفة سابقة). تزيد من رصيده وحقوقه في المحل وتُضاف للخزينة المحددة.
            </p>
          </div>

          <div className="bg-white/5 border border-white/10 p-4 rounded-2xl space-y-2 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-2 text-rose-300 font-black text-sm">
              <ArrowDownRight size={18} className="text-rose-400" />
              <span>2️⃣ المسحوبات والسلف الكاش (-)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-bold">
              أي أموال يسحبها الشريك من الخزينة لاستخدامه الشخصي أو كسلفة. يتم تقييدها فوراً كمسحوبات تُخصم من رصيده الجاري ومن الخزينة المحددة دون منع أو تعطيل للعملية.
            </p>
          </div>

          <div className="bg-white/5 border border-white/10 p-4 rounded-2xl space-y-2 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
              <Coins size={18} className="text-amber-400" />
              <span>3️⃣ الرصيد الصافي المتاح (له أم عليه)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-bold">
              إذا كان الرصيد <span className="text-emerald-400 font-black">أخضر (له بالمحل)</span> فهو يستحق هذا المبلغ ويمكنه سحبه. إذا كان <span className="text-rose-400 font-black">أحمر (عليه سلفة)</span> فهذا يعني أنه سحب سلفاً تتجاوز أرباحه وإيداعاته بالمحل.
            </p>
          </div>
        </div>
      </div>

      {/* 📊 التحليل المالي البصري والرسوم البيانية (Recharts Analytics) */}
      <div className="my-8 bg-white dark:bg-slate-800 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-700/60 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-2xl">
              <Activity size={24} />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-800 dark:text-white">التحليل البياني والبصري لحصص الشركاء</h3>
              <p className="text-xs font-bold text-slate-400">رسم بياني توضيحي لنسب ملكية الأرباح والمقارنة الماليّة المباشرة</p>
            </div>
          </div>
          <button
            onClick={() => setShowVisualAnalytics(!showVisualAnalytics)}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-200 font-bold text-xs rounded-xl hover:bg-slate-200 transition-colors"
          >
            {showVisualAnalytics ? 'إخفاء الرسوم البيانية' : 'عرض الرسوم البيانية'}
          </button>
        </div>

        {showVisualAnalytics && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-2">
            {/* Donut Chart: Shares */}
            <div className="bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-4">
              <h4 className="text-sm font-black text-slate-700 dark:text-slate-200 flex items-center gap-2">
                <PieChart size={16} className="text-indigo-600" /> توزيع نسب الشراكة والأرباح (%)
              </h4>
              {pieChartData.length > 0 ? (
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={pieChartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={85}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {pieChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                        ))}
                      </Pie>
                      <ReTooltip
                        formatter={(value: any) => [`${value}%`, 'نسبة الربح']}
                        contentStyle={{ backgroundColor: '#1e293b', borderRadius: '12px', border: 'none', color: '#fff' }}
                      />
                      <Legend />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-slate-400 text-xs font-bold">لا يوجد بيانات نسب محددة بعد</div>
              )}
            </div>

            {/* Bar Chart: Financial Snapshot */}
            <div className="bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-4">
              <h4 className="text-sm font-black text-slate-700 dark:text-slate-200 flex items-center gap-2">
                <TrendingUp size={16} className="text-emerald-600" /> مقارنة رؤوس الأموال والأرباح والمسحوبات لكل شريك (ج.م)
              </h4>
              {barChartData.length > 0 ? (
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ReBarChart data={barChartData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <ReTooltip
                        contentStyle={{ backgroundColor: '#1e293b', borderRadius: '12px', border: 'none', color: '#fff' }}
                      />
                      <Legend />
                      <Bar dataKey="رأس المال" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="الأرباح الموزعة" fill="#10b981" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="المسحوبات والسلف" fill="#f43f5e" radius={[6, 6, 0, 0]} />
                    </ReBarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-slate-400 text-xs font-bold">لا توجد بيانات شركاء مفرزة بعد</div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 🔍 شريط البحث والتصفية المتقدم للشركاء */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="بحث باسم الشريك..."
            className="w-full pr-11 pl-4 py-3 bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs font-bold outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex bg-slate-100 dark:bg-slate-900 p-1.5 rounded-2xl w-full md:w-auto overflow-x-auto">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-xl font-bold text-xs whitespace-nowrap transition-all ${filterStatus === 'all' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}
          >
            الكل ({partners.length})
          </button>
          <button
            onClick={() => setFilterStatus('positive')}
            className={`px-4 py-2 rounded-xl font-bold text-xs whitespace-nowrap transition-all ${filterStatus === 'positive' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}
          >
            🟢 له مستحقات
          </button>
          <button
            onClick={() => setFilterStatus('loan')}
            className={`px-4 py-2 rounded-xl font-bold text-xs whitespace-nowrap transition-all ${filterStatus === 'loan' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}
          >
            🔴 عليه سلفة
          </button>
          <button
            onClick={() => setFilterStatus('custody')}
            className={`px-4 py-2 rounded-xl font-bold text-xs whitespace-nowrap transition-all ${filterStatus === 'custody' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}
          >
            🟡 بعهدة نقدية
          </button>
        </div>
      </div>

      <div className="flex justify-between items-center px-2">
        <h2 className="text-2xl font-black text-slate-800 dark:text-white">الشركاء والمركز المالي</h2>
        <span className="text-xs font-bold text-slate-400">عرض {filteredPartners.length} من {partners.length} شريك</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12">
        {filteredPartners.length === 0 ? (
          <div className="col-span-full bg-white dark:bg-slate-800 p-12 rounded-3xl text-center space-y-4 border border-slate-200 dark:border-slate-800">
            <Users2 size={48} className="mx-auto text-slate-400" />
            <p className="text-slate-500 font-bold">لا يوجد شركاء يطابقون خيارات البحث الحالية.</p>
          </div>
        ) : (
          filteredPartners.map((partner, index) => (
          <motion.div 
            key={partner.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300 group flex flex-col"
          >
            <div className="p-6 border-b border-slate-50 dark:border-slate-700/50">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-110 transition-transform">
                      <User size={30} />
                  </div>
                  <div className="space-y-1">
                    {editPartnerId === partner.id ? (
                      <div className="flex flex-col gap-2 bg-slate-50 dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                        <div className="flex flex-col gap-1">
                          <label className="text-[10px] font-bold text-slate-400">اسم الشريك</label>
                          <input 
                            value={editPartnerName} 
                            onChange={(e) => setEditPartnerName(e.target.value)} 
                            className="font-black text-sm bg-white dark:bg-slate-800 border-2 border-indigo-600/30 rounded-lg px-2 py-1 outline-none w-48"
                          />
                        </div>
                        <div className="flex flex-col gap-1">
                          <label className="text-[10px] font-bold text-slate-400">رمز المرور للبوابة (PIN)</label>
                          <input 
                            value={editPartnerPasscode} 
                            onChange={(e) => setEditPartnerPasscode(e.target.value.replace(/\D/g, ''))} 
                            className="font-black text-sm bg-white dark:bg-slate-800 border-2 border-indigo-600/30 rounded-lg px-2 py-1 outline-none w-48"
                            maxLength={6}
                          />
                        </div>
                        <div className="flex gap-2 mt-1">
                          <button onClick={savePartnerName} className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black px-2 py-1 rounded"><Check size={12}/> حفظ</button>
                          <button onClick={() => setEditPartnerId(null)} className="flex items-center gap-1 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-[10px] font-black px-2 py-1 rounded"><X size={12}/> إلغاء</button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col">
                        <h3 className="text-xl font-black text-slate-800 dark:text-white leading-none">
                            <Link to={`/store/${storeId}/partners/${partner.id}`} className="hover:text-indigo-600 transition-colors">{partner.name}</Link>
                        </h3>
                        <div className="flex items-center gap-2 mt-2 flex-wrap">
                           <span className="text-[10px] font-black bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full">شريك مؤسس</span>
                           {partner.profitRatio > 0 && (
                             <span className="text-[10px] font-black bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-full">نسبة {partner.profitRatio}%</span>
                           )}
                           <button
                             onClick={() => openPinModal(partner)}
                             className="text-[10px] font-black bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/30 dark:hover:bg-amber-900/50 text-amber-700 dark:text-amber-400 px-2.5 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition-colors border border-amber-300/40"
                             title="انقر لتغيير أو تعيين رمز PIN"
                           >
                             <Lock size={10} /> PIN: {partner.passcode || '0000'}
                             <span className="text-[9px] underline mr-1 text-amber-800 dark:text-amber-300">تعديل</span>
                           </button>
                           <button
                             onClick={() => copyPartnerPortalLink(partner)}
                             className="text-[10px] font-black bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200/50 dark:border-indigo-800/50 px-2.5 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition-colors"
                             title="نسخ رابط الدخول المباشر للبوابة"
                           >
                             <Share2 size={10} /> نسخ الرابط
                           </button>
                           <button
                             onClick={() => sharePartnerWhatsApp(partner)}
                             className="text-[10px] font-black bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 border border-emerald-200/50 dark:border-emerald-800/50 px-2.5 py-0.5 rounded-full flex items-center gap-1 cursor-pointer transition-colors"
                             title="مشاركة رابط البوابة ورمز PIN للشريك عبر واتساب"
                           >
                             <span>📲 واتساب</span>
                           </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => setSelectedPermissionsPartner(partner)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-xl transition-all" title="التحكم في صلاحيات الموظفين للشريك"><ShieldCheck size={16}/></button>
                    <button onClick={() => openPinModal(partner)} className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded-xl transition-all" title="تعيين وتعديل رمز PIN"><Lock size={16}/></button>
                    <button onClick={() => sharePartnerWhatsApp(partner)} className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-xl transition-all" title="إرسال الرابط والرمز عبر واتساب"><Share2 size={16}/></button>
                    <button onClick={() => setPreviewPartner(partner)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-xl transition-all" title="معاينة وطباعة كشف الحساب"><Printer size={16}/></button>
                    <button onClick={() => startEditPartner(partner)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-xl transition-all" title="تعديل"><Edit2 size={16}/></button>
                    <button onClick={() => {
                        setDialog({
                            isOpen: true,
                            title: 'تأكيد تصفية الحساب',
                            message: 'سيتم تسجيل حركة تسوية وإغلاق الرصيد مع الاحتفاظ بكل المعاملات السابقة للمراجعة. هل أنت متأكد؟',
                            onConfirm: () => {
                                const currentBalance = Number(partner.balance) || 0;
                                const settlementAmount = Math.abs(currentBalance);
                                const settlement: PartnerTransaction | null = settlementAmount > 0 ? {
                                    id: generateSafeId('pt_settlement'),
                                    partnerId: partner.id,
                                    type: currentBalance >= 0 ? 'profit_withdrawal' : 'repayment',
                                    amount: settlementAmount,
                                    date: new Date().toISOString(),
                                    note: `تسوية رصيد الشريك وإغلاق الحساب بدون حذف السجل السابق (${partner.name})`
                                } : null;
                                updateSettings({
                                    ...settings,
                                    partners: partners.map(p => p.id === partner.id ? {...p, balance: 0} : p),
                                    partnerTransactions: settlement ? [...transactions, settlement] : transactions
                                });
                                setDialog(null);
                                showToast('تم تصفية حساب الشريك بنجاح، يمكنك الآن حذفه.');
                            }
                        });
                    }} className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded-xl transition-all" title="تصفية الحساب"><Coins size={16}/></button>
                    <button onClick={() => deletePartner(partner.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all" title="حذف"><Trash2 size={16}/></button>
                </div>
              </div>
              
              {(() => {
                const pTxs = transactions.filter(t => t.partnerId === partner.id);
                const pCapital = pTxs.filter(t => ['capital_addition', 'supply_funding', 'shipping_funding', 'expense_coverage'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0) - pTxs.filter(t => t.type === 'capital_withdrawal').reduce((sum, t) => sum + (t.amount || 0), 0);
                const pDividends = pTxs.filter(t => t.type === 'profit_distribution').reduce((sum, t) => sum + (t.amount || 0), 0);
                const pWithdrawals = pTxs.filter(t => ['loan', 'profit_withdrawal', 'expense_repayment', 'internal_transfer_out', 'capital_withdrawal'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                const pRepayments = pTxs.filter(t => ['repayment', 'internal_transfer_in'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                const pNetWithdrawals = Math.max(0, pWithdrawals - pRepayments);
                const holderId = `part_${partner.id}`;
                const partnerHolders = (settings.cashHolders || []).filter((h: any) => 
                    h.userId === holderId || 
                    h.userId === partner.id || 
                    normalizeName(h.userName) === normalizeName(partner.name)
                );
                const partnerUserIds = [holderId, partner.id, ...partnerHolders.map(h => h.userId)];

                const partnerHandovers = allHandovers.filter(h => 
                    partnerUserIds.includes(h.fromUserId) || 
                    partnerUserIds.includes(h.toUserId) || 
                    h.toUserId === partner.id || 
                    h.toUserId === holderId || 
                    h.fromUserId === partner.id || 
                    h.fromUserId === holderId || 
                    normalizeName(h.toUserName || '').includes(normalizeName(partner.name)) || 
                    normalizeName(h.fromUserName || '').includes(normalizeName(partner.name))
                );

                const settlements = partnerHandovers.filter(h => 
                    h.toUserId === 'admin_deduction' || 
                    h.toUserId === 'admin_manual' ||
                    (h.toUserName && (h.toUserName.includes('خصم') || h.toUserName.includes('تصفية') || h.toUserName.includes('تسوية'))) ||
                    (h.notes && (h.notes.includes('خصم') || h.notes.includes('تصفية') || h.notes.includes('تسوية')))
                );
                const hasSettlement = settlements.length > 0;
                let holderSum = partnerHolders.reduce((sum, h) => sum + (h.currentBalance || 0), 0);

                let custodyAmt = 0;
                if (hasSettlement) {
                    const lastSettlement = settlements.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
                    const activeHandovers = partnerHandovers.filter(h => new Date(h.date).getTime() > new Date(lastSettlement.date).getTime());
                    const activeHandoverSum = activeHandovers.reduce((sum, h) => {
                        const isGive = partnerUserIds.includes(h.toUserId) || normalizeName(h.toUserName || '').includes(normalizeName(partner.name));
                        return isGive ? sum + (Number(h.amount) || 0) : sum - (Number(h.amount) || 0);
                    }, 0);
                    custodyAmt = Math.max(0, holderSum) + Math.max(0, activeHandoverSum);
                } else {
                    let handoverSum = partnerHandovers.reduce((sum, h) => {
                        const isGive = partnerUserIds.includes(h.toUserId) || normalizeName(h.toUserName || '').includes(normalizeName(partner.name));
                        return isGive ? sum + (Number(h.amount) || 0) : sum - (Number(h.amount) || 0);
                    }, 0);
                    custodyAmt = Math.max(holderSum, Math.max(0, handoverSum));
                    if (custodyAmt <= 0 && holderSum > 0) custodyAmt = holderSum;
                }
                custodyAmt = Math.max(0, custodyAmt);

                return (
                  <div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                        <div className="p-3 bg-blue-50/70 dark:bg-blue-950/20 rounded-2xl border border-blue-100 dark:border-blue-900/30">
                            <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase mb-0.5">رأس المال والاستثمار</p>
                            <p className="text-base font-black text-slate-800 dark:text-white">{pCapital.toLocaleString()} <span className="text-[10px] font-normal text-slate-400">ج.م</span></p>
                        </div>
                        <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                            <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase mb-0.5">الأرباح الموزعة له</p>
                            <p className="text-base font-black text-slate-800 dark:text-white">{pDividends.toLocaleString()} <span className="text-[10px] font-normal text-slate-400">ج.م</span></p>
                        </div>
                        <div className="p-3 bg-rose-50/70 dark:bg-rose-950/20 rounded-2xl border border-rose-100 dark:border-rose-900/30">
                            <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase mb-0.5">المسحوبات والسلف</p>
                            <p className="text-base font-black text-rose-600 dark:text-rose-400">-{pNetWithdrawals.toLocaleString()} <span className="text-[10px] font-normal opacity-70">ج.م</span></p>
                        </div>
                        <div className={`p-3 rounded-2xl border ${partner.balance >= 0 ? 'bg-indigo-50/90 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800/50' : 'bg-rose-50/90 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/50'}`}>
                            <p className="text-[10px] font-bold text-slate-400 uppercase mb-0.5 flex items-center justify-between">
                               <span>الرصيد الصافي المتاح</span>
                               <span className={`text-[9px] px-1.5 py-0.5 rounded font-black ${partner.balance >= 0 ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>{partner.balance >= 0 ? 'له بالمحل' : 'عليه سلفة'}</span>
                            </p>
                            <p className={`text-base font-black ${partner.balance >= 0 ? 'text-indigo-600 dark:text-indigo-300' : 'text-rose-600 dark:text-rose-300'}`}>
                                {partner.balance.toLocaleString()} <span className="text-[10px] font-normal opacity-70">ج.م</span>
                            </p>
                        </div>
                    </div>

                    {(() => {
                      const pExpenseCoverage = pTxs.filter(t => ['expense_coverage', 'shipping_funding', 'supply_funding'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                      const normPName = normalizeName(partner.name);
                      const pDirectExpenses = (wallet.transactions || []).filter(t => {
                        const isExp = t.type === 'سحب' && (t.category as string) !== 'pos_sale';
                        if (!isExp) return false;
                        if (t.details?.paidByPartnerId === partner.id) return true;
                        
                        // If it has a treasury or bank account ID, it is paid from treasury/bank, NOT the partner
                        const tAccId = t.details?.treasuryAccountId || (t as any).treasuryAccountId;
                        if (tAccId && tAccId !== '') return false;

                        const normPayer = normalizeName(t.details?.expensePaidBy || t.details?.payerName || '');
                        if (normPayer && normPayer === normPName) return true;

                        const normNote = normalizeName(t.note || '');
                        const hasExplicitPayerInNote = normNote.includes(`بواسطه ${normPName}`) || normNote.includes(`بواسطة ${normPName}`) || normNote.includes(`دفعهم ${normPName}`) || normNote.includes(`سداد ${normPName}`);
                        return hasExplicitPayerInNote;
                      }).reduce((sum, t) => {
                        const text = t.details?.expensePaidBy || t.note;
                        const regex = new RegExp(`(\\d+(?:\\.\\d+)?)\\s*دفعهم\\s*${partner.name}`, 'i');
                        const match = text?.match(regex);
                        if (match && parseFloat(match[1]) > 0) return sum + parseFloat(match[1]);
                        return sum + (Number(t.amount) || 0);
                      }, 0);
                      const grandTotalSpent = Math.max(pExpenseCoverage, pDirectExpenses);

                      if (grandTotalSpent <= 0) return null;
                      return (
                        <div className="mb-2 p-2.5 bg-teal-500/[0.06] dark:bg-teal-500/[0.04] rounded-2xl border border-teal-500/20 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 bg-teal-500/10 text-teal-600 rounded-lg">
                              <DollarSign size={14} />
                            </div>
                            <div>
                              <p className="text-[11px] font-black text-slate-700 dark:text-slate-200">إجمالي المصروفات والتغطيات المسددة بواسطة الشريك:</p>
                              <p className="text-[9.5px] font-bold text-slate-400">مبالغ سددها عن المحل وتم قيدها في حسابه</p>
                            </div>
                          </div>
                          <p className="text-sm font-black text-teal-600 dark:text-teal-400 font-mono">
                            {grandTotalSpent.toLocaleString()} ج.م
                          </p>
                        </div>
                      );
                    })()}

                    <div className="mt-2 p-3.5 bg-amber-500/[0.05] dark:bg-amber-500/[0.03] rounded-2xl border border-amber-500/15 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5">
                           <div className="p-2 bg-amber-500/10 text-amber-600 rounded-xl">
                             <Coins size={16} />
                           </div>
                           <div>
                             <p className="text-xs font-black text-slate-700 dark:text-slate-200">العهدة والنقدية التشغيلية طرف الشريك:</p>
                             <p className="text-[10px] font-bold text-slate-400">سائلة بعهدة الشريك (بانتظار التسوية كاش أو مسحوبات شخصية)</p>
                           </div>
                        </div>
                        <div className="flex items-center gap-3 justify-end">
                           <p className={`text-base font-black ${custodyAmt > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400'}`}>
                              {custodyAmt.toLocaleString()} ج.م
                           </p>
                           {custodyAmt > 0 && (
                             <button
                                 onClick={() => handleDeductPartnerCustodyDirectly(partner, custodyAmt)}
                                 className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white dark:bg-slate-700 dark:hover:bg-slate-600 font-black text-[11px] rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                                 title="تحويل العهدة إلى مسحوبات شخصية تُخصم من رصيد الشريك الدفتري (في حال تعذر ردها كاش)"
                             >
                                 <Coins size={13} className="text-amber-400" />
                                 تسوية العهدة كمسحوبات شخصية
                             </button>
                           )}
                        </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="flex-1 p-6 space-y-4">
                <div className="space-y-4">
                  <p className="text-xs font-black text-slate-400 uppercase tracking-widest px-1">التحكم في المعاملات</p>
                  
                  {activePartnerId !== partner.id ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <button 
                              onClick={() => {
                                setActivePartnerId(partner.id);
                                setTxCategoryTab('personal');
                                setTransactionType('loan');
                              }}
                              className="w-full flex items-center justify-center gap-2 bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white dark:bg-rose-950/40 dark:hover:bg-rose-600 dark:text-rose-400 font-black py-3.5 px-3 rounded-2xl border-2 border-rose-200 dark:border-rose-900/60 transition-all shadow-sm group/btn text-xs"
                          >
                              <ArrowDownRight size={18} className="group-hover/btn:-translate-y-0.5 transition-transform flex-shrink-0" />
                              <span>💸 تسجيل سحب / سلفة (-)</span>
                          </button>

                          <button 
                              onClick={() => {
                                setActivePartnerId(partner.id);
                                setTxCategoryTab('capital');
                                setTransactionType('capital_addition');
                              }}
                              className="w-full flex items-center justify-center gap-2 bg-emerald-50 hover:bg-emerald-600 text-emerald-600 hover:text-white dark:bg-emerald-950/40 dark:hover:bg-emerald-600 dark:text-emerald-400 font-black py-3.5 px-3 rounded-2xl border-2 border-emerald-200 dark:border-emerald-900/60 transition-all shadow-sm group/btn text-xs"
                          >
                              <ArrowUpLeft size={18} className="group-hover/btn:-translate-y-0.5 transition-transform flex-shrink-0" />
                              <span>💰 إيداع تمويل / رأس مال (+)</span>
                          </button>
                      </div>
                  ) : (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      className="space-y-4 bg-slate-50 dark:bg-slate-900/90 p-5 rounded-3xl border-2 border-indigo-500/30 shadow-xl"
                    >
                        <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-700/60 pb-3">
                          <label className="text-sm font-black text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
                             {txCategoryTab === 'personal' ? <ArrowDownRight size={18} className="text-rose-500" /> : <ArrowUpLeft size={18} className="text-emerald-500" />}
                             {txCategoryTab === 'personal' ? `تسجيل سحب أو سلفة على الشريك: ${partner.name}` : `تسجيل إيداع أو تمويل من الشريك: ${partner.name}`}
                          </label>
                          <button onClick={() => setActivePartnerId(null)} className="text-slate-400 hover:text-red-500 p-1 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700"><X size={18}/></button>
                        </div>
                        
                        {/* Main Mode Toggles */}
                        <div className="grid grid-cols-2 gap-2 bg-slate-200/70 dark:bg-slate-800 p-1.5 rounded-2xl">
                          <button 
                            type="button"
                            onClick={() => { setTxCategoryTab('personal'); setTransactionType('loan'); }}
                            className={`py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${txCategoryTab === 'personal' ? 'bg-rose-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-300 hover:bg-white/50 dark:hover:bg-slate-700'}`}
                          >
                            <span>💸 سحب أموال (سلفة / مسحوبات)</span>
                          </button>
                          <button 
                            type="button"
                            onClick={() => { setTxCategoryTab('capital'); setTransactionType('capital_addition'); }}
                            className={`py-2.5 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${txCategoryTab !== 'personal' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-600 dark:text-slate-300 hover:bg-white/50 dark:hover:bg-slate-700'}`}
                          >
                            <span>💰 ضخ أموال (رأس مال / تمويل)</span>
                          </button>
                        </div>

                        <div className="space-y-3 pt-1">
                            <p className="text-[11px] font-black text-slate-500 dark:text-slate-400 px-1">اختر نوع العملية والمسمى المحاسبي الدقيق:</p>
                            
                            <div className="grid grid-cols-1 gap-2">
                              {txCategoryTab === 'personal' ? [
                                { key: 'loan', label: '1️⃣ سلفة شخصية / سحب كاش عام (-)', desc: 'يُخصم مباشرة من رصيده الجاري ومن الخزينة المحددة.', icon: ArrowDownRight, badge: 'سحب كاش مباشر', badgeColor: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' },
                                { key: 'profit_withdrawal', label: '2️⃣ سحب من أرباحه الموزعة (-)', desc: 'سحب نقدي من نصيبه في الأرباح السابقة التي تم توزيعها له بالمحل.', icon: DollarSign, badge: 'سحب أرباح', badgeColor: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' },
                                { key: 'capital_withdrawal', label: '3️⃣ سحب من رأس المال (تخفيض حصة) (-)', desc: 'سحب مبلغ من رأس المال الأساسي المسجل للشريك (تخفيض الحصة الاستثمارية).', icon: ArrowDownRight, badge: 'تخفيض رأس مال', badgeColor: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300' },
                                { key: 'expense_repayment', label: '4️⃣ استرداد مقابل مصروفات دفعها للمحل (-)', desc: 'رد مبلغ نقدي للشريك كان قد صرفه من جيبه الخاص على فواتير أو مصروفات المحل.', icon: Check, badge: 'رد مصاريف', badgeColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300' }
                              ].map(type => (
                                <div 
                                  key={type.key}
                                  onClick={() => setTransactionType(type.key as any)}
                                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col gap-1.5 ${
                                    transactionType === type.key 
                                      ? 'border-rose-500 bg-rose-500/10 dark:bg-rose-500/20 shadow-md' 
                                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600'
                                  }`}
                                >
                                  <div className="flex items-center justify-between">
                                     <span className={`font-black text-xs sm:text-sm flex items-center gap-2 ${transactionType === type.key ? 'text-rose-600 dark:text-rose-400' : 'text-slate-800 dark:text-white'}`}>
                                        <type.icon size={18} className="flex-shrink-0" />
                                        {type.label}
                                     </span>
                                     <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${type.badgeColor}`}>{type.badge}</span>
                                  </div>
                                  <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400 pr-6 leading-relaxed">{type.desc}</p>
                                </div>
                              )) : [
                                { key: 'capital_addition', label: '1️⃣ إيداع رأس مال / زيادة حصة استثمارية (+)', desc: 'ضخ سيولة لزيادة رأس مال المحل وحصته الثابتة (لا يتأثر بالسحب اليومي).', icon: ArrowUpLeft, badge: 'رأس مال ثابت', badgeColor: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' },
                                { key: 'repayment', label: '2️⃣ سداد سلفة / إرجاع كاش للمحل (+)', desc: 'إرجاع الشريك لمبلغ سلفة أو كاش كان قد سحبه سابقاً من المحل.', icon: Check, badge: 'سداد سلفة', badgeColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300' },
                                { key: 'supply_funding', label: '3️⃣ تمويل شراء بضاعة ومخزون (تمويل البضائع) (+)', desc: 'دفع الشريك سيولة من ماله الخاص لشراء بضاعة ومخزون جديد للمحل.', icon: PackageIcon, badge: 'تمويل بضاعة', badgeColor: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300' },
                                { key: 'shipping_funding', label: '4️⃣ تغطية مصروفات تشغيلية أو شحن (+)', desc: 'دفع الشريك فواتير شحن أو مصروفات تشغيلية عن المحل من جيبه الخاص.', icon: Truck, badge: 'مصروفات وشحن', badgeColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300' }
                              ].map(type => (
                                <div 
                                  key={type.key}
                                  onClick={() => setTransactionType(type.key as any)}
                                  className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col gap-1.5 ${
                                    transactionType === type.key 
                                      ? 'border-emerald-500 bg-emerald-500/10 dark:bg-emerald-500/20 shadow-md' 
                                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600'
                                  }`}
                                >
                                  <div className="flex items-center justify-between">
                                     <span className={`font-black text-xs sm:text-sm flex items-center gap-2 ${transactionType === type.key ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-800 dark:text-white'}`}>
                                        <type.icon size={18} className="flex-shrink-0" />
                                        {type.label}
                                     </span>
                                     <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${type.badgeColor}`}>{type.badge}</span>
                                  </div>
                                  <p className="text-[11px] font-bold text-slate-500 dark:text-slate-400 pr-6 leading-relaxed">{type.desc}</p>
                                </div>
                              ))}
                            </div>
                            
                            {/* Amount Input */}
                            <div className="pt-2">
                              <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-1.5">المبلغ المطلوب تسجيله (ج.م):</label>
                              <input 
                                  type="number"
                                  value={transactionAmount}
                                  onChange={(e) => setTransactionAmount(e.target.value)}
                                  placeholder="0.00"
                                  className="w-full p-4 bg-white dark:bg-slate-800 border-2 border-indigo-400 dark:border-indigo-600 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-500/20 font-black text-center text-xl text-slate-900 dark:text-white shadow-inner"
                                  autoFocus
                              />
                            </div>

                            {/* Optional Treasury Account Selection */}
                            {treasury && (
                              <div className="space-y-1.5 pt-1">
                                <label className="block text-xs font-black text-slate-700 dark:text-slate-300 text-right flex items-center gap-1.5">
                                   <span>🏦 الخزينة أو الحساب المالي المستخدم (لتسجيل حركة الكاش الفعلية):</span>
                                </label>
                                <select
                                  value={selectedTreasuryId}
                                  onChange={(e) => setSelectedTreasuryId(e.target.value)}
                                  className="w-full bg-white dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 p-3.5 rounded-2xl font-bold text-xs focus:outline-none focus:border-indigo-500 text-right dark:text-white shadow-sm"
                                >
                                  <option value="">📋 تسجيل دفتري / حساب جاري فقط (بدون سحب أو إيداع من خزائن المحل الفعلية)</option>
                                  <option value="central_wallet" className="text-indigo-600 font-black">
                                    💳 المحفظة الماليّة المركزيّة (الرصيد الأساسي) — (الرصيد حالياً: {Math.max(0, walletBalance - hidden).toLocaleString()} ج.م)
                                  </option>
                                  {(Array.isArray(treasury.accounts) ? treasury.accounts : Object.values(treasury.accounts || {})).map((acc: any) => (
                                    <option key={acc.id} value={acc.id}>
                                      🏦 {acc.name} — (الرصيد المتاح حالياً: {acc.balance.toLocaleString()} ج.م)
                                    </option>
                                  ))}
                                </select>
                              </div>
                            )}

                            <button 
                              type="button"
                              onClick={() => {
                                if (!transactionAmount) return;
                                addTransaction(partner.id);
                                setActivePartnerId(null);
                              }} 
                              className={`w-full text-white p-4 rounded-2xl font-black transition-all shadow-lg text-sm sm:text-base cursor-pointer flex items-center justify-center gap-2 mt-3 ${
                                txCategoryTab === 'personal'
                                  ? 'bg-rose-600 hover:bg-rose-700 shadow-rose-500/25'
                                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/25'
                              }`}
                            >
                              <Check size={20} />
                              <span>{txCategoryTab === 'personal' ? 'تأكيد خصم السحب من حساب الشريك والخزينة' : 'تأكيد إضافة التمويل لحساب الشريك والخزينة'}</span>
                            </button>
                        </div>
                    </motion.div>
                  )}

                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-4 rounded-2xl space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-500">نسبة الشراكة (الربح)</span>
                        <span className="text-sm font-black text-indigo-600 dark:text-indigo-400">{partner.profitRatio || 0}%</span>
                      </div>
                      <input 
                        type="range"
                        min="0"
                        max="100"
                        value={partner.profitRatio || 0}
                        onChange={(e) => {
                          const val = parseInt(e.target.value);
                          updateSettings({
                            ...settings,
                            partners: partners.map(p => p.id === partner.id ? {...p, profitRatio: val} : p)
                          });
                        }}
                        className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full appearance-none cursor-pointer accent-indigo-600"
                      />

                      <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60 space-y-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-bold text-slate-500">رأس المال / الاستثمار</span>
                          <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 font-mono">{((partner.capital || partner.initialCapital || 0)).toLocaleString()} ج.م</span>
                        </div>
                        <div className="relative">
                          <input 
                            type="number"
                            placeholder="أدخل رأس المال أو الاستثمار"
                            value={partner.capital ?? ''}
                            onChange={(e) => {
                              const val = e.target.value === '' ? 0 : parseFloat(e.target.value);
                              updateSettings({
                                ...settings,
                                partners: partners.map(p => p.id === partner.id ? {...p, capital: val, initialCapital: val} : p)
                              });
                            }}
                            className="w-full text-xs font-bold font-mono px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        </div>
                      </div>
                  </div>
                  
                  <div className="space-y-3 pt-2">
                      <div className="flex justify-between items-center px-1">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">آخر 3 معاملات</p>
                          <Link to={`/store/${storeId}/partners/${partner.id}`} className="text-[10px] font-black text-indigo-600 hover:underline">عرض الكل</Link>
                      </div>
                      <div className="space-y-2">
                        {transactions
                          .filter(t => t.partnerId === partner.id)
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .slice(0, 3)
                          .map(t => (
                              <div key={t.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-slate-200 dark:border-slate-800/50">
                                  <div className="flex items-center gap-3">
                                      <div className={`p-1.5 rounded-lg ${
                                        ['capital_addition', 'repayment', 'supply_funding', 'expense_coverage'].includes(t.type) 
                                          ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600' 
                                          : 'bg-rose-100 dark:bg-rose-900/30 text-rose-600'
                                      }`}>
                                        {['loan', 'customer_advance'].includes(t.type) ? <ArrowDownRight size={12}/> : 
                                         t.type === 'capital_addition' ? <ArrowUpLeft size={12}/> : 
                                         t.type === 'shipping_funding' ? <Truck size={12}/> : 
                                         t.type === 'repayment' ? <Check size={12}/> : 
                                         t.type === 'expense_repayment' ? <Check size={12}/> :
                                         t.type === 'expense_coverage' ? <DollarSign size={12}/> :
                                         t.type === 'supply_funding' ? <PackageIcon size={12}/> : <DollarSign size={12}/>}
                                      </div>
                                      <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400">
                                        {(t.note?.includes('عهدة') || t.note?.includes('عهده') || t.note?.includes('تسوية عهدة') || t.note?.includes('خصم عهدة') || t.notes?.includes('عهدة') || t.notes?.includes('عهده')) ? 'تسوية عهدة' : t.type === 'loan' ? 'سلفة' : t.type === 'customer_advance' ? 'عربون محصل' : t.type === 'capital_addition' ? 'رأس مال' : t.type === 'shipping_funding' ? 'شحن' : t.type === 'profit_withdrawal' ? 'سحب أرباح' : t.type === 'profit_distribution' ? 'إضافة أرباح' : t.type === 'supply_funding' ? 'تمويل بضاعة' : t.type === 'expense_coverage' ? (t.note?.includes('توريد') ? 'مصاريف توريد' : 'تغطية مصروفات') : t.type === 'expense_repayment' ? 'رد مصروفات' : 'سداد'}
                                      </span>
                                  </div>
                                  <span className={`text-[10px] font-black ${['capital_addition', 'repayment', 'supply_funding', 'shipping_funding', 'profit_distribution', 'expense_coverage'].includes(t.type) ? 'text-emerald-600' : 'text-rose-600'}`}>
                                      {['loan', 'profit_withdrawal', 'expense_repayment'].includes(t.type) ? '-' : '+'}{t.amount.toLocaleString()} 
                                      <span className="text-[10px] ml-1">ج.م</span>
                                  </span>
                              </div>
                          ))}
                        {transactions.filter(t => t.partnerId === partner.id).length === 0 && (
                          <div className="text-center py-4 text-slate-400 text-[10px] font-medium italic">
                            لا توجد معاملات مسجلة بعد
                          </div>
                        )}
                      </div>
                  </div>
                </div>
            </div>
          </motion.div>
        )))
        }
      </div>

      <h2 className="text-2xl font-black text-slate-800 dark:text-white px-2 mt-8">سجل توزيعات الأرباح السابقة</h2>
      <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm mb-12">
          {(() => {
              const profitDistributions = transactions
                  .filter(t => t.type === 'profit_distribution' || t.type === 'profit_withdrawal')
                  .sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
              
              if (profitDistributions.length === 0) {
                  return <div className="text-center py-8 text-slate-400 font-bold">لا يوجد توزيعات أرباح سابقة.</div>;
              }

              return (
                  <div className="overflow-x-auto">
                      <table className="w-full text-right">
                          <thead>
                              <tr className="border-b border-slate-200 dark:border-slate-700/50 text-slate-500 text-sm">
                                  <th className="py-3 px-4 font-bold">التاريخ</th>
                                  <th className="py-3 px-4 font-bold">الشريك</th>
                                  <th className="py-3 px-4 font-bold">المبلغ</th>
                                  <th className="py-3 px-4 font-bold">ملاحظات</th>
                              </tr>
                          </thead>
                          <tbody>
                              {profitDistributions.map(t => {
                                  const partner = partners.find(p => p.id === t.partnerId);
                                  return (
                                      <tr key={t.id} className="border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-900/50 transition-colors">
                                          <td className="py-4 px-4 text-sm font-bold text-slate-700 dark:text-slate-300">{new Date(t.date).toLocaleString('ar-EG')}</td>
                                          <td className="py-4 px-4 font-black text-indigo-600 dark:text-indigo-400">{partner?.name || 'شريك محذوف'}</td>
                                          <td className="py-4 px-4 font-black text-emerald-600 dark:text-emerald-400">
                                              {t.amount.toLocaleString()} ج.م
                                          </td>
                                          <td className="py-4 px-4 text-sm text-slate-500">{t.note}</td>
                                      </tr>
                                  );
                              })}
                          </tbody>
                      </table>
                  </div>
              );
          })()}
      </div>
      </div>
      )}

      {activeSection === 'simulator' && (
      <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
        <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-indigo-600 dark:text-indigo-400 rotate-12 scale-150">
               <Calculator size={150} />
            </div>
            
            <div className="relative z-10 max-w-4xl space-y-8">
               <div className="space-y-2">
                   <h2 className="text-2xl font-black text-slate-800 dark:text-white flex items-center gap-3">
                      <Sparkles className="text-amber-500" /> محاكاة وتوقع الأرباح
                   </h2>
                   <p className="text-slate-500 font-medium">قم بإدخال مبلغ أرباح افتراضي لحساب حصة كل شريك بناءً على النسب المحددة حالياً والمبالغ الاحتياطية.</p>
               </div>

               <div className="grid md:grid-cols-2 gap-8">
                   <div className="space-y-6 bg-slate-50 dark:bg-slate-900/50 p-6 rounded-3xl border border-slate-200 dark:border-slate-800/80">
                       <div>
                           <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">إجمالي الأرباح المتوقعة (ج.م)</label>
                           <input 
                               type="number" 
                               value={simProfitAmount}
                               onChange={e => setSimProfitAmount(e.target.value)}
                               placeholder="أدخل مبلغ المحاكاة..."
                               className="w-full px-6 py-4 bg-white dark:bg-slate-800 border-2 border-transparent focus:border-indigo-600/30 rounded-2xl outline-none transition-all font-black text-xl"
                           />
                       </div>

                       <div>
                           <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2 flex items-center justify-between">
                               <span>نسبة الاحتياطي للطوارئ (%)</span>
                               <span className="text-indigo-600 font-black">{reserveRatio}%</span>
                           </label>
                           <input 
                               type="range"
                               min="0" max="100" step="1"
                               value={reserveRatio}
                               onChange={e => setReserveRatio(Number(e.target.value))}
                               className="w-full accent-indigo-600"
                           />
                           <p className="text-xs text-slate-400 mt-2 font-medium">سيتم استقطاع هذه النسبة قبل توزيع الباقي على الشركاء.</p>
                       </div>
                   </div>

                   {(() => {
                       const amount = Number(simProfitAmount) || 0;
                       const reserveAmt = (amount * reserveRatio) / 100;
                       const distributedAmt = amount - reserveAmt;

                       return (
                       <div className="space-y-6">
                           <div className="grid grid-cols-2 gap-4">
                               <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 p-5 rounded-2xl">
                                  <p className="text-xs font-bold text-amber-600 dark:text-amber-500 mb-1 flex items-center gap-2"><Shield size={14}/> احتياطي محتجز</p>
                                  <p className="text-2xl font-black text-amber-700 dark:text-amber-400">{reserveAmt.toLocaleString()} <span className="text-sm">ج.م</span></p>
                               </div>
                               <div className="bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 p-5 rounded-2xl">
                                  <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400 mb-1 flex items-center gap-2"><Layers size={14}/> الرصيد الموزع</p>
                                  <p className="text-2xl font-black text-indigo-700 dark:text-indigo-400">{distributedAmt.toLocaleString()} <span className="text-sm">ج.م</span></p>
                               </div>
                           </div>

                           <div className="space-y-3">
                               <h3 className="text-sm font-black text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 pb-2">حصص الشركاء من التوزيع:</h3>
                               {partners.map(p => {
                                   const share = (distributedAmt * (p.profitRatio || 0)) / 100;
                                   return (
                                       <div key={p.id} className="flex justify-between items-center bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700/50">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-500">
                                                   <User size={14}/>
                                                </div>
                                                <div>
                                                   <p className="font-bold text-slate-800 dark:text-white">{p.name}</p>
                                                   <p className="text-[10px] text-slate-400 font-black">{p.profitRatio}%</p>
                                                </div>
                                            </div>
                                            <p className="font-black text-emerald-600 dark:text-emerald-400 text-lg">
                                               {share > 0 ? '+' : ''}{share.toLocaleString()} <span className="text-xs font-bold text-slate-400">ج.م</span>
                                            </p>
                                       </div>
                                   );
                               })}
                               {partners.length === 0 && <p className="text-xs text-slate-400 text-center py-4">لا يوجد شركاء لعرضهم</p>}
                           </div>
                       </div>
                       );
                   })()}
               </div>
            </div>
        </div>
      </div>
      )}

      {activeSection === 'transfers' && (
      <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
         <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-indigo-600 dark:text-indigo-400 rotate-12 scale-150">
               <ArrowRightLeft size={150} />
            </div>
            
            <div className="relative z-10 max-w-4xl space-y-8">
               <div className="space-y-2">
                   <h2 className="text-2xl font-black text-slate-800 dark:text-white flex items-center gap-3">
                      <ArrowRightLeft className="text-indigo-500" /> التحويلات الداخلية بين الشركاء
                   </h2>
                   <p className="text-slate-500 font-medium">تسجيل عملية نقل حصص استثمارية أو تحويل المديونيات والأرصدة من صندوق شريك لآخر بشكل مباشر دون كاش.</p>
               </div>

               <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-3xl border border-slate-200 dark:border-slate-800/80 space-y-8">
                   <div className="grid md:grid-cols-2 gap-6 relative">
                       {/* Line connector for visual effect */}
                       <div className="hidden md:block absolute top-[60%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white dark:bg-slate-800 rounded-full border-2 border-slate-200 dark:border-slate-700 z-10 flex items-center justify-center text-slate-400">
                          <ArrowRightLeft size={14} />
                       </div>

                       <div>
                           <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">من الشريك (المُحَوِّل)</label>
                           <select 
                               value={fromPartnerId}
                               onChange={e => setFromPartnerId(e.target.value)}
                               className="w-full px-6 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-indigo-600/30 rounded-2xl outline-none transition-all font-bold"
                           >
                               <option value="">-- اختر الشريك --</option>
                               {partners.map(p => (
                                   <option key={`from-${p.id}`} value={p.id}>{p.name} (المتاح: {p.balance.toLocaleString()})</option>
                               ))}
                           </select>
                       </div>

                       <div>
                           <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">إلى الشريك (المُستَقبِل)</label>
                           <select 
                               value={toPartnerId}
                               onChange={e => setToPartnerId(e.target.value)}
                               className="w-full px-6 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-indigo-600/30 rounded-2xl outline-none transition-all font-bold"
                           >
                               <option value="">-- اختر الشريك --</option>
                               {partners.map(p => (
                                   <option key={`to-${p.id}`} value={p.id}>{p.name}</option>
                               ))}
                           </select>
                       </div>
                   </div>

                   <div className="grid md:grid-cols-2 gap-6">
                       <div>
                           <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">نوع التحويل والمبلغ المراد</label>
                           <div className="flex bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl overflow-hidden mb-3">
                               <button 
                                   onClick={() => setTransferType('balance')}
                                   className={`flex-1 py-3 text-sm font-bold transition-colors ${transferType === 'balance' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/80'}`}
                               >
                                   رصيد دائن (ج.م)
                               </button>
                               <button 
                                   onClick={() => setTransferType('capital')}
                                   className={`flex-1 py-3 text-sm font-bold transition-colors border-r border-slate-200 dark:border-slate-700 ${transferType === 'capital' ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/80'}`}
                               >
                                   حصة رأس مال (%)
                               </button>
                           </div>
                           <div className="relative">
                               <input 
                                   type="number" 
                                   value={transferAmount}
                                   onChange={e => setTransferAmount(e.target.value)}
                                   placeholder={`المبلغ بـ ${transferType === 'capital' ? '%' : 'جنيه'}`}
                                   className="w-full px-6 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-indigo-600/30 rounded-2xl outline-none transition-all font-black"
                               />
                               <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                                  {transferType === 'capital' ? '%' : 'ج.م'}
                               </span>
                           </div>
                       </div>

                       <div className="flex flex-col h-full">
                           <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">ملاحظات وسبب التحويل</label>
                           <textarea 
                               value={transferNotes}
                               onChange={e => setTransferNotes(e.target.value)}
                               placeholder="شرح سبب النقل والتحويل للتوثيق..."
                               className="w-full h-full min-h-[100px] px-6 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-indigo-600/30 rounded-2xl outline-none transition-all resize-none text-sm font-medium"
                           ></textarea>
                       </div>
                   </div>

                   <button 
                       onClick={executeTransfer}
                       className="w-full py-4 rounded-2xl font-black text-white bg-indigo-600 hover:bg-indigo-700 shadow-xl shadow-indigo-500/25 transition-all outline-none"
                   >
                       تأكيد واعتماد التحويل
                   </button>
               </div>
            </div>
         </div>
      </div>
      )}

       {activeSection === 'valuation' && (
        <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
          {/* 🛡️ تقييم المركز المالي الشامل للمشروع */}
          <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-700/60 pb-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-2xl flex items-center justify-center shadow-inner">
                  <Sparkles size={28} />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-slate-800 dark:text-white leading-none">تقييم القيمة الكلية للمشروع (Business Valuation)</h2>
                  <p className="text-xs font-bold text-slate-400 mt-2">جرد شامل للأصول السائلة، البضاعة، والأرباح المحتجزة للوقوف على مركز مالي دقيق.</p>
                </div>
              </div>
              <div className="bg-indigo-50 dark:bg-indigo-900/20 px-6 py-3 rounded-2xl border border-indigo-100 dark:border-indigo-800/50">
                 <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase block mb-0.5">القيمة الكلية التقديرية للمشروع</span>
                 <p className="text-2xl font-black text-slate-800 dark:text-white tabular-nums">{(availableLiquidity + inventoryValue).toLocaleString()} <span className="text-xs font-normal">ج.م</span></p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Card 1: Inventory */}
              <div className="p-6 bg-amber-50/50 dark:bg-amber-950/10 border border-amber-100 dark:border-amber-900/30 rounded-3xl relative overflow-hidden group">
                <div className="absolute -right-4 -bottom-4 opacity-5 text-amber-600 group-hover:scale-110 transition-transform"><PackageIcon size={120} /></div>
                <h4 className="text-xs font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-4">📦 قيمة البضاعة الحالية (بالمخزن)</h4>
                <div className="space-y-1">
                  <p className="text-3xl font-black text-slate-800 dark:text-white">{inventoryValue.toLocaleString()} <span className="text-xs font-normal text-slate-400">ج.م</span></p>
                  <p className="text-[10px] font-bold text-slate-400">القيمة بناءً على تكلفة الشراء الأصلية لـ {settings.products?.length || 0} صنف</p>
                </div>
              </div>

              {/* Card 2: Liquidity */}
              <div className="p-6 bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-100 dark:border-emerald-900/30 rounded-3xl relative overflow-hidden group">
                <div className="absolute -right-4 -bottom-4 opacity-5 text-emerald-600 group-hover:scale-110 transition-transform"><WalletIcon size={120} /></div>
                <h4 className="text-xs font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-4">💰 إجمالي السيولة والكاش المتاح</h4>
                <div className="space-y-1">
                  <p className="text-3xl font-black text-slate-800 dark:text-white">{availableLiquidity.toLocaleString()} <span className="text-xs font-normal text-slate-400">ج.m</span></p>
                  <p className="text-[10px] font-bold text-slate-400">يشمل رصيد المحفظة المركزية ({Math.max(0, (wallet.balance || 0) - (settings.enableHiddenWalletAmount ? (settings.hiddenWalletAmount || 0) : 0)).toLocaleString()} ج.م) + الخزائن الفرعية</p>
                </div>
              </div>

              {/* Card 3: Undistributed Profit */}
              <div className="p-6 bg-indigo-50/50 dark:bg-indigo-950/10 border border-indigo-100 dark:border-indigo-900/30 rounded-3xl relative overflow-hidden group">
                <div className="absolute -right-4 -bottom-4 opacity-5 text-indigo-600 group-hover:scale-110 transition-transform"><TrendingUp size={120} /></div>
                <h4 className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest mb-4">📈 الأرباح المحتجزة (غير الموزعة)</h4>
                <div className="space-y-1">
                  <p className="text-3xl font-black text-slate-800 dark:text-white">{undistributedProfit.toLocaleString()} <span className="text-xs font-normal text-slate-400">ج.م</span></p>
                  <p className="text-[10px] font-bold text-slate-400">صافي الأرباح التشغيلية المتراكمة بعد المصاريف والخسائر والتي لم تُوزع بعد</p>
                </div>
              </div>
            </div>

            {/* 📊 توزيع الحصص حسب الشركاء */}
            <div className="space-y-4">
               <h3 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-2 px-2">
                 <Users2 size={20} className="text-indigo-600" /> تحليل نصيب كل شريك من القيمة الفعلية (السيولة + البضاعة)
               </h3>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {partners.map(partner => {
                    const pTxs = transactions.filter(t => t.partnerId === partner.id);
                    const pCapital = pTxs.filter(t => ['capital_addition', 'supply_funding', 'shipping_funding', 'expense_coverage'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                    
                    // Share of Undistributed Profit
                    const profitShare = (undistributedProfit * (partner.profitRatio / 100));
                    
                    // Total "Daftari" Rights (Capital + Profit Share + Current Balance Adjustments)
                    const totalRights = partner.balance + profitShare;
                    
                    // Proportion of Current Inventory (Based on Profit Ratio or Capital? Usually Profit Ratio for ongoing, Capital for liquidation)
                    // Let's show both or a combined view
                    const inventoryShare = (inventoryValue * (partner.profitRatio / 100));

                    return (
                      <div key={`val-${partner.id}`} className="bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 p-6 rounded-[2rem] hover:border-indigo-300 transition-all group">
                         <div className="flex justify-between items-center mb-6">
                            <div className="flex items-center gap-3">
                               <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center border border-slate-200 dark:border-slate-700 font-black text-indigo-600">
                                  {partner.name.charAt(0)}
                               </div>
                               <div>
                                  <h4 className="font-black text-slate-800 dark:text-white">{partner.name}</h4>
                                  <p className="text-[10px] font-bold text-slate-400">نسبة الربح: {partner.profitRatio}%</p>
                               </div>
                            </div>
                            <div className="text-right">
                               <span className="text-[10px] font-black text-slate-400 block mb-0.5">القيمة التقديرية لنصيبه</span>
                               <span className="text-xl font-black text-indigo-600 dark:text-indigo-400">{(partner.balance + profitShare + inventoryShare).toLocaleString()} ج.م</span>
                            </div>
                         </div>

                         <div className="grid grid-cols-2 gap-3 text-[11px]">
                            <div className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700/50">
                               <span className="text-slate-400 block mb-1">نصيبه من الكاش والسيولة:</span>
                               <span className="font-black text-slate-800 dark:text-white">{(partner.balance + profitShare).toLocaleString()} ج.م</span>
                               <p className="text-[9px] text-slate-500 mt-1">(رصيد جاري + نصيب أرباح غير موزعة)</p>
                            </div>
                            <div className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700/50">
                               <span className="text-slate-400 block mb-1">نصيبه من قيمة البضاعة:</span>
                               <span className="font-black text-slate-800 dark:text-white">{inventoryShare.toLocaleString()} ج.م</span>
                               <p className="text-[9px] text-slate-500 mt-1">(حصة عينية في المخزن الحالي)</p>
                            </div>
                         </div>

                         {/* Action: Settle / Liquidate */}
                         <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800">
                            <button 
                              onClick={() => {
                                setExitModalPartnerId(partner.id);
                                setIsExitModalOpen(true);
                              }}
                              className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-rose-600 to-indigo-600 hover:opacity-90 text-white font-black text-xs rounded-xl transition-all shadow-sm cursor-pointer"
                            >
                               <LogOut size={14} /> حاسبة وتقرير تخارج الشريك ({partner.name})
                            </button>
                         </div>
                      </div>
                    );
                 })}
               </div>
            </div>

            {/* 📝 دليل التصفية والخروج */}
            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30 p-6 rounded-3xl space-y-4">
               <h4 className="text-sm font-black text-amber-800 dark:text-amber-400 flex items-center gap-2">
                 <HelpCircle size={18} /> كيف أصفي حساب شريك يرغب في التخارج (الرحيل)؟
               </h4>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs leading-relaxed text-amber-900/80 dark:text-amber-300/80">
                  <div className="space-y-3">
                     <p className="font-bold">1. حساب المستحقات (الحسبة الموضحة بالأعلى):</p>
                     <ul className="list-decimal list-inside space-y-1 pr-2">
                        <li>يُحسب رصيده الجاري (إيداعاته - مسحوباته).</li>
                        <li>يُضاف له نصيبه من الأرباح المحتجزة (Undistributed Profit).</li>
                        <li>يُضاف له نصيبه من قيمة البضاعة الحالية بالمخزن (Inventory Value).</li>
                     </ul>
                  </div>
                  <div className="space-y-3">
                     <p className="font-bold">2. إجراءات التنفيذ العملية:</p>
                     <ul className="list-decimal list-inside space-y-1 pr-2">
                        <li><span className="font-black underline">توزيع الأرباح:</span> قم بتوزيع الأرباح المحتجزة دفترياً أولاً لتصحيح رصيده.</li>
                        <li><span className="font-black underline">تسوية البضاعة:</span> سجل "إيداع تصفية بضاعة" برصيده ليعكس قيمتها نقداً له.</li>
                        <li><span className="font-black underline">سحب التصفية:</span> سجل "سحب تصفية نهائية" بكامل المبلغ من الخزينة.</li>
                     </ul>
                  </div>
               </div>
               <p className="text-[10px] font-bold text-amber-700/60 dark:text-amber-500/60 text-center border-t border-amber-200/50 dark:border-amber-900/50 pt-3 italic">
                 💡 ملاحظة: تصفية الشريك تعني أن المحل "يشتري" حصة الشريك الخارج، ويتحمل الشركاء الباقون قيمتها لزيادة حصصهم.
               </p>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'summary_table' && (
      <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
          <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
             <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-700/60 pb-6">
                <div>
                   <h2 className="text-2xl font-black text-slate-800 dark:text-white flex items-center gap-3">
                     <FileText className="text-indigo-600" /> المركز المالي المجمع وحسابات الشركاء
                   </h2>
                   <p className="text-sm font-bold text-slate-500 dark:text-slate-400 mt-1">كشف شامل يوضح رؤوس الأموال المستثمرة، الأرباح الموزعة، والمسحوبات الشخصية لكل شريك بالمحل.</p>
                </div>
                <button 
                  onClick={() => window.print()}
                  className="px-6 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 font-black text-xs rounded-2xl transition-all flex items-center gap-2 text-slate-700 dark:text-white"
                >
                  <Printer size={16} /> طباعة التقرير المجمع
                </button>
             </div>

             <div className="overflow-x-auto">
               <table className="w-full text-right border-collapse">
                 <thead>
                   <tr className="bg-slate-50 dark:bg-slate-900/50 text-slate-500 dark:text-slate-400 text-xs font-black border-y border-slate-200 dark:border-slate-700">
                     <th className="py-4 px-4">اسم الشريك</th>
                     <th className="py-4 px-4 text-center">نسبة الربح (%)</th>
                     <th className="py-4 px-4">رأس المال والاستثمار</th>
                     <th className="py-4 px-4">الأرباح الموزعة</th>
                     <th className="py-4 px-4">المسحوبات والسلف</th>
                     <th className="py-4 px-4">العهد التشغيلية طرفه</th>
                     <th className="py-4 px-4">الرصيد الصافي (له / عليه)</th>
                     <th className="py-4 px-4 text-center">إجراءات</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                   {partners.map(partner => {
                     const pTxs = transactions.filter(t => t.partnerId === partner.id);
                     const pCapital = pTxs.filter(t => ['capital_addition', 'supply_funding', 'shipping_funding', 'expense_coverage'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                     const pDividends = pTxs.filter(t => t.type === 'profit_distribution').reduce((sum, t) => sum + (t.amount || 0), 0);
                     const pWithdrawals = pTxs.filter(t => ['loan', 'profit_withdrawal', 'expense_repayment', 'internal_transfer_out'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                     const pRepayments = pTxs.filter(t => ['repayment', 'internal_transfer_in'].includes(t.type)).reduce((sum, t) => sum + (t.amount || 0), 0);
                     const pNetWithdrawals = Math.max(0, pWithdrawals - pRepayments);
                     const holderId = `part_${partner.id}`;
                     const holder = (settings.cashHolders || []).find((h: any) => h.userId === holderId || h.userId === partner.id);
                     const custodyAmt = holder ? holder.currentBalance || 0 : 0;

                     return (
                       <tr key={partner.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors">
                         <td className="py-4 px-4 font-black text-slate-800 dark:text-white flex items-center gap-2">
                           <div className="w-8 h-8 rounded-full bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 flex items-center justify-center font-black text-xs">
                             <User size={14} />
                           </div>
                           <span>{partner.name}</span>
                         </td>
                         <td className="py-4 px-4 text-center font-black text-indigo-600 dark:text-indigo-400">{partner.profitRatio || 0}%</td>
                         <td className="py-4 px-4 font-black text-blue-600 dark:text-blue-400">{pCapital.toLocaleString()} ج.م</td>
                         <td className="py-4 px-4 font-black text-emerald-600 dark:text-emerald-400">{pDividends.toLocaleString()} ج.م</td>
                         <td className="py-4 px-4 font-black text-rose-600 dark:text-rose-400">{pNetWithdrawals > 0 ? `-${pNetWithdrawals.toLocaleString()}` : '0'} ج.م</td>
                         <td className="py-4 px-4 font-black text-amber-600 dark:text-amber-400">{custodyAmt > 0 ? `${custodyAmt.toLocaleString()} ج.م` : '0'}</td>
                         <td className="py-4 px-4">
                           <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl font-black text-xs ${partner.balance >= 0 ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200' : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 border border-rose-200'}`}>
                              {partner.balance >= 0 ? '🟢 مستحق له: ' : '🔴 سلفة عليه: '}
                              {partner.balance.toLocaleString()} ج.م
                           </span>
                         </td>
                         <td className="py-4 px-4 text-center">
                           <div className="flex items-center justify-center gap-1.5">
                             <button
                               onClick={() => setPreviewPartner(partner)}
                               className="px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 dark:bg-slate-700 dark:hover:bg-indigo-900/40 text-slate-700 dark:text-slate-300 rounded-xl font-black text-xs inline-flex items-center gap-1 transition-all cursor-pointer"
                               title="معاينة وطباعة كشف الحساب"
                             >
                               <Printer size={13} />
                               <span>طباعة</span>
                             </button>
                             <Link
                               to={`/store/${storeId}/partners/${partner.id}`}
                               className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl font-black text-xs inline-flex items-center gap-1 transition-all"
                             >
                               <span>كشف تفصيلي</span>
                             </Link>
                           </div>
                         </td>
                       </tr>
                     );
                   })}
                 </tbody>
                 {partners.length > 0 && (
                   <tfoot>
                     <tr className="bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-white font-black text-sm border-t-2 border-slate-300 dark:border-slate-700">
                       <td className="py-4 px-4">إجمالي الشركة</td>
                       <td className="py-4 px-4 text-center">{partners.reduce((sum, p) => sum + (p.profitRatio || 0), 0)}%</td>
                       <td className="py-4 px-4 text-blue-600 dark:text-blue-400">
                         {partners.reduce((sum, p) => {
                           const pTxs = transactions.filter(t => t.partnerId === p.id);
                           return sum + pTxs.filter(t => ['capital_addition', 'supply_funding', 'shipping_funding', 'expense_coverage'].includes(t.type)).reduce((s, t) => s + (t.amount || 0), 0);
                         }, 0).toLocaleString()} ج.م
                       </td>
                       <td className="py-4 px-4 text-emerald-600 dark:text-emerald-400">
                         {partners.reduce((sum, p) => {
                           const pTxs = transactions.filter(t => t.partnerId === p.id);
                           return sum + pTxs.filter(t => t.type === 'profit_distribution').reduce((s, t) => s + (t.amount || 0), 0);
                         }, 0).toLocaleString()} ج.م
                       </td>
                       <td className="py-4 px-4 text-rose-600 dark:text-rose-400">
                         -{partners.reduce((sum, p) => {
                           const pTxs = transactions.filter(t => t.partnerId === p.id);
                           const w = pTxs.filter(t => ['loan', 'profit_withdrawal', 'expense_repayment', 'internal_transfer_out'].includes(t.type)).reduce((s, t) => s + (t.amount || 0), 0);
                           const r = pTxs.filter(t => ['repayment', 'internal_transfer_in'].includes(t.type)).reduce((s, t) => s + (t.amount || 0), 0);
                           return sum + Math.max(0, w - r);
                         }, 0).toLocaleString()} ج.م
                       </td>
                       <td className="py-4 px-4 text-amber-600 dark:text-amber-400">
                         {partners.reduce((sum, p) => {
                           const holderId = `part_${p.id}`;
                           const holder = (settings.cashHolders || []).find((h: any) => h.userId === holderId || h.userId === p.id);
                           return sum + (holder ? holder.currentBalance || 0 : 0);
                         }, 0).toLocaleString()} ج.م
                       </td>
                       <td className="py-4 px-4 font-black">
                         {partners.reduce((sum, p) => sum + (p.balance || 0), 0).toLocaleString()} ج.م
                       </td>
                       <td></td>
                     </tr>
                   </tfoot>
                 )}
               </table>
             </div>
          </div>
       </div>
       )}

      {/* Partner Requests Section */}
      {activeSection === 'requests' && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 animate-in fade-in zoom-in-95 duration-300">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 dark:border-slate-700/60 pb-6">
            <div>
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 rounded-2xl">
                  <Send size={24} />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-slate-800 dark:text-white flex items-center gap-3">
                    طلبات واستفسارات الشركاء من البوابة
                    {pendingRequestsCount > 0 && (
                      <span className="bg-rose-500 text-white text-xs font-black px-2.5 py-0.5 rounded-full animate-pulse">
                        {pendingRequestsCount} معلق
                      </span>
                    )}
                  </h2>
                  <p className="text-sm font-bold text-slate-500 dark:text-slate-400 mt-1">
                    متابعة واعتماد طلبات سحب الأرباح والمصروفات المدفوعة والاستفسارات المرسلة مباشرة من بوابة الشركاء.
                  </p>
                </div>
              </div>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-900/60 p-1 rounded-xl">
              <button
                onClick={() => setRequestsFilterStatus('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${requestsFilterStatus === 'all' ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500'}`}
              >
                الكل ({partnerRequests.length})
              </button>
              <button
                onClick={() => setRequestsFilterStatus('pending')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${requestsFilterStatus === 'pending' ? 'bg-amber-500 text-white shadow-sm' : 'text-slate-500'}`}
              >
                المعلقة ({partnerRequests.filter((r: any) => r.status === 'pending').length})
              </button>
              <button
                onClick={() => setRequestsFilterStatus('approved')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${requestsFilterStatus === 'approved' ? 'bg-emerald-500 text-white shadow-sm' : 'text-slate-500'}`}
              >
                المعتمدة ({partnerRequests.filter((r: any) => r.status === 'approved').length})
              </button>
            </div>
          </div>

          {/* Requests List */}
          {partnerRequests.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-16 h-16 bg-slate-100 dark:bg-slate-700/50 rounded-2xl flex items-center justify-center mx-auto text-slate-400">
                <MessageSquare size={32} />
              </div>
              <h3 className="font-black text-slate-700 dark:text-slate-300 text-base">لا توجد طلبات واردة حتى الآن</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                عند قيام أي شريك بالضغط على "تقديم طلب للإدارة" من بوابته المالية، سيظهر طلبه هنا فوراً مع خيارات الاعتماد أو الرفض.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {partnerRequests
                .filter((r: any) => requestsFilterStatus === 'all' || r.status === requestsFilterStatus)
                .map((req: any) => {
                  const isPending = req.status === 'pending';
                  const isApproved = req.status === 'approved';

                  const badgeColor = isPending
                    ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400'
                    : isApproved
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400'
                    : 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-400';

                  const statusArabic = isPending ? '⏳ قيد المراجعة' : isApproved ? '✅ تم الاعتماد والتسجيل' : '❌ تم الرفض';

                  return (
                    <div 
                      key={req.id}
                      className="p-5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/30 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-indigo-200 dark:hover:border-indigo-800 transition-all"
                    >
                      <div className="space-y-2 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-black text-slate-900 dark:text-white text-base">
                            👤 {req.partnerName}
                          </span>
                          <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 border border-indigo-200 dark:border-indigo-800">
                            {req.typeArabic || (req.type === 'withdrawal' ? 'طلب سحب أرباح' : req.type === 'expense' ? 'تسجيل مصروف' : 'استفسار')}
                          </span>
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-lg border ${badgeColor}`}>
                            {statusArabic}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            📅 {new Date(req.date).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        {req.amount > 0 && (
                          <div className="text-lg font-black text-indigo-600 dark:text-indigo-400 font-mono">
                            المبلغ المطلوب: {Number(req.amount).toLocaleString()} ج.م
                          </div>
                        )}

                        {req.notes && (
                          <div className="text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                            <strong>ملاحظات الشريك:</strong> {req.notes}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                        {isPending && (
                          <>
                            <button
                              onClick={() => handleApprovePartnerRequest(req)}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                            >
                              <Check size={14} />
                              <span>اعتماد وتسجيل</span>
                            </button>
                            <button
                              onClick={() => handleRejectPartnerRequest(req.id)}
                              className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl transition-all border border-rose-200 cursor-pointer"
                            >
                              <X size={14} />
                              <span>رفض</span>
                            </button>
                          </>
                        )}
                        <button
                          onClick={() => handleDeletePartnerRequest(req.id)}
                          className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all cursor-pointer"
                          title="حذف من السجل"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* Partner Statement & Print Preview Modal */}
      {previewPartner && (
        <PartnerStatementModal
          partner={previewPartner}
          settings={settings}
          wallet={wallet}
          orders={orders}
          treasury={treasury}
          onClose={() => setPreviewPartner(null)}
        />
      )}

      {/* Period Closing and Rollover Modal */}
      <PeriodClosingModal
        isOpen={isClosingModalOpen}
        onClose={() => setIsClosingModalOpen(false)}
        settings={settings}
        updateSettings={updateSettings}
        orders={orders}
        wallet={wallet}
        setWallet={setWallet}
        treasury={treasury}
        setTreasury={setTreasury}
      />

      {/* Partner Exit & Settlement Modal */}
      {isExitModalOpen && (
        <PartnerExitModal
          initialPartnerId={exitModalPartnerId || undefined}
          partners={partners}
          settings={settings}
          wallet={wallet}
          orders={orders}
          onClose={() => {
            setIsExitModalOpen(false);
            setExitModalPartnerId(null);
          }}
          onExecuteLiquidation={(partnerId, amount, method, note) => {
            handleExecuteLiquidationTransaction(partnerId, amount, method, note);
          }}
        />
      )}

      {/* Dedicated Partner PIN Management & Direct Link Sharing Modal */}
      <AnimatePresence>
        {pinModalPartner && (
          <div className="fixed inset-0 z-[120] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6 text-right"
              dir="rtl"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-2xl flex items-center justify-center">
                    <Lock size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-800 dark:text-white">تعيين ومشاركة رمز PIN</h3>
                    <p className="text-xs font-bold text-slate-400">{pinModalPartner.name} - بوابة الشركاء</p>
                  </div>
                </div>
                <button
                  onClick={() => setPinModalPartner(null)}
                  className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-4">
                {/* 1. Email address for OTP */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-700 dark:text-slate-300">
                    البريد الإلكتروني المعتمد لاستلام كود التحقق (OTP):
                  </label>
                  <div className="relative">
                    <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input
                      type="email"
                      value={pinModalEmail}
                      onChange={(e) => setPinModalEmail(e.target.value)}
                      placeholder="partner@example.com"
                      className="w-full pr-11 pl-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-emerald-500 rounded-2xl outline-none font-bold text-xs text-slate-800 dark:text-white"
                    />
                  </div>
                </div>

                {/* 2. Enforce Email OTP toggle */}
                <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200/80 dark:border-emerald-800/60 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-black text-emerald-900 dark:text-emerald-200 block">
                      🔒 فرض التحقق بالبريد (Email OTP)
                    </span>
                    <span className="text-[10px] text-emerald-700 dark:text-emerald-400 block leading-tight">
                      إلزام الشريك بإدخال كود التحقق الأمني لمرة واحدة عند الدخول
                    </span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer shrink-0 mr-2">
                    <input
                      type="checkbox"
                      checked={pinModalRequireOtp}
                      onChange={(e) => setPinModalRequireOtp(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#008060]"></div>
                  </label>
                </div>

                {/* 3. PIN code */}
                <div className="space-y-2">
                  <label className="block text-xs font-black text-slate-600 dark:text-slate-300">
                    رمز المرور السري (PIN) للشريك
                  </label>
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input
                        type="text"
                        maxLength={6}
                        value={pinModalCode}
                        onChange={(e) => setPinModalCode(e.target.value.replace(/\D/g, ''))}
                        placeholder="أدخل 4-6 أرقام..."
                        className="w-full pr-12 pl-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-amber-500/30 rounded-2xl outline-none font-black text-center text-lg tracking-widest text-slate-800 dark:text-white"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={generateRandomPin}
                      className="px-3 py-3 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 rounded-2xl text-xs font-black transition-colors flex items-center gap-1 cursor-pointer border border-amber-300/40"
                      title="توليد رمز PIN عشوائي جديد"
                    >
                      <Sparkles size={14} className="text-amber-500" />
                      <span>توليد تلقائي</span>
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-3">
                  <span className="text-xs font-black text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                    <Share2 size={14} className="text-indigo-600" /> خيارات مشاركة الرابط المباشر:
                  </span>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => copyPartnerPortalLink(pinModalPartner)}
                      className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Copy size={13} />
                      <span>نسخ الرابط</span>
                    </button>

                    <button
                      onClick={() => sharePartnerWhatsApp(pinModalPartner)}
                      className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <span>📲 واتساب</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={handleSavePin}
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-3.5 rounded-2xl font-black text-xs transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check size={16} /> حفظ وتحديث رمز PIN
                </button>
                <button
                  onClick={() => setPinModalPartner(null)}
                  className="px-5 py-3.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Partner Employee Permissions Modal */}
      {selectedPermissionsPartner && (
        <PartnerPermissionsModal
          partner={selectedPermissionsPartner}
          storeId={storeId || ''}
          storeName={settings.storeName || ''}
          settings={settings}
          updateSettings={updateSettings}
          onClose={() => setSelectedPermissionsPartner(null)}
          showToast={showToast}
        />
      )}

    </div>
  );
};

export default PartnersPage;
