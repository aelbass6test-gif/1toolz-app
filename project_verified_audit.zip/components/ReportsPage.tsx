import React, { useMemo, useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Order, Settings, Wallet, Store, Treasury } from '../types';
import { FileText, TrendingUp, Package, Truck, DollarSign, ArrowUp, ArrowDown, PieChart as PieChartIcon, Printer, AlertTriangle, MapPin, Calendar, Wallet as WalletIcon, Download, Loader2, ArrowUpLeft, ArrowDownRight, X, Eye, EyeOff, Coins, Monitor, ShoppingBasket, Users, Info, Percent, CheckCircle, Settings as SettingsIcon, Share2, Link as LinkIcon, Copy, Check, Search, Filter, Sparkles, Calculator, Grid, List, ShieldCheck, Lock, LogOut, BookOpen } from 'lucide-react';
import { FinancialPnLDashboard } from './FinancialPnLDashboard';
import { AccountingReports, CustodyLedger } from './AccountingReports';
import { PeriodClosingModal } from './PeriodClosingModal';
import { PartnerExitModal } from './PartnerExitModal';
import { calculateOrderProfitLoss, calculateCodFee, getLatestProductCost, isBosta, calculateInsuranceFee, calculateBostaVat, getOrderProductCost, getStandardShippingFee, resolveCashHolderName, resolveItemCatalogPrice, findProductInSettings } from '../utils/financials';
import { generateLossesReportHTML, generateComprehensiveFinancialReportHTML, generatePartnersFinancialReportHTML, generatePurchasesAndInventoryReportHTML, generatePosReportHTML, generateAbdoMediaPolicyHTML, ComprehensiveReportSections } from '../utils/reportGenerator';
import { useInventoryVisibility } from '../utils/useInventoryVisibility';
import * as htmlToImage from 'html-to-image';
import { jsPDF } from 'jspdf';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, LineChart, Line, CartesianGrid, Legend } from 'recharts';
import { printHTMLDirectly } from '../utils/printHelper';
import { exportHTMLToPDF } from '../utils/pdfHelper';
import { exportComprehensiveFinancialReportExcel } from '../utils/excelExport';
import { useLocalStorage } from '../src/hooks/useLocalStorage';
import { shareReport } from '../services/reportShareService';

const normalizeName = (name: string): string => {
    return (name || '').trim().toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
};

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

interface ReportsPageProps {
  orders: Order[];
  settings: Settings;
  wallet: Wallet;
  treasury?: Treasury;
  activeStore?: Store;
  setSettings?: React.Dispatch<React.SetStateAction<Settings>>;
  setWallet?: React.Dispatch<React.SetStateAction<Wallet>>;
  dateRangeText?: string;
  supplyOrders?: any[];
}

const ReportCard: React.FC<{ title: string; value: string; icon: React.ReactNode; subValue?: string; color: 'emerald' | 'red' | 'amber' | 'blue' | 'teal' | 'indigo' | 'purple' | 'cyan' | 'slate'; tooltip?: string }> = ({ title, value, icon, subValue, color, tooltip }) => {
    const colorClasses: Record<string, { bg: string; text: string; border: string }> = {
        emerald: { bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-600', border: 'border-emerald-200 dark:border-emerald-800' },
        red: { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-600', border: 'border-red-200 dark:border-red-800' },
        amber: { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-600', border: 'border-amber-200 dark:border-amber-800' },
        blue: { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600', border: 'border-blue-200 dark:border-blue-800' },
        teal: { bg: 'bg-teal-100 dark:bg-teal-900/30', text: 'text-teal-600', border: 'border-teal-200 dark:border-teal-800' },
        indigo: { bg: 'bg-indigo-100 dark:bg-indigo-900/30', text: 'text-indigo-600', border: 'border-indigo-200 dark:border-indigo-800' },
        purple: { bg: 'bg-purple-100 dark:bg-purple-900/30', text: 'text-purple-600', border: 'border-purple-200 dark:border-purple-800' },
        cyan: { bg: 'bg-cyan-100 dark:bg-cyan-900/30', text: 'text-cyan-600', border: 'border-cyan-200 dark:border-cyan-800' },
        slate: { bg: 'bg-slate-100 dark:bg-slate-800', text: 'text-slate-600', border: 'border-slate-200 dark:border-slate-700' },
    };
    const currentColors = colorClasses[color] || colorClasses.blue;

    return (
        <div className={`p-6 rounded-2xl border ${currentColors.border} bg-white dark:bg-slate-900 shadow-sm relative group`} title={tooltip}>
            <div className="flex justify-between items-start">
                <div className="space-y-1">
                    <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        {title}
                        {tooltip && <span className="text-slate-300 cursor-help">ⓘ</span>}
                    </h3>
                    <p className="text-3xl font-black text-slate-800 dark:text-white">{value}</p>
                    {subValue && <p className="text-xs font-bold text-slate-400 dark:text-slate-500">{subValue}</p>}
                </div>
                <div className={`p-3 rounded-xl ${currentColors.bg} ${currentColors.text}`}>
                    {icon}
                </div>
            </div>
        </div>
    );
};

const PartnerWithdrawalBreakdown = ({ partner, settings }: { partner: any; settings: Settings }) => {
    const allTxs = settings.partnerTransactions || [];
    const normPName = normalizeName(partner.name);
    
    const partnerTxs = allTxs.filter(t => {
        const matchesId = t.partnerId === partner.id || t.partnerId === `part_${partner.id}` || t.partnerId === `partner_${partner.id}`;
        const matchesName = t.partnerName && normalizeName(t.partnerName) === normPName;
        const matchesNote = t.notes && normalizeName(t.notes).includes(normPName);
        return matchesId || matchesName || matchesNote;
    });

    const withdrawalTxs = partnerTxs.filter(t => {
        const isWithdrawalType = ['profit_withdrawal', 'loan', 'personal_withdrawal', 'custody_withdrawal', 'wallet_withdrawal', 'withdrawal', 'draw'].includes(t.type) ||
            (t.amount > 0 && t.type !== 'capital_addition' && t.type !== 'profit_distribution' && t.type !== 'repayment' && t.type !== 'supply_funding' && t.type !== 'shipping_funding' && t.type !== 'expense_coverage' && t.type !== 'internal_transfer_in' && t.type !== 'custody_receive');
        
        if (!isWithdrawalType) return false;
        
        const notes = (t.notes || t.description || '').toLowerCase();
        // Filter out equalization settlements
        return !(notes.includes('تسوية') && (notes.includes('مخزون') || notes.includes('بضاعة') || notes.includes('مقاصة')));
    });

    if (withdrawalTxs.length === 0) {
        return (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-center text-xs text-slate-400">
                لا توجد مسحوبات أو سلف تفصيلية مسجلة للشريك {partner.name}.
            </div>
        );
    }

    const totalAmt = withdrawalTxs.reduce((s, t) => s + (t.amount || 0), 0);

    return (
        <div className="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-2xl space-y-3 my-2 text-right">
            <div className="flex justify-between items-center text-xs font-black text-rose-800 dark:text-rose-300 pb-2 border-b border-rose-200/50 dark:border-rose-900/40">
                <span>تفاصيل مسحوبات وسلف الشريك ({partner.name})</span>
                <span className="text-xs font-mono font-black text-rose-600 dark:text-rose-400">
                    الإجمالي: -{totalAmt.toLocaleString()} ج.م
                </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {withdrawalTxs.map(t => {
                    const notes = t.notes || t.description || t.category || t.note || '';
                    const notesNorm = normalizeName(notes);
                    
                    let badge = 'مسحوبات';
                    let badgeClass = 'bg-rose-100 dark:bg-rose-900/50 text-rose-700 dark:text-rose-300 border-rose-200';

                    if (notesNorm.includes('عهدة') || notesNorm.includes('عهده') || notesNorm.includes('تسوية عهدة') || notesNorm.includes('خصم عهدة') || notesNorm.includes('تسوية عهده') || notesNorm.includes('خصم عهده')) {
                        badge = 'تسوية عهدة';
                        badgeClass = 'bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-300 border-amber-200';
                    } else if (t.type === 'loan' || notesNorm.includes('سلفة') || notesNorm.includes('سلفه')) {
                        badge = 'سلفة';
                        badgeClass = 'bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-300 border-amber-200';
                    } else if (t.type === 'wallet_withdrawal' || notesNorm.includes('محفظة') || notesNorm.includes('سحب محفظة') || notesNorm.includes('بنك')) {
                        badge = 'سحب محفظة';
                        badgeClass = 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 border-emerald-200';
                    } else if (t.type === 'profit_withdrawal') {
                        badge = 'سحب أرباح';
                        badgeClass = 'bg-sky-100 dark:bg-sky-900/50 text-sky-800 dark:text-sky-300 border-sky-200';
                    } else if (t.type === 'profit_distribution') {
                        badge = 'توزيع أرباح';
                        badgeClass = 'bg-purple-100 dark:bg-purple-900/50 text-purple-800 dark:text-purple-300 border-purple-200';
                    }

                    const displayNote = notes || (badge === 'سلفة' ? 'مسحوبات شخصية' : 'مسحوبات شريك');
                    const dateStr = t.date ? new Date(t.date).toLocaleDateString('ar-EG') : '---';

                    return (
                        <div key={t.id} className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex justify-between items-center gap-2">
                            <div className="space-y-1 text-right min-w-0">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${badgeClass}`}>
                                        {badge}
                                    </span>
                                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                                        {displayNote}
                                    </span>
                                </div>
                                <p className="text-[10px] text-slate-400 font-medium">📅 {dateStr}</p>
                            </div>
                            <span className="font-mono font-black text-rose-600 dark:text-rose-400 text-xs whitespace-nowrap">
                                -{Number(t.amount || 0).toLocaleString()} ج.م
                            </span>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

const SalesSummaryReport: React.FC<Omit<ReportsPageProps, 'activeStore'>> = ({ orders, settings, wallet }) => {
    const reportData = useMemo(() => {
        if (!settings) return null;
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();
        
        const currentMonthOrders = orders.filter(o => {
            const d = new Date(o.date);
            return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
        });

        const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
        const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
        const prevMonthOrders = orders.filter(o => {
            const d = new Date(o.date);
            return d.getMonth() === prevMonth && d.getFullYear() === prevYear;
        });

        const getRevenue = (os: Order[]) => os.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)).reduce((sum, o) => sum + ((o.items || []).reduce((itemSum, item) => itemSum + (item.price * item.quantity), 0) + o.shippingFee - (o.discount || 0)), 0);
        
        const currentRevenue = getRevenue(currentMonthOrders);
        const prevRevenue = getRevenue(prevMonthOrders);
        const revenueGrowth = prevRevenue > 0 ? ((currentRevenue - prevRevenue) / prevRevenue) * 100 : 0;

        const collectedOrders = orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status));
        const totalProductRevenue = collectedOrders.reduce((sum, o) => sum + (o.items || []).reduce((itemSum, item) => itemSum + (item.price * item.quantity), 0), 0);
        const totalRevenue = collectedOrders.reduce((sum, o) => sum + ((o.items || []).reduce((itemSum, item) => itemSum + (item.price * item.quantity), 0) + o.shippingFee - (o.discount || 0)), 0);
        const totalOrders = orders.length;
        const avgOrderValue = collectedOrders.length > 0 ? totalRevenue / collectedOrders.length : 0;
        
        let totalProfit = 0;
        let totalLoss = 0;
        orders.forEach(order => {
            const { net } = calculateOrderProfitLoss(order, settings);
            if (net > 0) totalProfit += net;
            else totalLoss += Math.abs(net);
        });

        const totalExpenses = (wallet?.transactions || []).filter(t => t.type === 'سحب' && (t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings?.expenseCategories || []).includes(t.category || ''))).reduce((sum, t) => sum + t.amount, 0);
        
        // Compute trend based on standard days in filtered data
        // If they chose custom range, map those days; otherwise last 7 days as default
        const datesInOrders = Array.from(new Set(orders.map(o => (o.date || '').split('T')[0]))).filter(Boolean).sort();
        const targetDates = datesInOrders.length > 1 ? datesInOrders.slice(-10) : [...Array(7)].map((_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - i);
            return d.toISOString().split('T')[0];
        }).reverse();

        const salesTrend = targetDates.map(date => {
            const dayOrders = orders.filter(o => (o.date || '').startsWith(date) && (o.status === 'تم_التحصيل' || o.status === 'مدفوعة'));
            return {
                date: date.split('-').slice(1).join('/'),
                revenue: dayOrders.reduce((sum, o) => sum + ((o.items || []).reduce((itemSum, item) => itemSum + (item.price * item.quantity), 0) + o.shippingFee - (o.discount || 0)), 0)
            };
        });

        const productPerformance = settings.products.map(product => {
            const soldItems = orders
                .filter(o => o.status === 'تم_التحصيل' || o.status === 'مدفوعة' || o.status === 'تم_توصيلها' || o.status === 'تم_التوصيل')
                .flatMap(o => o.items || [])
                .filter(i => i.productId === product.id);
            
            const quantitySold = soldItems.reduce((sum, i) => sum + i.quantity, 0);
            const cost = product.costPrice || 0;
            const price = product.price || 0;
            const netProfit = soldItems.reduce((sum, i) => sum + ((i.price - (i.cost || cost)) * i.quantity), 0);
            
            return { name: product.name, quantitySold, netProfit };
        }).sort((a, b) => b.quantitySold - a.quantitySold).slice(0, 5);

        const shippingPerformance: { name: string; count: number; successRate: number }[] = [];
        const companies = Object.keys(settings.shippingOptions);
        companies.forEach(company => {
            const companyOrders = orders.filter(o => o.shippingCompany === company);
            if (companyOrders.length > 0) {
                const successful = companyOrders.filter(o => o.status === 'تم_التحصيل' || o.status === 'تم_توصيلها' || o.status === 'تم_التوصيل').length;
                shippingPerformance.push({ name: company, count: companyOrders.length, successRate: (successful / companyOrders.length) * 100 });
            }
        });

        // Delivery breakdown for Pie chart
        const deliveredCount = orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)).length;
        const returnedCount = orders.filter(o => ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي', 'تم_الاستبدال'].includes(o.status)).length;
        const processingCount = orders.length - deliveredCount - returnedCount;

        const deliveryBreakdown = [
            { name: 'توصيل وتحصيل ناجح ✅', value: deliveredCount, color: '#10b981' },
            { name: 'مرتجع وفشل شحن ❌', value: returnedCount, color: '#ef4444' },
            { name: 'قيد التجهيز والمعالجة ⏱️', value: processingCount, color: '#3b82f6' }
        ].filter(d => d.value > 0);

        return { 
            totalRevenue, totalProductRevenue, totalOrders, avgOrderValue, 
            totalProfit, totalLoss, totalExpenses, 
            netFinancial: totalProfit - totalLoss - totalExpenses, 
            productPerformance, shippingPerformance,
            salesTrend, revenueGrowth, currentRevenue, deliveryBreakdown
        };
    }, [orders, settings, wallet]);

    // Income Statement Breakdown
    const incomeStatement = useMemo(() => {
        if (!settings || !reportData) return null;
        const grossSales = orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)).reduce((sum, o) => {
            const itemsRevenue = (o.items || []).reduce((itemSum, item) => itemSum + (item.price * item.quantity), 0);
            
            const isDefinitivelyPosOrder = o.channel === 'pos' || o.shippingCompany === 'كاشير - بيع مباشر' || o.shippingArea === 'نقطة البيع' || (o.id && o.id.startsWith('POS-'));
            const compFeesLocal = settings.companySpecificFees?.[o.shippingCompany];
            const useCustomLocal = compFeesLocal?.useCustomFees ?? false;
            const inspectionFeeParams = !isDefinitivelyPosOrder && (o.includeInspectionFee ?? true) ? (useCustomLocal ? (compFeesLocal?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
            
            const orderSales = o.totalAmountOverride !== undefined && o.totalAmountOverride !== null
                ? o.totalAmountOverride + (o.advancePayment || 0)
                : (itemsRevenue + o.shippingFee - (o.discount || 0) + (o.inspectionFeePaidByCustomer ? inspectionFeeParams : 0));
                
            return sum + orderSales;
        }, 0);
        
        let totalCogs = 0;
        let returnsLoss = 0;
        orders.forEach(order => {
            const { loss, net } = calculateOrderProfitLoss(order, settings);
            if (['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(order.status)) {
                totalCogs += getOrderProductCost(order, settings);
            }
            if (['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي', 'تم_الاستبدال'].includes(order.status)) {
                returnsLoss += (loss || (net < 0 ? Math.abs(net) : 0));
            }
        });

        const totalExpenses = (wallet?.transactions || []).filter(t => t.type === 'سحب' && (t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings?.expenseCategories || []).includes(t.category || ''))).reduce((sum, t) => sum + t.amount, 0);
        
        const marketingAds = (wallet?.transactions || [])
            .filter(t => t.category === 'expense_ads' || (t.note && (t.note.toLowerCase().includes('تسويق') || t.note.toLowerCase().includes('إعلان') || t.note.toLowerCase().includes('ads') || t.note.toLowerCase().includes('marketing'))))
            .reduce((sum, t) => sum + t.amount, 0);

        const otherAdmin = totalExpenses - marketingAds;
        
        let successfulShippingOperations = 0;
        orders.forEach(order => {
            if (['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(order.status)) {
                const { profit } = calculateOrderProfitLoss(order, settings);
                const safeProductCost = getOrderProductCost(order, settings);
                const isDefinitivelyPosOrder = order.channel === 'pos' || order.shippingCompany === 'كاشير - بيع مباشر' || order.shippingArea === 'نقطة البيع' || (order.id && order.id.startsWith('POS-'));
                const compFeesLocal = settings.companySpecificFees?.[order.shippingCompany];
                const useCustomLocal = compFeesLocal?.useCustomFees ?? false;
                const inspectionFeeParams = !isDefinitivelyPosOrder && (order.includeInspectionFee ?? true) ? (useCustomLocal ? (compFeesLocal?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
                
                const itemsRevenue = (order.items || []).reduce((itemSum, item) => itemSum + (item.price * item.quantity), 0);
                const totalCollected = order.totalAmountOverride !== undefined && order.totalAmountOverride !== null
                    ? order.totalAmountOverride + (order.advancePayment || 0)
                    : (itemsRevenue + order.shippingFee - order.discount + (order.inspectionFeePaidByCustomer ? inspectionFeeParams : 0));
                successfulShippingOperations += Math.max(0, totalCollected - profit - safeProductCost);
            }
        });

        const realNetProfit = reportData?.netFinancial || 0;
        const marginRate = grossSales > 0 ? (realNetProfit / grossSales) * 100 : 0;

        return {
            grossSales,
            totalCogs,
            returnsLoss,
            marketingAds,
            otherAdmin,
            successfulShippingOperations,
            realNetProfit,
            marginRate
        };
    }, [orders, settings, wallet, reportData]);

    const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];

    const handleExportCSV = () => {
        if (!reportData || !incomeStatement) return;
        const headers = ['إحصائية', 'القيمة'];
        const rows = [
            ['إجمالي الأرباح المستلمة', `${reportData.totalProfit} ج.م`],
            ['إجمالي خسائر شركات الشحن للمرتجعات', `${reportData.totalLoss} ج.م`],
            ['إجمالي المبيعات الإجمالية الناجحة', `${incomeStatement.grossSales} ج.م`],
            ['تكلفة المنتج الأصلي (COGS)', `${incomeStatement.totalCogs} ج.م`],
            ['تكاليف التسويق والإعلانات الممولة', `${incomeStatement.marketingAds} ج.م`],
            ['مصروفات إدارية ورقية وتشغيلية أخرى', `${incomeStatement.otherAdmin} ج.م`],
            ['أتعاب عمليات الشحن والتوصيل الناجح', `${incomeStatement.successfulShippingOperations} ج.م`],
            ['صافي الربح الفعلي الحقيقي', `${incomeStatement.realNetProfit} ج.م`],
            ['هامش صافي الربح %', `${incomeStatement.marginRate.toFixed(1)}%`],
            ['متوسط قيمة الفاتورة الناجحة', `${reportData.avgOrderValue.toFixed(1)} ج.م`],
            ['إجمالي عدد الطلبات الكلي', `${reportData.totalOrders}`],
        ];

        (reportData.productPerformance || []).forEach((p, i) => {
            rows.push([`المنتج الأكثر مبيعاً #${i+1}: ${p.name}`, `عدد: ${p.quantitySold} قطعة (أرباح صافية منه: ${p.netProfit} ج.م)`]);
        });

        (reportData.shippingPerformance || []).forEach(s => {
            rows.push([`شركة الشحن: ${s.name}`, `طلبات: ${s.count} (معدل تسليم ناجح: ${s.successRate.toFixed(1)}%)`]);
        });
        
        const csvContent = "\uFEFF" + [
            headers.join(","),
            ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))
        ].join("\n");
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `ملخص_أداء_المبيعات_والأرباح_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const [isExporting, setIsExporting] = useState(false);
    const [expandedPartnerId, setExpandedPartnerId] = useState<string | null>(null);
    const reportRef = React.useRef<HTMLDivElement>(null);

    const handleExportPDF = async () => {
        if (!reportRef.current) return;
        setIsExporting(true);
        try {
            await exportHTMLToPDF(reportRef.current, 'landscape', `ملخص_أداء_المبيعات_${new Date().toISOString().split('T')[0]}.pdf`);
        } catch (error) {
            console.error('PDF Export Error:', error);
            alert('حدث خطأ أثناء تصدير PDF');
        } finally {
            setIsExporting(false);
        }
    };

    const handlePrint = () => {
        window.print();
    };

    if (!reportData || !incomeStatement) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل التقارير المالية...</p>
            </div>
        );
    }

    return (
         <div className="space-y-6 animate-in fade-in-5 duration-300" ref={reportRef}>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex-1">
                    <h2 className="text-xl font-bold text-slate-700 dark:text-white flex items-center gap-2">
                        <Coins className="text-blue-500" />
                        الملخص التفصيلي للحالة المالية والأرباح
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">توضح هذه اللوحة التحاليل المتكاملة والتكاليف بما فيها الإعلانات وسعر تكلفة المنتجات.</p>
                </div>
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto no-print">
                    <button 
                        onClick={handleExportCSV}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-700"
                    >
                        <Download size={14}/>
                        CSV
                    </button>
                    <button 
                        onClick={handleExportPDF}
                        disabled={isExporting}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-xl font-bold text-xs hover:bg-blue-700 transition-all border border-transparent disabled:opacity-50"
                    >
                        {isExporting ? <Loader2 size={14} className="animate-spin" /> : <FileText size={14} />}
                        PDF
                    </button>
                    <button 
                        onClick={handlePrint}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-700"
                    >
                        <Printer size={14}/>
                        طباعة
                    </button>
                    <div className="bg-slate-50 dark:bg-slate-800 p-2 rounded-xl text-left hidden sm:block">
                        <p className="text-[10px] font-bold text-slate-400 uppercase">مقارنة مبيعات الشهر الحالي</p>
                        <p className={`text-sm font-black flex items-center gap-1 ${reportData.revenueGrowth >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                            {reportData.revenueGrowth >= 0 ? <ArrowUp size={12}/> : <ArrowDown size={12}/>}
                            {Math.abs(reportData.revenueGrowth).toFixed(1)}%
                        </p>
                    </div>
                </div>
                
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                <ReportCard title="إجمالي الأرباح" value={`${(reportData?.totalProfit || 0).toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م`} icon={<ArrowUp size={24}/>} color='emerald' tooltip="مجموع الأرباح الصافية من جميع الطلبات الناجحة (بعد خصم تكلفة المنتجات ومصاريف الشحن والرسوم)." />
                <ReportCard title="إجمالي الخسائر" value={`${(reportData?.totalLoss || 0).toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م`} icon={<ArrowDown size={24}/>} color='red' tooltip="مجموع مصاريف الشحن والارتجاع الضائع للطلبات المرتجعة والفاشلة." />
                <ReportCard title="مبيعات المنتجات" value={`${(reportData?.totalProductRevenue || 0).toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م`} icon={<Package size={24}/>} color='blue' tooltip="إجمالي قيمة المنتجات المباعة في الطلبات الناجحة بدون الشحن." />
                <ReportCard title="إجمالي المصروفات" value={`${(reportData?.totalExpenses || 0).toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م`} icon={<DollarSign size={24}/>} color='amber' tooltip="مجموع المصروفات الإدارية المسجلة بالخزنة كإعلانات وصيانة ورواتب لتخصم من الأرباح الكلية." />
                <ReportCard title="الصافي الفعلي الحقيقي" value={`${(reportData?.netFinancial || 0).toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م`} icon={<PieChartIcon size={24}/>} color='blue' tooltip="الربح الباقي النهائي والحقيقي بعد طرح إجمالي الخسائر وإجمالي المصاريف من أصل الربح." />
            </div>

            {/* Income Statement & Net Profit Margin Board */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                    <div>
                        <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                            <span className="p-1.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg"><Coins size={18}/></span>
                            كشف الأرباح والتحليل التشريحي للتكاليف (Income Statement)
                        </h3>
                        <p className="text-xs text-slate-400 mb-6">يقوم النظام بفرز الدخل التشغيلي للمتجر وخصم تكلفة البضاعة بدقة وخصم تكاليف التسويق للوصول لصافي الربح الفعلي.</p>
                        
                        <div className="space-y-4">
                            <div>
                                <div className="flex justify-between items-center mb-1 text-sm font-bold">
                                    <span className="text-slate-600 dark:text-slate-300">إجمالي حجم المبيعات الناجحة (إيرادات المبيعات + التوصيل)</span>
                                    <span>{incomeStatement.grossSales.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م (100%)</span>
                                </div>
                                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-blue-500" style={{ width: '100%' }}></div>
                                </div>
                            </div>

                            <div>
                                <div className="flex justify-between items-center mb-1 text-sm font-bold">
                                    <span className="text-slate-600 dark:text-slate-300">تكلفة شراء البضاعة المباعة الأصلية (COGS)</span>
                                    <span className="text-red-500">
                                        {incomeStatement.totalCogs.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                        ({incomeStatement.grossSales > 0 ? ((incomeStatement.totalCogs / incomeStatement.grossSales) * 100).toFixed(1) : 0}%)
                                    </span>
                                </div>
                                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-red-400" style={{ width: `${incomeStatement.grossSales > 0 ? (incomeStatement.totalCogs / incomeStatement.grossSales) * 100 : 0}%` }}></div>
                                </div>
                            </div>

                            <div>
                                <div className="flex justify-between items-center mb-1 text-sm font-bold">
                                    <span className="text-slate-600 dark:text-slate-300">تكاليف التسويق والإعلانات الممولة</span>
                                    <span className="text-orange-500">
                                        {incomeStatement.marketingAds.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                        ({incomeStatement.grossSales > 0 ? ((incomeStatement.marketingAds / incomeStatement.grossSales) * 100).toFixed(1) : 0}%)
                                    </span>
                                </div>
                                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-orange-400" style={{ width: `${incomeStatement.grossSales > 0 ? (incomeStatement.marketingAds / incomeStatement.grossSales) * 100 : 0}%` }}></div>
                                </div>
                            </div>

                            <div>
                                <div className="flex justify-between items-center mb-1 text-sm font-bold">
                                    <span className="text-slate-600 dark:text-slate-300">أتعاب وتكاليف خدمات التوصيل والتحصيل للطلبات الناجحة</span>
                                    <span className="text-amber-500">
                                        {incomeStatement.successfulShippingOperations.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                        ({incomeStatement.grossSales > 0 ? ((incomeStatement.successfulShippingOperations / incomeStatement.grossSales) * 100).toFixed(1) : 0}%)
                                    </span>
                                </div>
                                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-amber-400" style={{ width: `${incomeStatement.grossSales > 0 ? (incomeStatement.successfulShippingOperations / incomeStatement.grossSales) * 100 : 0}%` }}></div>
                                </div>
                            </div>

                            <div>
                                <div className="flex justify-between items-center mb-1 text-sm font-bold">
                                    <span className="text-slate-600 dark:text-slate-300">خسائر التوصيل والارتجاع للطلبيات المرجوعة</span>
                                    <span className="text-red-500">
                                        {incomeStatement.returnsLoss.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                        ({incomeStatement.grossSales > 0 ? ((incomeStatement.returnsLoss / incomeStatement.grossSales) * 100).toFixed(1) : 0}%)
                                    </span>
                                </div>
                                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-red-500" style={{ width: `${incomeStatement.grossSales > 0 ? (incomeStatement.returnsLoss / incomeStatement.grossSales) * 100 : 0}%` }}></div>
                                </div>
                            </div>

                            <div>
                                <div className="flex justify-between items-center mb-1 text-sm font-bold">
                                    <span className="text-slate-600 dark:text-slate-300">أي مصروفات تشغيلية ورواتب ومصاريف إدارية أخرى</span>
                                    <span className="text-purple-500">
                                        {incomeStatement.otherAdmin.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                        ({incomeStatement.grossSales > 0 ? ((incomeStatement.otherAdmin / incomeStatement.grossSales) * 100).toFixed(1) : 0}%)
                                    </span>
                                </div>
                                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-purple-400" style={{ width: `${incomeStatement.grossSales > 0 ? (incomeStatement.otherAdmin / incomeStatement.grossSales) * 100 : 0}%` }}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-50 dark:bg-slate-800/20 p-4 rounded-xl">
                        <div>
                            <p className="text-xs text-slate-400 font-bold">هامش صافي الربح الفعلي الحقيقي:</p>
                            <p className="text-slate-500 text-[10px] mt-0.5">الربح المتبقي للشركاء بعد تصفية كل المصاريف المترتبة على حجم المبيعات الكلي.</p>
                        </div>
                        <div className="text-left w-full sm:w-auto">
                            <span className="text-2xl font-black text-emerald-500 tabular-nums">
                                {incomeStatement.marginRate.toFixed(1)}% 🚀
                            </span>
                            <div className="text-xs text-slate-400 font-bold">({incomeStatement.realNetProfit.toLocaleString('ar-EG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م)</div>
                        </div>
                    </div>
                </div>

                <div className="space-y-6">
                    {/* Ring Chart: Delivery Breakdown */}
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between h-full">
                        <div>
                            <h3 className="text-sm font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-1.5 pb-2 border-b border-rose-50 dark:border-slate-800">
                                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                تحليل كفاءة التوصيل والارتداد
                            </h3>
                            <div className="h-44 relative flex items-center justify-center">
                                {reportData.deliveryBreakdown.length === 0 ? (
                                    <p className="text-xs text-slate-400">لا توجد بيانات كافية</p>
                                ) : (
                                    <>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie
                                                    data={reportData.deliveryBreakdown}
                                                    innerRadius={50}
                                                    outerRadius={70}
                                                    paddingAngle={3}
                                                    dataKey="value"
                                                >
                                                    {reportData.deliveryBreakdown.map((entry, index) => (
                                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                                    ))}
                                                </Pie>
                                                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', direction: 'rtl' }} />
                                            </PieChart>
                                        </ResponsiveContainer>
                                        <div className="absolute text-center">
                                            <span className="text-[10px] text-slate-400 font-bold block uppercase">معدل النجاح</span>
                                            <span className="text-xl font-black text-emerald-500">
                                                {reportData.totalOrders > 0 
                                                    ? ((orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)).length / reportData.totalOrders) * 100).toFixed(0) 
                                                    : 0}%
                                            </span>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="space-y-2 mt-4">
                            {reportData.deliveryBreakdown.map((item, idx) => {
                                const percentage = reportData.totalOrders > 0 ? (item.value / reportData.totalOrders) * 100 : 0;
                                return (
                                    <div key={idx} className="flex justify-between items-center text-xs p-2 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/80">
                                        <div className="flex items-center gap-2">
                                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                                            <span className="font-bold text-slate-600 dark:text-slate-300">{item.name}</span>
                                        </div>
                                        <span className="font-black text-slate-700 dark:text-slate-100">{item.value} طلب ({percentage.toFixed(0)}%)</span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-2">
                        <TrendingUp className="text-blue-500" />
                        منحنى تطور المبيعات (حجم الإيرادات التاريخي)
                    </h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={reportData.salesTrend}>
                                <defs>
                                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.8}/>
                                        <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#64748b' }} />
                                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', direction: 'rtl' }} />
                                <Line type="monotone" dataKey="revenue" name="الإيرادات ج.م" stroke="#4f46e5" strokeWidth={4} dot={{ r: 4, fill: '#4f46e5', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 6 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div className="border-b border-slate-100 dark:border-slate-800 pb-2 mb-4">
                        <h3 className="text-md font-bold text-slate-800 dark:text-white flex items-center gap-2">
                            <Package className="text-emerald-500" />
                            المنتجات الـ 5 الأكثر بيعاً وربحاً
                        </h3>
                        <p className="text-[10px] text-slate-400 mt-1">يقارن هذا المخطط عدد القطع الكلية المباعة مقابل هامش الربح المحقق منها.</p>
                    </div>
                    
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={reportData.productPerformance} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                                <XAxis dataKey="name" tick={{ fontSize: 9, fill: 'rgb(100 116 139)' }} axisLine={false} tickLine={false} />
                                <YAxis yAxisId="left" orientation="left" stroke="#4f46e5" tick={{ fontSize: 9 }} axisLine={false} />
                                <YAxis yAxisId="right" orientation="right" stroke="#10b981" tick={{ fontSize: 9 }} axisLine={false} />
                                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', direction: 'rtl' }} />
                                <Bar yAxisId="left" dataKey="quantitySold" name="القطع المباعة" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={15} />
                                <Bar yAxisId="right" dataKey="netProfit" name="الربح الصافي (ج.م)" fill="#10b981" radius={[4, 4, 0, 0]} barSize={15} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

             <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2"><Truck/> أداء شركات الشحن</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {reportData.shippingPerformance.map(company => (
                         <div key={company.name} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800">
                            <h4 className="font-bold text-slate-700 dark:text-white">{company.name}</h4>
                            <p className="text-xs text-slate-500 dark:text-slate-400">إجمالي الطلبات: {company.count}</p>
                            <div className="mt-3">
                                <div className="flex justify-between items-center text-xs font-bold mb-1">
                                    <span className="text-emerald-600 dark:text-emerald-400">نسبة النجاح</span>
                                    <span>{company.successRate.toFixed(1)}%</span>
                                </div>
                                <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${company.successRate}%` }}></div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const LossesReport: React.FC<Omit<ReportsPageProps, 'wallet'>> = ({ orders, settings, activeStore, dateRangeText }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل إعدادات التقارير...</p>
            </div>
        );
    }
    const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('landscape');
    const [isContinuous, setIsContinuous] = useState(false);
    const [isExporting, setIsExporting] = useState(false);
    
    const failedOrders = useMemo(() => {
        return orders.filter(o => {
            const { loss, net } = calculateOrderProfitLoss(o, settings);
            return ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status) || loss > 0 || net < 0;
        }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [orders, settings]);

    const stats = useMemo(() => {
        let totalLoss = 0;
        let totalCompensated = 0;
        let compensatedCount = 0;
        failedOrders.forEach(order => {
            const { loss, net } = calculateOrderProfitLoss(order, settings);
            totalLoss += (loss > 0 ? loss : (net < 0 ? Math.abs(net) : 0));
            
            const compStatus = (order as any).compensationStatus;
            const compAmount = Number((order as any).compensationAmount) || 0;
            if (compStatus === 'compensated' && compAmount > 0) {
                totalCompensated += compAmount;
                compensatedCount++;
            }
        });
        return { totalLoss, count: failedOrders.length, totalCompensated, compensatedCount };
    }, [failedOrders, settings]);

    // Return Reasons and Company Auditing
    const returnAudit = useMemo(() => {
        const reasons = {
            'no_response': 0, // العميل لا يرد / هاتف مغلق
            'damaged': 0,     // منتج تالف / عيب مصنعي
            'delay': 0,       // تأخر في الشحن والتسليم
            'canceled': 0,    // تغيير رأي العميل / إلغاء الطلب
            'price_issue': 0, // اعتراض على السعر / قيمة التوصيل
            'mismatch': 0,    // المنتج غير مطابق للمواصفات أو المقاس
            'other': 0,       // أخرى / غير محدد
        };

        const companyStats: Record<string, { total: number; returned: number; delivered: number; loss: number }> = {};

        // Initialize companyStats with active companies
        Object.keys(settings.shippingOptions || {}).forEach(c => {
            companyStats[c] = { total: 0, returned: 0, delivered: 0, loss: 0 };
        });

        // Loop over ALL orders in selection to get proper denominators
        orders.forEach(o => {
            const company = o.shippingCompany || 'غير معروف';
            if (!companyStats[company]) {
                companyStats[company] = { total: 0, returned: 0, delivered: 0, loss: 0 };
            }
            companyStats[company].total += 1;

            const isReturned = ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status);
            const isDelivered = ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status);

            if (isReturned) {
                companyStats[company].returned += 1;
                const { loss } = calculateOrderProfitLoss(o, settings);
                companyStats[company].loss += loss;

                // Classify reason
                const notesText = ((o.notes || '') + ' ' + (o.cancellationReason || '') + ' ' + (o.returnDescription || '')).toLowerCase();
                if (notesText.includes('لا يرد') || notesText.includes('لا يجيب') || notesText.includes('مغلق') || notesText.includes('موبايل غير متاح') || notesText.includes('المشترك مغلق') || notesText.includes('يردش') || notesText.includes('تليفون مقفول')) {
                    reasons.no_response += 1;
                } else if (notesText.includes('تالف') || notesText.includes('عيب') || notesText.includes('مكسور') || notesText.includes('قطع') || notesText.includes('مفتوح') || notesText.includes('خربش')) {
                    reasons.damaged += 1;
                } else if (notesText.includes('تأخر') || notesText.includes('تأخير') || notesText.includes('اتأخر') || notesText.includes('بطيء') || notesText.includes('غاب') || notesText.includes('طول')) {
                    reasons.delay += 1;
                } else if (notesText.includes('مقاس') || notesText.includes('شكل') || notesText.includes('لون') || notesText.includes('مختلف') || notesText.includes('غير مطابق') || notesText.includes('اللون') || notesText.includes('المقاس')) {
                    reasons.mismatch += 1;
                } else if (notesText.includes('سعر') || notesText.includes('غالي') || notesText.includes('فلوس') || notesText.includes('مصاريف')) {
                    reasons.price_issue += 1;
                } else if (notesText.includes('الغاء') || notesText.includes('الغي') || notesText.includes('مش عايز') || notesText.includes('تراجع') || notesText.includes('رفض') || notesText.includes('غير رأيه')) {
                    reasons.canceled += 1;
                } else {
                    reasons.other += 1;
                }
            } else if (isDelivered) {
                companyStats[company].delivered += 1;
            }
        });

        const reasonLabels: Record<string, string> = {
            'no_response': 'العميل لا يرد / هاتف مغلق',
            'damaged': 'منتج تالف / عيب مصنعي',
            'delay': 'تأخر في الشحن والتسليم',
            'canceled': 'تغيير رأي العميل / إلغاء',
            'price_issue': 'اعتراض على السعر / الشحن',
            'mismatch': 'المنتج غير مطابق للمقاس/الموديل',
            'other': 'أسباب أخرى / غير محددة',
        };

        const chartData = Object.entries(reasons).map(([key, count]) => ({
            name: reasonLabels[key],
            value: count,
        })).filter(r => r.value > 0);

        const COLORS = ['#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6', '#06b6d4', '#ec4899', '#64748b'];

        return { chartData, companyStats: Object.entries(companyStats).map(([name, stats]) => ({ name, ...stats })).filter(c => c.total > 0), COLORS };
    }, [orders, settings]);

    const [previewHtml, setPreviewHtml] = useState<string | null>(null);
    const [isSharing, setIsSharing] = useState(false);
    const [shareLink, setShareLink] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);

    const handlePreview = () => {
        const storeName = activeStore?.name || 'متجري';
        const html = generateLossesReportHTML(failedOrders, settings, storeName, orientation, isContinuous, dateRangeText);
        setPreviewHtml(html);
        setShareLink(null);
    };

    const handleShare = async () => {
        if (!previewHtml) return;
        setIsSharing(true);
        try {
            const id = await shareReport(previewHtml);
            setShareLink(`${window.location.origin}/shared-report/${id}`);
        } catch (error) {
            console.error('Share Error:', error);
            alert('حدث خطأ أثناء إنشاء رابط المشاركة.');
        } finally {
            setIsSharing(false);
        }
    };

    const handleCopyLink = () => {
        if (shareLink) {
            navigator.clipboard.writeText(shareLink);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const handleActualExportPDF = async () => {
        if (!previewHtml) return;
        setIsExporting(true);
        try {
            await exportHTMLToPDF(previewHtml, orientation, `تقرير_الخسائر_${new Date().toISOString().split('T')[0]}.pdf`, isContinuous);
        } catch (error) {
            console.error('PDF Export Error:', error);
            alert('حدث خطأ أثناء تصدير PDF.');
        } finally {
            setIsExporting(false);
        }
    };

    const handleActualPrint = () => {
        if (!previewHtml) return;
        printHTMLDirectly(previewHtml);
    };

    const handleExportPDF = async () => {
        setIsExporting(true);
        try {
            const storeName = activeStore?.name || 'متجري';
            const html = generateLossesReportHTML(failedOrders, settings, storeName, orientation, isContinuous, dateRangeText);
            await exportHTMLToPDF(html, orientation, `تقرير_الخسائر_${new Date().toISOString().split('T')[0]}.pdf`, isContinuous);
        } catch (error) {
            console.error('PDF Export Error:', error);
            alert('حدث خطأ أثناء تصدير PDF.');
        } finally {
            setIsExporting(false);
        }
    };

    const handlePrint = () => {
        const storeName = activeStore?.name || 'متجري';
        const html = generateLossesReportHTML(failedOrders, settings, storeName, orientation, isContinuous, dateRangeText);
        printHTMLDirectly(html);
    };

    const handleExportCSV = () => {
        const headers = ['رقم الطلب', 'العميل', 'الهاتف', 'شركة الشحن', 'المنتجات', 'الكمية', 'التكلفة', 'مصاريف الشحن', 'الخسارة ج.م', 'السبب والملاحظات'];
        const rows = failedOrders.map(o => {
            const { loss, net } = calculateOrderProfitLoss(o, settings);
            const actualLoss = loss > 0 ? loss : (net < 0 ? Math.abs(net) : 0);
            const itemsText = (o.items || []).map(i => `${i.name} (x${i.quantity})`).join(' + ');
            const qty = (o.items || []).reduce((sum, item) => sum + item.quantity, 0);
            return [
                o.orderNumber,
                o.customerName,
                o.customerPhone,
                o.shippingCompany,
                itemsText,
                qty,
                (o.items || []).reduce((sum, item) => sum + (item.cost * item.quantity), 0),
                o.shippingFee,
                actualLoss,
                o.cancellationReason || o.notes || ''
            ];
        });

        const csvContent = "\uFEFF" + [
            headers.join(","),
            ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))
        ].join("\n");
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `تقرير_المرتجعات_والخسائر_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    
    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h2 className="text-xl font-bold text-slate-700 dark:text-white flex items-center gap-2">
                        <AlertTriangle className="text-red-500" />
                        تشريح أسباب المرتجعات والخسائر المالية (Losses Analysis)
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">يحلل هذا الجزء أسباب الارتداد الكامنة ومستويات إخفاق شركات الشحن في تسليم شحناتك.</p>
                </div>
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                    <button 
                        onClick={handleExportCSV}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-700"
                    >
                        <Download size={14}/> CSV
                    </button>
                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                        <button 
                            onClick={() => setIsContinuous(false)}
                            className={`px-3 py-1 rounded-md text-[11px] font-bold transition-all ${!isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            صفحات
                        </button>
                        <button 
                            onClick={() => setIsContinuous(true)}
                            className={`px-3 py-1 rounded-md text-[11px] font-bold transition-all ${isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            متصل
                        </button>
                    </div>
                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                        <button 
                            onClick={() => setOrientation('portrait')}
                            className={`px-3 py-1 rounded-md text-[11px] font-bold transition-all ${orientation === 'portrait' ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            طولي
                        </button>
                        <button 
                            onClick={() => setOrientation('landscape')}
                            className={`px-3 py-1 rounded-md text-[11px] font-bold transition-all ${orientation === 'landscape' ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            عرضي
                        </button>
                    </div>
                    <button 
                        onClick={handlePreview} 
                        disabled={isExporting}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 text-white rounded-lg font-bold text-xs hover:bg-indigo-700 transition-all shadow-sm"
                    >
                        <Eye size={12}/>
                        معاينة الطباعة / PDF
                    </button>
                </div>
            </div>
            
            <div className="text-xs text-slate-600 dark:text-slate-400 bg-red-50 dark:bg-red-900/10 p-4 rounded-xl border-r-4 border-red-500">
                <strong>شرح توضيحي:</strong> يعرض هذا القسم تفاصيل الطلبات التي لم تنجح (مرتجع، فشل توصيل). يوضح تكلفة الشحن المهدرة وأي رسوم أخرى تحملتها بالإضافة إلى تصنيف آلي لأسباب الفشل وتصنيف فاعلية شركات الشحن.
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <ReportCard title="إجمالي الخسائر المقدرة" value={`${stats.totalLoss.toLocaleString('ar-EG')} ج.م`} icon={<ArrowDown size={24}/>} color="red" tooltip="إجمالي المبالغ المهدرة على مصاريف الشحن للطلبات التي لم يتم تسليمها." />
                <ReportCard title="إجمالي التعويضات المستردة" value={`${stats.totalCompensated.toLocaleString('ar-EG')} ج.م`} icon={<CheckCircle size={24}/>} color="indigo" tooltip="إجمالي المبالغ التي تم استردادها أو تعويضها من شركات الشحن." />
                <ReportCard title="عدد الطلبات الفاشلة/المرتجعة" value={stats.count.toString()} icon={<AlertTriangle size={24}/>} color="amber" tooltip="إجمالي عدد الطلبات التي حالتها مرتجع أو فشل توصيل." />
                <ReportCard title="عدد الطلبات المعوضة" value={stats.compensatedCount.toString()} icon={<Package size={24}/>} color="blue" tooltip="إجمالي عدد الطلبات التي تم تعويضك عنها." />
            </div>

            {/* RETURN REASONS AUDITING & SHIPPING AUDITING VISUALS */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Return Reasons Analysis */}
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                    <div>
                        <h3 className="text-md font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                            <span className="p-1.5 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-lg"><AlertTriangle size={16}/></span>
                            تشريح وتحليل أسباب المرتجعات الأكثر شيوعاً
                        </h3>
                        <p className="text-xs text-slate-400 mb-6">يصنف النظام أسباب فشل التوصيل والارتداد بشكل تلقائي عبر مسح الملاحظات للوقوف على الخلل الحقيقي.</p>

                        <div className="h-64">
                            {returnAudit.chartData.length === 0 ? (
                                <p className="text-center py-12 text-slate-400 text-xs">لا توجد بيانات مرتجعات متاحة حالياً للتصنيف.</p>
                            ) : (
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie
                                            data={returnAudit.chartData}
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={3}
                                            dataKey="value"
                                        >
                                            {returnAudit.chartData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={returnAudit.COLORS[index % returnAudit.COLORS.length]} />
                                            ))}
                                        </Pie>
                                        <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', direction: 'rtl' }} />
                                    </PieChart>
                                </ResponsiveContainer>
                            )}
                        </div>
                    </div>

                    <div className="space-y-2 mt-4">
                        {returnAudit.chartData.map((item, idx) => {
                            const ratio = stats.count > 0 ? (item.value / stats.count) * 100 : 0;
                            return (
                                <div key={idx} className="flex justify-between items-center text-xs p-2 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/80">
                                    <div className="flex items-center gap-2">
                                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: returnAudit.COLORS[idx % returnAudit.COLORS.length] }} />
                                        <span className="font-bold text-slate-600 dark:text-slate-300">{item.name}</span>
                                    </div>
                                    <span className="font-black text-slate-700 dark:text-slate-100">{item.value} حالة ({ratio.toFixed(1)}%)</span>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Shipping Companies Performance Auditing */}
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                    <div>
                        <h3 className="text-md font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                            <span className="p-1.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-lg"><Truck size={16}/></span>
                            تحليل ومساءلة شركات الشحن (معدلات المرتجعات والأموال المهدرة)
                        </h3>
                        <p className="text-xs text-slate-400 mb-6">يقارن هذا الجدول كفاءة كل شركة شحن بشكل دقيق: نسبة الارتداد والمال الضائع في الشحن المهدر.</p>

                        <div className="overflow-x-auto">
                            <table className="w-full text-right text-xs">
                                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-bold">
                                    <tr>
                                        <th className="px-3 py-2">شركة الشحن</th>
                                        <th className="px-3 py-2 text-center">إجمالي الشحنات</th>
                                        <th className="px-3 py-2 text-center">المرتجعة</th>
                                        <th className="px-3 py-2 text-center">معدل المرتجعات</th>
                                        <th className="px-3 py-2">الشحن الضائع (خسارة)</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                    {returnAudit.companyStats.map(c => {
                                        const returnRate = c.total > 0 ? (c.returned / c.total) * 100 : 0;
                                        return (
                                            <tr key={c.name} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                                <td className="px-3 py-3 font-bold text-slate-800 dark:text-white">{c.name}</td>
                                                <td className="px-3 py-3 text-center font-mono">{c.total}</td>
                                                <td className="px-3 py-3 text-center font-mono text-red-500">{c.returned}</td>
                                                <td className="px-3 py-3 text-center">
                                                    <div className="flex items-center justify-center gap-1">
                                                        <span className={`font-mono font-bold ${returnRate > 15 ? 'text-red-500' : 'text-slate-500'}`}>
                                                            {returnRate.toFixed(1)}%
                                                        </span>
                                                        <div className="w-12 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden inline-block sm:inline-block">
                                                            <div className={`h-full ${returnRate > 15 ? 'bg-red-500' : 'bg-blue-500'}`} style={{ width: `${returnRate}%` }}></div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="px-3 py-3 font-mono font-bold text-red-600">
                                                    -{c.loss.toLocaleString('ar-EG')} ج.م
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100 dark:border-slate-800">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white">سجل الطلبات الفاشلة بالتفصيل</h3>
                </div>
                 <div className="overflow-x-auto">
                    <table className="w-full text-right font-sans">
                        <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 text-[10px] font-black uppercase tracking-wider">
                           <tr>
                                <th className="px-4 py-3" title="اسم العميل ورقم هاتفه.">العميل</th>
                                <th className="px-4 py-3" title="المنتجات التي تم طلبها.">المنتجات</th>
                                <th className="px-4 py-3 text-center" title="إجمالي عدد القطع في الطلب.">الكمية</th>
                                <th className="px-4 py-3" title="سعر بيع المنتجات للعميل.">السعر</th>
                                <th className="px-4 py-3" title="تكلفة الشحن المدفوعة لشركة الشحن.">الشحن</th>
                                <th className="px-4 py-3" title="رسوم التأمين والمعاينة إن وجدت.">تأمين/معاينة</th>
                                <th className="px-4 py-3" title="تكلفة البضاعة الأصلية (سعر الجملة).">التكلفة</th>
                                <th className="px-4 py-3" title="حالة الطلب الحالية.">الحالة</th>
                                <th className="px-4 py-3" title="حالة تحصيل الأموال من شركة الشحن.">الدفع</th>
                                <th className="px-4 py-3 text-center" title="قيمة الخسارة الناتجة عن هذا الطلب (عادة مصاريف الشحن المهدرة).">الخسارة/التحصيل</th>
                           </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                            {failedOrders.length === 0 ? (
                                <tr><td colSpan={10} className="text-center py-12 text-slate-400">لا توجد طلبات فاشلة أو مرتجعة.</td></tr>
                            ) : (
                                failedOrders.map(order => {
                                    const { loss, net } = calculateOrderProfitLoss(order, settings);
                                    const actualLoss = loss > 0 ? loss : (net < 0 ? Math.abs(net) : 0);
                                    const codFee = calculateCodFee(order, settings);
                                    
                                    const compFees = settings.companySpecificFees?.[order.shippingCompany];
                                    const useCustom = compFees?.useCustomFees ?? false;
                                    const isPosOrder = order.channel === 'pos' || order.shippingCompany === 'كاشير - بيع مباشر';
                                    const insuranceRate = useCustom ? (compFees?.insuranceFeePercent ?? 0) : (settings.enableInsurance ? settings.insuranceFeePercent : 0);
                                    const inspectionCost = !isPosOrder && (order.includeInspectionFee ?? true) ? (useCustom ? (compFees?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
                                    const isInsured = order.isInsured ?? true;
                                    const insuranceFee = !isPosOrder && isInsured ? calculateInsuranceFee(order, insuranceRate, settings) : 0;
                                    const bostaVat = !isPosOrder && isBosta(order.shippingCompany) ? calculateBostaVat(order, insuranceFee, settings) : 0;

                                    const productsList = (order.items || []).map(i => `${i.name} (الكمية: ${i.quantity})`).join(' + ') || order.productName;

                                    return (
                                        <tr key={order.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 text-xs text-right">
                                            <td className="px-4 py-3 font-bold text-slate-800 dark:text-white">
                                                <div>{order.customerName}</div>
                                                <div className="text-[10px] text-slate-400 font-mono mt-0.5">{order.customerPhone}</div>
                                            </td>
                                            <td className="px-4 py-3 text-slate-500 max-w-[200px] truncate" title={productsList}>{productsList}</td>
                                            <td className="px-4 py-3 text-center font-bold text-slate-700 dark:text-slate-300">{(order.items || []).reduce((sum, item) => sum + item.quantity, 0)}</td>
                                            <td className="px-4 py-3 font-mono">{(order.productPrice || 0).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono">{(order.shippingFee || 0).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono">{(insuranceFee + inspectionCost + bostaVat).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono">{(order.items || []).reduce((sum, item) => sum + (item.cost * item.quantity), 0).toLocaleString()}</td>
                                            <td className="px-4 py-3">
                                                {(() => {
                                                    const isCancelledWithLoss = order.status === 'ملغي';
                                                    if (isCancelledWithLoss) {
                                                        return (
                                                            <span className="inline-flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold bg-orange-100 text-orange-700 dark:bg-orange-900/50 dark:text-orange-300 rounded-full whitespace-nowrap">
                                                                <span>ملغي</span>
                                                                <svg width="12" height="12" viewBox="0 0 24 24" fill="#25D366" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.937 3.659 1.432 5.631 1.433h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                                                                </svg>
                                                            </span>
                                                        );
                                                    }
                                                    return (
                                                        <span className="px-2 py-0.5 text-[10px] font-bold bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 rounded-full whitespace-nowrap">
                                                            {order.status.replace(/_/g, ' ')}
                                                        </span>
                                                    );
                                                })()}
                                            </td>
                                            <td className="px-4 py-3 text-[10px] text-slate-500">{order.paymentStatus}</td>
                                            <td className="px-4 py-3 text-center">
                                                <div className="font-black text-red-600">-{(actualLoss || 0).toLocaleString()}</div>
                                                {codFee > 0 && <div className="text-[9px] text-slate-400">تحصيل: {codFee}</div>}
                                                {order.compensationStatus === 'compensated' && (
                                                    <div className="mt-1 inline-flex flex-wrap items-center gap-1 px-1.5 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg text-[9px] font-bold border border-indigo-200 dark:border-indigo-800 text-right w-full justify-center">
                                                        <CheckCircle size={10} className="flex-shrink-0" />
                                                        <span>معوض ({order.compensationAmount}) {order.compensationCourierName ? `من ${order.compensationCourierName}` : ''}</span>
                                                    </div>
                                                )}
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                 </div>
            </div>

            {previewHtml && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
                    <div className="bg-slate-200 dark:bg-slate-800 w-full max-w-7xl h-full max-h-[90vh] rounded-2xl shadow-2xl flex flex-col border border-slate-300 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                        <div className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-t-2xl">
                            <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <FileText className="text-red-500" />
                                معاينة تقرير الخسائر
                            </h3>
                            <div className="flex items-center gap-2">
                                {shareLink && (
                                    <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800">
                                        <LinkIcon size={14} />
                                        <span className="text-xs font-bold whitespace-nowrap hidden sm:inline" dir="ltr">{shareLink.slice(0, 35)}...</span>
                                        <button onClick={handleCopyLink} className="p-1 hover:bg-indigo-100 dark:hover:bg-indigo-800 rounded-lg transition-colors text-indigo-600 dark:text-indigo-400" title="نسخ الرابط">
                                            {copied ? <Check size={14} /> : <Copy size={14} />}
                                        </button>
                                    </div>
                                )}
                                <button 
                                    onClick={handleShare} 
                                    disabled={isSharing}
                                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-sm disabled:opacity-50"
                                >
                                    {isSharing ? <Loader2 size={16} className="animate-spin"/> : <Share2 size={16}/>}
                                    <span className="hidden sm:inline">{isSharing ? 'جاري الإنشاء...' : 'مشاركة أونلاين'}</span>
                                </button>
                                <button 
                                    onClick={handleActualExportPDF} 
                                    disabled={isExporting}
                                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all shadow-sm disabled:opacity-50"
                                >
                                    {isExporting ? <Loader2 size={16} className="animate-spin"/> : <Download size={16}/>}
                                    <span className="hidden sm:inline">{isExporting ? 'جاري التصدير...' : 'تصدير PDF'}</span>
                                </button>
                                <button onClick={handleActualPrint} className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-xl font-bold text-sm hover:bg-slate-900 transition-all">
                                    <Printer size={16}/> <span className="hidden sm:inline">طباعة التقرير</span>
                                </button>
                                <button onClick={() => setPreviewHtml(null)} className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 rounded-xl transition-colors mr-2">
                                    <X size={20} />
                                </button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-auto p-4 sm:p-8 bg-slate-100 dark:bg-slate-800/50 flex align-top justify-center">
                            <div className="bg-white rounded-xl shadow-lg w-full overflow-hidden h-fit min-h-full" style={{ maxWidth: orientation === 'landscape' ? '1122.5px' : '793px' }}>
                                <iframe srcDoc={previewHtml} className="w-full h-[800px] border-0" title="Report Preview" />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const ComprehensiveReport: React.FC<ReportsPageProps> = ({ orders, settings, wallet, treasury, activeStore, dateRangeText, supplyOrders, setSettings, setWallet }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل التقرير الشامل...</p>
            </div>
        );
    }
    const { showInventoryValue, toggleInventoryValue } = useInventoryVisibility();
    const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('landscape');
    const [isContinuous, setIsContinuous] = useState(false);
    const [isExporting, setIsExporting] = useState(false);
    const [expandedPartnerId, setExpandedPartnerId] = useState<string | null>(null);
    const [isExitModalOpen, setIsExitModalOpen] = useState(false);
    const [selectedPartnerIdForExit, setSelectedPartnerIdForExit] = useState<string | undefined>(undefined);
    const [previewHtml, setPreviewHtml] = useState<string | null>(null);
    const [isSharing, setIsSharing] = useState(false);
    const [shareLink, setShareLink] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);
    const [reportSections, setReportSections] = useLocalStorage<ComprehensiveReportSections>('report_sections_prefs', {
        showSummary: true,
        showKpis: true,
        showWaterfall: true,
        showIncomeStatement: true,
        showTrialBalance: true,
        showOperational: true,
        showGeoPerformance: true,
        showProductProfitability: true,
        showPartners: true,
        showPartnerEqualization: true,
        showCustody: true,
        showCollectionLog: true,
        showLossLog: true,
        showExpensesLog: true,
        showInventoryLog: true,
        showSignatures: true,
        showRecommendations: true,
        showInventoryValue: showInventoryValue,
        includeMarkupsInProductRevenue: false,
        showExtraServicesRow: true,
        showFlexShipAmount: true,
        showColProducts: true,
        showColPrice: true,
        showColPriceAfterDiscount: true,
        showColCost: true,
        showColSurplusProfit: true,
        showColPercentageProfit: true,
        showColTotalProfitBeforeExpenses: true,
        showColDiscounts: true,
        showColShipping: true,
        showColInsurance: true,
        showColTax: true,
        showColInspection: true,
        showColCod: true,
        showColNetProfit: true,
    });
    const [isControlsExpanded, setIsControlsExpanded] = useState(false);

    useEffect(() => {
        setReportSections(prev => ({ ...prev, showInventoryValue: showInventoryValue }));
    }, [showInventoryValue]);

    useEffect(() => {
        if (previewHtml !== null) {
            const storeName = activeStore?.name || 'متجري';
            const html = generateComprehensiveFinancialReportHTML(orders, settings, wallet, storeName, orientation, isContinuous, dateRangeText, treasury, { ...reportSections, supplyOrders });
            setPreviewHtml(html);
        }
    }, [reportSections, orientation, isContinuous, supplyOrders]);
    
    const stats = useMemo(() => {
        const failedOrders = orders.filter(o => {
            const { loss, net } = calculateOrderProfitLoss(o, settings);
            return ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status) || loss > 0 || net < 0;
        });
        const collectedOrders = orders.filter(o => {
            return ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل', 'تم_الاستبدال'].includes(o.status) && !failedOrders.some(f => f.id === o.id);
        });

        let totalRevenue = 0;
        let totalProductRevenue = 0;
        let totalProductExtraMarkup = 0;
        let totalExtraMarkup = 0;
        let totalShippingRevenue = 0;
        let totalActualShipping = 0;
        let totalShippingMarkup = 0;
        let totalCogs = 0;
        let totalInsuranceFees = 0;
        let totalInspectionFees = 0;
        let totalCodFees = 0;
        let totalProfit = 0;
        let totalPercentageProfit = 0;
        let totalCommissionProfit = 0;
        let totalRequiredCollection = 0;

        collectedOrders.forEach(order => {
            const { profit, netRevenue } = calculateOrderProfitLoss(order, settings);
            const codFee = calculateCodFee(order, settings);
            
            const compFees = settings.companySpecificFees?.[order.shippingCompany];
            const useCustom = compFees?.useCustomFees ?? false;
            const insuranceRate = useCustom ? (compFees?.insuranceFeePercent ?? 0) : (settings.enableInsurance ? settings.insuranceFeePercent : 0);
            const isPosOrder = order.channel === 'pos' || order.shippingCompany === 'كاشير - بيع مباشر';
            const inspectionCost = !isPosOrder && (order.includeInspectionFee ?? true) ? (useCustom ? (compFees?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
            const isInsured = order.isInsured ?? true;
            const insuranceFee = !isPosOrder && isInsured ? calculateInsuranceFee(order, insuranceRate, settings) : 0;
            const inspectionAdjustment = (!isPosOrder && order.inspectionFeePaidByCustomer) ? 0 : inspectionCost;

            const safeProductPrice = Number(order.productPrice) || 0;
            const safeShippingFee = Number(order.shippingFee) || 0;
            const safeDiscount = Number(order.discount) || 0;
            const safeAdvance = Number(order.advancePayment) || 0;

            const isDefinitivelyPosOrder = order.channel === 'pos' || order.shippingCompany === 'كاشير - بيع مباشر' || order.shippingArea === 'نقطة البيع' || (order.id && order.id.startsWith('POS-'));
            const inspectionFeeParams = !isDefinitivelyPosOrder && (order.includeInspectionFee ?? true) ? (useCustom ? (compFees?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
            
            const totalCollected = order.totalAmountOverride !== undefined && order.totalAmountOverride !== null
                ? order.totalAmountOverride + safeAdvance
                : (safeProductPrice + safeShippingFee - safeDiscount + (order.inspectionFeePaidByCustomer ? inspectionFeeParams : 0));

            totalRevenue += totalCollected;
            totalShippingRevenue += order.shippingFee;
            totalRequiredCollection += netRevenue;

            const standardShipping = isPosOrder ? 0 : getStandardShippingFee(order, settings);
            totalActualShipping += standardShipping;

            const shippingMarkup = isPosOrder ? 0 : Math.max(0, order.shippingFee - standardShipping);
            totalShippingMarkup += shippingMarkup;

            totalCogs += (order.items || []).reduce((sum, item) => {
                const product = findProductInSettings(item, settings);
                const actualCost = (item.cost !== undefined && item.cost !== null && item.cost > 0) ? item.cost : (getLatestProductCost(product?.id || item.productId, settings) || item.cost || 0);
                return sum + (actualCost * item.quantity);
            }, 0);
            totalInsuranceFees += insuranceFee;
            totalInspectionFees += inspectionAdjustment;
            totalCodFees += codFee;
            totalProfit += profit;

            // Calculate item-level profits and separate base revenue from markup
            let orderProductExtraMarkup = 0;
            let orderBaseRevenue = 0;
            order.items.forEach(item => {
                const product = findProductInSettings(item, settings);
                const variant = product?.variants?.find(v => v.id === item.productId);
                const actualCost = (item.cost !== undefined && item.cost !== null && item.cost > 0) ? item.cost : (getLatestProductCost(product?.id || item.productId, settings) || item.cost || 0);
                const itemProfit = (item.price - actualCost) * item.quantity;
                
                const catalogPrice = resolveItemCatalogPrice(item, product, actualCost);

                let basePercentageProfit = itemProfit;
                if (item.price > catalogPrice) {
                    orderBaseRevenue += catalogPrice * item.quantity;
                    orderProductExtraMarkup += (item.price - catalogPrice) * item.quantity;
                    basePercentageProfit = Math.max(0, (catalogPrice - actualCost) * item.quantity);
                } else {
                    orderBaseRevenue += item.price * item.quantity;
                }

                if (product?.profitMode === 'commission') {
                    totalCommissionProfit += basePercentageProfit;
                } else {
                    totalPercentageProfit += basePercentageProfit;
                }
            });
            const totalOrderDiscounts = Number(order.discount) || 0;
            const netProductExtraMarkup = Math.max(0, orderProductExtraMarkup - totalOrderDiscounts);
            totalProductRevenue += orderBaseRevenue;
            totalProductExtraMarkup += netProductExtraMarkup;
            totalExtraMarkup += (netProductExtraMarkup + shippingMarkup);
        });

        let totalLoss = 0;
        let totalFailedShipping = 0;
        let totalFailedInsurance = 0;
        let totalFailedInspection = 0;
        let totalReturnFees = 0;

        failedOrders.forEach(order => {
            const { loss, net } = calculateOrderProfitLoss(order, settings);
            const actualLoss = loss > 0 ? loss : (net < 0 ? Math.abs(net) : 0);
            const compFees = settings.companySpecificFees?.[order.shippingCompany];
            const useCustom = compFees?.useCustomFees ?? false;
            
            const insuranceRate = useCustom ? (compFees?.insuranceFeePercent ?? 0) : (settings.enableInsurance ? settings.insuranceFeePercent : 0);
            const isPosOrder = order.channel === 'pos' || order.shippingCompany === 'كاشير - بيع مباشر';
            const inspectionCost = !isPosOrder && (order.includeInspectionFee ?? true) ? (useCustom ? (compFees?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
            const isInsured = order.isInsured ?? true;
            const insuranceFee = !isPosOrder && isInsured ? calculateInsuranceFee(order, insuranceRate, settings) : 0;
            const bostaVat = !isPosOrder && isBosta(order.shippingCompany) ? calculateBostaVat(order, insuranceFee, settings) : 0;
            
            const applyReturnFee = !isPosOrder && (useCustom ? (compFees?.enableFixedReturn ?? false) : settings.enableReturnShipping);
            const returnFeeAmount = applyReturnFee ? (useCustom ? (compFees?.returnShippingFee ?? 0) : settings.returnShippingFee) : 0;
            const inspectionFeeCollected = (!isPosOrder && order.inspectionFeePaidByCustomer) ? inspectionCost : 0;

            totalFailedShipping += order.shippingFee;
            totalFailedInsurance += insuranceFee;
            totalFailedInspection += (inspectionCost - inspectionFeeCollected);
            totalReturnFees += returnFeeAmount;
            totalLoss += actualLoss;
        });

        const extraPosSales = (settings?.posSales || []).filter(s => !orders.some(o => o.id === s.id || o.orderNumber === s.saleNumber));
        let extraPosProfit = 0;
        let extraPosRevenue = 0;
        let extraPosCOGS = 0;
        extraPosSales.forEach(s => {
            (s.items || []).forEach(item => {
                const cost = getLatestProductCost(item.productId, settings) || item.cost || 0;
                extraPosCOGS += (cost * (item.quantity || 1));
                extraPosRevenue += (item.price * (item.quantity || 1));
                const itemProfit = (item.price - cost) * (item.quantity || 1);
                extraPosProfit += itemProfit;
                totalPercentageProfit += itemProfit; // Add to percentage profit out of simplicity
            });
        });

        totalRevenue += extraPosRevenue;
        totalProductRevenue += extraPosRevenue;
        totalCogs += extraPosCOGS;
        totalProfit += extraPosProfit;

        const totalNetRevenue = totalRevenue - totalActualShipping - totalInsuranceFees - totalInspectionFees - totalCodFees - totalReturnFees;

        const totalExpenses = (wallet?.transactions || []).filter(t => t.type === 'سحب' && (t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings?.expenseCategories || []).includes(t.category || ''))).reduce((sum, t) => sum + t.amount, 0);

        const finalNet = totalProfit - totalLoss - totalExpenses;

        // --- NEW CALCULATIONS ---
        const successRate = orders.length > 0 ? Math.round((collectedOrders.length / orders.length) * 10000) / 100 : 0;
        const grossProfit = totalPercentageProfit + totalCommissionProfit;
        const lossRatio = grossProfit > 0 ? (totalLoss / grossProfit) * 100 : 0;
        const avgProfitPerOrder = orders.length > 0 ? finalNet / orders.length : 0;

        // Demographic Analysis (Exclude cancelled/draft/reviewing orders for accurate success rates & profits)
        const geoStats: Record<string, { count: number, success: number, revenue: number, loss: number, netProfit: number }> = {};
        orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل', 'مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن'].includes(o.status)).forEach(o => {
            const area = o.governorate || o.shippingArea || 'غير محدد';
            if (!geoStats[area]) geoStats[area] = { count: 0, success: 0, revenue: 0, loss: 0, netProfit: 0 };
            geoStats[area].count++;
            const { net, loss } = calculateOrderProfitLoss(o, settings);
            geoStats[area].netProfit += net;
            if (['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)) {
                geoStats[area].success++;
                geoStats[area].revenue += (o.items.reduce((sum, item) => sum + (item.price * item.quantity), 0) + o.shippingFee);
            }
            geoStats[area].loss += loss;
        });

        const geoData = Object.entries(geoStats).map(([name, s]) => ({
            name,
            successRate: s.count > 0 ? (s.success / s.count) * 100 : 0,
            revenue: s.revenue,
            loss: s.loss,
            net: s.netProfit
        })).sort((a, b) => b.revenue - a.revenue);

        // Expense Categories for Pie Chart
        const expenseCategories = [
            { name: 'إعلانات', value: (wallet?.transactions || []).filter(t => t.category === 'expense_ads').reduce((sum, t) => sum + t.amount, 0), color: '#4f46e5' },
            { name: 'إدارة شؤون الموظفين', value: (wallet?.transactions || []).filter(t => t.category === 'expense_hr' || t.category === 'expense_salary').reduce((sum, t) => sum + t.amount, 0), color: '#06b6d4' },
            { name: 'إيجار', value: (wallet?.transactions || []).filter(t => t.category === 'expense_rent').reduce((sum, t) => sum + t.amount, 0), color: '#8b5cf6' },
            { name: 'شحن مشتريات (توريد)', value: (wallet?.transactions || []).filter(t => (t.category as string) === 'supply_expense_shipping' || t.category === 'expense_shipping_fees').reduce((sum, t) => sum + t.amount, 0), color: '#f59e0b' },
            { name: 'مصاريف توريد أخرى', value: (wallet?.transactions || []).filter(t => (t.category as string) === 'supply_expense_other').reduce((sum, t) => sum + t.amount, 0), color: '#059669' },
            { name: 'أخرى', value: (wallet?.transactions || []).filter(t => {
                const isExp = t.type === 'سحب' && (t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings?.expenseCategories || []).includes(t.category || ''));
                if (!isExp) return false;
                const standardCategories = ['expense_ads', 'expense_salary', 'expense_hr', 'expense_rent', 'supply_expense_shipping', 'expense_shipping_fees', 'supply_expense_other'];
                return !standardCategories.includes(t.category || '');
            }).reduce((sum, t) => sum + t.amount, 0), color: '#ec4899' },
        ].filter(c => c.value > 0);

        // Carrier Performance (Filter to processed orders only)
        const carrierStats: Record<string, { count: number, success: number, shipping: number, profit: number }> = {};
        orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل', 'مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن'].includes(o.status)).forEach(o => {
            const name = o.shippingCompany || 'غير محدد';
            if (!carrierStats[name]) carrierStats[name] = { count: 0, success: 0, shipping: 0, profit: 0 };
            carrierStats[name].count++;
            if (['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)) carrierStats[name].success++;
            carrierStats[name].shipping += o.shippingFee;
            const { net } = calculateOrderProfitLoss(o, settings);
            carrierStats[name].profit += net;
        });

        // Product Profitability
        const productStats: Record<string, { revenue: number, extra: number, cost: number, sold: number, returns: number }> = {};
        orders.forEach(o => {
            o.items.forEach(item => {
                if (!productStats[item.name]) productStats[item.name] = { revenue: 0, extra: 0, cost: 0, sold: 0, returns: 0 };
                if (o.status === 'تم_التحصيل' || o.status === 'مدفوعة') {
                    const product = findProductInSettings(item, settings);
                    const actualCost = (item.cost !== undefined && item.cost !== null && item.cost > 0) ? item.cost : (getLatestProductCost(product?.id || item.productId, settings) || item.cost || 0);
                    const catalogPrice = resolveItemCatalogPrice(item, product, actualCost);
                    if (item.price > catalogPrice) {
                        productStats[item.name].revenue += catalogPrice * item.quantity;
                        productStats[item.name].extra += (item.price - catalogPrice) * item.quantity;
                    } else {
                        productStats[item.name].revenue += item.price * item.quantity;
                    }
                    productStats[item.name].cost += actualCost * item.quantity;
                    productStats[item.name].sold += item.quantity;
                } else if (['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'تمت_الاعادة_لشركة_الشحن'].includes(o.status)) {
                    productStats[item.name].returns += item.quantity;
                }
            });
        });

        // Wallet Sync
        const pendingCollection = orders.filter(o => (o.status === 'تم_توصيلها' || o.status === 'تم_التوصيل') && !o.collectionProcessed).reduce((sum, o) => sum + (o.productPrice + o.shippingFee), 0);
        
        // --- PARTNER CALCULATIONS ---
        const partners = settings.partners || [];
        const partnerTransactions = settings.partnerTransactions || [];
        
        const totalCapital = partnerTransactions
            .filter(t => t.type === 'capital_addition' || t.type === 'supply_funding' || t.type === 'shipping_funding' || t.type === 'expense_coverage')
            .reduce((sum, t) => sum + t.amount, 0);
            
        const totalLoans = partnerTransactions
            .filter(t => t.type === 'loan')
            .reduce((sum, t) => sum + t.amount, 0);

        const totalAdvances = partnerTransactions
            .filter(t => t.type === 'customer_advance')
            .reduce((sum, t) => sum + t.amount, 0);
            
        const totalProfitWithdrawals = partnerTransactions
            .filter(t => t.type === 'profit_withdrawal')
            .reduce((sum, t) => sum + t.amount, 0);

        const totalProfitDistributions = partnerTransactions
            .filter(t => t.type === 'profit_distribution')
            .reduce((sum, t) => sum + t.amount, 0);

        const partnerPerformance = partners.map(partner => {
            const partnerTx = partnerTransactions.filter(t => t.partnerId === partner.id);
            const capitalContribution = partnerTx.filter(t => t.type === 'capital_addition' || t.type === 'supply_funding' || t.type === 'shipping_funding' || t.type === 'expense_coverage').reduce((sum, t) => sum + t.amount, 0);
            const loans = partnerTx.filter(t => t.type === 'loan').reduce((sum, t) => sum + t.amount, 0);
            const advances = partnerTx.filter(t => t.type === 'customer_advance').reduce((sum, t) => sum + t.amount, 0);
            const withdrawals = partnerTx.filter(t => t.type === 'profit_withdrawal').reduce((sum, t) => sum + t.amount, 0);
            const distributions = partnerTx.filter(t => t.type === 'profit_distribution').reduce((sum, t) => sum + t.amount, 0);
            const repayments = partnerTx.filter(t => t.type === 'repayment').reduce((sum, t) => sum + t.amount, 0);
            
            const currentProfitShare = (finalNet * (partner.profitRatio || 0)) / 100;
            const undistributedShare = Math.max(0, currentProfitShare - distributions);
            const currentBalance = partner.balance || 0; 
            
            return {
                ...partner,
                capitalContribution,
                loans,
                advances,
                withdrawals,
                distributions,
                repayments,
                netLoan: Math.max(0, loans - repayments),
                currentProfitShare: undistributedShare,
                currentBalance
            };
        });

        // Inventory Value
        const inventoryValue = (settings?.products || []).reduce((sum, p) => {
            if (p.hasVariants && p.variants && p.variants.length > 0) {
                return sum + p.variants.reduce((vSum, v) => {
                    const stock = v.stockQuantity ?? (v as any).stock ?? 0;
                    const cost = getLatestProductCost(v.id, settings) || getLatestProductCost(p.id, settings) || (v.costPrice ?? p.costPrice ?? 0);
                    return vSum + (stock * cost);
                }, 0);
            }
            const stock = p.stockQuantity ?? (p as any).stock ?? 0;
            const cost = getLatestProductCost(p.id, settings) || (p.costPrice || 0);
            return sum + (stock * cost);
        }, 0);

        const inventorySalesValue = (settings?.products || []).reduce((sum, p) => {
            if (p.hasVariants && p.variants && p.variants.length > 0) {
                return sum + p.variants.reduce((vSum, v) => {
                    const stock = v.stockQuantity ?? (v as any).stock ?? 0;
                    return vSum + ((v.price || p.price || 0) * stock);
                }, 0);
            }
            const stock = p.stockQuantity ?? (p as any).stock ?? 0;
            return sum + ((p.price || 0) * stock);
        }, 0);

        return { 
            totalRevenue, totalProductRevenue, totalProductExtraMarkup, totalExtraMarkup, totalShippingRevenue, totalActualShipping, totalShippingMarkup, totalCogs, 
            totalInsuranceFees, totalInspectionFees, totalCodFees, totalProfit, 
            totalLoss, totalFailedShipping, totalFailedInsurance, totalFailedInspection, 
            totalReturnFees, totalExpenses, finalNet, totalPercentageProfit, totalCommissionProfit, totalNetRevenue,
            successRate, lossRatio, avgProfitPerOrder, carrierStats, productStats, pendingCollection,
            collectedOrdersCount: collectedOrders.length, geoData, expenseCategories, inventoryValue, inventorySalesValue,
            partnerPerformance, totalCapital, totalLoans, totalAdvances, totalProfitWithdrawals, totalRequiredCollection
        };
    }, [orders, settings, wallet]);

    const handlePreview = () => {
        const storeName = activeStore?.name || 'متجري';
        const html = generateComprehensiveFinancialReportHTML(orders, settings, wallet, storeName, orientation, isContinuous, dateRangeText, treasury, { ...reportSections, supplyOrders });
        setPreviewHtml(html);
        setShareLink(null);
    };

    const handleShare = async () => {
        if (!previewHtml) return;
        setIsSharing(true);
        try {
            const id = await shareReport(previewHtml);
            setShareLink(`${window.location.origin}/shared-report/${id}`);
        } catch (error) {
            console.error('Share Error:', error);
            alert('حدث خطأ أثناء إنشاء رابط المشاركة.');
        } finally {
            setIsSharing(false);
        }
    };

    const handleCopyLink = () => {
        if (shareLink) {
            navigator.clipboard.writeText(shareLink);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const handleExportExcel = () => {
        const storeName = activeStore?.name || 'متجري';
        exportComprehensiveFinancialReportExcel(orders, settings, wallet, {
            storeName,
            dateRangeText,
            supplyOrders
        });
    };

    const handleActualExportPDF = async () => {
        if (!previewHtml) return;
        setIsExporting(true);
        try {
            await exportHTMLToPDF(previewHtml, orientation, `التقرير_الختامي_الشامل_${new Date().toISOString().split('T')[0]}.pdf`, isContinuous);
        } catch (error) {
            console.error('PDF Export Error:', error);
            alert('حدث خطأ أثناء تصدير PDF.');
        } finally {
            setIsExporting(false);
        }
    };

    const handleActualPrint = () => {
        if (!previewHtml) return;
        printHTMLDirectly(previewHtml);
    };

    const handleExportPDF = async () => {
        setIsExporting(true);
        try {
            const storeName = activeStore?.name || 'متجري';
            const html = generateComprehensiveFinancialReportHTML(orders, settings, wallet, storeName, orientation, isContinuous, dateRangeText, treasury, { ...reportSections, supplyOrders });
            await exportHTMLToPDF(html, orientation, `التقرير_الختامي_الشامل_${new Date().toISOString().split('T')[0]}.pdf`, isContinuous);
        } catch (error) {
            console.error('PDF generation failed:', error);
            alert('حدث خطأ أثناء تصدير PDF. قد تحتاج لتجربة الطباعة والحفظ.');
        } finally {
            setIsExporting(false);
        }
    };

    const handlePrint = () => {
        const storeName = activeStore?.name || 'متجري';
        const html = generateComprehensiveFinancialReportHTML(orders, settings, wallet, storeName, orientation, isContinuous, dateRangeText, treasury, { ...reportSections, supplyOrders });
        printHTMLDirectly(html);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center flex-col sm:flex-row gap-4 mb-4">
                <h2 className="text-lg sm:text-xl font-bold text-slate-700 dark:text-white">ملخص شامل لأداء متجرك والمركز المالي للشركاء</h2>
                <div className="flex flex-wrap items-center gap-2 sm:gap-4 justify-center">
                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                        <button 
                            onClick={() => setIsContinuous(false)}
                            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${!isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            صفحات
                        </button>
                        <button 
                            onClick={() => setIsContinuous(true)}
                            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            متصل
                        </button>
                    </div>
                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                        <button 
                            onClick={() => setOrientation('portrait')}
                            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${orientation === 'portrait' ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            طولي
                        </button>
                        <button 
                            onClick={() => setOrientation('landscape')}
                            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${orientation === 'landscape' ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            عرضي
                        </button>
                    </div>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={() => setReportSections(prev => ({ ...prev, includeMarkupsInProductRevenue: !prev.includeMarkupsInProductRevenue }))}
                            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border shadow-sm ${
                                reportSections.includeMarkupsInProductRevenue
                                    ? 'bg-amber-500 text-white border-amber-600 shadow-amber-100 dark:shadow-none'
                                    : 'bg-emerald-600 text-white border-emerald-700 shadow-emerald-100 dark:shadow-none'
                            }`}
                            title="تغيير طريقة حساب وعرض أرباح المنتجات في التقرير (بالسعر الأساسي أو شامل الزيادات)"
                        >
                            <Coins size={14} />
                            <span>
                                {reportSections.includeMarkupsInProductRevenue
                                    ? 'عرض المنتجات: شامل الزيادات والتعلية'
                                    : 'عرض المنتجات: بالسعر الأساسي (بدون زيادات)'}
                            </span>
                        </button>
                        <button
                            onClick={() => setReportSections(prev => ({ ...prev, showExtraServicesRow: prev.showExtraServicesRow === false ? true : false }))}
                            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border shadow-sm ${
                                reportSections.showExtraServicesRow !== false
                                    ? 'bg-blue-600 text-white border-blue-700 shadow-blue-100 dark:shadow-none'
                                    : 'bg-slate-500 text-white border-slate-600 shadow-slate-100 dark:shadow-none'
                            }`}
                            title="إخفاء أو إظهار بند أرباح الخدمات والإضافات (معاينة / تعديل يدوي) في التقرير (عند الإخفاء يتم استبعاده تماماً ولا يضاف لأي بند آخر)"
                        >
                            <Coins size={14} />
                            <span>
                                {reportSections.showExtraServicesRow !== false
                                    ? 'بند الخدمات والإضافات: ظاهر'
                                    : 'بند الخدمات والإضافات: مخفي (مستبعد)'}
                            </span>
                        </button>
                        <button
                            onClick={() => setReportSections(prev => ({ ...prev, showFlexShipAmount: prev.showFlexShipAmount === false ? true : false }))}
                            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border shadow-sm ${
                                reportSections.showFlexShipAmount !== false
                                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-emerald-100 dark:shadow-none'
                                    : 'bg-slate-500 text-white border-slate-600 shadow-slate-100 dark:shadow-none'
                            }`}
                            title="إخفاء أو إظهار مبلغ الفليكس شيب من تقرير المعاينة"
                        >
                            <Truck size={14} />
                            <span>
                                {reportSections.showFlexShipAmount !== false
                                    ? 'مبلغ الفليكس شيب: ظاهر'
                                    : 'مبلغ الفليكس شيب: مخفي'}
                            </span>
                        </button>
                        <button 
                            onClick={handleExportExcel}
                            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 dark:shadow-none"
                            title="تصدير شيت إكسيل احترافي متعدد الصفحات بمعادلات ميزان المراجعة والأرباح"
                        >
                            <Download size={16}/>
                            تصدير Excel
                        </button>
                        <button 
                            onClick={handlePreview} 
                            disabled={isExporting}
                            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none disabled:opacity-50"
                        >
                            <Eye size={16}/>
                            معاينة للطباعة / PDF
                        </button>
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
                <div 
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 cursor-pointer group"
                    onClick={() => setIsControlsExpanded(!isControlsExpanded)}
                >
                    <div className="flex items-center gap-3">
                        <span className="p-1.5 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-lg group-hover:bg-indigo-100 transition-colors">
                            <SettingsIcon size={18} className={`transform transition-transform ${isControlsExpanded ? 'rotate-90' : ''}`} />
                        </span>
                        <div>
                            <h3 className="font-bold text-slate-800 dark:text-white text-sm sm:text-base">تخصيص الأقسام المعروضة في التقرير والطباعة</h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400">اختر الأقسام التي ترغب في تضمينها (يتم حفظ تفضيلاتك تلقائياً)</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        {isControlsExpanded ? <ArrowUp size={18} className="text-slate-400" /> : <ArrowDown size={18} className="text-slate-400" />}
                    </div>
                </div>

                {isControlsExpanded && (
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-700 space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
                        <div className="flex flex-wrap items-center gap-2">
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setReportSections(prev => ({
                                        ...prev,
                                        showSummary: true, showKpis: true, showWaterfall: true, showIncomeStatement: true,
                                        showTrialBalance: true, showOperational: true, showGeoPerformance: true,
                                        showProductProfitability: true, showPartners: true, showPartnerEqualization: true,
                                        showCustody: true, showCollectionLog: true, showLossLog: true, showExpensesLog: true,
                                        showInventoryLog: true, showSignatures: true, showRecommendations: true,
                                        showInventoryValue: true, showExtraServicesRow: true, showFlexShipAmount: true
                                    }));
                                }}
                                className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-900/30 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 rounded-lg text-xs font-bold transition-all border border-indigo-100 dark:border-indigo-800"
                            >
                                تحديد الكل
                            </button>
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setReportSections(prev => ({
                                        ...prev,
                                        showSummary: true, showKpis: true, showWaterfall: true, showIncomeStatement: true,
                                        showTrialBalance: true, showOperational: false, showGeoPerformance: false,
                                        showProductProfitability: false, showPartners: false, showPartnerEqualization: false,
                                        showCustody: false, showCollectionLog: false, showLossLog: false, showExpensesLog: false,
                                        showInventoryLog: false, showSignatures: true, showRecommendations: true,
                                        showInventoryValue: false, showExtraServicesRow: true, showFlexShipAmount: true
                                    }));
                                }}
                                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold transition-all border border-slate-200 dark:border-slate-600"
                            >
                                الأساسيات فقط
                            </button>
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setReportSections(prev => ({
                                        ...prev,
                                        showSummary: true, showKpis: true, showWaterfall: true, showIncomeStatement: true,
                                        showTrialBalance: true, showOperational: true, showGeoPerformance: true,
                                        showProductProfitability: true, showPartners: true, showPartnerEqualization: true,
                                        showCustody: true, showCollectionLog: false, showLossLog: false, showExpensesLog: false,
                                        showInventoryLog: false, showSignatures: true, showRecommendations: true,
                                        showInventoryValue: true, showExtraServicesRow: true, showFlexShipAmount: true
                                    }));
                                }}
                                className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 dark:bg-amber-900/30 dark:hover:bg-amber-900/50 text-amber-700 dark:text-amber-300 rounded-lg text-xs font-bold transition-all border border-amber-200 dark:border-amber-800"
                            >
                                تقرير مدقق بدون جداول السجلات
                            </button>
                            <button
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setReportSections(prev => ({
                                        ...prev,
                                        showSummary: false, showKpis: false, showWaterfall: false, showIncomeStatement: false,
                                        showTrialBalance: false, showOperational: false, showGeoPerformance: false,
                                        showProductProfitability: false, showPartners: false, showPartnerEqualization: false,
                                        showCustody: false, showCollectionLog: false, showLossLog: false, showExpensesLog: false,
                                        showInventoryLog: false, showSignatures: false, showRecommendations: false,
                                        showInventoryValue: false, showExtraServicesRow: false, showFlexShipAmount: false
                                    }));
                                }}
                                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-300 rounded-lg text-xs font-bold transition-all border border-rose-200 dark:border-rose-800"
                            >
                                إلغاء الكل
                            </button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                            {[
                                { key: 'showSummary', label: 'ملخص الإيرادات والتكاليف' },
                                { key: 'showKpis', label: 'شريط مؤشرات الأداء (KPIs)' },
                                { key: 'showWaterfall', label: 'المسار المالي (Waterfall)' },
                                { key: 'showIncomeStatement', label: 'قائمة الدخل الموحدة' },
                                { key: 'showTrialBalance', label: 'ميزان المراجعة والتدقيق' },
                                { key: 'showOperational', label: 'الأداء التشغيلي (الشحن)' },
                                { key: 'showGeoPerformance', label: 'التحليل الجغرافي للمحافظات' },
                                { key: 'showProductProfitability', label: 'ربحية وأداء المنتجات' },
                                { key: 'showPartners', label: 'توزيع أرباح الشركاء' },
                                { key: 'showPartnerEqualization', label: 'مقاصة ومعادلة بضاعة الشركاء' },
                                { key: 'showCustody', label: 'العهد والذمم المعلقة' },
                                { key: 'showCollectionLog', label: 'سجل التحصيل المالي' },
                                { key: 'showLossLog', label: 'سجل المرتجعات والخسائر' },
                                { key: 'showExpensesLog', label: 'سجل المصروفات والإكراميات' },
                                { key: 'showInventoryLog', label: 'سجل وحركة المخزون' },
                                { key: 'showSignatures', label: 'التوقيعات والاعتماد الرسمي' },
                                { key: 'showRecommendations', label: 'التوصيات الذكية' },
                                { key: 'showInventoryValue', label: 'قيمة البضاعة بالمخزن' },
                                { key: 'showExtraServicesRow', label: 'أرباح الخدمات والإضافات' },
                                { key: 'showFlexShipAmount', label: 'مبلغ الفليكس شيب' },
                            ].map((sec) => {
                                const isSelected = reportSections[sec.key as keyof ComprehensiveReportSections] !== false;
                                return (
                                    <button
                                        key={sec.key}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            if (sec.key === 'showInventoryValue') {
                                                toggleInventoryValue();
                                            } else {
                                                setReportSections(prev => ({
                                                    ...prev,
                                                    [sec.key]: !isSelected
                                                }));
                                            }
                                        }}
                                        className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all border ${
                                            isSelected 
                                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-900/30 dark:border-indigo-700 dark:text-indigo-300 shadow-sm' 
                                                : 'bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/50 dark:border-slate-700 dark:text-slate-400 hover:bg-slate-100 hover:border-slate-300'
                                        }`}
                                    >
                                        <div className={`w-4 h-4 shrink-0 rounded flex items-center justify-center text-[10px] transition-colors ${isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-transparent'}`}>✓</div>
                                        <span className="text-right flex-1">{sec.label}</span>
                                    </button>
                                );
                            })}
                        </div>
                        
                        <div className="pt-2">
                            <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">أعمدة سجل التحصيل (تخصيص):</h4>
                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                                {[
                                    { key: 'showColProducts', label: 'المنتجات' },
                                    { key: 'showColPrice', label: 'السعر' },
                                    { key: 'showColDiscounts', label: 'الخصومات' },
                                    { key: 'showColPriceAfterDiscount', label: 'السعر بعد الخصم' },
                                    { key: 'showColCost', label: 'التكلفة' },
                                    { key: 'showColSurplusProfit', label: 'ربح الزيادة' },
                                    { key: 'showColPercentageProfit', label: 'ربح النسبة' },
                                    { key: 'showColTotalProfitBeforeExpenses', label: 'الربح (قبل المصاريف)' },
                                    { key: 'showColShipping', label: 'الشحن' },
                                    { key: 'showColInsurance', label: 'تأمين' },
                                    { key: 'showColTax', label: 'ضريبة' },
                                    { key: 'showColInspection', label: 'معاينة' },
                                    { key: 'showColCod', label: 'COD' },
                                    { key: 'showColNetProfit', label: 'الصافي' },
                                ].map((sec) => {
                                    const isSelected = reportSections[sec.key as keyof ComprehensiveReportSections] !== false;
                                    return (
                                        <button
                                            key={sec.key}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setReportSections(prev => ({
                                                    ...prev,
                                                    [sec.key]: !isSelected
                                                }));
                                            }}
                                            className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-[11px] font-bold transition-all border ${
                                                isSelected 
                                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-900/30 dark:border-emerald-700 dark:text-emerald-300 shadow-sm' 
                                                    : 'bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/50 dark:border-slate-700 dark:text-slate-400 hover:bg-slate-100 hover:border-slate-300'
                                            }`}
                                        >
                                            <div className={`w-3.5 h-3.5 shrink-0 rounded flex items-center justify-center text-[9px] transition-colors ${isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-transparent'}`}>✓</div>
                                            <span className="text-right flex-1">{sec.label}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Stage 1: Revenues */}
            <div className="bg-blue-50/30 dark:bg-blue-900/5 p-6 rounded-3xl border border-blue-100 dark:border-blue-800/50">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-black shadow-lg">1</div>
                    <div>
                        <h3 className="text-lg font-black text-blue-900 dark:text-blue-100">المرحلة الأولى: الإيرادات والتدفقات (ماذا دخل إلينا؟)</h3>
                        <p className="text-xs text-blue-600/70 dark:text-blue-400/70">كل المبالغ التي تم تحصيلها من العملاء قبل أي خصومات.</p>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                    <ReportCard title="إجمالي مبيعات المنتجات" value={`${((stats.totalProductRevenue || 0) + (stats.totalProductExtraMarkup || 0)).toLocaleString('ar-EG')} ج.م`} icon={<Package size={24}/>} color="blue" subValue="ثمن البيع (الأساسي + زيادة المنتج)" tooltip="إجمالي المبالغ التي تم بيع المنتجات بها للعملاء (السعر الأساسي للمنتج + زيادة سعر المنتج)." />
                    <ReportCard title="إجمالي المطلوب تحصيله" value={`${(stats.totalRequiredCollection || 0).toLocaleString('ar-EG')} ج.م`} icon={<DollarSign size={24}/>} color="blue" subValue="المبلغ المفترض تحصيله من العملاء" tooltip="إجمالي المبالغ المفترض تحصيلها من العملاء عند التوصيل (ثمن المنتج + الشحن - العربون والخصومات)." />
                    <ReportCard title="مبيعات المنتجات (بالأساسي)" value={`${(stats.totalProductRevenue || 0).toLocaleString('ar-EG')} ج.م`} icon={<Package size={24}/>} color="blue" subValue="أصل ثمن البيع قبل الزيادة" tooltip="إجمالي السعر الأساسي للمنتجات المباعة، بدون حساب أي زيادة إضافية قمت بوضعها." />
                    <ReportCard title="الربح الإضافي (تعلية المنتجات)" value={`${(stats.totalProductExtraMarkup || 0).toLocaleString('ar-EG')} ج.م`} icon={<TrendingUp size={24}/>} color="emerald" subValue="الفرق بين سعر البيع والأساسي" tooltip="إجمالي الأرباح الناتجة عن بيع المنتجات بسعر أعلى من سعرها الأساسي الموصى به." />
                    <ReportCard title="تحصيل الشحن" value={`${(stats.totalShippingRevenue || 0).toLocaleString('ar-EG')} ج.م`} icon={<Truck size={24}/>} color="blue" subValue="المبالغ المدفوعة للشحن" tooltip="إجمالي رسوم الشحن التي دفعها العملاء عند استلام الطلبات." />
                </div>
            </div>

            <div className="flex justify-center py-2">
                <ArrowDown className="text-slate-300 animate-bounce" size={24} />
            </div>

            {/* Stage 2: Direct Costs */}
            <div className="bg-slate-50/50 dark:bg-slate-800/20 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-slate-700 text-white rounded-full flex items-center justify-center font-black shadow-lg">2</div>
                    <div>
                        <h3 className="text-lg font-black text-slate-800 dark:text-slate-200">المرحلة الثانية: التكاليف المباشرة (ماذا خرج فوراً؟)</h3>
                        <p className="text-xs text-slate-500">تكلفة البضاعة ومصاريف الشحن الأساسية للطلبات الناجحة.</p>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <ReportCard title="إجمالي تكلفة البضاعة" value={`${(stats.totalCogs || 0).toLocaleString('ar-EG')} ج.م`} icon={<Package size={24}/>} color="blue" subValue="للطلبات التي تم تحصيلها" tooltip="إجمالي التكلفة الأصلية للمنتجات (سعر الجملة) للطلبات التي تم تسليمها بنجاح." />
                    <ReportCard title="مصاريف شحن الذهاب" value={`${(stats.totalShippingRevenue || 0).toLocaleString('ar-EG')} ج.م`} icon={<Truck size={24}/>} color="red" subValue="المدفوعة لشركات الشحن" tooltip="إجمالي مصاريف الشحن التي تم دفعها لشركات الشحن مقابل توصيل الطلبات الناجحة." />
                </div>
            </div>

            <div className="flex justify-center py-2">
                <ArrowDown className="text-slate-300 animate-bounce" size={24} />
            </div>

            {/* Stage 3: Fees */}
            <div className="bg-amber-50/30 dark:bg-amber-900/5 p-6 rounded-3xl border border-amber-100 dark:border-amber-800/50">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-amber-600 text-white rounded-full flex items-center justify-center font-black shadow-lg">3</div>
                    <div>
                        <h3 className="text-lg font-black text-amber-900 dark:text-amber-100">المرحلة الثالثة: الرسوم والأعباء (ماذا استنزف الربح؟)</h3>
                        <p className="text-xs text-amber-600/70 dark:text-amber-400/70">رسوم الخدمات المخصومة من كل طلب ناجح.</p>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <ReportCard title="إجمالي التأمين (ناجح)" value={`${(stats.totalInsuranceFees || 0).toLocaleString('ar-EG')} ج.م`} icon={<FileText size={24}/>} color="blue" subValue="رسوم التأمين للطلبات المحصلة" tooltip="إجمالي رسوم التأمين التي تم خصمها على الطلبات التي تم تسليمها بنجاح." />
                    <ReportCard title="إجمالي المعاينة (ناجح)" value={`${(stats.totalInspectionFees || 0).toLocaleString('ar-EG')} ج.م`} icon={<Package size={24}/>} color="blue" subValue="رسوم المعاينة للطلبات المحصلة" tooltip="إجمالي رسوم المعاينة التي تم خصمها على الطلبات التي تم تسليمها بنجاح." />
                    <ReportCard title="إجمالي الـ COD (ناجح)" value={`${(stats.totalCodFees || 0).toLocaleString('ar-EG')} ج.م`} icon={<DollarSign size={24}/>} color="blue" subValue="رسوم التحصيل للطلبات المحصلة" tooltip="إجمالي رسوم الدفع عند الاستلام (COD) التي تم خصمها على الطلبات التي تم تسليمها بنجاح." />
                </div>
            </div>

            <div className="flex justify-center py-2">
                <ArrowDown className="text-slate-300 animate-bounce" size={24} />
            </div>

            {/* Stage 4: Losses & Expenses */}
            <div className="bg-red-50/30 dark:bg-red-900/5 p-6 rounded-3xl border border-red-100 dark:border-red-800/50">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-red-600 text-white rounded-full flex items-center justify-center font-black shadow-lg">4</div>
                    <div>
                        <h3 className="text-lg font-black text-red-900 dark:text-red-100">المرحلة الرابعة: الخسائر والمصروفات العامة (التحديات الإدارية)</h3>
                        <p className="text-xs text-red-600/70 dark:text-red-400/70">تكلفة المرتجعات والمصروفات الإدارية الثابتة.</p>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <ReportCard title="إجمالي خسائر المرتجعات" value={`${(stats.totalLoss || 0).toLocaleString('ar-EG')} ج.م`} icon={<ArrowDown size={24}/>} color="red" subValue="شحن مهدر (فشل/مرتجع)" tooltip="إجمالي الخسائر الناتجة عن مصاريف الشحن المهدرة للطلبات التي لم يتم تسليمها." />
                    <ReportCard title="إجمالي المصروفات الإدارية" value={`${(stats.totalExpenses || 0).toLocaleString('ar-EG')} ج.م`} icon={<DollarSign size={24}/>} color="amber" subValue="إعلانات، مرتبات، إلخ." tooltip="إجمالي المصروفات الإدارية المسجلة في المحفظة (مثل الإعلانات، الرواتب، الإيجار)." />
                </div>

                {/* Final Net Banner */}
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 rounded-2xl text-white text-center shadow-xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
                    <h3 className="text-lg font-bold opacity-80 relative z-10">صافي الربح النهائي</h3>
                    <p className="text-6xl font-black tracking-tighter mt-2 relative z-10">{(stats.finalNet || 0).toLocaleString('ar-EG')} ج.م</p>
                    <p className="text-xs opacity-70 mt-2 relative z-10">(إجمالي الأرباح - إجمالي الخسائر - إجمالي المصروفات والرسوم)</p>
                    <div className="mt-6 pt-6 border-t border-white/20 text-sm relative z-10">
                        نقطة التعادل: تحتاج إلى <span className="font-black underline text-yellow-300">{Math.ceil(stats.totalExpenses / (stats.totalProfit / stats.collectedOrdersCount || 1))}</span> أوردر ناجح إضافي لتغطية المصروفات الإدارية.
                    </div>
                </div>
            </div>

            <div className="flex justify-center py-2">
                <ArrowDown className="text-slate-300 animate-bounce" size={24} />
            </div>

            {/* Stage 5: Analysis */}
            <div className="bg-emerald-50/30 dark:bg-emerald-900/5 p-6 rounded-3xl border border-emerald-100 dark:border-emerald-800/50">
                <div className="flex items-center gap-3 mb-8">
                    <div className="w-10 h-10 bg-emerald-600 text-white rounded-full flex items-center justify-center font-black shadow-lg">5</div>
                    <div>
                        <h3 className="text-lg font-black text-emerald-900 dark:text-emerald-100">المرحلة الخامسة: تحليل الأداء والنمو (كيف نتحسن؟)</h3>
                        <p className="text-xs text-emerald-600/70 dark:text-emerald-400/70">مؤشرات الأداء وتحليل البيانات لاتخاذ قرارات أفضل.</p>
                    </div>
                </div>

                {/* KPIs */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className={`p-6 rounded-2xl border-2 text-center relative group ${stats.successRate >= 70 ? 'bg-emerald-50 border-emerald-200 dark:bg-emerald-900/10 dark:border-emerald-800' : 'bg-red-50 border-red-200 dark:bg-red-900/10 dark:border-red-800'}`} title="نسبة الطلبات التي تم تسليمها بنجاح من إجمالي الطلبات.">
                        <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-2 flex items-center justify-center gap-1">نسبة نجاح التوصيل <span className="text-slate-300 cursor-help">ⓘ</span></h4>
                        <p className={`text-3xl font-black ${stats.successRate >= 70 ? 'text-emerald-600' : 'text-red-600'}`}>{stats.successRate.toFixed(1)}%</p>
                        <p className="text-[10px] mt-1 text-slate-400">{stats.successRate < 70 ? 'تحتاج لتحسين الشحن/التأكيد' : 'أداء ممتاز'}</p>
                    </div>
                    <div className="p-6 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center relative group" title="نسبة الخسائر (المرتجعات) مقارنة بإجمالي الأرباح التشغيلية. كلما قلت النسبة كان أفضل.">
                        <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-2 flex items-center justify-center gap-1">نسبة الخسارة إلى الربح <span className="text-slate-300 cursor-help">ⓘ</span></h4>
                        <p className="text-3xl font-black text-red-600">{stats.lossRatio.toFixed(1)}%</p>
                        <p className="text-[10px] mt-1 text-slate-400">المرتجعات تلتهم هذه النسبة من أرباحك</p>
                    </div>
                    <div className="p-6 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center relative group" title="متوسط الربح الصافي الذي تحققه من كل طلب (بما في ذلك الطلبات الفاشلة).">
                        <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-2 flex items-center justify-center gap-1">متوسط الربح للطلب <span className="text-slate-300 cursor-help">ⓘ</span></h4>
                        <p className="text-3xl font-black text-blue-600">{(stats.avgProfitPerOrder || 0).toLocaleString()} ج.م</p>
                        <p className="text-[10px] mt-1 text-slate-400">صافي الربح الفعلي لكل طلب</p>
                    </div>
                </div>

                {/* Wallet & Inventory */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-2xl border border-emerald-200 dark:border-emerald-800">
                        <h4 className="font-bold text-emerald-800 dark:text-emerald-400 mb-1 flex items-center gap-2"><WalletIcon size={18}/> النقدية المحققة</h4>
                        <p className="text-2xl font-black text-emerald-600">{( (stats.totalCogs || 0) + ((stats.totalProfit || 0) - (stats.totalLoss || 0)) ).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</p>
                        <p className="text-[10px] text-emerald-500 mt-1">تكلفة البضاعة المباعة + صافي الربح التشغيلي</p>
                    </div>
                    <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-2xl border border-blue-200 dark:border-blue-800">
                        <h4 className="font-bold text-blue-800 dark:text-blue-400 mb-1 flex items-center gap-2"><Truck size={18}/> مستحقات الشحن</h4>
                        <p className="text-2xl font-black text-blue-600">{(stats.pendingCollection || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</p>
                        <p className="text-[10px] text-blue-400 mt-1">مبالغ تم توصيلها ولم تُحصل بعد</p>
                    </div>
                    <div className="bg-amber-50 dark:bg-amber-900/10 p-6 rounded-2xl border border-amber-200 dark:border-amber-800 relative group">
                        <div className="flex items-center justify-between mb-1">
                            <h4 className="font-bold text-amber-800 dark:text-amber-400 flex items-center gap-2"><Package size={18}/> قيمة المخزون</h4>
                            <button 
                                onClick={toggleInventoryValue}
                                className="p-1 rounded-lg bg-amber-100 dark:bg-amber-800/40 text-amber-800 dark:text-amber-300 hover:bg-amber-200 transition-colors"
                                title={showInventoryValue ? "إخفاء قيمة البضاعة المتاحة في المخزن" : "إظهار قيمة البضاعة المتاحة في المخزن"}
                            >
                                {showInventoryValue ? <Eye size={14} className="text-amber-600" /> : <EyeOff size={14} />}
                            </button>
                        </div>
                        {showInventoryValue ? (
                            <p className="text-2xl font-black text-amber-600">{(stats.inventoryValue || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</p>
                        ) : (
                            <p className="text-2xl font-black text-amber-600/50 tracking-widest">•••••• ج.م</p>
                        )}
                        <p className="text-[10px] text-amber-500 mt-1">قيمة البضاعة المتاحة في المخزن</p>
                    </div>
                </div>

                {/* NEW: Final Comprehensive Report Section */}
                <div className="bg-slate-900 p-8 rounded-3xl text-white shadow-2xl relative overflow-hidden mt-8">
                    <h2 className="text-2xl font-black mb-8 flex items-center gap-3">
                        <FileText className="text-blue-400" /> التقرير الختامي الشامل
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
                            <p className="text-slate-400 text-xs font-bold uppercase mb-2">إجمالي المبيعات (كلي)</p>
                            <p className="text-2xl font-black">{((stats.totalProductRevenue || 0) + (stats.totalExtraMarkup || 0) + (stats.totalShippingRevenue || 0)).toLocaleString('ar-EG')} <span className="text-sm font-normal">ج.م</span></p>
                        </div>
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
                            <p className="text-slate-400 text-xs font-bold uppercase mb-2">إجمالي تكلفة البضاعة (COGS)</p>
                            <p className="text-2xl font-black text-red-400">{(stats.totalCogs || 0).toLocaleString('ar-EG')} <span className="text-sm font-normal">ج.م</span></p>
                        </div>
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
                            <p className="text-slate-400 text-xs font-bold uppercase mb-2">إجمالي الخسائر (مرتجع)</p>
                            <p className="text-2xl font-black text-red-400">{(stats.totalLoss || 0).toLocaleString('ar-EG')} <span className="text-sm font-normal">ج.م</span></p>
                        </div>
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
                            <p className="text-slate-400 text-xs font-bold uppercase mb-2">إجمالي المصروفات الإدارية</p>
                            <p className="text-2xl font-black text-amber-400">{(stats.totalExpenses || 0).toLocaleString('ar-EG')} <span className="text-sm font-normal">ج.م</span></p>
                        </div>
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
                            <p className="text-slate-400 text-xs font-bold uppercase mb-2">الصافي النهائي</p>
                            <p className="text-3xl font-black text-emerald-400">{(stats.finalNet || 0).toLocaleString('ar-EG')} <span className="text-base font-normal">ج.م</span></p>
                        </div>
                        
                        <div className="lg:col-span-3 border-t border-slate-700 pt-6 mt-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                             <div>
                                <div className="flex items-center justify-between mb-4">
                                    <p className="text-slate-400 text-xs font-bold uppercase">قيمة البضاعة المتاحة (في المخازن)</p>
                                    <button 
                                        onClick={toggleInventoryValue}
                                        className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700"
                                    >
                                        {showInventoryValue ? <Eye size={14} className="text-blue-400" /> : <EyeOff size={14} />}
                                        <span>{showInventoryValue ? 'ظاهر' : 'مخفي'}</span>
                                    </button>
                                </div>
                                {showInventoryValue ? (
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
                                            <p className="text-slate-400 text-[10px]">بسعر الشراء</p>
                                            <p className="font-black">{(stats.inventoryValue || 0).toLocaleString('ar-EG')} ج.م</p>
                                        </div>
                                        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
                                            <p className="text-slate-400 text-[10px]">بسعر البيع</p>
                                            <p className="font-black text-emerald-300">{(stats.inventorySalesValue || 0).toLocaleString('ar-EG')} ج.م</p>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="bg-slate-800/30 p-6 rounded-xl border border-slate-700/50 text-center text-slate-400 text-sm">
                                        تم إخفاء قيمة البضاعة المتاحة في المخازن للحفاظ على السرية. <button onClick={toggleInventoryValue} className="text-blue-400 underline ml-1 font-bold">إظهار</button>
                                    </div>
                                )}
                             </div>
                             <div>
                                <p className="text-slate-400 text-xs font-bold uppercase mb-4">أرصدة وعهدة الشركاء</p>
                                <div className="space-y-2">
                                    {stats.partnerPerformance.map(p => (
                                        <div key={p.id} className="flex justify-between items-center bg-slate-800 p-2 rounded-lg text-sm">
                                            <span className="font-bold">{p.name}</span>
                                            <span className={`${p.currentBalance >= 0 ? 'text-emerald-400' : 'text-red-400'} font-black tabular-nums`}>
                                                {(p.currentBalance || 0).toLocaleString('ar-EG')} ج.م
                                            </span>
                                        </div>
                                    ))}
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="flex justify-center py-2">
                <ArrowDown className="text-slate-300 animate-bounce" size={24} />
            </div>

            {/* Stage 6: Partners */}
            <div className="bg-indigo-50/30 dark:bg-indigo-900/5 p-6 rounded-3xl border border-indigo-100 dark:border-indigo-800/50">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center font-black shadow-lg">6</div>
                        <div>
                            <h3 className="text-lg font-black text-indigo-900 dark:text-indigo-100">المرحلة السادسة: إدارة الشركاء وتوزيع الأرباح والتخارج</h3>
                            <p className="text-xs text-indigo-600/70 dark:text-indigo-400/70">متابعة رؤوس الأموال، السلف، ونسبة كل شريك ومستحقات تصفية التخارج.</p>
                        </div>
                    </div>
                    <button
                        onClick={() => {
                            setSelectedPartnerIdForExit(undefined);
                            setIsExitModalOpen(true);
                        }}
                        className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-600 to-amber-600 text-white rounded-xl font-bold text-sm shadow-md hover:from-red-700 hover:to-amber-700 transition-all cursor-pointer"
                    >
                        <LogOut size={16} />
                        🚪 حاسبة وتصفية تخارج شريك
                    </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <ReportCard title="إجمالي رأس المال" value={`${(stats.totalCapital || 0).toLocaleString('ar-EG')} ج.م`} icon={<DollarSign size={24}/>} color="blue" subValue="رؤوس الأموال المودعة" tooltip="إجمالي المبالغ التي ساهم بها الشركاء كرأس مال للمشروع." />
                    <ReportCard title="إجمالي السلف" value={`${(stats.totalLoans || 0).toLocaleString('ar-EG')} ج.م`} icon={<ArrowUp size={24}/>} color="red" subValue="مبالغ مسحوبة كسلف" tooltip="إجمالي المبالغ التي سحبها الشركاء كسلف أو قروض من المشروع." />
                    <ReportCard title="إجمالي العرابين" value={`${(stats.totalAdvances || 0).toLocaleString('ar-EG')} ج.م`} icon={<Coins size={24}/>} color="teal" subValue="العرابين المحصلة للشركاء" tooltip="إجمالي مبالغ العربون المستلمة والمودعة لدى الشركاء كعهد مبيعات." />
                    <ReportCard title="أرباح تحت التوزيع" value={`${(stats.finalNet || 0).toLocaleString('ar-EG')} ج.م`} icon={<TrendingUp size={24}/>} color="emerald" subValue="صافي ربح الفترة الحالية" tooltip="صافي الأرباح المحققة في هذه الفترة والجاهزة للتوزيع حسب النسب." />
                </div>

                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 flex justify-between items-center">
                        <h4 className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                             موقف الشركاء الحالي وحاسبة التصفية
                        </h4>
                        <span className="text-xs text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-3 py-1 rounded-full font-bold border border-amber-200 dark:border-amber-800">
                            صافي التصفية = (رأس المال + الأرباح) - المسحوبات
                        </span>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-right text-sm">
                            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-bold uppercase tracking-wider">
                                <tr>
                                    <th className="px-4 py-3">الشريك</th>
                                    <th className="px-4 py-3">النسبة</th>
                                    <th className="px-4 py-3">المساهمة</th>
                                    <th className="px-4 py-3">الربح المستحق</th>
                                    <th className="px-4 py-3">صافي السلف</th>
                                    <th className="px-4 py-3">العرابين المستلمة</th>
                                    <th className="px-4 py-3">الرصيد التراكمي</th>
                                    <th className="px-4 py-3 text-amber-600 font-black">حق الكاش للتخارج</th>
                                    <th className="px-4 py-3 text-center">إجراء التصفية</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                {stats.partnerPerformance.length === 0 ? (
                                    <tr><td colSpan={9} className="text-center py-8 text-slate-400">لا يوجد شركاء مسجلين.</td></tr>
                                ) : (
                                    stats.partnerPerformance.map(p => {
                                        const isExpanded = expandedPartnerId === p.id;
                                        const netLiquidationVal = Math.max(0, (p.capitalContribution || 0) + (p.currentProfitShare || 0) - (p.netLoan || 0));
                                        return (
                                            <React.Fragment key={p.id}>
                                                <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer" onClick={() => setExpandedPartnerId(isExpanded ? null : p.id)}>
                                                    <td className="px-4 py-3 font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                                        <span className="text-xs text-indigo-500 font-mono">{isExpanded ? '▼' : '◀'}</span>
                                                        {p.name}
                                                    </td>
                                                    <td className="px-4 py-3"><span className="bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-bold">{p.profitRatio}%</span></td>
                                                    <td className="px-4 py-3 font-mono">{(p.capitalContribution || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</td>
                                                    <td className="px-4 py-3 font-mono text-emerald-600">+{(p.currentProfitShare || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</td>
                                                    <td className="px-4 py-3 font-mono text-red-600 font-bold hover:underline" title="انقر لعرض تفاصيل المسحوبات">
                                                        -{(p.netLoan || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
                                                    </td>
                                                    <td className="px-4 py-3 font-mono text-teal-600">-{(p.advances || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}</td>
                                                    <td className={`px-4 py-3 font-black ${p.currentBalance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                                                        {(p.currentBalance || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                                    </td>
                                                    <td className="px-4 py-3 font-mono text-amber-600 font-black">
                                                        +{(netLiquidationVal || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م
                                                    </td>
                                                    <td className="px-4 py-3 text-center">
                                                        <button
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                setSelectedPartnerIdForExit(p.id);
                                                                setIsExitModalOpen(true);
                                                            }}
                                                            className="px-3 py-1.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 mx-auto"
                                                            title="فتح حاسبة وتصفية التخارج للشريك"
                                                        >
                                                            <LogOut size={13} />
                                                            تصفية وتخارج
                                                        </button>
                                                    </td>
                                                </tr>
                                                {isExpanded && (
                                                    <tr>
                                                        <td colSpan={9} className="px-4 py-2 bg-slate-50/80 dark:bg-slate-900/50">
                                                            <PartnerWithdrawalBreakdown partner={p} settings={settings} />
                                                        </td>
                                                    </tr>
                                                )}
                                            </React.Fragment>
                                        );
                                    })
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Partner Exit Guidance & Policy Card */}
                <div className="mt-6 bg-gradient-to-r from-amber-50/90 via-indigo-50/50 to-slate-50 dark:from-amber-950/30 dark:via-indigo-950/20 dark:to-slate-900 p-5 rounded-2xl border border-amber-200/80 dark:border-amber-800/40 shadow-sm">
                    <div className="flex items-start gap-3">
                        <div className="p-2.5 bg-gradient-to-br from-amber-500 to-red-600 text-white rounded-xl shadow-md shrink-0 mt-0.5">
                            <BookOpen size={20} />
                        </div>
                        <div className="space-y-3 w-full">
                            <div className="flex items-center justify-between flex-wrap gap-2">
                                <h4 className="font-black text-slate-800 dark:text-amber-300 text-sm flex items-center gap-2">
                                    📘 الدليل الإرشادي والسياسة التنفيذية لتخارج وتصفية الشركاء (Exit Policy Guide)
                                </h4>
                                <span className="text-[11px] font-bold text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/50 px-3 py-1 rounded-full border border-amber-300 dark:border-amber-700">
                                    إجراء محاسبي معتمد ⚖️
                                </span>
                            </div>

                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                                في حال رغبة أحد الشركاء في <strong>التخارج النهائي</strong>، يضمن لك النظام حساب كافة المستحقات بدقة متناهية وإخلاء الطرف قانونياً ومحاسبياً دون أي تضارب مالي وفق القواعد التالية:
                            </p>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
                                <div className="bg-white dark:bg-slate-800/90 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-1.5">
                                    <div className="font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 text-xs">
                                        <Calculator size={14} /> 1. معادلة مستحقات التخارج
                                    </div>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                                        صافي الكاش = <strong>(مساهمة رأس المال + الأرباح المستحقة)</strong> ناقصاً <strong>(إجمالي السلف والمسحوبات الشخصية + العرابين)</strong>.
                                    </p>
                                </div>

                                <div className="bg-white dark:bg-slate-800/90 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-1.5">
                                    <div className="font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1.5 text-xs">
                                        <Package size={14} /> 2. خيارات التسوية المتاحة
                                    </div>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                                        تصفية المبلغ <strong>نقداً من الخزينة</strong>، أو <strong>بضاعة بسعر التكلفة</strong> لحماية سيولة المتجر، أو <strong>تسوية مختلطة</strong>.
                                    </p>
                                </div>

                                <div className="bg-white dark:bg-slate-800/90 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-1.5">
                                    <div className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 text-xs">
                                        <Printer size={14} /> 3. التوثيق المالي والقانوني
                                    </div>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                                        إصدار <strong>"مستند وتوثيق إخلاء طرف رسمي"</strong> للطباعة والتوقيع، مع توفير نص شارح للتصفية قابل للإرسال عبر واتساب.
                                    </p>
                                </div>
                            </div>

                            {/* Personalized Friendly Partner Exit Guidance Statements */}
                            <div className="pt-2 space-y-3 border-t border-amber-200/60 dark:border-amber-800/30">
                                <h5 className="text-xs font-bold text-slate-800 dark:text-amber-300 flex items-center gap-1.5">
                                    🤝 صيغة وإرشادات التصفية والتخارج الشفافة للشركاء (حسب أرقام التقرير المعتمدة):
                                </h5>

                                {/* Educational Explanation Card */}
                                <div className="bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/50 rounded-xl p-4 text-xs space-y-2.5 leading-relaxed text-slate-700 dark:text-slate-300">
                                    <div className="flex items-center gap-1.5 text-indigo-900 dark:text-indigo-300 font-bold">
                                        <span className="text-sm">💡</span>
                                        <span>توضيح محاسبي هام: كيف يتم احتساب مستحقات الشركاء عند التصفية؟</span>
                                    </div>
                                    <p className="text-[11.5px] text-slate-600 dark:text-slate-400">
                                        تتم التصفية وحساب حقوق كل شريك بناءً على <strong className="text-indigo-700 dark:text-indigo-400">الربح الصافي الفعلي</strong> المضاف إلى <strong className="text-indigo-700 dark:text-indigo-400">رأس المال المستثمر</strong>، وليس بناءً على مبالغ التحصيل (المبيعات الإجمالية).
                                    </p>
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1.5">
                                        <div className="bg-white dark:bg-slate-800/80 p-2.5 rounded-lg border border-slate-100 dark:border-slate-700/60 shadow-xs">
                                            <span className="font-semibold text-slate-800 dark:text-slate-200 block mb-0.5">🪙 1. رأس المال الأصلي</span>
                                            <span className="text-[10.5px] text-slate-500 dark:text-slate-400">هو المبلغ المالي الأصلي الذي ساهم به الشريك عند التأسيس، ويظل ثابتاً ومحفوظاً باسمه دون تغيير.</span>
                                        </div>
                                        <div className="bg-white dark:bg-slate-800/80 p-2.5 rounded-lg border border-slate-100 dark:border-slate-700/60 shadow-xs">
                                            <span className="font-semibold text-emerald-700 dark:text-emerald-400 block mb-0.5">📈 2. الأرباح الصافية (تُوزع)</span>
                                            <span className="text-[10.5px] text-slate-500 dark:text-slate-400">تساوي (إجمالي المبيعات والتحصيل - تكلفة البضاعة المباعة بسعر الجملة - مصاريف التشغيل والشحن)، والربح الصافي فقط هو ما يتم تقسيمه وإضافته للشريك.</span>
                                        </div>
                                        <div className="bg-white dark:bg-slate-800/80 p-2.5 rounded-lg border border-slate-100 dark:border-slate-700/60 shadow-xs">
                                            <span className="font-semibold text-red-600 dark:text-red-400 block mb-0.5">🛑 3. مبالغ التحصيل (لا تُوزع)</span>
                                            <span className="text-[10.5px] text-slate-500 dark:text-slate-400">لا يجوز تقسيم مبيعات المحل الإجمالية؛ لأنها تشتمل على ثمن البضاعة الأصلي ومصاريف التشغيل، وتوزيعها يعني تصفية وخسارة رأسمال المحل بالكامل.</span>
                                        </div>
                                    </div>
                                    <div className="bg-amber-50/70 dark:bg-amber-950/20 p-3 rounded-lg border border-amber-200/50 dark:border-amber-900/30 text-[11px] space-y-1.5">
                                        <div className="font-bold text-amber-950 dark:text-amber-300 flex items-center gap-1">
                                            <span>📝 مثال توضيحي عملي بالأرقام لشريكين (أحمد وباسم):</span>
                                        </div>
                                        <div className="text-slate-600 dark:text-slate-300 leading-relaxed space-y-1">
                                            <p>نفترض أن <strong className="text-slate-800 dark:text-white">أحمد</strong> و<strong className="text-slate-800 dark:text-white">باسم</strong> أسسا محلاً تجارياً بالتساوي (بنسبة 50% لكل منهما):</p>
                                            <div className="pr-2.5 border-r border-amber-300 dark:border-amber-800/80 text-[10.5px] space-y-0.5">
                                                • <strong>رأس المال المودع:</strong> ساهم كل شريك بـ <strong>10,000 ج.م</strong> (إجمالي رأس مال المتجر = <strong>20,000 ج.م</strong> لشراء بضاعة المخزن).<br />
                                                • <strong>مبيعات المحل (التحصيل):</strong> عمل المحل مبيعات إجمالية قدرها <strong>100,000 ج.م</strong> كاش.<br />
                                                • <strong>تكلفة البضاعة المباعة بسعر الجملة:</strong> بلغت <strong>70,000 ج.م</strong> (يجب إعادتها للدرج فوراً لشراء بضاعة بديلة ولا تُوزع).<br />
                                                • <strong>المصاريف (تشغيل، تسويق، شحن وإرجاع):</strong> بلغت <strong>18,000 ج.م</strong>.<br />
                                                • <strong>الربح الصافي الفعلي للمحل:</strong> 100,000 مبيعات - 70,000 تكلفة - 18,000 مصاريف = <strong className="text-emerald-700 dark:text-emerald-400">12,000 ج.م</strong> (هو الربح القابل للتوزيع فقط).
                                            </div>
                                            <div className="pt-1 text-[10.5px]">
                                                👥 <strong>توزيع الأرباح وحساب الأرصدة (50% لكل منهما):</strong><br />
                                                • <strong className="text-slate-800 dark:text-white">الشريك أحمد (سحب 2,000 ج.م):</strong> نصيبه من الأرباح 6,000 ج.م، يضاف لرأس ماله الأصلي ليصبح مستحقاته 16,000 ج.م، وبعد خصم مسحوباته، يستلم كاش <strong className="text-indigo-600 dark:text-indigo-400">14,000 ج.م</strong> عند التخارج.<br />
                                                • <strong className="text-slate-800 dark:text-white">الشريك باسم (لم يسحب شيئاً):</strong> نصيبه من الأرباح 6,000 ج.م، ومستحقاته 16,000 ج.م، وبما أنه لم يسحب أي مسحوبات شخصية (0 ج.م)، يستلم كاش <strong className="text-indigo-600 dark:text-indigo-400">16,000 ج.م</strong> عند التخارج.
                                            </div>
                                             <div className="mt-2.5 p-2.5 bg-white/60 dark:bg-slate-900/40 border border-amber-200/55 dark:border-amber-900/40 rounded-md text-[10px] text-slate-500 dark:text-slate-400 leading-normal">
                                                💡 <strong className="text-amber-950 dark:text-amber-300">توضيح مالي حاسم (كيف تبلغ التكلفة 70 ألف ورأس المال 20 ألف فقط؟):</strong><br />
                                                السر يكمن في سرعة <strong>دوران وتدوير رأس المال (Capital Turnover)</strong> خلال الشهر. الشريكان لم يشتريا بضاعة بـ 70,000 ج.م دفعة واحدة، بل قاما بتشغيل الـ 20,000 ج.م الأصلية عدة مرات متتالية:
                                                <div className="mt-1 pr-2 border-r border-slate-300 dark:border-slate-700/80 space-y-0.5">
                                                    • <strong>أسبوع 1:</strong> يشتريان بضاعة بـ 20,000 ج.م كاش ويعرضانها للبيع (رأس المال تحوّل لبضاعة).<br />
                                                    • <strong>أسبوع 2:</strong> عند بيع جزء بـ 15,000 ج.م (جملتها 10,000 ج.م)، يسحبان <strong>10,000 ج.م</strong> ويعيدان شراء بضاعة بديلة لملء الرفوف بها مجدداً، مع ترك الـ 5,000 ج.م كأرباح وسيولة في الخزينة.<br />
                                                    • <strong>تكرار الدورة:</strong> تكرار هذه الدورة 3 إلى 4 مرات شهرياً يراكم مبيعات بـ 100 ألف وتكلفة بـ 70 ألف، مع بقاء قيمة الـ 20,000 ج.م الأصلية كأصول وبضائع مستمرة على الرفوف لحماية المحل من التصفية والانهيار.
                                                </div>

                                                <div className="mt-3 pt-2.5 border-t border-amber-200/40 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2.5 text-[9.5px]">
                                                    <div className="flex flex-wrap items-center gap-1.5">
                                                        <span>🛡️ تم إعداد الدليل والمثال المحاسبي بموجب:</span>
                                                        <strong className="text-indigo-700 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-100 dark:border-indigo-900/50">سياسة التعامل في التسويق مع شركة عبده ميديا © 2026</strong>
                                                    </div>
                                                    <button
                                                        onClick={() => {
                                                            const html = generateAbdoMediaPolicyHTML(activeStore?.name || 'شركائنا للنجاح');
                                                            printHTMLDirectly(html);
                                                        }}
                                                        className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white font-bold py-1 px-2.5 rounded-md text-[10px] cursor-pointer transition-colors shadow-sm hover:shadow active:scale-95"
                                                    >
                                                        <Printer className="w-3.5 h-3.5" />
                                                        <span>طباعة وثيقة السياسة الرسمية (عبده ميديا)</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {stats.partnerPerformance.map(p => {
                                        const capital = p.capitalContribution || 0;
                                        const profits = p.currentProfitShare || 0;
                                        const totalRights = capital + profits;
                                        const withdrawals = p.netLoan || 0;
                                        const netCash = totalRights - withdrawals;
                                        
                                        const totalStockVal = stats.inventoryValue || 85200;

                                        const copyCashMsg = `يا ${p.name || 'الشريك'}، عشان نصلّي على النبي ونصفّي الحساب بينّا بكل أمانة ووضوح:\nإنت ليك رأس مال ${(capital || 0).toLocaleString('ar-EG')} ج.م.\nوليك أرباح موزعة وغير موزعة إجماليتها ${(profits || 0).toLocaleString('ar-EG')} ج.م.\nيبقى إجمالي حقك بالكامل ${(totalRights || 0).toLocaleString('ar-EG')} ج.م.\nنخصم منهم المسحوبات الشخصية والتسويات اللي سحبتها خلال الفترة بـ ${(withdrawals || 0).toLocaleString('ar-EG')} ج.م.\n💰 يبقى صافي الفلوس اللي تدريجياً أو كاش بتاخدها في إيدك وحسابك يتصفّى تماماً وتخرج بالخير هي: ${(netCash || 0).toLocaleString('ar-EG')} ج.م.`;

                                        const otherPartnerName = stats.partnerPerformance.filter(o => o && o.id !== p.id).map(o => o.name).join(' أو ') || 'الشريك التاني';

                                        return (
                                            <div key={p.id} className="bg-white dark:bg-slate-800/95 border border-amber-200 dark:border-amber-800/60 rounded-xl p-3.5 space-y-3 shadow-sm text-xs">
                                                <div className="flex items-center justify-between border-b border-amber-100 dark:border-slate-700 pb-2">
                                                    <span className="font-bold text-slate-800 dark:text-amber-200 text-xs flex items-center gap-1.5">
                                                        👤 إرشاد وتصفية الشريك: <strong className="text-indigo-600 dark:text-indigo-400">{p.name}</strong>
                                                    </span>
                                                    <div className="flex items-center gap-1.5 flex-wrap justify-end">
                                                        <button
                                                            onClick={() => {
                                                                navigator.clipboard.writeText(copyCashMsg);
                                                                alert(`تم نسخ نص تصفية الكاش للشريك (${p.name || ''})!`);
                                                            }}
                                                            className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 px-2 py-1 rounded-md border border-indigo-200 dark:border-indigo-800 flex items-center gap-1 transition-all cursor-pointer"
                                                            title="نسخ نص التصفية كاش"
                                                        >
                                                            <Copy size={11} /> نسخ صياغة الكاش
                                                        </button>
                                                        <button
                                                            onClick={() => {
                                                                const otherName = stats.partnerPerformance.filter(o => o && o.id !== p.id).map(o => o.name).join(' أو ') || 'الشريك المستمر';
                                                                const copyBuyoutMsg = `🛍️ خيار شراء واستحواذ الشريك الآخر على حصة الشريك (${p.name || ''}) بالبضاعة والمتجر بالكامل:\n• إجمالي بضاعة المتجر = ${(totalStockVal || 0).toLocaleString('ar-EG')} ج.م.\n• يدفع الشريك المشتري (${otherName}) لـ (${p.name || ''}) مبلغ صافي مستحقاته كاش وقدره = ${(netCash || 0).toLocaleString('ar-EG')} ج.م.\n👉 النتيجة: انتقال ملكية المتجر والمخزون بنسبة 100% للشريك المشتري (${otherName}) وتخارج الشريك (${p.name || ''}) وإخلاء طرفه نهائياً.`;
                                                                navigator.clipboard.writeText(copyBuyoutMsg);
                                                                alert(`تم نسخ نص شراء واستحواذ الحصة للشريك (${p.name || ''})!`);
                                                            }}
                                                            className="text-[10px] font-bold text-purple-700 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-950/50 px-2 py-1 rounded-md border border-purple-300 dark:border-purple-800 flex items-center gap-1 transition-all cursor-pointer"
                                                            title="نسخ نص شراء واستحواذ الحصة بالكامل"
                                                        >
                                                            <Copy size={11} /> نسخ صياغة الاستحواذ
                                                        </button>
                                                    </div>
                                                </div>

                                                {/* Option 1: Cash Exit */}
                                                <div className="bg-amber-50/60 dark:bg-amber-950/40 p-3 rounded-lg border-r-4 border-amber-500 text-slate-700 dark:text-slate-300 leading-relaxed font-medium text-[11.5px] space-y-1">
                                                    <p className="font-semibold flex items-center gap-1 text-amber-800 dark:text-amber-300">
                                                        💵 <strong>خيار 1: التصفية والتخارج النقدي (الكاش):</strong>
                                                    </p>
                                                    <p className="font-semibold">يا <strong className="text-indigo-700 dark:text-indigo-300">{p.name}</strong>، عشان نصلّي على النبي ونصفّي الحساب بينّا بكل أمانة ووضوح:</p>
                                                    <div className="pr-1 space-y-0.5 text-slate-600 dark:text-slate-400 text-[11px]">
                                                        <div>• إنت ليك رأس مال <strong className="font-mono text-indigo-700 dark:text-indigo-300 font-bold">{(capital || 0).toLocaleString('ar-EG')} ج.م.</strong></div>
                                                        <div>• وليك أرباح موزعة وغير موزعة إجماليتها <strong className="font-mono text-emerald-700 dark:text-emerald-400 font-bold">{(profits || 0).toLocaleString('ar-EG')} ج.م.</strong></div>
                                                        <div>• يبقى إجمالي حقك بالكامل <strong className="font-mono text-slate-800 dark:text-white font-bold">{(totalRights || 0).toLocaleString('ar-EG')} ج.م.</strong></div>
                                                        <div>• نخصم منهم المسحوبات الشخصية والتسويات اللي سحبتها خلال الفترة بـ <strong className="font-mono text-red-600 dark:text-red-400 font-bold">{(withdrawals || 0).toLocaleString('ar-EG')} ج.م.</strong></div>
                                                    </div>
                                                    <div className="pt-2 font-bold text-slate-800 dark:text-white border-t border-amber-200/60 dark:border-amber-800/50 text-[11.5px] flex items-center justify-between flex-wrap gap-1">
                                                        <span>💰 يبقى صافي الفلوس اللي تدريجياً أو كاش بتاخدها في إيدك وتخرج بالخير:</span>
                                                        <span className="text-emerald-700 dark:text-emerald-300 font-black bg-emerald-100 dark:bg-emerald-950/90 px-2.5 py-1 rounded-md border border-emerald-300 dark:border-emerald-700 font-mono text-xs shadow-xs">
                                                            {(netCash ?? 0).toLocaleString('ar-EG')} ج.م
                                                        </span>
                                                    </div>
                                                </div>

                                                {/* Option 2: Buyout / Acquisition of Partner Share */}
                                                <div className="bg-purple-50/60 dark:bg-purple-950/30 p-3 rounded-lg border-r-4 border-purple-500 text-slate-700 dark:text-slate-300 leading-relaxed font-medium text-[11.5px] space-y-1">
                                                    <p className="font-semibold flex items-center justify-between text-purple-900 dark:text-purple-300">
                                                        <span>🛍️ <strong>خيار 2: شراء واستحواذ الشريك المستمر على حصة البضاعة والمتجر بالكامل:</strong></span>
                                                    </p>
                                                    <div className="p-2 rounded-md text-[11px] font-bold bg-purple-100/70 dark:bg-purple-950/80 text-purple-950 dark:text-purple-200 border border-purple-200 dark:border-purple-800 leading-normal">
                                                        🤝 <strong>اتفاق الاستحواذ والتملك الكامل:</strong> في حال رغبة الشريك المشتري <strong className="text-indigo-700 dark:text-indigo-300">({stats.partnerPerformance.filter(o => o && o.id !== p.id).map(o => o.name).join(' أو ') || 'الشريك المستمر'})</strong> في تملك المتجر والمخزون بالكامل ({(totalStockVal || 0).toLocaleString('ar-EG')} ج.م):
                                                        <br />
                                                        يدفع الشريك المشتري <strong className="text-indigo-700 dark:text-indigo-300">({stats.partnerPerformance.filter(o => o && o.id !== p.id).map(o => o.name).join(' أو ') || 'الشريك المستمر'})</strong> لـ <strong className="text-purple-700 dark:text-purple-300">{p.name}</strong> صافي مستحقاته كاش وقدره <strong className="font-mono text-emerald-700 dark:text-emerald-300 underline font-black text-xs">{(netCash ?? 0).toLocaleString('ar-EG')} ج.م</strong> مقابل شراء كافة حقوقه وحصته بالبضاعة وتملك المتجر بالكامل بنسبة 100% وإخلاء طرف <strong className="text-purple-700 dark:text-purple-300">{p.name}</strong> نهائياً.
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>

                            <div className="flex items-center justify-between pt-2 border-t border-amber-200/60 dark:border-amber-800/30 text-xs flex-wrap gap-2">
                                <span className="text-[11px] text-slate-600 dark:text-slate-400">
                                    💡 اضغط على زر <strong>"تصفية وتخارج"</strong> المقابل لأي شريك بالجدول أعلاه لبدء الإجراء.
                                </span>
                                <button
                                    onClick={() => {
                                        setSelectedPartnerIdForExit(undefined);
                                        setIsExitModalOpen(true);
                                    }}
                                    className="text-amber-700 dark:text-amber-300 font-bold hover:underline flex items-center gap-1 text-[11px] bg-amber-100/60 dark:bg-amber-900/40 px-3 py-1 rounded-lg border border-amber-300/50 cursor-pointer"
                                >
                                    <LogOut size={13} /> فتح حاسبة التخارج الآن ←
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* 6. Unified Financial Statement */}
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                    <FileText className="text-blue-500"/> القائمة المالية الموحدة (Unified Financial Statement)
                </h3>
                
                <div className="text-sm text-slate-600 dark:text-slate-400 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg mb-6 border-r-4 border-blue-500">
                    <strong>شرح توضيحي:</strong> هذه القائمة توضح حركة الأموال بالتفصيل. تبدأ بـ <b>الإيرادات</b> (كل ما تم تحصيله)، ثم نخصم منها <b>تكلفة المبيعات</b> (ثمن البضاعة ومصاريف الشحن) لنصل إلى <b>الربح التشغيلي</b> (أرباحك الصافية من الطلبات الناجحة). أخيراً نخصم <b>الخسائر والمصروفات والرسوم</b> لنصل إلى <b>صافي الربح النهائي</b>.
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-right border-collapse">
                        <tbody>
                            <tr className="bg-slate-100 dark:bg-slate-800 font-bold">
                                <td className="p-3 border border-slate-200 dark:border-slate-700" colSpan={2} title="إجمالي الأموال التي دخلت إلى النظام من الطلبات الناجحة.">1. الإيرادات (Revenues)</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="إجمالي قيمة المنتجات المباعة بالسعر الأساسي.">إجمالي مبيعات المنتجات (بالسعر الأساسي)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold">+{stats.totalProductRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="الفروقات الإيجابية الناتجة عن تعلية السعر وتعديل السعر اليدوي.">(+) إيرادات الزيادة في السعر</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold">+{stats.totalProductExtraMarkup.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="الفروقات الإيجابية الناتجة عن زيادة شحن الطلب عن تكلفة الشحن الفعلية.">(+) إيرادات زيادة الشحن (فرق الشحن)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold">+{stats.totalShippingMarkup.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="إجمالي رسوم الشحن التي دفعها العملاء.">إجمالي تحصيل الشحن من العملاء</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold">+{stats.totalShippingRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</td>
                            </tr>
                            <tr className="bg-slate-50 dark:bg-slate-800/50 font-bold">
                                <td className="p-3 border border-slate-200 dark:border-slate-700" title="مجموع الإيرادات بالكامل.">(=) إجمالي الإيرادات (Total Revenue)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700">{(stats.totalProductRevenue + stats.totalExtraMarkup + stats.totalShippingRevenue).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} ج.م</td>
                            </tr>

                            <tr className="bg-slate-100 dark:bg-slate-800 font-bold">
                                <td className="p-3 border border-slate-200 dark:border-slate-700" colSpan={2} title="التكاليف المباشرة المرتبطة بالطلبات الناجحة.">2. تكلفة المبيعات (Cost of Goods Sold)</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="إجمالي التكلفة الأصلية للمنتجات (سعر الجملة).">(-) إجمالي مستحقات الموردين (ثمن البضاعة)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-red-600 font-bold">-${stats.totalCogs.toLocaleString()} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="مصاريف الشحن المدفوعة لشركات الشحن للطلبات الناجحة.">(-) إجمالي مصاريف شحن الذهاب (لشركات الشحن)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-red-600 font-bold">-${stats.totalActualShipping.toLocaleString()} ج.م</td>
                            </tr>

                            <tr className="bg-blue-50 dark:bg-blue-900/20 font-bold">
                                <td className="p-3 border border-slate-200 dark:border-slate-700" colSpan={2} title="الربح المتبقي بعد خصم تكلفة المبيعات من الإيرادات.">3. إجمالي الربح التشغيلي (Gross Profit)</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8 text-sm text-slate-500" title="الربح الأساسي من نظام العمولة.">تفصيل الربح: ربح العمولة</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold text-sm">+{stats.totalCommissionProfit.toLocaleString()} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8 text-sm text-slate-500" title="الأرباح الناتجة عن تعلية سعر المنتجات وتعديل السعر اليدوي.">تفصيل الربح: الزيادة في السعر</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold text-sm">+{stats.totalProductExtraMarkup.toLocaleString()} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8 text-sm text-slate-500" title="الأثر المالي لتجاوز سعر الشحن الفعلي بناءً على الشحن المدخل بالطلب.">تفصيل الربح: زيادة الشحن (فرق الشحن)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold text-sm">+{stats.totalShippingMarkup.toLocaleString()} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8 text-sm text-slate-500" title="الربح من نظام المبيعات (النسبة المئوية).">تفصيل الربح: ربح المبيعات</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-emerald-600 font-bold text-sm">+{stats.totalPercentageProfit.toLocaleString()} ج.م</td>
                            </tr>
                            <tr className="bg-blue-100 dark:bg-blue-900/40 font-bold">
                                <td className="p-3 border border-slate-200 dark:border-slate-700" title="مجموع الأرباح التشغيلية.">(=) إجمالي الربح التشغيلي</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-blue-700 dark:text-blue-300">{(stats.totalCommissionProfit + stats.totalPercentageProfit + stats.totalShippingMarkup + stats.totalProductExtraMarkup).toLocaleString()} ج.م</td>
                            </tr>

                            <tr className="bg-red-50 dark:bg-red-900/20 font-bold">
                                <td className="p-3 border border-slate-200 dark:border-slate-700" colSpan={2} title="الخسائر والمصروفات الإدارية.">4. الخسائر والمصروفات (Losses & Expenses)</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="مجموع رسوم التأمين والمعاينة والدفع عند الاستلام المخصومة من الطلبات الناجحة.">(-) إجمالي رسوم التأمين والمعاينة والتحصيل (للطلبات الناجحة)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-red-600 font-bold">-${(stats.totalInsuranceFees + stats.totalInspectionFees + stats.totalCodFees).toLocaleString(undefined, {maximumFractionDigits: 2})} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="إجمالي مصاريف الشحن المهدرة على الطلبات الفاشلة والمرتجعة.">(-) إجمالي خسائر المرتجعات والفشل</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-red-600 font-bold">-${stats.totalLoss.toLocaleString()} ج.م</td>
                            </tr>
                            <tr>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="إجمالي المصروفات الإدارية المسجلة في المحفظة.">(-) إجمالي المصروفات الإدارية (إعلانات، رواتب...)</td>
                                <td className="p-3 border border-slate-200 dark:border-slate-700 text-red-600 font-bold">-${stats.totalExpenses.toLocaleString()} ج.م</td>
                            </tr>
                            {(() => {
                                const otherAdjustments = (stats.totalCommissionProfit + stats.totalPercentageProfit + stats.totalShippingMarkup + stats.totalProductExtraMarkup) - (stats.totalInsuranceFees + stats.totalInspectionFees + stats.totalCodFees) - stats.totalLoss - stats.totalExpenses - stats.finalNet;
                                if (Math.abs(otherAdjustments) > 0.01) {
                                    return (
                                        <tr>
                                            <td className="p-3 border border-slate-200 dark:border-slate-700 pr-8" title="تسويات تقفيل الطلبات وفروقات أسعار الخدمات الإضافية وتعديلات فرق التقفيل اليدوي.">
                                                {otherAdjustments > 0 ? '(-) تسويات وفروقات تقفيل يدوي وخدمات إضافية' : '(+) فروقات تسويات وتسجيلات إيجابية'}
                                            </td>
                                            <td className={`p-3 border border-slate-200 dark:border-slate-700 font-bold ${otherAdjustments > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                                                {otherAdjustments > 0 ? '-' : '+'}{Math.abs(otherAdjustments).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} ج.م
                                            </td>
                                        </tr>
                                    );
                                }
                                return null;
                            })()}

                            <tr className="bg-indigo-600 text-white font-black text-lg">
                                <td className="p-4 border border-indigo-700" title="الربح النهائي بعد خصم جميع التكاليف والخسائر والمصروفات.">(=) صافي الربح النهائي (Net Profit)</td>
                                <td className="p-4 border border-indigo-700">{stats.finalNet.toLocaleString()} ج.م</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            {/* 7. Charts & Tables */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <h3 className="font-bold mb-6 text-slate-800 dark:text-white flex items-center gap-2"><MapPin className="text-blue-500"/> تحليل المناطق (الأكثر ربحية)</h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={stats.geoData.slice(0, 8)} margin={{ top: 20 }}>
                                <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                                <YAxis hide />
                                <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', direction: 'rtl' }} />
                                <Bar dataKey="revenue" name="الإيرادات" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="net" name="صافي الربح" fill="#10b981" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="mt-4 overflow-x-auto">
                        <table className="w-full text-xs text-right">
                            <thead>
                                <tr className="text-slate-400 border-b border-slate-100 dark:border-slate-800">
                                    <th className="pb-2" title="اسم المحافظة أو المنطقة.">المنطقة</th>
                                    <th className="pb-2" title="نسبة الطلبات الناجحة في هذه المنطقة.">النجاح</th>
                                    <th className="pb-2" title="إجمالي الإيرادات المحصلة من هذه المنطقة.">الإيرادات</th>
                                    <th className="pb-2" title="صافي الربح بعد خصم الخسائر في هذه المنطقة.">الصافي</th>
                                </tr>
                            </thead>
                            <tbody>
                                {stats.geoData.slice(0, 5).map(g => (
                                    <tr key={g.name} className="border-b border-slate-50 dark:border-slate-800/50">
                                        <td className="py-2 font-bold">{g.name}</td>
                                        <td className="py-2">{g.successRate.toFixed(1)}%</td>
                                        <td className="py-2">{g.revenue.toLocaleString()}</td>
                                        <td className={`py-2 font-bold ${g.net >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{g.net.toLocaleString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <h3 className="font-bold mb-6 text-slate-800 dark:text-white flex items-center gap-2"><DollarSign className="text-amber-500"/> توزيع المصروفات الإدارية</h3>
                    <div className="h-64 flex items-center justify-center">
                        {stats.expenseCategories.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={stats.expenseCategories} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                                        {stats.expenseCategories.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                    <Legend verticalAlign="bottom" height={36}/>
                                </PieChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="text-slate-400 text-sm">لا توجد مصروفات مسجلة حالياً</div>
                        )}
                    </div>
                    <div className="mt-4 space-y-2">
                        {stats.expenseCategories.map(cat => (
                            <div key={cat.name} className="flex justify-between items-center text-sm">
                                <div className="flex items-center gap-2">
                                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }}></div>
                                    <span className="text-slate-600 dark:text-slate-400">{cat.name}</span>
                                </div>
                                <span className="font-bold">{cat.value.toLocaleString()} ج.م</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <h3 className="font-bold mb-4 text-slate-800 dark:text-white">أداء شركات الشحن</h3>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-right">
                            <thead>
                                <tr className="text-slate-400 border-b border-slate-100 dark:border-slate-800">
                                    <th className="pb-2" title="اسم شركة الشحن.">الشركة</th>
                                    <th className="pb-2" title="إجمالي عدد الطلبات المسندة للشركة.">الطلبات</th>
                                    <th className="pb-2" title="نسبة الطلبات التي تم تسليمها بنجاح.">النجاح</th>
                                    <th className="pb-2" title="صافي الربح المحقق من الطلبات المشحونة عبر هذه الشركة.">الربح</th>
                                </tr>
                            </thead>
                            <tbody>
                                {Object.entries(stats.carrierStats).map(([name, s]) => (
                                    <tr key={name} className="border-b border-slate-50 dark:border-slate-800/50">
                                        <td className="py-3 font-bold">{name}</td>
                                        <td className="py-3">{s.count}</td>
                                        <td className="py-3">{(s.success / s.count * 100).toFixed(1)}%</td>
                                        <td className={`py-3 font-bold ${s.profit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{s.profit.toLocaleString()} ج.م</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <h3 className="font-bold mb-4 text-slate-800 dark:text-white">تحليل ربحية المنتجات</h3>
                    <div className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800 p-3 rounded-lg mb-4 border-r-2 border-slate-300">
                        يوضح هذا الجدول أداء كل منتج على حدة. الكمية المباعة (للطلبات الناجحة)، الكمية المرتجعة (للطلبات الفاشلة والمرتجعة)، وإجمالي الربح الصافي من هذا المنتج.
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-right">
                            <thead>
                                <tr className="text-slate-400 border-b border-slate-100 dark:border-slate-800">
                                    <th className="pb-2" title="اسم المنتج.">المنتج</th>
                                    <th className="pb-2" title="إجمالي الكمية المباعة (في الطلبات الناجحة).">المباع</th>
                                    <th className="pb-2" title="إجمالي الكمية المرتجعة (في الطلبات الفاشلة).">المرتجع</th>
                                    <th className="pb-2" title="صافي الربح المحقق من هذا المنتج.">الربح</th>
                                </tr>
                            </thead>
                            <tbody>
                                {Object.entries(stats.productStats).map(([name, s]) => {
                                    const isMultiProfit = s.extra > 0;
                                    return (
                                        <tr key={name} className={`border-b border-slate-50 dark:border-slate-800/50 ${isMultiProfit ? 'bg-blue-50/50 dark:bg-blue-900/10' : ''}`}>
                                            <td className="py-3 font-bold">
                                                {name}
                                                {isMultiProfit && <span className="block text-[8px] text-blue-500 font-normal">ربح مركب (أساسي + زيادة)</span>}
                                            </td>
                                            <td className="py-3">{s.sold}</td>
                                            <td className="py-3">{s.returns}</td>
                                            <td className="py-3 font-bold text-emerald-600">{(s.revenue - s.cost + s.extra).toLocaleString()} ج.م</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* 8. Detailed Orders (Successful) */}
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                    <TrendingUp className="text-emerald-500"/> تفاصيل الأرباح (الطلبات الناجحة)
                </h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-right text-xs border-collapse">
                        <thead>
                            <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400">
                                <th className="p-2 border border-slate-100 dark:border-slate-800" title="رقم الطلب التعريفي.">رقم الطلب</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800" title="اسم العميل.">العميل</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800" title="المنتجات التي تم بيعها في هذا الطلب.">المنتجات</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800" title="سعر البيع الإجمالي للطلب.">سعر البيع</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800" title="صافي الربح المحقق من هذا الطلب بعد خصم التكاليف.">صافي الربح</th>
                            </tr>
                        </thead>
                        <tbody>
                            {orders.filter(o => o.status === 'تم_التحصيل' || o.status === 'مدفوعة').length > 0 ? (
                                orders.filter(o => o.status === 'تم_التحصيل' || o.status === 'مدفوعة').map(order => {
                                    const { profit } = calculateOrderProfitLoss(order, settings);
                                    let orderExtraMarkup = 0;
                                    order.items.forEach(item => {
                                        const product = findProductInSettings(item, settings);
                                        const actualCost = (item.cost !== undefined && item.cost !== null && item.cost > 0) ? item.cost : (getLatestProductCost(product?.id || item.productId, settings) || item.cost || 0);
                                        const catalogPrice = resolveItemCatalogPrice(item, product, actualCost);
                                        if (item.price > catalogPrice) {
                                            orderExtraMarkup += Math.max(0, (item.price - catalogPrice) * item.quantity);
                                        }
                                    });
                                    const netOrderExtraMarkup = Math.max(0, orderExtraMarkup - (Number(order.discount) || 0));
                                    const isMultiProfit = netOrderExtraMarkup > 0;
                                    return (
                                        <tr key={order.id} className={`border-b border-slate-50 dark:border-slate-800/50 ${isMultiProfit ? 'bg-blue-50/50 dark:bg-blue-900/10 border-r-4 border-r-blue-500' : ''}`}>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800 font-bold">{order.orderNumber}</td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800">{order.customerName}</td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800">
                                                {order.items.map((item, idx) => {
                                                    const p = findProductInSettings(item, settings);
                                                    const actualCost = (item.cost !== undefined && item.cost !== null && item.cost > 0) ? item.cost : (getLatestProductCost(p?.id || item.productId, settings) || item.cost || 0);
                                                    const catalogPrice = resolveItemCatalogPrice(item, p, actualCost);
                                                    const isItemMulti = item.price > catalogPrice && isMultiProfit;
                                                    return (
                                                        <div key={`${order.id}-${item.productId}-${idx}`} className="mb-1">
                                                            {item.name} ({item.quantity})
                                                            {isItemMulti && <span className="block text-[8px] text-blue-500 font-normal">ربح مركب (أساسي + زيادة)</span>}
                                                        </div>
                                                    );
                                                })}
                                            </td>
                                             <td className="p-2 border border-slate-100 dark:border-slate-800">{(order.productPrice ?? 0).toLocaleString()} ج.م</td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800 font-bold text-emerald-600">{(profit ?? 0).toLocaleString()} ج.م</td>
                                        </tr>
                                    );
                                })
                            ) : (
                                <tr>
                                    <td colSpan={5} className="p-4 text-center text-slate-400">لا توجد طلبات ناجحة حالياً</td>
                                </tr>
                            )}
                        </tbody>
                        {orders.filter(o => o.status === 'تم_التحصيل' || o.status === 'مدفوعة').length > 0 && (
                            <tfoot className="bg-slate-50 dark:bg-slate-800/50 font-black text-slate-900 dark:text-white">
                                <tr>
                                    <td colSpan={3} className="p-2 border border-slate-100 dark:border-slate-800 text-left">الإجمالي:</td>
                                    <td className="p-2 border border-slate-100 dark:border-slate-800">{((stats.totalProductRevenue ?? 0) + (stats.totalProductExtraMarkup ?? 0)).toLocaleString()} ج.م</td>
                                    <td className="p-2 border border-slate-100 dark:border-slate-800 text-emerald-600">{(stats.totalProfit ?? 0).toLocaleString()} ج.م</td>
                                </tr>
                            </tfoot>
                        )}
                    </table>
                </div>
            </div>

            {/* 9. Detailed Orders (Failed) */}
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                    <AlertTriangle className="text-red-500"/> تفاصيل الخسائر (الطلبات الفاشلة)
                </h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-right text-xs border-collapse">
                        <thead>
                            <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400">
                                <th className="p-2 border border-slate-100 dark:border-slate-800">رقم الطلب</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800">العميل</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800">المنتجات</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800">الحالة</th>
                                <th className="p-2 border border-slate-100 dark:border-slate-800">الخسارة</th>
                            </tr>
                        </thead>
                        <tbody>
                            {orders.filter(o => 
                                ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status)
                            ).length > 0 ? (
                                orders.filter(o => 
                                    ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status)
                                ).map(order => {
                                    const { loss } = calculateOrderProfitLoss(order, settings);
                                    return (
                                        <tr key={order.id} className="border-b border-slate-50 dark:border-slate-800/50">
                                            <td className="p-2 border border-slate-100 dark:border-slate-800 font-bold">{order.orderNumber}</td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800">{order.customerName}</td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800">
                                                {order.items.map((item, idx) => (
                                                    <div key={`${order.id}-${item.productId}-${idx}`} className="mb-1">
                                                        {item.name} ({item.quantity})
                                                    </div>
                                                ))}
                                            </td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800">
                                                {(() => {
                                                    const isCancelledWithLoss = order.status === 'ملغي';
                                                    if (isCancelledWithLoss) {
                                                        return (
                                                            <span className="inline-flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold bg-orange-100 text-orange-700 dark:bg-orange-900/50 dark:text-orange-300 rounded-full whitespace-nowrap">
                                                                <span>ملغي</span>
                                                                <svg width="12" height="12" viewBox="0 0 24 24" fill="#25D366" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.937 3.659 1.432 5.631 1.433h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                                                                </svg>
                                                            </span>
                                                        );
                                                    }
                                                    return (
                                                        <span className="px-2 py-0.5 bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300 rounded-full text-[10px]">
                                                            {order.status.replace(/_/g, ' ')}
                                                        </span>
                                                    );
                                                })()}
                                            </td>
                                            <td className="p-2 border border-slate-100 dark:border-slate-800 font-bold text-red-600">-{(loss ?? 0).toLocaleString()} ج.م</td>
                                        </tr>
                                    );
                                })
                            ) : (
                                <tr>
                                    <td colSpan={5} className="p-4 text-center text-slate-400">لا توجد طلبات فاشلة حالياً</td>
                                </tr>
                            )}
                        </tbody>
                        {orders.filter(o => 
                            ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status)
                        ).length > 0 && (
                            <tfoot className="bg-slate-50 dark:bg-slate-800/50 font-black text-slate-900 dark:text-white">
                                <tr>
                                    <td colSpan={4} className="p-2 border border-slate-100 dark:border-slate-800 text-left">الإجمالي:</td>
                                    <td className="p-2 border border-slate-100 dark:border-slate-800 text-red-600">-{(stats.totalLoss ?? 0).toLocaleString()} ج.م</td>
                                </tr>
                            </tfoot>
                        )}
                    </table>
                </div>
            </div>

            {previewHtml && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
                    <div className="bg-slate-200 dark:bg-slate-800 w-full max-w-7xl h-full max-h-[90vh] rounded-2xl shadow-2xl flex flex-col border border-slate-300 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                        <div className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-t-2xl">
                            <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <FileText className="text-blue-500" />
                                معاينة التقرير الختامي الشامل
                            </h3>
                            <div className="flex items-center gap-2">
                                {shareLink && (
                                    <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800">
                                        <LinkIcon size={14} />
                                        <span className="text-xs font-bold whitespace-nowrap hidden sm:inline" dir="ltr">{shareLink.slice(0, 35)}...</span>
                                        <button onClick={handleCopyLink} className="p-1 hover:bg-indigo-100 dark:hover:bg-indigo-800 rounded-lg transition-colors text-indigo-600 dark:text-indigo-400" title="نسخ الرابط">
                                            {copied ? <Check size={14} /> : <Copy size={14} />}
                                        </button>
                                    </div>
                                )}
                                <button 
                                    onClick={handleShare} 
                                    disabled={isSharing}
                                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-sm disabled:opacity-50"
                                >
                                    {isSharing ? <Loader2 size={16} className="animate-spin"/> : <Share2 size={16}/>}
                                    <span className="hidden sm:inline">{isSharing ? 'جاري الإنشاء...' : 'مشاركة أونلاين'}</span>
                                </button>
                                <button 
                                    onClick={handleExportExcel} 
                                    className="flex items-center gap-2 px-4 py-2 bg-emerald-700 text-white rounded-xl font-bold text-sm hover:bg-emerald-800 transition-all shadow-sm"
                                    title="تصدير شيت إكسيل محاسبي معتمد"
                                >
                                    <Download size={16}/>
                                    <span className="hidden sm:inline">تصدير Excel</span>
                                </button>
                                <button 
                                    onClick={handleActualExportPDF} 
                                    disabled={isExporting}
                                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all shadow-sm disabled:opacity-50"
                                >
                                    {isExporting ? <Loader2 size={16} className="animate-spin"/> : <Download size={16}/>}
                                    <span className="hidden sm:inline">{isExporting ? 'جاري التصدير...' : 'تصدير PDF'}</span>
                                </button>
                                <button onClick={handleActualPrint} className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-xl font-bold text-sm hover:bg-slate-900 transition-all">
                                    <Printer size={16}/> <span className="hidden sm:inline">طباعة التقرير</span>
                                </button>
                                <button onClick={() => setPreviewHtml(null)} className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 rounded-xl transition-colors mr-2">
                                    <X size={20} />
                                </button>
                            </div>
                        </div>
                        <div className="bg-slate-100 dark:bg-slate-900/80 px-4 py-2.5 border-b border-slate-300 dark:border-slate-700 overflow-x-auto flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap flex items-center gap-1">
                                <SettingsIcon size={14} /> تخصيص سريع:
                            </span>

                            {/* أزرار الحسابات العامة */}
                            <button
                                onClick={() => setReportSections(prev => ({ ...prev, includeMarkupsInProductRevenue: !prev.includeMarkupsInProductRevenue }))}
                                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shadow-sm ${
                                    reportSections.includeMarkupsInProductRevenue
                                        ? 'bg-amber-500 text-white border-amber-600 shadow-amber-100 dark:shadow-none'
                                        : 'bg-emerald-600 text-white border-emerald-700 shadow-emerald-100 dark:shadow-none'
                                }`}
                                title="تغيير طريقة حساب وعرض أرباح المنتجات في التقرير"
                            >
                                <Coins size={13} />
                                <span>
                                    {reportSections.includeMarkupsInProductRevenue
                                        ? 'المنتجات: شامل الزيادات'
                                        : 'المنتجات: السعر الأساسي فقط'}
                                </span>
                            </button>
                            <button
                                onClick={() => setReportSections(prev => ({ ...prev, showExtraServicesRow: prev.showExtraServicesRow === false ? true : false }))}
                                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shadow-sm ${
                                    reportSections.showExtraServicesRow !== false
                                        ? 'bg-blue-600 text-white border-blue-700 shadow-blue-100 dark:shadow-none'
                                        : 'bg-slate-500 text-white border-slate-600 shadow-slate-100 dark:shadow-none'
                                }`}
                                title="إخفاء أو إظهار بند أرباح الخدمات والإضافات في التقرير"
                            >
                                <Coins size={13} />
                                <span>
                                    {reportSections.showExtraServicesRow !== false
                                        ? 'بند الإضافات: ظاهر'
                                        : 'بند الإضافات: مخفي'}
                                </span>
                            </button>
                            <button
                                onClick={() => setReportSections(prev => ({ ...prev, showFlexShipAmount: prev.showFlexShipAmount === false ? true : false }))}
                                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shadow-sm ${
                                    reportSections.showFlexShipAmount !== false
                                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-emerald-100 dark:shadow-none'
                                        : 'bg-slate-500 text-white border-slate-600 shadow-slate-100 dark:shadow-none'
                                }`}
                                title="إخفاء أو إظهار مبلغ الفليكس شيب"
                            >
                                <Truck size={13} />
                                <span>
                                    {reportSections.showFlexShipAmount !== false
                                        ? 'الفليكس شيب: ظاهر'
                                        : 'الفليكس شيب: مخفي'}
                                </span>
                            </button>

                            <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1"></div>

                            {/* القوالب السريعة */}
                            <button
                                onClick={() => setReportSections(prev => ({
                                    ...prev,
                                    showSummary: true, showKpis: true, showWaterfall: true, showIncomeStatement: true,
                                    showTrialBalance: true, showOperational: true, showGeoPerformance: true,
                                    showProductProfitability: true, showPartners: true, showPartnerEqualization: true,
                                    showCustody: true, showCollectionLog: true, showLossLog: true, showExpensesLog: true,
                                    showInventoryLog: true, showSignatures: true, showRecommendations: true,
                                    showInventoryValue: true, showExtraServicesRow: true, showFlexShipAmount: true
                                }))}
                                className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 rounded-lg text-xs font-bold whitespace-nowrap border border-indigo-200 dark:border-indigo-800"
                            >
                                تحديد الكل
                            </button>
                            <button
                                onClick={() => setReportSections(prev => ({
                                    ...prev,
                                    showSummary: true, showKpis: true, showWaterfall: true, showIncomeStatement: true,
                                    showTrialBalance: true, showOperational: false, showGeoPerformance: false,
                                    showProductProfitability: false, showPartners: false, showPartnerEqualization: false,
                                    showCustody: false, showCollectionLog: false, showLossLog: false, showExpensesLog: false,
                                    showInventoryLog: false, showSignatures: true, showRecommendations: true,
                                    showInventoryValue: false, showExtraServicesRow: true, showFlexShipAmount: true
                                }))}
                                className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold whitespace-nowrap border border-slate-300 dark:border-slate-600"
                            >
                                الأساسيات فقط
                            </button>
                            <button
                                onClick={() => setReportSections(prev => ({
                                    ...prev,
                                    showSummary: true, showKpis: true, showWaterfall: true, showIncomeStatement: true,
                                    showTrialBalance: true, showOperational: true, showGeoPerformance: true,
                                    showProductProfitability: true, showPartners: true, showPartnerEqualization: true,
                                    showCustody: true, showCollectionLog: false, showLossLog: false, showExpensesLog: false,
                                    showInventoryLog: false, showSignatures: true, showRecommendations: true,
                                    showInventoryValue: true, showExtraServicesRow: true, showFlexShipAmount: true
                                }))}
                                className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 rounded-lg text-xs font-bold whitespace-nowrap border border-amber-300 dark:border-amber-700"
                            >
                                بدون سجلات
                            </button>

                            <div className="h-4 w-px bg-slate-300 dark:bg-slate-700 mx-1"></div>

                            {/* أزرار جميع الأقسام */}
                            {[
                                { key: 'showSummary', label: 'الإيرادات والتكاليف' },
                                { key: 'showKpis', label: 'مؤشرات KPIs' },
                                { key: 'showWaterfall', label: 'المسار المالي' },
                                { key: 'showIncomeStatement', label: 'قائمة الدخل' },
                                { key: 'showTrialBalance', label: 'ميزان المراجعة' },
                                { key: 'showOperational', label: 'الأداء التشغيلي' },
                                { key: 'showGeoPerformance', label: 'التحليل الجغرافي' },
                                { key: 'showProductProfitability', label: 'ربحية المنتجات' },
                                { key: 'showPartners', label: 'أرباح الشركاء' },
                                { key: 'showPartnerEqualization', label: 'معادلة البضاعة' },
                                { key: 'showCustody', label: 'العهد والذمم' },
                                { key: 'showCollectionLog', label: 'سجل التحصيل' },
                                { key: 'showLossLog', label: 'سجل المرتجعات' },
                                { key: 'showExpensesLog', label: 'المصروفات' },
                                { key: 'showInventoryLog', label: 'حركة المخزون' },
                                { key: 'showSignatures', label: 'الاعتماد والتوقيعات' },
                                { key: 'showRecommendations', label: 'التوصيات الذكية' },
                                { key: 'showInventoryValue', label: 'بضاعة المخزن' },
                            ].map((sec) => {
                                const isSelected = reportSections[sec.key as keyof ComprehensiveReportSections] !== false;
                                return (
                                    <button
                                        key={sec.key}
                                        onClick={() => {
                                            if (sec.key === 'showInventoryValue') {
                                                toggleInventoryValue();
                                            } else {
                                                setReportSections(prev => ({
                                                    ...prev,
                                                    [sec.key]: !isSelected
                                                }));
                                            }
                                        }}
                                        className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
                                            isSelected 
                                                ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                                                : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-600'
                                        }`}
                                    >
                                        <span>{isSelected ? '✓' : ''}</span>
                                        {sec.label}
                                    </button>
                                );
                            })}
                        </div>
                        <div className="flex-1 overflow-auto p-4 sm:p-8 bg-slate-100 dark:bg-slate-800/50 flex align-top justify-center">
                            <div className="bg-white rounded-xl shadow-lg w-full overflow-hidden h-fit min-h-full" style={{ maxWidth: orientation === 'landscape' ? '1122.5px' : '793px' }}>
                                <iframe srcDoc={previewHtml} className="w-full h-[800px] border-0" title="Report Preview" />
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {isExitModalOpen && (
                <PartnerExitModal
                    initialPartnerId={selectedPartnerIdForExit}
                    partners={settings.partners || []}
                    settings={settings}
                    wallet={wallet}
                    orders={orders}
                    onClose={() => setIsExitModalOpen(false)}
                    onExecuteLiquidation={(partnerId, amount, method, note) => {
                        if (setSettings) {
                            setSettings(prev => ({
                                ...prev,
                                partners: (prev.partners || []).map(pt => pt.id === partnerId ? {
                                    ...pt,
                                    balance: Math.max(0, (pt.balance || 0) - amount),
                                    notes: `${pt.notes || ''} [تم تخارج وتصفية الشريك بتاريخ ${new Date().toLocaleDateString('ar-EG')}]`
                                } : pt),
                                partnerTransactions: [
                                    {
                                        id: `tx_exit_${Date.now()}`,
                                        partnerId,
                                        partnerName: (prev.partners || []).find(pt => pt.id === partnerId)?.name || '',
                                        type: 'profit_withdrawal',
                                        amount,
                                        date: new Date().toISOString(),
                                        notes: note || 'تصفية وتخارج شريك'
                                    },
                                    ...(prev.partnerTransactions || [])
                                ]
                            }));
                        }
                        setIsExitModalOpen(false);
                    }}
                />
            )}
        </div>
    );
};

const PartnersFinancialReport: React.FC<ReportsPageProps> = ({ orders, settings, wallet, treasury, activeStore, dateRangeText, setSettings, setWallet }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل تقرير الشركاء...</p>
            </div>
        );
    }
    const { storeId } = useParams<{ storeId: string }>();
    const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('landscape');
    const [isContinuous, setIsContinuous] = useState(false);
    const [isExporting, setIsExporting] = useState(false);
    const [partnerSearchTerm, setPartnerSearchTerm] = useState('');
    const [partnerFilter, setPartnerFilter] = useState<'all' | 'loans' | 'top_ratio' | 'positive_balance'>('all');
    const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
    const [showSimulator, setShowSimulator] = useState(false);
    const [simulatedAmount, setSimulatedAmount] = useState<number>(50000);
    const [isExitModalOpen, setIsExitModalOpen] = useState(false);
    const [selectedPartnerIdForExit, setSelectedPartnerIdForExit] = useState<string | undefined>(undefined);

    const transactions = useMemo(() => settings.partnerTransactions || [], [settings.partnerTransactions]);
    const partners = useMemo(() => settings.partners || [], [settings.partners]);

    const stats = useMemo(() => {
        let grossMargin = 0;
        let operationalFees = 0;
        let returnsLosses = 0;

        orders.forEach(order => {
            const { profit, loss } = calculateOrderProfitLoss(order, settings);
            if (['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل', 'تم_الاستبدال'].includes(order.status)) {
                const totalItemsRevenue = (order.items || []).reduce((sum, item) => sum + (item.price * item.quantity), 0);
                const totalItemsCost = (order.items || []).reduce((sum, item) => sum + (item.cost * item.quantity), 0);
                grossMargin += (totalItemsRevenue - totalItemsCost);
                operationalFees += (totalItemsRevenue - totalItemsCost) - profit;
            } else if (['مرتجع', 'فشل_التوصيل', 'تمت_الاعادة_لشركة_الشحن', 'مرتجع_جزئي', 'مرتجع_بعد_الاستلام', 'ملغي'].includes(order.status)) {
                returnsLosses += loss;
            }
        });

        // Add standalone POS sales profit/revenue/cogs to match exactly with Income Statement and Dashboard
        let extraPosRevenue = 0;
        let extraPosCOGS = 0;
        let extraPosProfit = 0;
        const extraPosSales = (settings?.posSales || []).filter(s => !orders.some(o => o.id === s.id || o.orderNumber === s.saleNumber));
        extraPosSales.forEach(s => {
            (s.items || []).forEach(item => {
                const cost = getLatestProductCost(item.productId, settings) || item.cost || 0;
                extraPosCOGS += (cost * (item.quantity || 1));
                extraPosRevenue += (item.price * (item.quantity || 1));
                extraPosProfit += ((item.price - cost) * (item.quantity || 1));
            });
        });

        grossMargin += extraPosRevenue;
        operationalFees += extraPosRevenue - extraPosProfit;

        const adminExpenses = (wallet?.transactions || [])
            .filter(t => t.type === 'سحب' && (t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings?.expenseCategories || []).includes(t.category || '')))
            .reduce((sum, t) => sum + t.amount, 0);

        const totalOperationalExpenses = operationalFees + returnsLosses + adminExpenses;
        const allTimeNetProfit = grossMargin - totalOperationalExpenses;

        const distributed = transactions
            .filter(t => t.type === 'profit_distribution')
            .reduce((sum, t) => sum + t.amount, 0);

        const undistributedProfit = Math.max(0, allTimeNetProfit - distributed);

        const partnerOrderAdvancesItems = orders.filter(o => {
            const safeAdvance = Number(o.advancePayment) || 0;
            if (safeAdvance <= 0) return false;
            if (o.advancePaymentTreasuryId || (o.cashHolderId && o.cashHolderId.startsWith('treas_'))) return false;
            
            // Check if employee ID or cashHolderId actually belongs to a partner
            const empId = o.advancePaymentEmployeeId || (o.cashHolderId && o.cashHolderId.startsWith('emp_') ? o.cashHolderId.substring(4) : null);
            if (empId) {
                const isPt = partners.some(pt => String(pt.id) === String(empId));
                if (!isPt) return false;
            }
            return true;
        });
        const partnerOrderAdvancesTotal = partnerOrderAdvancesItems.filter(o => !(o.channel === "pos" || o.shippingCompany === "كاشير - بيع مباشر")).reduce((sum, o) => sum + (Number(o.advancePayment) || 0), 0);
        const partnerPOSSalesTotal = partnerOrderAdvancesItems.filter(o => o.channel === "pos" || o.shippingCompany === "كاشير - بيع مباشر").reduce((sum, o) => sum + (Number(o.advancePayment) || 0), 0);

        const txAdvancesTotal = transactions.filter(t => t.type === 'customer_advance').reduce((a, b) => a + b.amount, 0);

        const totals = {
            capital: transactions.filter(t => t.type === 'capital_addition' || t.type === 'supply_funding' || t.type === 'shipping_funding' || t.type === 'expense_coverage').reduce((a, b) => a + b.amount, 0),
            loans: transactions.filter(t => t.type === 'loan').reduce((a, b) => a + b.amount, 0),
            advances: txAdvancesTotal + partnerOrderAdvancesTotal,
            posSales: partnerPOSSalesTotal,
            repayments: transactions.filter(t => t.type === 'repayment').reduce((a, b) => a + b.amount, 0),
            withdrawals: transactions.filter(t => t.type === 'profit_withdrawal' || t.type === 'personal_withdrawal' || t.type === 'wallet_withdrawal' || t.type === 'custody_withdrawal').reduce((a, b) => a + b.amount, 0)
        };

        return {
            allTimeNetProfit,
            undistributedProfit,
            distributedProfit: distributed,
            totals,
            grossMargin,
            totalOperationalExpenses,
            partnerDetails: partners.map(p => {
                const pTx = transactions.filter(t => t.partnerId === p.id);
                const capital = pTx.filter(t => t.type === 'capital_addition' || t.type === 'supply_funding' || t.type === 'shipping_funding' || t.type === 'expense_coverage').reduce((a, b) => a + b.amount, 0);
                const loans = pTx.filter(t => t.type === 'loan').reduce((a, b) => a + b.amount, 0);
                
                const pTxAdvances = pTx.filter(t => t.type === 'customer_advance').reduce((a, b) => a + b.amount, 0);
                const pOrderAdvancesItems = orders.filter(o => {
                    const safeAdvance = Number(o.advancePayment) || 0;
                    if (safeAdvance <= 0) return false;
                    if (o.advancePaymentTreasuryId || (o.cashHolderId && o.cashHolderId.startsWith('treas_'))) return false;
                    
                    // Check if employee ID or cashHolderId actually belongs to a partner
                    const empId = o.advancePaymentEmployeeId || (o.cashHolderId && o.cashHolderId.startsWith('emp_') ? o.cashHolderId.substring(4) : null);
                    if (empId) {
                        const isPt = partners.some(pt => String(pt.id) === String(empId));
                        if (!isPt) return false;
                    }

                    if (o.advancePaymentPartnerId === p.id || o.cashHolderId === `part_${p.id}`) return true;
                    if (empId && String(empId) === String(p.id)) return true;
                    if (Array.isArray(o.advancePaymentHistory) && o.advancePaymentHistory.some((h: any) => h.recipientId === p.id || (h.recipientType === 'partner' && (h.recipientName === p.name || h.recipientId === p.id)))) return true;
                    if (partners.length === 1) return true;
                    return false;
                });
                const pOrderAdvances = pOrderAdvancesItems.filter(o => !(o.channel === "pos" || o.shippingCompany === "كاشير - بيع مباشر")).reduce((sum, o) => sum + (Number(o.advancePayment) || 0), 0);
                const pPOSSales = pOrderAdvancesItems.filter(o => o.channel === "pos" || o.shippingCompany === "كاشير - بيع مباشر").reduce((sum, o) => sum + (Number(o.advancePayment) || 0), 0);

                const advances = pTxAdvances + pOrderAdvances;
                const posSales = pPOSSales;

                const repayments = pTx.filter(t => t.type === 'repayment').reduce((a, b) => a + b.amount, 0);
                const withdrawals = pTx.filter(t => t.type === 'profit_withdrawal').reduce((a, b) => a + b.amount, 0);
                const distributions = pTx.filter(t => t.type === 'profit_distribution').reduce((a, b) => a + b.amount, 0);
                const profitShare = Math.max(0, (allTimeNetProfit * (p.profitRatio / 100)) - distributions);
                const balance = p.balance ?? 0;
                
                return {
                    ...p,
                    capital,
                    loans,
                    advances,
                    posSales,
                    repayments,
                    withdrawals,
                    distributions,
                    profitShare,
                    balance
                };
            })
        };
    }, [orders, settings, wallet, transactions, partners]);

    useEffect(() => {
        if (stats.undistributedProfit > 0) {
            setSimulatedAmount(stats.undistributedProfit);
        }
    }, [stats.undistributedProfit]);

    const filteredPartnerDetails = useMemo(() => {
        return stats.partnerDetails.filter(p => {
            const matchesSearch = p.name.toLowerCase().includes(partnerSearchTerm.toLowerCase()) || (p.phone && p.phone.includes(partnerSearchTerm));
            if (!matchesSearch) return false;

            if (partnerFilter === 'loans') {
                return (p.loans - p.repayments) > 0;
            }
            if (partnerFilter === 'top_ratio') {
                return p.profitRatio >= 20;
            }
            if (partnerFilter === 'positive_balance') {
                return p.balance > 0;
            }
            return true;
        });
    }, [stats.partnerDetails, partnerSearchTerm, partnerFilter]);

    const [previewHtml, setPreviewHtml] = useState<string | null>(null);
    const [isSharing, setIsSharing] = useState(false);
    const [shareLink, setShareLink] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);

    const handlePreview = () => {
        const html = generatePartnersFinancialReportHTML(stats, activeStore?.name || 'المتجر', orientation, isContinuous, dateRangeText);
        setPreviewHtml(html);
        setShareLink(null);
    };

    const handleShare = async () => {
        if (!previewHtml) return;
        setIsSharing(true);
        try {
            const id = await shareReport(previewHtml);
            setShareLink(`${window.location.origin}/shared-report/${id}`);
        } catch (error) {
            console.error('Share Error:', error);
            alert('حدث خطأ أثناء إنشاء رابط المشاركة.');
        } finally {
            setIsSharing(false);
        }
    };

    const handleCopyLink = () => {
        if (shareLink) {
            navigator.clipboard.writeText(shareLink);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const handleActualPrint = () => {
        if (!previewHtml) return;
        printHTMLDirectly(previewHtml);
    };

    const handleActualExportPDF = async () => {
        if (!previewHtml) return;
        setIsExporting(true);
        try {
            await exportHTMLToPDF(previewHtml, orientation, `تقرير_الشركاء_والمركز_المالي_${new Date().toISOString().split('T')[0]}.pdf`, isContinuous);
        } catch (error) {
            console.error("Error generating PDF:", error);
            alert('حدث خطأ أثناء تصدير PDF. قد تحتاج لتجربة الطباعة وحفظ كملف PDF.');
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div className="space-y-6">
            {/* Header Section */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <div>
                    <h2 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2">
                        <PieChartIcon className="text-indigo-600 dark:text-indigo-400" size={24} />
                        مركز الشركاء والتحليل المالي الذكي
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        متابعة الذمم المادية رؤوس الأموال والأرباح المستحقة (غير الموزعة) لكل شريك بالتفصيل
                    </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 sm:gap-3 w-full lg:w-auto">
                    <button
                        onClick={() => setShowSimulator(!showSimulator)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition-all border ${
                            showSimulator 
                                ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-100' 
                                : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 dark:bg-indigo-900/30 dark:text-indigo-300 dark:border-indigo-800'
                        }`}
                    >
                        <Calculator size={16} />
                        {showSimulator ? 'إغلاق محاكي التوزيع' : 'محاكي توزيع الأرباح ✨'}
                    </button>

                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                        <button 
                            onClick={() => setIsContinuous(false)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${!isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            صفحات
                        </button>
                        <button 
                            onClick={() => setIsContinuous(true)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            متصل
                        </button>
                    </div>

                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                        <button 
                            onClick={() => setOrientation('portrait')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${orientation === 'portrait' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            طولي
                        </button>
                        <button 
                            onClick={() => setOrientation('landscape')}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${orientation === 'landscape' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            عرضي
                        </button>
                    </div>

                    <button 
                        onClick={handlePreview} 
                        disabled={isExporting}
                        className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-xl font-bold text-xs hover:from-indigo-700 hover:to-violet-700 transition-all shadow-md shadow-indigo-200 dark:shadow-none disabled:opacity-50"
                    >
                        <Eye size={16}/>
                        معاينة التقرير وتصدير PDF
                    </button>
                </div>
            </div>

            {/* Interactive Simulator Panel */}
            {showSimulator && (
                <div className="bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl border border-indigo-800 shadow-xl space-y-4 animate-in slide-in-from-top duration-300">
                    <div className="flex justify-between items-center border-b border-indigo-800/80 pb-4">
                        <div>
                            <h3 className="text-lg font-bold flex items-center gap-2 text-indigo-200">
                                <Sparkles size={20} className="text-amber-400" />
                                محاكي توزيع الأرباح المقترحة
                            </h3>
                            <p className="text-xs text-indigo-300 mt-0.5">
                                أدخل مبلغاً افتراضياً لتوزيع الأرباح واعرف حصة كل شريك بالريال والنسبة فوراً
                            </p>
                        </div>
                        <button onClick={() => setShowSimulator(false)} className="text-indigo-400 hover:text-white p-1">
                            <X size={18} />
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                        <div className="space-y-1 md:col-span-1">
                            <label className="text-xs font-bold text-indigo-200">المبلغ المراد توزيعه (ج.م)</label>
                            <input 
                                type="number" 
                                value={simulatedAmount} 
                                onChange={(e) => setSimulatedAmount(Math.max(0, Number(e.target.value)))}
                                className="w-full bg-indigo-950/80 border border-indigo-700 rounded-xl px-4 py-2 text-white font-mono font-bold text-lg focus:outline-none focus:border-amber-400"
                            />
                        </div>

                        <div className="flex flex-wrap gap-2 md:col-span-2 items-center pt-5">
                            <span className="text-xs text-indigo-300 font-bold">خيارات سريعة:</span>
                            <button 
                                onClick={() => setSimulatedAmount(stats.undistributedProfit)}
                                className="px-3 py-1.5 bg-indigo-800/60 hover:bg-indigo-700 text-indigo-200 rounded-lg text-xs font-bold border border-indigo-700 transition-colors"
                            >
                                الأرباح القابلة للتوزيع ({stats.undistributedProfit.toLocaleString()} ج.م)
                            </button>
                            <button 
                                onClick={() => setSimulatedAmount(25000)}
                                className="px-3 py-1.5 bg-indigo-800/60 hover:bg-indigo-700 text-indigo-200 rounded-lg text-xs font-bold border border-indigo-700 transition-colors"
                            >
                                25,000 ج.م
                            </button>
                            <button 
                                onClick={() => setSimulatedAmount(50000)}
                                className="px-3 py-1.5 bg-indigo-800/60 hover:bg-indigo-700 text-indigo-200 rounded-lg text-xs font-bold border border-indigo-700 transition-colors"
                            >
                                50,000 ج.م
                            </button>
                            <button 
                                onClick={() => setSimulatedAmount(100000)}
                                className="px-3 py-1.5 bg-indigo-800/60 hover:bg-indigo-700 text-indigo-200 rounded-lg text-xs font-bold border border-indigo-700 transition-colors"
                            >
                                100,000 ج.م
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                        {stats.partnerDetails.map(p => {
                            const partnerShare = (simulatedAmount * p.profitRatio) / 100;
                            const newExpectedBalance = p.balance + partnerShare;
                            return (
                                <div key={p.id} className="bg-indigo-950/50 border border-indigo-800/70 p-3.5 rounded-xl flex flex-col justify-between">
                                    <div className="flex justify-between items-center mb-2">
                                        <span className="font-bold text-sm text-white">{p.name}</span>
                                        <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[11px] font-black px-2 py-0.5 rounded-full">
                                            {p.profitRatio}%
                                        </span>
                                    </div>

                                    <div className="space-y-1 text-xs">
                                        <div className="flex justify-between text-indigo-200">
                                            <span>الحصة المستحقة:</span>
                                            <span className="font-mono font-bold text-emerald-400 text-sm">+{partnerShare.toLocaleString('ar-EG')} ج.م</span>
                                        </div>
                                        <div className="flex justify-between text-indigo-300 text-[11px]">
                                            <span>الرصيد المتوقع بعد التوزيع:</span>
                                            <span className="font-mono font-bold text-white">{newExpectedBalance.toLocaleString('ar-EG')} ج.م</span>
                                        </div>
                                    </div>

                                    <div className="w-full bg-indigo-900/80 h-1.5 rounded-full mt-2.5 overflow-hidden">
                                        <div className="bg-amber-400 h-full rounded-full transition-all duration-300" style={{ width: `${Math.min(100, p.profitRatio)}%` }}></div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Overall Historical Profit Banner */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gradient-to-r from-indigo-500 via-indigo-600 to-violet-600 text-white p-5 rounded-2xl shadow-lg">
                <div className="space-y-1">
                    <p className="text-xs font-bold text-indigo-200 uppercase tracking-wider">المركز المالي الإجمالي للمتجر</p>
                    <h3 className="text-2xl sm:text-3xl font-black">{stats.allTimeNetProfit.toLocaleString('ar-EG')} ج.م</h3>
                    <p className="text-xs text-indigo-100">صافي الأرباح المحققة تاريخياً لجميع الشركاء</p>
                </div>
                <div className="flex gap-2">
                    <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/20 text-right">
                        <p className="text-[10px] text-indigo-200 font-bold">أرباح تم توزيعها</p>
                        <p className="text-lg font-black text-emerald-300">+{(stats.distributedProfit ?? 0).toLocaleString()} ج.م</p>
                    </div>
                    <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/20 text-right">
                        <p className="text-[10px] text-indigo-200 font-bold">أرباح قابلة للتوزيع</p>
                        <p className="text-lg font-black text-amber-300">{(stats.undistributedProfit ?? 0).toLocaleString()} ج.م</p>
                    </div>
                </div>
            </div>

            {/* Key Metric Scorecards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
                <ReportCard title="إجمالي رأس المال" value={`${(stats.totals?.capital ?? 0).toLocaleString()} ج.م`} icon={<ArrowUpLeft size={22}/>} color="blue" tooltip="مجموع رؤوس الأموال التي تم إيداعها من قبل جميع الشركاء." />
                <ReportCard title="الأرباح الموزعة" value={`${(stats.distributedProfit ?? 0).toLocaleString()} ج.م`} icon={<TrendingUp size={22}/>} color="emerald" tooltip="إجمالي الأرباح التي تم سحبها بالفعل من قبل الشركاء." />
                <ReportCard title="الأرباح المستحقة (غير الموزعة)" value={`${(stats.undistributedProfit ?? 0).toLocaleString()} ج.م`} icon={<PieChartIcon size={22}/>} color="amber" tooltip="الأرباح المحققة التي لم يتم توزيعها على الشركاء بعد." />
                <ReportCard title="إجمالي السلف القائمة" value={`${Math.max(0, (stats.totals?.loans ?? 0) - (stats.totals?.repayments ?? 0)).toLocaleString()} ج.م`} icon={<ArrowDownRight size={22}/>} color="red" tooltip="إجمالي مديونات الشركاء (السلف التي لم يتم سدادها بعد)." />
                <ReportCard title="إجمالي العربونات المستلمة" value={`${(stats.totals?.advances ?? 0).toLocaleString()} ج.م`} icon={<Coins size={22}/>} color="teal" tooltip="إجمالي عربونات العملاء التي تم استلامها." />
                <ReportCard title="عهد المبيعات (POS)" value={`${(stats.totals?.posSales ?? 0).toLocaleString()} ج.م`} icon={<Coins size={22}/>} color="indigo" tooltip="إجمالي عهد مبيعات الكاشير المباشر لدى الشركاء." />
            </div>

            {/* Controls Bar: Search, Filters & View Mode */}
            <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="flex items-center gap-2 flex-1 max-w-md">
                    <div className="relative w-full">
                        <Search className="absolute right-3 top-2.5 text-slate-400" size={16} />
                        <input 
                            type="text"
                            placeholder="بحث باسم الشريك أو رقم الهاتف..."
                            value={partnerSearchTerm}
                            onChange={(e) => setPartnerSearchTerm(e.target.value)}
                            className="w-full pr-9 pl-3 py-2 bg-slate-50 dark:bg-slate-800 text-xs text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-indigo-500"
                        />
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold">
                        <button
                            onClick={() => setPartnerFilter('all')}
                            className={`px-2.5 py-1 rounded-lg transition-all ${partnerFilter === 'all' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            الكل ({stats.partnerDetails.length})
                        </button>
                        <button
                            onClick={() => setPartnerFilter('loans')}
                            className={`px-2.5 py-1 rounded-lg transition-all ${partnerFilter === 'loans' ? 'bg-white dark:bg-slate-700 shadow-sm text-rose-600 dark:text-rose-400' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            لديهم سلف
                        </button>
                        <button
                            onClick={() => setPartnerFilter('top_ratio')}
                            className={`px-2.5 py-1 rounded-lg transition-all ${partnerFilter === 'top_ratio' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            حصة أرباح عريضة (≥20%)
                        </button>
                        <button
                            onClick={() => setPartnerFilter('positive_balance')}
                            className={`px-2.5 py-1 rounded-lg transition-all ${partnerFilter === 'positive_balance' ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600 dark:text-emerald-400' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            رصيد موجب
                        </button>
                    </div>

                    <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                        <button
                            onClick={() => setViewMode('cards')}
                            className={`p-1.5 rounded-lg transition-all ${viewMode === 'cards' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600' : 'text-slate-400'}`}
                            title="عرض البطاقات التفصيلية"
                        >
                            <Grid size={16} />
                        </button>
                        <button
                            onClick={() => setViewMode('table')}
                            className={`p-1.5 rounded-lg transition-all ${viewMode === 'table' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600' : 'text-slate-400'}`}
                            title="عرض الجدول المالي"
                        >
                            <List size={16} />
                        </button>
                    </div>
                </div>
            </div>

            {/* View Mode 1: Interactive Cards */}
            {viewMode === 'cards' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredPartnerDetails.length === 0 ? (
                        <div className="col-span-full bg-white dark:bg-slate-900 rounded-2xl p-12 text-center border border-slate-200 dark:border-slate-800">
                            <Users className="mx-auto text-slate-300 dark:text-slate-600 mb-3" size={40} />
                            <p className="text-slate-500 dark:text-slate-400 font-bold text-sm">لا يوجد شركاء يطابقون خيارات البحث أو التصفية.</p>
                        </div>
                    ) : (
                        filteredPartnerDetails.map((p, idx) => {
                            const netLoan = Math.max(0, p.loans - p.repayments);
                            const roiPercent = p.capital > 0 ? (((p.distributions + p.profitShare) / p.capital) * 100).toFixed(1) : '0';
                            const isPositive = p.balance >= 0;

                            return (
                                <div key={p.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all p-5 space-y-4 relative overflow-hidden group">
                                    <div className="flex justify-between items-start">
                                        <div className="flex items-center gap-3">
                                            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white font-black text-lg flex items-center justify-center shadow-md shadow-indigo-100 dark:shadow-none">
                                                {p.name.charAt(0)}
                                            </div>
                                            <div>
                                                <Link to={`/store/${storeId}/partners/${p.id}`} className="font-black text-slate-800 dark:text-white text-base hover:text-indigo-600 transition-colors">
                                                    {p.name}
                                                </Link>
                                                {p.phone && <p className="text-xs text-slate-400 dir-ltr text-right">{p.phone}</p>}
                                            </div>
                                        </div>

                                        <div className="flex flex-col items-end gap-1">
                                            <span className="bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 text-xs font-black px-2.5 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800">
                                                حصة الأرباح: {p.profitRatio}%
                                            </span>
                                        </div>
                                    </div>

                                    {/* Equity Progress Bar */}
                                    <div className="space-y-1">
                                        <div className="flex justify-between text-[11px] font-bold text-slate-500">
                                            <span>نسبة الملكية من المحفظة</span>
                                            <span>{p.profitRatio}%</span>
                                        </div>
                                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                                            <div 
                                                className="bg-indigo-600 h-full rounded-full transition-all duration-500" 
                                                style={{ width: `${Math.min(100, p.profitRatio)}%` }}
                                            ></div>
                                        </div>
                                    </div>

                                    {/* Metric Grid */}
                                    <div className="grid grid-cols-2 gap-2.5 pt-1 text-xs">
                                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                                            <span className="text-[10px] font-bold text-slate-400 block">رأس المال المودع</span>
                                            <span className="font-mono font-bold text-slate-700 dark:text-slate-200">{(p.capital ?? 0).toLocaleString()} ج.م</span>
                                        </div>

                                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                                            <span className="text-[10px] font-bold text-slate-400 block">أرباح حصل عليها</span>
                                            <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">+{(p.distributions ?? 0).toLocaleString()} ج.م</span>
                                        </div>

                                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                                            <span className="text-[10px] font-bold text-slate-400 block">السلف القائمة</span>
                                            <span className={`font-mono font-bold ${netLoan > 0 ? 'text-rose-600' : 'text-slate-600'}`}>
                                                {(netLoan ?? 0).toLocaleString()} ج.m
                                            </span>
                                        </div>

                                        <div className="bg-emerald-50/40 dark:bg-emerald-950/20 p-2.5 rounded-xl border border-emerald-100/50 dark:border-emerald-900/30">
                                            <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 block">أرباح مستحقة غير موزعة</span>
                                            <span className="font-mono font-black text-emerald-600 dark:text-emerald-400">+{Math.round(p.profitShare ?? 0).toLocaleString()} ج.م</span>
                                        </div>

                                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                                            <span className="text-[10px] font-bold text-slate-400 block">العربونات المستلمة</span>
                                            <span className="font-mono font-bold text-teal-600">{(p.advances ?? 0).toLocaleString()} ج.م</span>
                                        </div>
                                        <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                                            <span className="text-[10px] font-bold text-slate-400 block">عهد المبيعات (POS)</span>
                                            <span className="font-mono font-bold text-indigo-600">{(p.posSales ?? 0).toLocaleString()} ج.م</span>
                                        </div>
                                    </div>

                                    {/* ROI & Net Balance Footer */}
                                    <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2 text-right">
                                        <div>
                                            <span className="text-[9px] font-bold text-slate-400 uppercase block">الرصيد الجاري بالمحل</span>
                                            <span className={`text-xs font-bold font-mono ${p.balance >= 0 ? 'text-slate-700 dark:text-slate-300' : 'text-rose-600'}`}>
                                                {(p.balance ?? 0).toLocaleString('ar-EG')} ج.م
                                            </span>
                                        </div>

                                        <div className="text-left border-r pr-2 border-slate-100 dark:border-slate-800">
                                            <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase block">إجمالي حقوق التصفية</span>
                                            <span className="text-sm font-black text-indigo-700 dark:text-indigo-400 font-mono">
                                                {((p.balance ?? 0) + (p.profitShare ?? 0)).toLocaleString('ar-EG')} ج.م
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            ) : (
                /* View Mode 2: Detailed Financial Table */
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                        <h3 className="font-bold text-slate-800 dark:text-white text-sm">جدول بيان الذمم ورؤوس الأموال للشركاء</h3>
                        <span className="text-xs text-slate-400 font-bold">{filteredPartnerDetails.length} شريك</span>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-right text-xs">
                            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-bold uppercase tracking-wider">
                                <tr>
                                    <th className="px-4 py-3">الشريك</th>
                                    <th className="px-4 py-3">نسبة الأرباح</th>
                                    <th className="px-4 py-3">رأس المال</th>
                                    <th className="px-4 py-3">أرباح حصل عليها</th>
                                    <th className="px-4 py-3">سحوبات شخصية</th>
                                    <th className="px-4 py-3">السلف القائمة</th>
                                    <th className="px-4 py-3 text-emerald-600 font-bold">أرباح مستحقة غير موزعة</th>
                                    <th className="px-4 py-3">العربونات المستلمة</th>
                                    <th className="px-4 py-3">عهد مبيعات (POS)</th>
                                    <th className="px-4 py-3">الرصيد الجاري بالمحل</th>
                                    <th className="px-4 py-3 text-indigo-600 font-extrabold">إجمالي حقوق التصفية</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                                {filteredPartnerDetails.length === 0 ? (
                                    <tr><td colSpan={11} className="text-center py-12 text-slate-400 font-medium">لا يوجد شركاء مسجلين حالياً.</td></tr>
                                ) : (
                                    filteredPartnerDetails.map(p => (
                                        <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                                            <td className="px-4 py-3 font-bold text-slate-800 dark:text-white">
                                                <Link to={`/store/${storeId}/partners/${p.id}`} className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 hover:underline transition-colors">
                                                    {p.name}
                                                </Link>
                                            </td>
                                            <td className="px-4 py-3"><span className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-2 py-0.5 rounded-full font-bold">{p.profitRatio}%</span></td>
                                            <td className="px-4 py-3 font-mono">{(p.capital ?? 0).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono text-emerald-600">+{(p.distributions ?? 0).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono text-amber-600">-{(p.withdrawals ?? 0).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono text-red-600">{Math.max(0, (p.loans ?? 0) - (p.repayments ?? 0)).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono text-emerald-600 font-bold">+{Math.round(p.profitShare ?? 0).toLocaleString()}</td>
                                            <td className="px-4 py-3 font-mono text-teal-600">-{p.advances ? (p.advances ?? 0).toLocaleString() : '0'}</td>
                                            <td className="px-4 py-3 font-mono text-indigo-600">-{p.posSales ? (p.posSales ?? 0).toLocaleString() : '0'}</td>
                                            <td className={`px-4 py-3 font-bold ${p.balance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                                                {(p.balance ?? 0).toLocaleString()} ج.م
                                            </td>
                                            <td className="px-4 py-3 font-black text-indigo-600 dark:text-indigo-400 font-mono">
                                                {((p.balance ?? 0) + (p.profitShare ?? 0)).toLocaleString()} ج.م
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Clarification Note about Custodies and Down Payments */}
            <div className="bg-slate-50 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-start gap-3.5 shadow-sm">
                <span className="text-xl leading-none">💡</span>
                <div className="text-xs leading-relaxed text-slate-600 dark:text-slate-400 text-right w-full">
                    <strong className="text-slate-800 dark:text-slate-200 font-bold block mb-1">توضيح مالي هام بخصوص العهد والذمم المالية للشركاء:</strong>
                    مبالغ <span className="text-teal-600 dark:text-teal-400 font-bold bg-teal-50 dark:bg-teal-950/30 px-1.5 py-0.5 rounded-md border border-teal-100 dark:border-teal-900">العربونات المستلمة</span> و<span className="text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-950/30 px-1.5 py-0.5 rounded-md border border-indigo-100 dark:border-indigo-900">عهد مبيعات (POS)</span> الموضحة أعلاه هي مبالغ وعهد مالية مؤقتة تحت التسوية لتغطية طلبات العملاء. هذه المبالغ <strong className="text-slate-700 dark:text-slate-300">ليست سحوبات شخصية نهائية</strong> مقتطعة من رأس مال الشريك أو مستحقاته، ولا تؤثر كخصم قطعي إلا في حال تسويتها رسمياً مع الطلبات أو قيدها وتوثيقها كـ <strong className="text-indigo-600 dark:text-indigo-400">سحوبات شخصية</strong>.
                </div>
            </div>

            {/* Analytics Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 className="text-base font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                        <PieChartIcon className="text-indigo-500"/> توزيع نسب الشركاء وحصص الأرباح
                    </h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie 
                                    data={stats.partnerDetails.map(p => ({ name: p.name, value: p.profitRatio }))} 
                                    innerRadius={55} 
                                    outerRadius={80} 
                                    paddingAngle={5} 
                                    dataKey="value"
                                >
                                    {stats.partnerDetails.map((_, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip contentStyle={{ borderRadius: '12px' }} />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 className="text-base font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                        <ArrowDownRight className="text-rose-500"/> رأس المال المودع مقابل السلف القائمة
                    </h3>
                    <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={stats.partnerDetails}>
                                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                                <Tooltip contentStyle={{ borderRadius: '12px' }} />
                                <Bar dataKey="capital" name="رأس المال المودع" fill="#6366f1" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="loans" name="إجمالي السلف" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                                <Bar dataKey="repayments" name="المسدد من السلف" fill="#10b981" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            {/* Modal for Preview / PDF Share */}
            {previewHtml && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
                    <div className="bg-slate-200 dark:bg-slate-800 w-full max-w-7xl h-full max-h-[90vh] rounded-2xl shadow-2xl flex flex-col border border-slate-300 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                        <div className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-t-2xl">
                            <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <FileText className="text-indigo-500" />
                                معاينة تقرير الشركاء والمركز المالي
                            </h3>
                            <div className="flex items-center gap-2">
                                {shareLink && (
                                    <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800">
                                        <LinkIcon size={14} />
                                        <span className="text-xs font-bold whitespace-nowrap hidden sm:inline" dir="ltr">{shareLink.slice(0, 35)}...</span>
                                        <button onClick={handleCopyLink} className="p-1 hover:bg-indigo-100 dark:hover:bg-indigo-800 rounded-lg transition-colors text-indigo-600 dark:text-indigo-400" title="نسخ الرابط">
                                            {copied ? <Check size={14} /> : <Copy size={14} />}
                                        </button>
                                    </div>
                                )}
                                <button 
                                    onClick={handleShare} 
                                    disabled={isSharing}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold text-xs transition-colors border border-slate-200 dark:border-slate-700 disabled:opacity-50"
                                >
                                    {isSharing ? <Loader2 size={14} className="animate-spin" /> : <Share2 size={14} />}
                                    مشاركة
                                </button>
                                <button 
                                    onClick={handleActualPrint}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold text-xs transition-colors border border-slate-200 dark:border-slate-700"
                                >
                                    <Printer size={14} />
                                    طباعة
                                </button>
                                <button 
                                    onClick={handleActualExportPDF}
                                    disabled={isExporting}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs transition-colors shadow-sm disabled:opacity-50"
                                >
                                    {isExporting ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                                    تصدير PDF
                                </button>
                                <button 
                                    onClick={() => setPreviewHtml(null)}
                                    className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl text-slate-500 transition-colors"
                                >
                                    <X size={18} />
                                </button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-auto p-4 sm:p-8 bg-slate-100 dark:bg-slate-800/50 flex justify-center">
                            <div className="bg-white rounded-xl shadow-lg w-full overflow-hidden h-fit min-h-full" style={{ maxWidth: orientation === 'landscape' ? '1122.5px' : '793px' }}>
                                <iframe srcDoc={previewHtml} className="w-full h-[800px] border-0" title="Partners Report Preview" />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const InventoryReport: React.FC<{ activeStore?: Store; settings: Settings; dateRangeText?: string }> = ({ activeStore, settings, dateRangeText }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل تقرير المخزون...</p>
            </div>
        );
    }
    const { showInventoryValue, toggleInventoryValue } = useInventoryVisibility();
    const [isExporting, setIsExporting] = useState(false);
    const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('landscape');
    const [isContinuous, setIsContinuous] = useState(false);
    const [previewHtml, setPreviewHtml] = useState<string | null>(null);
    const [isSharing, setIsSharing] = useState(false);
    const [shareLink, setShareLink] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);

    const products = settings?.products || [];
    const suppliers = settings?.suppliers || [];
    const supplyOrders = settings?.supplyOrders || [];

    const stats = useMemo(() => {
        let totalInventoryValue = 0;
        let totalPurchasesValue = 0;
        let totalOrdersCount = supplyOrders.length;

        const productHistory: Record<string, {
            name: string;
            purchaseCount: number;
            totalPurchasedQuantity: number;
            lastPurchaseDate: string | null;
            suppliers: Set<string>;
            currentStock: number;
            stockValue: number;
        }> = {};

        // Compute product purchase history AND inventory value
        products.forEach(p => {
            let currentStock = 0;
            let stockValue = 0;
            if (p.hasVariants && p.variants && p.variants.length > 0) {
                p.variants.forEach(v => {
                    const stock = v.stockQuantity ?? (v as any).stock ?? 0;
                    currentStock += stock;
                    // Use getLatestProductCost, fallback to variant costPrice or product costPrice
                    const cost = getLatestProductCost(v.id, settings) || getLatestProductCost(p.id, settings) || (v.costPrice ?? p.costPrice ?? 0);
                    const vStockValue = stock * cost;
                    stockValue += vStockValue;
                    totalInventoryValue += vStockValue;
                });
            } else {
                currentStock = p.stockQuantity ?? (p as any).stock ?? 0;
                const cost = getLatestProductCost(p.id, settings) || (p.costPrice || 0);
                stockValue = currentStock * cost;
                totalInventoryValue += stockValue;
            }

            productHistory[p.id] = {
                name: p.name,
                purchaseCount: 0,
                totalPurchasedQuantity: 0,
                lastPurchaseDate: null,
                suppliers: new Set(),
                currentStock,
                stockValue
            };
        });

        // Calculate total purchases value
        supplyOrders.forEach(o => {
            if (o.status !== 'cancelled') {
                const orderGrandTotal = Number(o.totalCost || o.grandTotal || 0) - (Number(o.shippingFees) || 0) - (Number(o.otherFees) || 0);
                totalPurchasesValue += orderGrandTotal;
            }
            
            const supplierName = suppliers.find(s => s.id === o.supplierId)?.name || 'غير معروف';

            o.items.forEach(item => {
                // Find matching product by ID. Product ID could be the main product ID, or a variant ID.
                let matchingProductId = item.productId;
                if (!productHistory[matchingProductId]) {
                    // Try to find if this is a variant ID
                    const parentProduct = products.find(p => p.variants?.some(v => v.id === item.productId));
                    if (parentProduct && productHistory[parentProduct.id]) {
                        matchingProductId = parentProduct.id;
                    }
                }

                if (productHistory[matchingProductId]) {
                    productHistory[matchingProductId].purchaseCount += 1;
                    productHistory[matchingProductId].totalPurchasedQuantity += item.quantity;
                    productHistory[matchingProductId].suppliers.add(supplierName);
                    
                    if (!productHistory[matchingProductId].lastPurchaseDate || new Date(o.date) > new Date(productHistory[matchingProductId].lastPurchaseDate as string)) {
                        productHistory[matchingProductId].lastPurchaseDate = o.date;
                    }
                }
            });
        });

        const sortedProductHistory = Object.values(productHistory).sort((a, b) => b.stockValue - a.stockValue);
        const sortedSupplyOrders = [...supplyOrders].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(o => ({
            ...o,
            supplierName: suppliers.find(s => s.id === o.supplierId)?.name || 'غير معروف'
        }));

        return {
            totalInventoryValue,
            totalPurchasesValue,
            totalOrdersCount,
            productHistory: sortedProductHistory,
            supplyOrders: sortedSupplyOrders
        };
    }, [products, suppliers, supplyOrders, settings]);

    const handlePreview = () => {
        const html = generatePurchasesAndInventoryReportHTML(stats, activeStore?.name || 'متجري', orientation, isContinuous, dateRangeText, showInventoryValue);
        setPreviewHtml(html);
        setShareLink(null);
    };

    const handleShare = async () => {
        if (!previewHtml) return;
        setIsSharing(true);
        try {
            const id = await shareReport(previewHtml);
            setShareLink(`${window.location.origin}/shared-report/${id}`);
        } catch (error) {
            console.error('Share Error:', error);
            alert('حدث خطأ أثناء إنشاء رابط المشاركة.');
        } finally {
            setIsSharing(false);
        }
    };

    const handleCopyLink = () => {
        if (shareLink) {
            navigator.clipboard.writeText(shareLink);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    const handleActualExportPDF = async () => {
        if (!previewHtml) return;
        setIsExporting(true);

        try {
            await exportHTMLToPDF(previewHtml, orientation, `تقرير_المشتريات_والمخزون_${new Date().toISOString().split('T')[0]}.pdf`, isContinuous);
        } catch (error) {
            console.error('PDF generation failed:', error);
            alert('حدث خطأ أثناء تصدير PDF');
        } finally {
            setIsExporting(false);
        }
    };

    const handleActualPrint = () => {
        if (!previewHtml) return;
        printHTMLDirectly(previewHtml);
    };

    return (
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 p-4 sm:p-6 mb-8 animate-in fade-in-5 duration-300">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 sm:mb-8 gap-4 border-b border-slate-100 dark:border-slate-800 pb-4 sm:pb-6">
                <div>
                    <h2 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white flex items-center gap-2">
                        <Package className="text-emerald-500" /> تقرير المشتريات والمخزون
                    </h2>
                </div>
                <div className="flex flex-wrap items-center gap-2 sm:gap-4 w-full lg:w-auto">
                    <div className="flex items-center gap-2">
                        <button
                            onClick={toggleInventoryValue}
                            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm border transition-all ${
                                showInventoryValue 
                                    ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-800' 
                                    : 'bg-slate-100 text-slate-500 border-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                            }`}
                            title={showInventoryValue ? "إخفاء قيمة المخزون" : "إظهار قيمة المخزون"}
                        >
                            {showInventoryValue ? <Eye size={18} className="text-amber-600" /> : <EyeOff size={18} />}
                            {showInventoryValue ? 'تفاصيل المخزون ظاهرة' : 'إظهار قيمة المخزون'}
                        </button>
                        <button 
                            onClick={handlePreview} 
                            disabled={isExporting}
                            className="flex items-center gap-2 px-6 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 dark:shadow-none disabled:opacity-50"
                        >
                            <Eye size={18}/>
                            معاينة التقرير للطباعة والتصدير
                        </button>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-8">
                {showInventoryValue ? (
                    <ReportCard title="إجمالي قيمة المخزون (رأس المال)" value={`${stats.totalInventoryValue.toLocaleString('ar-EG')} ج.م`} icon={<Package size={24}/>} color="emerald" tooltip="إجمالي قيمة المخزون الحالي بناءً على تكلفة المنتجات." />
                ) : (
                    <ReportCard title="إجمالي قيمة المخزون (رأس المال)" value="•••••• ج.م" icon={<Package size={24}/>} color="emerald" tooltip="تم إخفاء القيمة. انقر على زر إظهار قيمة المخزون بالأعلى." />
                )}
                <ReportCard title="إجمالي المشتريات التاريخية" value={`${stats.totalPurchasesValue.toLocaleString('ar-EG')} ج.م`} icon={<TrendingUp size={24}/>} color="blue" tooltip="إجمالي قيمة فواتير الشراء التي تم تسجيلها." />
                <ReportCard title="عدد مرات الشراء (الفواتير)" value={`${stats.totalOrdersCount} طلب`} icon={<FileText size={24}/>} color="amber" />
            </div>

            <div className="space-y-6">
                <div>
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">حركة المنتجات والمخزون الحالي</h3>
                    <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                        <table className="w-full text-sm text-right">
                            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400">
                                <tr>
                                    <th className="px-4 py-3 font-semibold">المنتج</th>
                                    <th className="px-4 py-3 font-semibold">المخزون المتوفر</th>
                                    {showInventoryValue && <th className="px-4 py-3 font-semibold">قيمة المخزون</th>}
                                    <th className="px-4 py-3 font-semibold">مرات الشراء</th>
                                    <th className="px-4 py-3 font-semibold">تاريخ آخر شراء</th>
                                    <th className="px-4 py-3 font-semibold">الموردين</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200 dark:divide-slate-700 bg-white dark:bg-slate-900">
                                {stats.productHistory.slice(0, 10).map((p: any, i: number) => (
                                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                                        <td className="px-4 py-3 font-medium text-slate-800 dark:text-white">{p.name}</td>
                                        <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                                            {p.currentStock > 0 ? (
                                                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 font-bold">
                                                    {p.currentStock}
                                                </span>
                                            ) : (
                                                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-bold">
                                                    نفذ
                                                </span>
                                            )}
                                        </td>
                                        {showInventoryValue && <td className="px-4 py-3 text-slate-800 dark:text-white font-mono">{p.stockValue.toLocaleString('ar-EG')} ج.م</td>}
                                        <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{p.purchaseCount}</td>
                                        <td className="px-4 py-3 text-slate-600 dark:text-slate-300 hover:text-slate-800">
                                            {p.lastPurchaseDate ? new Date(p.lastPurchaseDate).toLocaleDateString('ar-EG') : 'لم يشترى'}
                                        </td>
                                        <td className="px-4 py-3 text-slate-600 dark:text-slate-300 text-xs">
                                            {Array.from(p.suppliers).join('، ') || 'لا يوجد'}
                                        </td>
                                    </tr>
                                ))}
                                {stats.productHistory.length === 0 && (
                                    <tr>
                                        <td colSpan={showInventoryValue ? 6 : 5} className="px-4 py-8 text-center text-slate-500">لا توجد منتجات مسجلة</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div>
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4">أحدث طلبات التوريد</h3>
                    <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                        <table className="w-full text-sm text-right">
                            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400">
                                <tr>
                                    <th className="px-4 py-3 font-semibold">رقم المرجع / الفاتورة</th>
                                    <th className="px-4 py-3 font-semibold">التاريخ</th>
                                    <th className="px-4 py-3 font-semibold">المورد</th>
                                    <th className="px-4 py-3 font-semibold">القيمة الإجمالية</th>
                                    <th className="px-4 py-3 font-semibold">عدد الأصناف</th>
                                    <th className="px-4 py-3 font-semibold">طريقة الدفع</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200 dark:divide-slate-700 bg-white dark:bg-slate-900">
                                {stats.supplyOrders.slice(0, 10).map((o: any, i: number) => (
                                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                                        <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-300 font-bold">{o.referenceNumber || o.orderNumber || o.id.slice(-6).toUpperCase()}</td>
                                        <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{new Date(o.date).toLocaleDateString('ar-EG')}</td>
                                        <td className="px-4 py-3 font-medium text-slate-800 dark:text-white">{o.supplierName}</td>
                                        <td className="px-4 py-3 font-bold text-emerald-600 dark:text-emerald-400">{o.totalCost.toLocaleString('ar-EG')} ج.م</td>
                                        <td className="px-4 py-3 text-slate-600 dark:text-slate-300 flex items-center gap-2">
                                            <div className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-mono font-bold">{(o.items || []).reduce((sum: number, item: any) => sum + item.quantity, 0)}</div>
                                            منتج
                                        </td>
                                        <td className="px-4 py-3 text-slate-500 truncate max-w-[200px]">{o.paymentMethod === 'cash' ? 'نقدي' : o.paymentMethod === 'credit' ? 'آجل' : 'غير محدد'}</td>
                                    </tr>
                                ))}
                                {stats.supplyOrders.length === 0 && (
                                    <tr>
                                        <td colSpan={5} className="px-4 py-8 text-center text-slate-500">لا توجد طلبات توريد</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {previewHtml && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
                    <div className="bg-slate-200 dark:bg-slate-800 w-full max-w-7xl h-full max-h-[90vh] rounded-2xl shadow-2xl flex flex-col border border-slate-300 dark:border-slate-700 animate-in zoom-in-95 duration-200">
                        <div className="flex items-center justify-between p-4 border-b border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 rounded-t-2xl">
                            <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <FileText className="text-emerald-500" />
                                معاينة تقرير المشتريات والمخزون
                            </h3>
                            <div className="flex flex-wrap items-center gap-2">
                                {shareLink && (
                                    <div className="flex items-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800">
                                        <LinkIcon size={14} />
                                        <span className="text-xs font-bold whitespace-nowrap hidden sm:inline" dir="ltr">{shareLink.slice(0, 35)}...</span>
                                        <button onClick={handleCopyLink} className="p-1 hover:bg-indigo-100 dark:hover:bg-indigo-800 rounded-lg transition-colors text-indigo-600 dark:text-indigo-400" title="نسخ الرابط">
                                            {copied ? <Check size={14} /> : <Copy size={14} />}
                                        </button>
                                    </div>
                                )}
                                <button 
                                    onClick={handleShare} 
                                    disabled={isSharing}
                                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all shadow-sm disabled:opacity-50"
                                >
                                    {isSharing ? <Loader2 size={16} className="animate-spin"/> : <Share2 size={16}/>}
                                    <span className="hidden sm:inline">{isSharing ? 'جاري الإنشاء...' : 'مشاركة أونلاين'}</span>
                                </button>
                                <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                                    <button 
                                        onClick={() => setIsContinuous(false)}
                                        className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${!isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
                                    >
                                        صفحات
                                    </button>
                                    <button 
                                        onClick={() => setIsContinuous(true)}
                                        className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${isContinuous ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
                                    >
                                        متصل
                                    </button>
                                </div>
                                <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                                    <button 
                                        onClick={() => setOrientation('portrait')}
                                        className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${orientation === 'portrait' ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
                                    >
                                        طولي
                                    </button>
                                    <button 
                                        onClick={() => setOrientation('landscape')}
                                        className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${orientation === 'landscape' ? 'bg-white dark:bg-slate-700 shadow-sm text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
                                    >
                                        عرضي
                                    </button>
                                </div>
                                 <button 
                                    onClick={handleActualExportPDF} 
                                    disabled={isExporting}
                                    className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all shadow-sm disabled:opacity-50"
                                >
                                    {isExporting ? <Loader2 size={16} className="animate-spin"/> : <Download size={16}/>}
                                    <span className="hidden sm:inline">{isExporting ? 'جاري التصدير...' : 'تصدير PDF'}</span>
                                </button>
                                <button onClick={handleActualPrint} className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-xl font-bold text-sm hover:bg-slate-900 transition-all">
                                    <Printer size={16}/> <span className="hidden sm:inline">طباعة</span>
                                </button>
                                <button onClick={() => setPreviewHtml(null)} className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 rounded-xl transition-colors">
                                    <X size={20} />
                                </button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-auto p-4 sm:p-8 bg-slate-100 dark:bg-slate-800/50 flex align-top justify-center">
                            <div className="bg-white rounded-xl shadow-lg w-full overflow-hidden h-fit min-h-full" style={{ maxWidth: orientation === 'landscape' ? '1122.5px' : '793px' }}>
                                <iframe srcDoc={previewHtml} className="w-full h-[800px] border-0" title="Report Preview" />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const FinalReport: React.FC<ReportsPageProps> = ({ orders, settings, wallet, treasury, activeStore, dateRangeText, supplyOrders }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل التقرير الختامي...</p>
            </div>
        );
    }
    const { showInventoryValue, toggleInventoryValue } = useInventoryVisibility();
    const [subTab, setSubTab] = useState<'summary' | 'financials' | 'operations' | 'partners'>('summary');
    const stats = useMemo(() => {
        const failedOrders = orders.filter(o => {
            const { loss, net } = calculateOrderProfitLoss(o, settings);
            return ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي', 'تمت_الاعادة_لشركة_الشحن', 'ملغي'].includes(o.status) || loss > 0 || net < 0;
        });
        const collectedOrders = orders.filter(o => {
            return ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل', 'تم_الاستبدال'].includes(o.status) && !failedOrders.some(f => f.id === o.id);
        });

        let totalProductRevenue = 0;
        let totalExtraMarkup = 0;
        let totalShippingRevenue = 0;
        let totalCogs = 0;
        let totalProfit = 0;
        let totalCarrierFees = 0;
        let totalNetRevenue = 0;
        let totalInspectionRevenue = 0;
        let totalManualAdjustments = 0; // فرق التقفيل اليدوي
        let totalRequiredCollection = 0;
        let totalShippingMarkup = 0;

        collectedOrders.forEach(order => {
            const { profit, carrierFees, netRevenue, productCost } = calculateOrderProfitLoss(order, settings);
            const safeProductPrice = Number(order.productPrice) || 0;
            const safeShippingFee = Number(order.shippingFee) || 0;
            const safeTax = Number(order.tax) || 0;
            const safeDiscount = Number(order.discount) || 0;
            const safeAdvance = Number(order.advancePayment) || 0;
            
            const isPosOrder = order.channel === 'pos' || order.shippingCompany === 'كاشير - بيع مباشر';
            
            const compFees = settings.companySpecificFees?.[order.shippingCompany];
            const useCustom = compFees?.useCustomFees ?? false;
            const inspectionFeeRate = !isPosOrder && (order.includeInspectionFee ?? true) ? (useCustom ? (compFees?.inspectionFee ?? 0) : (settings.enableInspection ? settings.inspectionFee : 0)) : 0;
            const inspectionRevenue = (!isPosOrder && order.includeInspectionFee !== false && order.inspectionFeePaidByCustomer !== false) ? inspectionFeeRate : 0;

            const baseExpectedRevenue = safeProductPrice + safeShippingFee + safeTax - safeDiscount + inspectionRevenue;
            
            totalProductRevenue += safeProductPrice;
            totalShippingRevenue += safeShippingFee;
            totalInspectionRevenue += inspectionRevenue;
            totalRequiredCollection += netRevenue;
            
            totalCogs += productCost;
            totalProfit += profit;
            totalCarrierFees += carrierFees;
            totalNetRevenue += netRevenue;

            totalManualAdjustments += (netRevenue - baseExpectedRevenue);
            
            (order.items || []).forEach(item => {
                const product = findProductInSettings(item, settings);
                const actualCost = (item.cost !== undefined && item.cost !== null && item.cost > 0) ? item.cost : (getLatestProductCost(product?.id || item.productId, settings) || item.cost || 0);
                const catalogPrice = resolveItemCatalogPrice(item, product, actualCost);
                if (item.price > catalogPrice) {
                    totalExtraMarkup += (item.price - catalogPrice) * item.quantity;
                }
            });

            // Calculate Shipping Markup
            const standardShipping = isPosOrder ? 0 : getStandardShippingFee(order, settings);
            const shippingMarkup = isPosOrder ? 0 : Math.max(0, safeShippingFee - standardShipping);
            totalShippingMarkup += shippingMarkup;
        });

        let totalLoss = 0;
        failedOrders.forEach(order => {
            const { loss, net } = calculateOrderProfitLoss(order, settings);
            const actualLoss = loss > 0 ? loss : (net < 0 ? Math.abs(net) : 0);
            totalLoss += actualLoss;
        });

        const totalExpenses = (wallet?.transactions || []).filter(t => t.type === 'سحب' && (t.category?.startsWith('expense_') || t.category?.startsWith('supply_expense_') || (settings?.expenseCategories || []).includes(t.category || ''))).reduce((sum, t) => sum + t.amount, 0);
        const finalNet = totalProfit - totalLoss - totalExpenses;

        const inventoryValue = (settings?.products || []).reduce((sum, p) => {
            if (p.hasVariants && p.variants && p.variants.length > 0) {
                return sum + p.variants.reduce((vSum, v) => {
                    const stock = v.stockQuantity ?? (v as any).stock ?? 0;
                    const cost = getLatestProductCost(v.id, settings) || getLatestProductCost(p.id, settings) || (v.costPrice ?? p.costPrice ?? 0);
                    return vSum + (stock * cost);
                }, 0);
            }
            const stock = p.stockQuantity ?? (p as any).stock ?? 0;
            const cost = getLatestProductCost(p.id, settings) || (p.costPrice || 0);
            return sum + (stock * cost);
        }, 0);

        const inventorySalesValue = (settings?.products || []).reduce((sum, p) => {
            if (p.hasVariants && p.variants && p.variants.length > 0) {
                return sum + p.variants.reduce((vSum, v) => {
                    const stock = v.stockQuantity ?? (v as any).stock ?? 0;
                    return vSum + ((v.price || p.price || 0) * stock);
                }, 0);
            }
            const stock = p.stockQuantity ?? (p as any).stock ?? 0;
            return sum + ((p.price || 0) * stock);
        }, 0);

        const partners = settings.partners || [];
        const partnerTransactions = settings.partnerTransactions || [];
        const totalCapital = partnerTransactions
            .filter(t => t.type === 'capital_addition' || t.type === 'supply_funding' || t.type === 'shipping_funding' || t.type === 'expense_coverage')
            .reduce((sum, t) => sum + t.amount, 0);

        const pendingCollection = orders.filter(o => (o.status === 'تم_توصيلها' || o.status === 'تم_التوصيل') && !o.collectionProcessed).reduce((sum, o) => sum + (o.productPrice + o.shippingFee), 0);

        const partnerPerformance = partners.map(partner => {
             const partnerTx = partnerTransactions.filter(t => t.partnerId === partner.id);
             const distributions = partnerTx.filter(t => t.type === 'profit_distribution').reduce((sum, t) => sum + t.amount, 0);
             const currentProfitShare = (finalNet * (partner.profitRatio || 0)) / 100;
             const undistributedShare = Math.max(0, currentProfitShare - distributions);
             return { ...partner, currentBalance: partner.balance || 0, undistributedShare, distributions };
        });

        const uncompensatedFailedOrders = orders.filter(o => 
            ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي'].includes(o.status) && 
            (o as any).compensationStatus !== 'compensated'
        );
        const uncompensatedLoss = uncompensatedFailedOrders.reduce((sum, o) => {
            const { loss } = calculateOrderProfitLoss(o, settings);
            return sum + loss;
        }, 0);

        const waSentCount = orders.filter(o => (o as any).waMessagesSent?.length > 0).length;
        const waSuccessCount = orders.filter(o => (o as any).waMessagesSent?.some((m: any) => m.success)).length;

        return { 
            totalProductRevenue, totalExtraMarkup, totalShippingRevenue, totalInspectionRevenue, 
            totalManualAdjustments, totalCogs, totalCarrierFees, totalLoss, totalExpenses, 
            finalNet, inventoryValue, inventorySalesValue, partnerPerformance, 
            totalCapital, pendingCollection, totalProfit, totalNetRevenue, totalRequiredCollection,
            totalShippingMarkup, uncompensatedLoss, uncompensatedCount: uncompensatedFailedOrders.length,
            waSentCount, waSuccessCount
        };
    }, [orders, settings, wallet]);

    // Operational Analytics Calculations
    const totalProcessedCount = orders.filter(o => !['جديد', 'جاري_المراجعة', 'في_انتظار_المكالمة', 'مسودة'].includes(o.status)).length;
    const successCount = orders.filter(o => ['تم_التحصيل', 'مدفوعة', 'تم_توصيلها', 'تم_التوصيل'].includes(o.status)).length;
    const deliverySuccessRate = totalProcessedCount > 0 ? (successCount / totalProcessedCount) * 100 : 0;
    const returnLossRatio = stats.totalProfit > 0 ? (stats.totalLoss / stats.totalProfit) * 100 : 0;
    const returnCount = orders.filter(o => ['مرتجع', 'فشل_التوصيل', 'مرتجع_بعد_الاستلام', 'مرتجع_جزئي'].includes(o.status)).length;
    const returnRate = totalProcessedCount > 0 ? (returnCount / totalProcessedCount) * 100 : 0;
    const roi = stats.totalCapital > 0 ? (stats.finalNet / stats.totalCapital) * 100 : 0;
    const netProfitMargin = stats.totalNetRevenue > 0 ? (stats.finalNet / stats.totalNetRevenue) * 100 : 0;

    // Charts Data
    const comparisonChartData = [
        { name: 'الإيرادات المحصلة', 'المبلغ (ج.م)': stats.totalNetRevenue, fill: '#10b981' },
        { name: 'تكلفة البضاعة (COGS)', 'المبلغ (ج.م)': stats.totalCogs, fill: '#ef4444' },
        { name: 'بوالص الشحن', 'المبلغ (ج.م)': stats.totalCarrierFees, fill: '#f59e0b' },
        { name: 'خسائر المرتجعات', 'المبلغ (ج.م)': stats.totalLoss, fill: '#ec4899' },
        { name: 'المصروفات الإدارية', 'المبلغ (ج.م)': stats.totalExpenses, fill: '#8b5cf6' },
    ];

    const profitStreamsData = [
        { name: 'عمولات المنتجات الأساسية', value: Math.max(0, stats.totalProfit - stats.totalExtraMarkup - stats.totalShippingMarkup), color: '#6366f1' },
        { name: 'أرباح زيادة السعر اليدوية', value: stats.totalExtraMarkup, color: '#10b981' },
        { name: 'أرباح زيادة الشحن (فرق الشحن)', value: stats.totalShippingMarkup, color: '#f59e0b' },
        { name: 'إيرادات المعاينة والتسويات', value: stats.totalInspectionRevenue + (stats.totalManualAdjustments > 0 ? stats.totalManualAdjustments : 0), color: '#ec4899' },
    ].filter(item => item.value > 0);

    return (
        <div className="bg-slate-900 p-6 sm:p-8 rounded-3xl text-white shadow-2xl relative overflow-hidden mt-8 border border-slate-800">
            {/* Background Gradient Accents */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

            {/* Header section */}
            <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 border-b border-slate-800 pb-6">
                <div className="space-y-1.5">
                    <div className="flex items-center gap-2.5">
                        <div className="p-2 bg-blue-500/10 text-blue-400 rounded-xl border border-blue-500/20">
                            <FileText size={22} />
                        </div>
                        <h2 className="text-xl sm:text-2xl font-black tracking-tight">التقرير الختامي الشامل (تفصيلي وتحليلي)</h2>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-400 flex items-center gap-2">
                        <span>تحليلات مالية متطورة مستندة إلى أحدث البيانات الحقيقية</span>
                        {dateRangeText && <span className="px-2 py-0.5 bg-slate-800 rounded-full text-slate-300 font-bold">{dateRangeText}</span>}
                    </p>
                </div>

                {/* Sub-tab Navigation */}
                <div className="flex flex-wrap gap-1 bg-slate-800/60 p-1.5 rounded-2xl border border-slate-700/50">
                    <button
                        onClick={() => setSubTab('summary')}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${subTab === 'summary' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
                    >
                        <TrendingUp size={14} /> الملخص التنفيذي
                    </button>
                    <button
                        onClick={() => setSubTab('financials')}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${subTab === 'financials' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
                    >
                        <Coins size={14} /> التحليل المالي والبياني
                    </button>
                    <button
                        onClick={() => setSubTab('operations')}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${subTab === 'operations' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
                    >
                        <Monitor size={14} /> التشخيص والذكاء التشغيلي
                    </button>
                    <button
                        onClick={() => setSubTab('partners')}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${subTab === 'partners' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
                    >
                        <Users size={14} /> الشركاء والمخزون
                    </button>
                </div>
            </div>

            {/* Content Switcher */}
            {subTab === 'summary' && (
                <div className="space-y-8 animate-in fade-in-50 duration-300">
                    {/* Executive Stat Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                        <div className="bg-slate-800/40 p-5 rounded-2xl border border-slate-700/60 shadow-lg relative group overflow-hidden">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-xl" />
                            <div className="flex justify-between items-start mb-3">
                                <span className="text-slate-400 text-xs font-bold uppercase tracking-wider">رأس المال الفعلي</span>
                                <span className="p-2 bg-blue-500/10 text-blue-400 rounded-lg"><WalletIcon size={16} /></span>
                            </div>
                            <h4 className="text-2xl font-black text-blue-400 tabular-nums">
                                {stats.totalCapital.toLocaleString('ar-EG')} <span className="text-xs font-normal text-slate-300">ج.م</span>
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-2">إجمالي السيولة وضخ رأس المال المستثمر</p>
                        </div>

                        <div className="bg-slate-800/40 p-5 rounded-2xl border border-slate-700/60 shadow-lg relative group overflow-hidden">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-xl" />
                            <div className="flex justify-between items-start mb-3">
                                <span className="text-slate-400 text-xs font-bold uppercase tracking-wider">إجمالي المطلوب تحصيله</span>
                                <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg"><Truck size={16} /></span>
                            </div>
                            <h4 className="text-2xl font-black text-indigo-400 tabular-nums">
                                {stats.totalRequiredCollection.toLocaleString('ar-EG')} <span className="text-xs font-normal text-slate-300">ج.م</span>
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-2">المستهدف الكلي المطلوب تحصيله من العملاء</p>
                        </div>

                        <div className="bg-slate-800/40 p-5 rounded-2xl border border-slate-700/60 shadow-lg relative group overflow-hidden">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl" />
                            <div className="flex justify-between items-start mb-3">
                                <span className="text-slate-400 text-xs font-bold uppercase tracking-wider">الإيرادات الفعلية المقبوضة</span>
                                <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg"><DollarSign size={16} /></span>
                            </div>
                            <h4 className="text-2xl font-black text-emerald-400 tabular-nums">
                                {stats.totalNetRevenue.toLocaleString('ar-EG')} <span className="text-xs font-normal text-slate-300">ج.m</span>
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-2">السيولة الحرة المتوفرة التي تم استلامها</p>
                        </div>

                        <div className="bg-slate-800/40 p-5 rounded-2xl border border-slate-700/60 shadow-lg relative group overflow-hidden">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-xl" />
                            <div className="flex justify-between items-start mb-3">
                                <span className="text-slate-400 text-xs font-bold uppercase tracking-wider">شحن قيد التحصيل</span>
                                <span className="p-2 bg-amber-500/10 text-amber-400 rounded-lg"><Calendar size={16} /></span>
                            </div>
                            <h4 className="text-2xl font-black text-amber-400 tabular-nums">
                                {stats.pendingCollection.toLocaleString('ar-EG')} <span className="text-xs font-normal text-slate-300">ج.م</span>
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-2">أموال معلقة لدى شركات الشحن للتوصيل والتحصيل</p>
                        </div>

                        <div className="bg-emerald-950/40 p-5 rounded-2xl border border-emerald-500/30 shadow-lg relative group overflow-hidden col-span-1 sm:col-span-2 lg:col-span-1">
                            <div className="absolute inset-0 bg-emerald-500/5 animate-pulse" />
                            <div className="flex justify-between items-start mb-3">
                                <span className="text-emerald-300 text-xs font-bold uppercase tracking-wider">الصافي النهائي للأرباح</span>
                                <span className="p-2 bg-emerald-500/20 text-emerald-300 rounded-lg"><ArrowUpLeft size={16} /></span>
                            </div>
                            <h4 className={`text-2xl sm:text-3xl font-black tabular-nums ${stats.finalNet >= 0 ? 'text-emerald-300' : 'text-rose-400'}`}>
                                {stats.finalNet.toLocaleString('ar-EG')} <span className="text-xs font-normal">ج.م</span>
                            </h4>
                            <p className="text-[10px] text-emerald-400 mt-2">صافي الربح الفعلي الموزع بعد خصم المرتجعات والمصروفات</p>
                        </div>
                    </div>

                    {/* AI Smart Analyst Block */}
                    <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700/80 shadow-md relative overflow-hidden">
                        <div className="absolute top-0 left-0 bg-blue-500/10 text-blue-400 px-4 py-1.5 rounded-br-2xl text-xs font-bold flex items-center gap-1">
                            <Info size={12} /> الأخصائي التشغيلي الذكي
                        </div>
                        <h3 className="text-lg font-bold text-slate-100 mb-3 flex items-center gap-2">
                            <span>ملخص الرؤية التشغيلية والمالية للمتجر</span>
                        </h3>
                        <div className="text-slate-300 text-sm leading-relaxed space-y-3">
                            <p>
                                بناءً على تحليل حركة المبيعات وتكاليف التوصيل للمتجر خلال الفترة المحددة، تظهر الأرقام أن متجرك قد حقق حجم أعمال إجمالي بقيمة <b className="text-indigo-400 font-mono">{(stats.totalProductRevenue + stats.totalShippingRevenue).toLocaleString('ar-EG')} ج.م</b>. بعد احتساب تكلفة شراء السلع وتصفية حسابات بوالص الشحن، استقرت الأرباح التشغيلية للمتجر عند <b className="text-emerald-400 font-mono">{stats.totalProfit.toLocaleString('ar-EG')} ج.م</b>.
                            </p>
                            <p>
                                عقب خصم خسائر الطرود المرتجعة وغير المسلمة التي بلغت <b className="text-rose-400 font-mono">{stats.totalLoss.toLocaleString('ar-EG')} ج.م</b>، والمصروفات الإدارية بقيمة <b className="text-purple-400 font-mono">{stats.totalExpenses.toLocaleString('ar-EG')} ج.م</b>، استقر <b>صافي الربح النهائي الحقيقي</b> لمتجرك عند <b className="text-emerald-400 text-base font-mono">{stats.finalNet.toLocaleString('ar-EG')} ج.م</b>.
                            </p>
                            <div className="pt-3 border-t border-slate-700/60 mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700/40">
                                    <div className="flex items-center gap-2 text-amber-400 mb-1">
                                        <AlertTriangle size={16} />
                                        <span className="text-xs font-black uppercase">تنبيه الخسائر غير المعوضة</span>
                                    </div>
                                    <p className="text-xs text-slate-400">
                                        يوجد <b className="text-amber-400">{(stats as any).uncompensatedCount || 0}</b> أوردرات مرتجعة لم يتم تسجيل تعويض لها بعد، بقيمة خسارة إجمالية تقدر بـ <b className="text-amber-400">{(stats as any).uncompensatedLoss?.toLocaleString('ar-EG') || 0} ج.م</b>.
                                    </p>
                                </div>
                                <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700/40">
                                    <div className="flex items-center gap-2 text-emerald-400 mb-1">
                                        <Share2 size={16} />
                                        <span className="text-xs font-black uppercase">مؤشرات التواصل الذكي</span>
                                    </div>
                                    <p className="text-xs text-slate-400">
                                        تم استخدام نظام WhatsApp API للتواصل مع <b className="text-emerald-400">{(stats as any).waSentCount || 0}</b> عميل، بنسبة نجاح في التسليم بلغت <b className="text-emerald-400">{((stats as any).waSuccessCount / ((stats as any).waSentCount || 1) * 100).toFixed(1)}%</b>.
                                    </p>
                                </div>
                            </div>
                            <p className="text-slate-400 text-[10px] pt-2 border-t border-slate-700/40 opacity-70 italic">
                                * التنبيهات الذكية تساعدك في تقليل الخسائر عبر متابعة التعويضات وتأكيد الأوردرات آلياً.
                            </p>
                        </div>
                    </div>

                    {/* Quick Highlights Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Financial Efficiency Indicators */}
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50">
                            <h3 className="text-base font-bold mb-4 text-indigo-300 flex items-center gap-2">
                                <TrendingUp size={16} /> كفاءة دوران الأصول والسيولة
                            </h3>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between text-xs mb-1.5">
                                        <span className="text-slate-400">عائد الاستثمار لراس المال المستثمر (ROI)</span>
                                        <span className="text-indigo-300 font-bold font-mono">{roi.toFixed(1)}%</span>
                                    </div>
                                    <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                                        <div className="bg-indigo-500 h-full rounded-full transition-all" style={{ width: `${Math.min(100, roi)}%` }} />
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between text-xs mb-1.5">
                                        <span className="text-slate-400">معدل تحصيل المستحقات من شركات الشحن</span>
                                        <span className="text-amber-400 font-bold font-mono">
                                            {stats.totalNetRevenue > 0 ? ((stats.totalNetRevenue / (stats.totalNetRevenue + stats.pendingCollection || 1)) * 100).toFixed(1) : 0}%
                                        </span>
                                    </div>
                                    <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                                        <div className="bg-amber-500 h-full rounded-full transition-all" style={{ width: `${stats.totalNetRevenue > 0 ? (stats.totalNetRevenue / (stats.totalNetRevenue + stats.pendingCollection || 1)) * 100 : 0}%` }} />
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between text-xs mb-1.5">
                                        <span className="text-slate-400">كفاءة تشغيل المخزون الفعلي</span>
                                        <span className="text-emerald-400 font-bold font-mono">
                                            {stats.inventoryValue > 0 ? ((stats.totalCogs / (stats.inventoryValue || 1)) * 100).toFixed(0) : 0}%
                                        </span>
                                    </div>
                                    <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                                        <div className="bg-emerald-500 h-full rounded-full transition-all" style={{ width: `${stats.inventoryValue > 0 ? Math.min(100, (stats.totalCogs / stats.inventoryValue) * 100) : 0}%` }} />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Inventory Value quick overview */}
                        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50 flex flex-col justify-between">
                            <div>
                                <div className="flex items-center justify-between mb-2">
                                    <h3 className="text-base font-bold text-emerald-300 flex items-center gap-2">
                                        <Package size={16} /> القيمة السوقية الكامنة للمخزون بالمستودع
                                    </h3>
                                    <button onClick={toggleInventoryValue} className="text-slate-400 hover:text-white transition-colors" title={showInventoryValue ? "إخفاء التفاصيل" : "إظهار التفاصيل"}>
                                        {showInventoryValue ? <Eye size={16} className="text-emerald-400" /> : <EyeOff size={16} />}
                                    </button>
                                </div>
                                <p className="text-slate-400 text-xs leading-relaxed mb-4">
                                    هناك أرباح معلقة كامنة في بضاعتك الحالية المتواجدة في المخزن. قيمتها بسعر الشراء الفعلي تختلف عن قيمتها المتوقعة عند البيع الكامل.
                                </p>
                            </div>
                            {showInventoryValue ? (
                                <>
                                    <div className="grid grid-cols-2 gap-3 mb-2">
                                        <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                                            <span className="text-slate-400 text-[10px] block mb-0.5">سعر التكلفة الأساسي</span>
                                            <span className="font-mono text-base font-black text-slate-100">{stats.inventoryValue.toLocaleString('ar-EG')} ج.م</span>
                                        </div>
                                        <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                                            <span className="text-slate-400 text-[10px] block mb-0.5">القيمة عند البيع الكامل</span>
                                            <span className="font-mono text-base font-black text-emerald-300">{stats.inventorySalesValue.toLocaleString('ar-EG')} ج.م</span>
                                        </div>
                                    </div>
                                    <div className="mt-2 pt-2 border-t border-slate-700/50 flex justify-between items-center text-xs">
                                        <span className="text-slate-400">الربح المتوقع إضافته عند نفاذ الكمية:</span>
                                        <span className="text-emerald-400 font-bold font-mono">+{Math.max(0, stats.inventorySalesValue - stats.inventoryValue).toLocaleString('ar-EG')} ج.م</span>
                                    </div>
                                </>
                            ) : (
                                <div className="bg-slate-900/40 p-6 rounded-xl border border-slate-800 text-center my-auto">
                                    <p className="text-slate-400 text-sm mb-2">تم إخفاء القيمة الكامنة للمخزون</p>
                                    <button onClick={toggleInventoryValue} className="text-xs text-blue-400 hover:text-blue-300 underline font-bold">انقر للإظهار</button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {subTab === 'financials' && (
                <div className="space-y-8 animate-in fade-in-50 duration-300">
                    {/* Visual Charts Grid */}
                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 bg-slate-800/30 p-5 rounded-2xl border border-slate-800">
                        {/* Revenues vs Expenses Chart */}
                        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800/80">
                            <h3 className="text-sm font-black text-slate-300 mb-4 flex items-center gap-1.5">
                                <TrendingUp size={14} className="text-emerald-400" /> هيكل مقارنة الإيرادات مقابل التكاليف الفعلية والمصروفات
                            </h3>
                            <div className="h-64">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={comparisonChartData} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                                        <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                        <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569', borderRadius: '8px', color: '#fff', direction: 'rtl' }}
                                            formatter={(value) => [`${value.toLocaleString()} ج.م`, 'المبلغ']}
                                        />
                                        <Bar dataKey="المبلغ (ج.م)" radius={[6, 6, 0, 0]}>
                                            {comparisonChartData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.fill} />
                                            ))}
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Profit streams breakdown chart */}
                        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800/80">
                            <h3 className="text-sm font-black text-slate-300 mb-4 flex items-center gap-1.5">
                                <Coins size={14} className="text-indigo-400" /> تفكيك مصادر الأرباح التشغيلية المحققة (الأوردرات الناجحة)
                            </h3>
                            {profitStreamsData.length === 0 ? (
                                <div className="h-64 flex items-center justify-center text-slate-500 text-xs">
                                    لا توجد أرباح لتوزيعها حالياً
                                </div>
                            ) : (
                                <div className="h-64 flex flex-col justify-around">
                                    <div className="space-y-4">
                                        {profitStreamsData.map((item, idx) => {
                                            const percentage = stats.totalProfit > 0 ? (item.value / stats.totalProfit) * 100 : 0;
                                            return (
                                                <div key={idx} className="space-y-1">
                                                    <div className="flex justify-between text-xs">
                                                        <span className="flex items-center gap-1.5 text-slate-300">
                                                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                                                            {item.name}
                                                        </span>
                                                        <span className="font-mono font-bold text-slate-100">
                                                            {(item.value ?? 0).toLocaleString('ar-EG')} ج.م ({percentage.toFixed(1)}%)
                                                        </span>
                                                    </div>
                                                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                                        <div className="h-full rounded-full transition-all" style={{ backgroundColor: item.color, width: `${percentage}%` }} />
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    <div className="text-[10px] text-slate-500 text-center mt-2">
                                        إجمالي الأرباح التشغيلية قبل خصم خسائر الارتجاع والمصروفات الإدارية: {stats.totalProfit.toLocaleString('ar-EG')} ج.م
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Step-by-Step Mathematical Financial Statement (القائمة المالية الموحدة) */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Revenues Deep Dive */}
                        <div className="bg-slate-800/60 p-5 rounded-2xl border border-slate-700/60">
                            <h3 className="text-base font-black mb-4 text-emerald-400 border-b border-slate-700/50 pb-2 flex items-center justify-between">
                                <span>1. جدول تفصيل الإيرادات المحققة</span>
                                <span className="text-xs bg-emerald-500/10 text-emerald-300 px-2.5 py-0.5 rounded-full">داخل للخزينة</span>
                            </h3>
                            <div className="space-y-3 text-sm">
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">إجمالي مبيعات البضاعة الأساسية (بسعر البيع العادي)</span>
                                    <span className="font-bold font-mono text-emerald-400">+{stats.totalProductRevenue.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">زيادة أسعار بيع المنتجات فوق السعر الأساسي (أرباح التعلية)</span>
                                    <span className="font-bold font-mono text-emerald-400">+{stats.totalExtraMarkup.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">إجمالي تحصيل رسوم الشحن المدخلة من العملاء</span>
                                    <span className="font-bold font-mono text-emerald-400">+{stats.totalShippingRevenue.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">إجمالي تحصيل عوائد معاينة البضاعة</span>
                                    <span className="font-bold font-mono text-emerald-400">+{stats.totalInspectionRevenue.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">تسويات يدوية وفروقات تقفيل الحسابات</span>
                                    <span className={`font-bold font-mono ${stats.totalManualAdjustments >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                        {stats.totalManualAdjustments > 0 ? '+' : ''}{stats.totalManualAdjustments.toLocaleString('ar-EG')} ج.م
                                    </span>
                                </div>
                                <div className="border-t border-slate-700/80 pt-3 mt-4 flex justify-between font-black text-base">
                                    <span className="text-slate-100">(=) إجمالي المقبوضات (إجمالي الإيرادات)</span>
                                    <span className="text-emerald-400 font-mono">{stats.totalNetRevenue.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                            </div>
                        </div>

                        {/* Costs Deep Dive */}
                        <div className="bg-slate-800/60 p-5 rounded-2xl border border-slate-700/60">
                            <h3 className="text-base font-black mb-4 text-rose-400 border-b border-slate-700/50 pb-2 flex items-center justify-between">
                                <span>2. جدول تصفية التكاليف والمصروفات</span>
                                <span className="text-xs bg-rose-500/10 text-rose-300 px-2.5 py-0.5 rounded-full">خارج من الخزينة</span>
                            </h3>
                            <div className="space-y-3 text-sm">
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">تكلفة شراء البضاعة المباعة لدى الموردين (COGS)</span>
                                    <span className="font-bold font-mono text-rose-300">{stats.totalCogs.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">رسوم بوالص شحن الأوردرات الصادرة لشركات التوصيل</span>
                                    <span className="font-bold font-mono text-rose-300">{stats.totalCarrierFees.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">إجمالي خسائر الشحن والارتجاع والطرود التالفة</span>
                                    <span className="font-bold font-mono text-rose-300">{stats.totalLoss.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="flex justify-between p-2.5 bg-slate-900/40 rounded-lg hover:bg-slate-900/80 transition-colors">
                                    <span className="text-slate-300">المصروفات الإدارية والتشغيلية (إعلانات، إيجار، عمالة)</span>
                                    <span className="font-bold font-mono text-rose-300">{stats.totalExpenses.toLocaleString('ar-EG')} ج.م</span>
                                </div>
                                <div className="border-t border-slate-700/80 pt-3 mt-4 flex justify-between font-black text-base">
                                    <span className="text-slate-100">(=) إجمالي التكاليف والمصروفات بالكامل</span>
                                    <span className="text-rose-400 font-mono">{(stats.totalCogs + stats.totalCarrierFees + stats.totalLoss + stats.totalExpenses).toLocaleString('ar-EG')} ج.م</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {subTab === 'operations' && (
                <div className="space-y-8 animate-in fade-in-50 duration-300">
                    {/* Visual Gauges Row */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Success Rate Gauge */}
                        <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700/60 flex flex-col items-center text-center">
                            <span className="text-xs font-bold text-slate-400 mb-4 block">معدل نجاح تسليم الطلبات</span>
                            <div className="relative w-36 h-36 mb-4 flex items-center justify-center">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle cx="72" cy="72" r="60" stroke="#1e293b" strokeWidth="12" fill="transparent" />
                                    <circle cx="72" cy="72" r="60" stroke={deliverySuccessRate >= 80 ? '#10b981' : '#f59e0b'} strokeWidth="12" fill="transparent" strokeDasharray={`${2 * Math.PI * 60}`} strokeDashoffset={`${2 * Math.PI * 60 * (1 - deliverySuccessRate / 100)}`} strokeLinecap="round" />
                                </svg>
                                <span className="absolute text-2xl font-black tabular-nums">{deliverySuccessRate.toFixed(1)}%</span>
                            </div>
                            <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${deliverySuccessRate >= 80 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                                {deliverySuccessRate >= 80 ? 'أداء شحن ممتاز وفعال' : 'بحاجة لتحسين تأكيد الأوردرات'}
                            </span>
                            <p className="text-[10px] text-slate-400 mt-3 leading-relaxed">
                                يقيس نسبة الأوردرات التي تم استلامها وتحصيل قيمتها بنجاح مقارنة بجميع الطلبات الصادرة لشركات التوصيل.
                            </p>
                        </div>

                        {/* Return Loss Ratio Gauge */}
                        <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700/60 flex flex-col items-center text-center">
                            <span className="text-xs font-bold text-slate-400 mb-4 block">نسبة الخسائر إلى الأرباح</span>
                            <div className="relative w-36 h-36 mb-4 flex items-center justify-center">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle cx="72" cy="72" r="60" stroke="#1e293b" strokeWidth="12" fill="transparent" />
                                    <circle cx="72" cy="72" r="60" stroke={returnLossRatio < 15 ? '#10b981' : '#ef4444'} strokeWidth="12" fill="transparent" strokeDasharray={`${2 * Math.PI * 60}`} strokeDashoffset={`${2 * Math.PI * 60 * (1 - Math.min(100, returnLossRatio) / 100)}`} strokeLinecap="round" />
                                </svg>
                                <span className="absolute text-2xl font-black tabular-nums">{returnLossRatio.toFixed(1)}%</span>
                            </div>
                            <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${returnLossRatio < 15 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                                {returnLossRatio < 15 ? 'أثر المرتجع آمن وممتاز' : 'المرتجع يستنزف جزءاً من أرباحك'}
                            </span>
                            <p className="text-[10px] text-slate-400 mt-3 leading-relaxed">
                                يوضح النسبة المئوية التي تقتطعها خسائر الطرود المرتجعة من إجمالي الأرباح التشغيلية الأساسية لمتجرك.
                            </p>
                        </div>

                        {/* ROI Gauge */}
                        <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700/60 flex flex-col items-center text-center">
                            <span className="text-xs font-bold text-slate-400 mb-4 block">العائد الفعلي على رأس المال</span>
                            <div className="relative w-36 h-36 mb-4 flex items-center justify-center">
                                <svg className="w-full h-full transform -rotate-90">
                                    <circle cx="72" cy="72" r="60" stroke="#1e293b" strokeWidth="12" fill="transparent" />
                                    <circle cx="72" cy="72" r="60" stroke={roi >= 15 ? '#6366f1' : '#10b981'} strokeWidth="12" fill="transparent" strokeDasharray={`${2 * Math.PI * 60}`} strokeDashoffset={`${2 * Math.PI * 60 * (1 - Math.min(100, roi) / 100)}`} strokeLinecap="round" />
                                </svg>
                                <span className="absolute text-2xl font-black tabular-nums">{roi.toFixed(1)}%</span>
                            </div>
                            <span className="px-2.5 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-xs font-bold">
                                {roi > 0 ? 'مؤشر نمو سيولة إيجابي' : 'رأس المال الموظف خامل'}
                            </span>
                            <p className="text-[10px] text-slate-400 mt-3 leading-relaxed">
                                يقيس العائد المالي الصافي المحقق مقارنةً بإجمالي الأموال ورأس المال الذي تم ضخه بالمتجر من الشركاء.
                            </p>
                        </div>
                    </div>

                    {/* Operational Recommendations & Strategic SWOT Matrix */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Recommendations card */}
                        <div className="bg-slate-800/80 p-6 rounded-2xl border border-slate-700">
                            <h3 className="text-base font-bold mb-4 text-emerald-300 flex items-center gap-2">
                                <CheckCircle size={18} /> نصائح مالية وتشغيلية موصى بها فوراً
                            </h3>
                            <div className="space-y-4 text-xs sm:text-sm text-slate-300">
                                <div className="flex gap-3 items-start bg-slate-900/40 p-3 rounded-xl">
                                    <span className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg font-bold">1</span>
                                    <div>
                                        <b className="text-slate-100 block mb-1">تثبيت وتأكيد البيانات الجغرافية للعملاء</b>
                                        <span>ينصح بإلزام خدمة العملاء بتأكيد دقة العنوان في مكالمات التأكيد، لتجنب ارتجاع الشحنات بسبب نقص العنوان.</span>
                                    </div>
                                </div>
                                <div className="flex gap-3 items-start bg-slate-900/40 p-3 rounded-xl">
                                    <span className="p-1.5 bg-blue-500/10 text-blue-400 rounded-lg font-bold">2</span>
                                    <div>
                                        <b className="text-slate-100 block mb-1">الربط التلقائي لأسعار التعلية</b>
                                        <span>تحقيق أرباح تعلية ممتازة يثبت نجاح التسعير اليدوي. يفضل تحويل أكثر المنتجات طلباً إلى نظام العمولة لزيادة الربحية المباشرة.</span>
                                    </div>
                                </div>
                                <div className="flex gap-3 items-start bg-slate-900/40 p-3 rounded-xl">
                                    <span className="p-1.5 bg-purple-500/10 text-purple-400 rounded-lg font-bold">3</span>
                                    <div>
                                        <b className="text-slate-100 block mb-1">ترشيد مصروفات بوالص الارتجاع</b>
                                        <span>يرجى التعاقد مع شركات شحن تقدم رسوم ارتجاع مخفضة، حيث أن خسائر المرتجع تقتطع الكثير من أرباحك الصافية.</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* SWOT Matrix Card */}
                        <div className="bg-slate-800/80 p-6 rounded-2xl border border-slate-700 flex flex-col justify-between">
                            <h3 className="text-base font-bold mb-4 text-blue-300 flex items-center gap-2">
                                <Percent size={18} /> مصفوفة التحليل الاستراتيجي التشغيلي (SWOT)
                            </h3>
                            <div className="grid grid-cols-2 gap-3 text-[11px] sm:text-xs">
                                <div className="bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-900/30">
                                    <h4 className="font-bold text-emerald-400 mb-1 flex items-center gap-1">💪 نقاط القوة (Strengths)</h4>
                                    <p className="text-slate-400">تنوع مصادر الربح من تعلية منتجات، وفروقات شحن، وعمولات.</p>
                                </div>
                                <div className="bg-red-950/20 p-3.5 rounded-xl border border-red-900/30">
                                    <h4 className="font-bold text-red-400 mb-1 flex items-center gap-1">⚠️ نقاط الضعف (Weaknesses)</h4>
                                    <p className="text-slate-400">تأثير تكلفة مرتجعات الشحن المرتفعة على الصافي الحقيقي.</p>
                                </div>
                                <div className="bg-blue-950/20 p-3.5 rounded-xl border border-blue-900/30">
                                    <h4 className="font-bold text-blue-400 mb-1 flex items-center gap-1">🚀 الفرص (Opportunities)</h4>
                                    <p className="text-slate-400">الربح الكامن بالمستودع يمكن تصريفه بخصومات تصفية سريعة.</p>
                                </div>
                                <div className="bg-amber-950/20 p-3.5 rounded-xl border border-amber-900/30">
                                    <h4 className="font-bold text-amber-400 mb-1 flex items-center gap-1">⚡ التهديدات (Threats)</h4>
                                    <p className="text-slate-400">أرصدة شحن معلقة قيد التحصيل قد تضغط على السيولة النقدية.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {subTab === 'partners' && (
                <div className="space-y-8 animate-in fade-in-50 duration-300">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Warehouse Liquidation & Valuation */}
                        <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="text-base font-bold text-blue-300 flex items-center gap-2">
                                    <Package size={18} /> قيمة البضاعة المتاحة حالياً (في مخزن المتجر)
                                </h3>
                                <button onClick={toggleInventoryValue} className="text-slate-400 hover:text-white transition-colors" title={showInventoryValue ? "إخفاء التفاصيل" : "إظهار التفاصيل"}>
                                    {showInventoryValue ? <Eye size={16} className="text-blue-400" /> : <EyeOff size={16} />}
                                </button>
                            </div>
                            {showInventoryValue ? (
                                <>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
                                        <div className="bg-slate-900/80 p-5 rounded-xl border border-slate-800 relative overflow-hidden">
                                            <span className="text-slate-400 text-xs block mb-1">بقيمة التكلفة (الشراء)</span>
                                            <p className="text-2xl font-black font-mono text-slate-100">{stats.inventoryValue.toLocaleString('ar-EG')} ج.م</p>
                                            <p className="text-[10px] text-slate-500 mt-2">رأس المال الفعلي المجمد حالياً في بضاعة في المستودع</p>
                                        </div>
                                        <div className="bg-slate-900/80 p-5 rounded-xl border border-slate-800 relative overflow-hidden">
                                            <span className="text-slate-400 text-xs block mb-1">بسعر البيع المتوقع الكلي</span>
                                            <p className="text-2xl font-black font-mono text-emerald-400">{stats.inventorySalesValue.toLocaleString('ar-EG')} ج.م</p>
                                            <p className="text-[10px] text-emerald-500/80 mt-2">القيمة النقدية المقدرة عند بيع البضاعة بالكامل بالأسعار الحالية</p>
                                        </div>
                                    </div>
                                    <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800/60 flex justify-between items-center text-sm">
                                        <span className="text-slate-400">الربح الصافي المعلق بالكامل في المخزن:</span>
                                        <span className="text-emerald-400 font-bold font-mono">+{Math.max(0, stats.inventorySalesValue - stats.inventoryValue).toLocaleString('ar-EG')} ج.م</span>
                                    </div>
                                </>
                            ) : (
                                <div className="bg-slate-900/40 p-12 rounded-xl border border-slate-800 text-center my-auto">
                                    <p className="text-slate-400 text-sm mb-2">تم إخفاء قيمة البضاعة المتاحة في مخزن المتجر</p>
                                    <button onClick={toggleInventoryValue} className="text-xs text-blue-400 hover:text-blue-300 underline font-bold">انقر للإظهار</button>
                                </div>
                            )}
                        </div>

                        {/* Partner Equity accounts */}
                        <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700">
                            <h3 className="text-base font-bold mb-4 text-indigo-300 flex items-center gap-2">
                                <Users size={18} /> أرصدة وحسابات عهد الشركاء الحقيقية
                            </h3>
                            <div className="space-y-4">
                                {stats.partnerPerformance.map(p => (
                                    <div key={p.id} className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row justify-between sm:items-center gap-3 hover:border-slate-700 transition-colors">
                                        <div className="space-y-1">
                                            <div className="flex items-center gap-2">
                                                <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                                                <span className="font-black text-slate-100 text-sm sm:text-base">{p.name || 'الشريك'}</span>
                                            </div>
                                            <div className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-slate-400">
                                                <span>نسبة حصة الأرباح: <b>{p.profitRatio || 0}%</b></span>
                                                <span className="text-slate-500">|</span>
                                                <span>إجمالي المسحوبات والتوزيعات: <b>{(p.distributions ?? 0).toLocaleString('ar-EG')} ج.م</b></span>
                                            </div>
                                        </div>
                                        <div className="text-right flex items-center justify-between sm:justify-start gap-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800">
                                            <div className="text-right">
                                                <span className="text-[10px] text-slate-400 block">الرصيد الفعلي الحالي</span>
                                                <span className={`block font-black font-mono text-base sm:text-lg ${(p.currentBalance ?? 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                                    {(p.currentBalance ?? 0) > 0 ? '+' : ''}{(p.currentBalance ?? 0).toLocaleString('ar-EG')} ج.م
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                                {stats.partnerPerformance.length === 0 && (
                                    <div className="text-center text-slate-500 text-xs py-8">
                                        لم يتم تسجيل أي شركاء في إعدادات المتجر حالياً.
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const POSSalesReport: React.FC<{ orders: Order[], settings: Settings, activeStore?: Store, dateRangeText?: string }> = ({ orders, settings, activeStore, dateRangeText }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تحميل تقرير الكاشير...</p>
            </div>
        );
    }
    const [selectedCashier, setSelectedCashier] = useState<string>('all');
    const [paymentFilter, setPaymentFilter] = useState<string>('all');
    const [searchQuery, setSearchQuery] = useState<string>('');

    const storeName = activeStore?.name || (settings as any).storeName || 'متجر الكاشير المباشر';

    const allPosOrders = useMemo(() => {
        return orders.filter(o => o.channel === 'pos' || o.id?.startsWith('POS-') || o.shippingCompany?.startsWith('كاشير -') || o.shippingArea === 'نقطة البيع');
    }, [orders]);

    const allCashierNames = useMemo(() => {
        const set = new Set<string>();
        allPosOrders.forEach(o => {
            const name = resolveCashHolderName(o, settings) || o.createdBy || 'كاشير مجهول';
            set.add(name);
        });
        return Array.from(set);
    }, [allPosOrders, settings]);

    const filteredPosOrders = useMemo(() => {
        return allPosOrders.filter(o => {
            const cashierName = resolveCashHolderName(o, settings) || o.createdBy || 'كاشير مجهول';
            if (selectedCashier !== 'all' && cashierName !== selectedCashier) return false;

            if (paymentFilter === 'cash') {
                if (o.paymentMethod === 'card' || o.paymentMethod === 'visa' || o.cashHolderId === 'wallet') return false;
            } else if (paymentFilter === 'card') {
                if (o.paymentMethod !== 'card' && o.paymentMethod !== 'visa' && o.paymentMethod !== 'online') return false;
            } else if (paymentFilter === 'wallet') {
                if (o.cashHolderId !== 'wallet' && o.paymentMethod !== 'wallet') return false;
            }

            if (searchQuery.trim()) {
                const q = searchQuery.trim().toLowerCase();
                const matchId = (o.orderNumber || o.id || '').toLowerCase().includes(q);
                const matchCustomer = (o.customerName || '').toLowerCase().includes(q);
                const matchPhone = (o.customerPhone || '').includes(q);
                const matchItems = (o.items || []).some(i => i.name.toLowerCase().includes(q));
                return matchId || matchCustomer || matchPhone || matchItems;
            }

            return true;
        });
    }, [allPosOrders, selectedCashier, paymentFilter, searchQuery, settings]);

    const stats = useMemo(() => {
        let totalRevenue = 0;
        let totalItems = 0;
        let totalProfit = 0;
        let totalDiscount = 0;
        let ordersWithDiscount = 0;

        const productMelt: Record<string, { label: string, quantity: number, revenue: number, profit: number }> = {};
        const cashierPerformance: Record<string, { label: string, count: number, revenue: number, profit: number }> = {};
        
        const paymentStats = {
            cash: { label: 'نقدي (عهدة كاشير)', count: 0, revenue: 0 },
            card: { label: 'دفع إلكتروني / بطاقة', count: 0, revenue: 0 },
            wallet: { label: 'إيداع مباشر بالمحفظة', count: 0, revenue: 0 },
        };

        const hourlyMap: Record<string, number> = {
            '08:00-11:00': 0,
            '11:00-14:00': 0,
            '14:00-17:00': 0,
            '17:00-20:00': 0,
            '20:00-23:00': 0,
            '23:00-08:00': 0,
        };

        filteredPosOrders.forEach(o => {
            const revenue = (o.totalPrice || (o.productPrice + o.shippingFee));
            totalRevenue += revenue;
            const discount = o.discount || 0;
            totalDiscount += discount;
            if (discount > 0) ordersWithDiscount++;

            const { profit } = calculateOrderProfitLoss(o, settings);
            totalProfit += profit;

            (o.items || []).forEach(item => {
                totalItems += item.quantity;
                const pKey = item.productId || item.name;
                if (!productMelt[pKey]) {
                    productMelt[pKey] = { label: item.name, quantity: 0, revenue: 0, profit: 0 };
                }
                productMelt[pKey].quantity += item.quantity;
                productMelt[pKey].revenue += (item.price * item.quantity);
                productMelt[pKey].profit += (item.price - ((item as any).costPrice || 0)) * item.quantity;
            });

            const cashierName = resolveCashHolderName(o, settings) || o.createdBy || 'كاشير مجهول';
            if (!cashierPerformance[cashierName]) {
                cashierPerformance[cashierName] = { label: cashierName, count: 0, revenue: 0, profit: 0 };
            }
            cashierPerformance[cashierName].count += 1;
            cashierPerformance[cashierName].revenue += revenue;
            cashierPerformance[cashierName].profit += profit;

            // Payment classification
            if (o.paymentMethod === 'card' || o.paymentMethod === 'visa' || o.paymentMethod === 'online') {
                paymentStats.card.count += 1;
                paymentStats.card.revenue += revenue;
            } else if (o.cashHolderId === 'wallet' || o.paymentMethod === 'wallet') {
                paymentStats.wallet.count += 1;
                paymentStats.wallet.revenue += revenue;
            } else {
                paymentStats.cash.count += 1;
                paymentStats.cash.revenue += revenue;
            }

            // Hourly distribution
            if (o.date) {
                const hour = new Date(o.date).getHours();
                if (hour >= 8 && hour < 11) hourlyMap['08:00-11:00'] += revenue;
                else if (hour >= 11 && hour < 14) hourlyMap['11:00-14:00'] += revenue;
                else if (hour >= 14 && hour < 17) hourlyMap['14:00-17:00'] += revenue;
                else if (hour >= 17 && hour < 20) hourlyMap['17:00-20:00'] += revenue;
                else if (hour >= 20 && hour < 23) hourlyMap['20:00-23:00'] += revenue;
                else hourlyMap['23:00-08:00'] += revenue;
            }
        });

        const overallStoreRevenue = orders.reduce((sum, o) => sum + (o.totalPrice || (o.productPrice + o.shippingFee)), 0);
        const posSalesShare = overallStoreRevenue > 0 ? Math.round((totalRevenue / overallStoreRevenue) * 100) : 0;
        const profitMargin = totalRevenue > 0 ? Math.round((totalProfit / totalRevenue) * 100) : 0;
        const avgBasket = filteredPosOrders.length > 0 ? (totalRevenue / filteredPosOrders.length) : 0;
        const avgItemsPerOrder = filteredPosOrders.length > 0 ? (totalItems / filteredPosOrders.length).toFixed(1) : '0';

        const bestProducts = Object.values(productMelt).sort((a, b) => b.revenue - a.revenue).slice(0, 8);
        const cashierList = Object.values(cashierPerformance).sort((a, b) => b.revenue - a.revenue);

        const hourlyChartData = Object.entries(hourlyMap).map(([slot, amount]) => ({
            slot,
            مبيعات: amount
        }));

        return {
            totalRevenue,
            totalItems,
            totalProfit,
            totalDiscount,
            ordersWithDiscount,
            count: filteredPosOrders.length,
            avgBasket,
            avgItemsPerOrder,
            posSalesShare,
            profitMargin,
            bestProducts,
            cashierList,
            paymentStats,
            hourlyChartData
        };
    }, [filteredPosOrders, orders, settings]);

    const handlePrintShiftReport = () => {
        const html = generatePosReportHTML(filteredPosOrders, settings, storeName, dateRangeText);
        printHTMLDirectly(html);
    };

    const handleExportPDF = async () => {
        const html = generatePosReportHTML(filteredPosOrders, settings, storeName, dateRangeText);
        await exportHTMLToPDF(html, 'landscape', `تقرير_الكاشير_${storeName}.pdf`);
    };

    return (
        <div className="space-y-6 animate-in fade-in-5 duration-300">
            {/* Top Action & Analytics Bar */}
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 sm:p-8 rounded-3xl border border-indigo-900/40 shadow-xl text-white relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400"></div>
                <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-6 relative z-10">
                    <div className="space-y-2">
                        <div className="flex items-center gap-3">
                            <div className="p-3 bg-indigo-500/20 border border-indigo-400/30 rounded-2xl text-indigo-300 backdrop-blur-md">
                                <Monitor size={28} />
                            </div>
                            <div>
                                <div className="flex items-center gap-2">
                                    <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                                        مركز تحليلات نقطة البيع (POS)
                                    </h2>
                                    <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                        كاشير نشط
                                    </span>
                                </div>
                                <p className="text-slate-300 text-xs sm:text-sm font-medium mt-1">
                                    رصد مباشر لحركة المبيعات الفورية، أداء الوردية، وكفاءة تسوية نقدية الكاشير بمتجر "<span className="text-indigo-300 font-bold">{storeName}</span>"
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                        <button
                            onClick={handlePrintShiftReport}
                            className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-[1.02] text-xs sm:text-sm"
                        >
                            <Printer size={16} />
                            طباعة تقرير الوردية (A4)
                        </button>
                        <button
                            onClick={handleExportPDF}
                            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold px-4 py-2.5 rounded-xl transition-all text-xs sm:text-sm backdrop-blur-md"
                        >
                            <Download size={16} />
                            تصدير PDF
                        </button>
                    </div>
                </div>

                {/* Filter Controls Bar */}
                <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                        <label className="text-[11px] font-bold text-slate-300 mb-1 block">الكاشير / الموظف المسؤول:</label>
                        <select
                            value={selectedCashier}
                            onChange={e => setSelectedCashier(e.target.value)}
                            className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="all">جميع الكاشيرية (كل الوردية)</option>
                            {allCashierNames.map((name, idx) => (
                                <option key={idx} value={name}>{name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="text-[11px] font-bold text-slate-300 mb-1 block">طريقة التحصيل / الدفع:</label>
                        <select
                            value={paymentFilter}
                            onChange={e => setPaymentFilter(e.target.value)}
                            className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="all">جميع طرق الدفع</option>
                            <option value="cash">نقدي (عهدة الكاشير)</option>
                            <option value="card">دفع إلكتروني / بطاقة</option>
                            <option value="wallet">إيداع مباشر بالمحفظة العامة</option>
                        </select>
                    </div>

                    <div>
                        <label className="text-[11px] font-bold text-slate-300 mb-1 block">بحث الفاتورة / العميل / المنتج:</label>
                        <input
                            type="text"
                            placeholder="بحث برقم الفاتورة، اسم العميل..."
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                            className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-bold text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                    </div>
                </div>
            </div>

            {/* Empty State */}
            {stats.count === 0 ? (
                <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl border border-slate-200 dark:border-slate-800 text-center flex flex-col items-center justify-center space-y-4 shadow-sm">
                    <div className="p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-3xl text-indigo-500 border border-indigo-200 dark:border-indigo-800">
                        <Monitor size={48} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-800 dark:text-slate-200">لا توجد مبيعات كاشير مطابقة للفلتر</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm max-w-sm">
                        تأكد من اختيار نطاق تاريخي يحتوي على مبيعات POS أو جرب تغيير خيارات الفلترة المحددة أعلاه.
                    </p>
                </div>
            ) : (
                <>
                    {/* Executive Modern KPI Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden group">
                            <div className="absolute top-0 left-0 right-0 h-1 bg-indigo-500"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">إجمالي مبيعات POS</span>
                                <div className="p-2 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 rounded-xl">
                                    <ShoppingBasket size={16} />
                                </div>
                            </div>
                            <h4 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums">
                                {stats.totalRevenue.toLocaleString()} <span className="text-xs font-bold text-slate-400">ج.م</span>
                            </h4>
                            <p className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 mt-2 flex items-center gap-1">
                                <span>📈 {stats.posSalesShare}%</span>
                                <span className="text-slate-400 font-normal">من إجمالي مبيعات المتجر</span>
                            </p>
                        </div>

                        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 left-0 right-0 h-1 bg-cyan-500"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">عدد الفواتير والقطع</span>
                                <div className="p-2 bg-cyan-50 dark:bg-cyan-950/50 text-cyan-600 rounded-xl">
                                    <FileText size={16} />
                                </div>
                            </div>
                            <h4 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums">
                                {stats.count} <span className="text-xs font-bold text-slate-400">فاتورة</span>
                            </h4>
                            <p className="text-[11px] font-bold text-cyan-600 dark:text-cyan-400 mt-2">
                                📦 {stats.totalItems} قطعة مباعة <span className="text-slate-400 font-normal">({stats.avgItemsPerOrder} قطعة/طلب)</span>
                            </p>
                        </div>

                        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-500"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">صافي أرباح الكاشير</span>
                                <div className="p-2 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 rounded-xl">
                                    <TrendingUp size={16} />
                                </div>
                            </div>
                            <h4 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                                +{stats.totalProfit.toLocaleString()} <span className="text-xs font-bold text-emerald-400">ج.م</span>
                            </h4>
                            <p className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 mt-2">
                                💡 هامش ربح صافي: {stats.profitMargin}%
                            </p>
                        </div>

                        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 left-0 right-0 h-1 bg-purple-500"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">متوسط سلة المبيعات (AOV)</span>
                                <div className="p-2 bg-purple-50 dark:bg-purple-950/50 text-purple-600 rounded-xl">
                                    <Coins size={16} />
                                </div>
                            </div>
                            <h4 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums">
                                {Math.round(stats.avgBasket).toLocaleString()} <span className="text-xs font-bold text-slate-400">ج.م</span>
                            </h4>
                            <p className="text-[11px] font-bold text-purple-600 dark:text-purple-400 mt-2">
                                🛒 متوسط القيمة للفاتورة الواحدة
                            </p>
                        </div>

                        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
                            <div className="absolute top-0 left-0 right-0 h-1 bg-rose-500"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-xs font-bold text-rose-500 uppercase tracking-wider">الخصومات الممنوحة</span>
                                <div className="p-2 bg-rose-50 dark:bg-rose-950/50 text-rose-600 rounded-xl">
                                    <Percent size={16} />
                                </div>
                            </div>
                            <h4 className="text-2xl font-black text-rose-600 tabular-nums">
                                {stats.totalDiscount.toLocaleString()} <span className="text-xs font-bold text-rose-400">ج.م</span>
                            </h4>
                            <p className="text-[11px] font-bold text-rose-500 mt-2">
                                🏷️ {stats.ordersWithDiscount} فاتورة تضمنت خصماً
                            </p>
                        </div>
                    </div>

                    {/* Analytics Section - Charts & Breakdown Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Peak Hours Hourly Chart */}
                        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                            <div className="flex justify-between items-center mb-6">
                                <div>
                                    <h3 className="font-black text-slate-800 dark:text-white text-base flex items-center gap-2">
                                        <TrendingUp className="text-indigo-500" size={18} />
                                        ساعات الذروة ونشاط الكاشير على مدار اليوم
                                    </h3>
                                    <p className="text-slate-400 text-xs mt-0.5">تحليل توقيت الإقبال وكثافة عمليات الشراء المباشرة</p>
                                </div>
                                <span className="px-3 py-1 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-bold border border-indigo-100 dark:border-indigo-900">
                                    توزع الزخم الزمني
                                </span>
                            </div>

                            <div className="h-64 w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={stats.hourlyChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.5} />
                                        <XAxis dataKey="slot" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                                        <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                                        <Tooltip
                                            formatter={(value: number) => [`${value.toLocaleString()} ج.م`, 'إجمالي المبيعات']}
                                            labelStyle={{ fontWeight: 'bold', color: '#0f172a' }}
                                            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
                                        />
                                        <Bar dataKey="مبيعات" fill="#6366f1" radius={[8, 8, 0, 0]}>
                                            {stats.hourlyChartData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={index === 3 || index === 4 ? '#4f46e5' : '#818cf8'} />
                                            ))}
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Payment Method Distribution */}
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                            <div>
                                <h3 className="font-black text-slate-800 dark:text-white text-base mb-1 flex items-center gap-2">
                                    <WalletIcon className="text-emerald-500" size={18} />
                                    توزيع طرق التحصيل
                                </h3>
                                <p className="text-slate-400 text-xs mb-6">نسبة التحصيل النقدي والشبكة والإيداعات</p>

                                <div className="space-y-4">
                                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                                                <span>💵</span> نقدي (عهدة الكاشير الشخصية)
                                            </span>
                                            <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                                                {stats.paymentStats.cash.revenue.toLocaleString()} ج.م
                                            </span>
                                        </div>
                                        <div className="text-[11px] text-slate-400 flex justify-between">
                                            <span>{stats.paymentStats.cash.count} فاتورة</span>
                                            <span>{stats.totalRevenue > 0 ? Math.round((stats.paymentStats.cash.revenue / stats.totalRevenue) * 100) : 0}% من الكاشير</span>
                                        </div>
                                    </div>

                                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                                                <span>💳</span> دفع إلكتروني / بطاقة شبكة
                                            </span>
                                            <span className="text-xs font-black text-cyan-600 dark:text-cyan-400">
                                                {stats.paymentStats.card.revenue.toLocaleString()} ج.م
                                            </span>
                                        </div>
                                        <div className="text-[11px] text-slate-400 flex justify-between">
                                            <span>{stats.paymentStats.card.count} فاتورة</span>
                                            <span>{stats.totalRevenue > 0 ? Math.round((stats.paymentStats.card.revenue / stats.totalRevenue) * 100) : 0}% من الكاشير</span>
                                        </div>
                                    </div>

                                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                                                <span>👛</span> إيداع مباشر بالمحفظة العامة
                                            </span>
                                            <span className="text-xs font-black text-purple-600 dark:text-purple-400">
                                                {stats.paymentStats.wallet.revenue.toLocaleString()} ج.م
                                            </span>
                                        </div>
                                        <div className="text-[11px] text-slate-400 flex justify-between">
                                            <span>{stats.paymentStats.wallet.count} فاتورة</span>
                                            <span>{stats.totalRevenue > 0 ? Math.round((stats.paymentStats.wallet.revenue / stats.totalRevenue) * 100) : 0}% من الكاشير</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
                                <span className="text-[11px] font-bold text-slate-400">
                                    💡 إجمالي الفواتير المحصلة: {stats.count} فاتورة
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Cashier Staff Leaderboard & Top Selling Products */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Cashier Efficiency Leaderboard */}
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                            <h3 className="font-black text-slate-800 dark:text-white mb-6 flex items-center gap-2 text-base">
                                <Users className="text-indigo-500" size={18} />
                                كفاءة وأداء كاشيرية الوردية (Staff Leaderboard)
                            </h3>

                            <div className="space-y-3">
                                {stats.cashierList.map((c, idx) => {
                                    const sharePercent = stats.totalRevenue > 0 ? Math.round((c.revenue / stats.totalRevenue) * 100) : 0;
                                    const rankBadge = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`;

                                    return (
                                        <div key={idx} className="p-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col gap-2">
                                            <div className="flex justify-between items-center">
                                                <div className="flex items-center gap-2.5">
                                                    <span className="text-base font-black">{rankBadge}</span>
                                                    <div>
                                                        <h4 className="font-bold text-slate-800 dark:text-slate-200 text-sm">{c.label}</h4>
                                                        <p className="text-slate-400 text-xs">{c.count} عملية بيع ناجحة</p>
                                                    </div>
                                                </div>
                                                <div className="text-left">
                                                    <div className="font-black text-indigo-600 dark:text-indigo-400 text-base">{c.revenue.toLocaleString()} ج.م</div>
                                                    <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">أرباح: +{c.profit.toLocaleString()} ج.م</div>
                                                </div>
                                            </div>

                                            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                                                <div className="bg-indigo-600 h-full rounded-full transition-all" style={{ width: `${sharePercent}%` }}></div>
                                            </div>
                                            <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                                                <span>نسبة المساهمة بالمبيعات: {sharePercent}%</span>
                                                <span>متوسط الفاتورة: {c.count > 0 ? Math.round(c.revenue / c.count).toLocaleString() : 0} ج.م</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>

                        {/* Top Sold Products in POS */}
                        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                            <h3 className="font-black text-slate-800 dark:text-white mb-6 flex items-center gap-2 text-base">
                                <Package className="text-cyan-500" size={18} />
                                المنتجات الأكثر مبيعاً في الكاشير
                            </h3>

                            <div className="space-y-4">
                                {stats.bestProducts.map((p, idx) => {
                                    const percentage = stats.totalRevenue > 0 ? Math.round((p.revenue / stats.totalRevenue) * 100) : 0;
                                    return (
                                        <div key={idx} className="space-y-1.5">
                                            <div className="flex justify-between items-center text-xs font-bold">
                                                <span className="text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                                                    <span className="text-slate-400 font-mono">#{idx + 1}</span>
                                                    {p.label}
                                                </span>
                                                <span className="text-indigo-600 dark:text-indigo-400 font-black">
                                                    {p.revenue.toLocaleString()} ج.م <span className="text-slate-400 font-medium">({p.quantity} قطعة)</span>
                                                </span>
                                            </div>
                                            <div className="h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                                <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full transition-all" style={{ width: `${percentage}%` }}></div>
                                            </div>
                                            <div className="flex justify-between text-[10px] text-slate-400">
                                                <span>المساهمة: {percentage}%</span>
                                                <span className="text-emerald-600 font-bold">صافي الربح: +{p.profit.toLocaleString()} ج.م</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>

                    {/* Live POS Order & Receipt Table Log */}
                    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                            <div>
                                <h3 className="font-black text-slate-800 dark:text-white text-base flex items-center gap-2">
                                    <FileText className="text-indigo-500" size={18} />
                                    سجل معاملات الكاشير المباشرة ({filteredPosOrders.length} فاتورة)
                                </h3>
                                <p className="text-slate-400 text-xs mt-0.5">جدول تفصيلي بكل عمليات البيع المحصلة بالكاشير</p>
                            </div>
                            <span className="text-xs font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl self-start sm:self-auto">
                                إجمالي القيمة: {stats.totalRevenue.toLocaleString()} ج.م
                            </span>
                        </div>

                        <div className="overflow-x-auto">
                            <table className="w-full text-right border-collapse">
                                <thead>
                                    <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 text-xs font-bold border-b border-slate-100 dark:border-slate-800">
                                        <th className="py-3.5 px-4">الفاتورة</th>
                                        <th className="py-3.5 px-4">التاريخ والوقت</th>
                                        <th className="py-3.5 px-4">الكاشير المسئول</th>
                                        <th className="py-3.5 px-4">العميل / البيان</th>
                                        <th className="py-3.5 px-4">المنتجات</th>
                                        <th className="py-3.5 px-4 text-center">الخصم</th>
                                        <th className="py-3.5 px-4">إجمالي السداد</th>
                                        <th className="py-3.5 px-4">الربح الصافي</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                                    {filteredPosOrders.map((o, idx) => {
                                        const { profit } = calculateOrderProfitLoss(o, settings);
                                        const cashierName = resolveCashHolderName(o, settings) || o.createdBy || 'كاشير';
                                        const totalAmt = (o.totalPrice || (o.productPrice + o.shippingFee));

                                        return (
                                            <tr key={idx} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                                                <td className="py-3.5 px-4 font-black text-indigo-600 dark:text-indigo-400">
                                                    #{o.orderNumber || o.id?.slice(0, 8)}
                                                </td>
                                                <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                                                    {new Date(o.date).toLocaleDateString('ar-EG')}
                                                    <span className="block text-[10px] text-slate-400">{new Date(o.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</span>
                                                </td>
                                                <td className="py-3.5 px-4">
                                                    <span className="px-2.5 py-1 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900 rounded-full font-bold text-[11px]">
                                                        👤 {cashierName}
                                                    </span>
                                                </td>
                                                <td className="py-3.5 px-4 font-bold text-slate-800 dark:text-slate-200">
                                                    {o.customerName || 'عميل كاشير مباشر'}
                                                    {o.customerPhone && <span className="block text-[10px] text-slate-400 font-mono" dir="ltr">{o.customerPhone}</span>}
                                                </td>
                                                <td className="py-3.5 px-4 max-w-[180px] truncate text-slate-600 dark:text-slate-400" title={(o.items || []).map(i => `${i.name} (${i.quantity})`).join(', ')}>
                                                    {(o.items || []).map(i => `${i.name} (x${i.quantity})`).join(', ') || 'منتجات كاشير'}
                                                </td>
                                                <td className="py-3.5 px-4 text-center font-bold">
                                                    {(o.discount || 0) > 0 ? (
                                                        <span className="text-rose-600 dark:text-rose-400">
                                                            -{(o.discount || 0).toLocaleString()} ج.م
                                                        </span>
                                                    ) : (
                                                        <span className="text-slate-300 dark:text-slate-600">-</span>
                                                    )}
                                                </td>
                                                <td className="py-3.5 px-4 font-black text-slate-900 dark:text-white text-sm" dir="ltr">
                                                    {totalAmt.toLocaleString()} ج.م
                                                </td>
                                                <td className="py-3.5 px-4 font-bold text-emerald-600 dark:text-emerald-400" dir="ltr">
                                                    +{profit.toLocaleString()} ج.م
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

const ReportsPage: React.FC<ReportsPageProps> = ({ orders, settings, wallet, treasury, activeStore, setSettings, setWallet }) => {
    if (!settings) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 bg-white/50 dark:bg-slate-900/50 rounded-[2rem] border border-slate-200 dark:border-slate-800">
                <Loader2 size={32} className="animate-spin text-indigo-500 mb-4" />
                <p className="text-sm font-bold">جاري تهيئة مركز التقارير...</p>
            </div>
        );
    }
    const [activeTab, setActiveTab] = useState<'pnl' | 'summary' | 'losses' | 'comprehensive' | 'final' | 'partners' | 'inventory' | 'accounting' | 'pos' | 'custody'>('pnl');
    const [dateRangeType, setDateRangeType] = useState<string>(() => settings?.activePeriodStartDate ? 'activePeriod' : 'all');
    const [customStartDate, setCustomStartDate] = useState<string>('');
    const [customEndDate, setCustomEndDate] = useState<string>('');
    const [isClosingModalOpen, setIsClosingModalOpen] = useState<boolean>(false);

    const filteredData = useMemo(() => {
        const parseSafeDate = (dateVal: any): Date | null => {
            if (!dateVal) return null;
            if (dateVal instanceof Date) return isNaN(dateVal.getTime()) ? null : dateVal;
            if (typeof dateVal === 'number') {
                const d = new Date(dateVal);
                return isNaN(d.getTime()) ? null : d;
            }
            
            let str = String(dateVal).trim();
            if (!str) return null;
            
            // Convert Arabic-Indic numerals (٠١٢٣٤٥٦٧٨٩) to Latin (0123456789)
            str = str.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d).toString());

            let parsed = new Date(str);
            if (!isNaN(parsed.getTime())) return parsed;

            // Handle DD/MM/YYYY or YYYY-MM-DD or DD-MM-YYYY
            const parts = str.split(/[\/\-\sT:]/);
            if (parts.length >= 3) {
                const n0 = parseInt(parts[0], 10);
                const n1 = parseInt(parts[1], 10);
                const n2 = parseInt(parts[2], 10);
                const h = parts[3] ? parseInt(parts[3], 10) : 0;
                const m = parts[4] ? parseInt(parts[4], 10) : 0;
                const s = parts[5] ? parseInt(parts[5], 10) : 0;

                if (!isNaN(n0) && !isNaN(n1) && !isNaN(n2)) {
                    if (n0 > 1000) {
                        parsed = new Date(n0, n1 - 1, n2, h, m, s);
                    } else if (n2 > 1000) {
                        parsed = new Date(n2, n1 - 1, n0, h, m, s);
                    }
                    if (!isNaN(parsed.getTime())) return parsed;
                }
            }
            return null;
        };

        const now = new Date();
        const startOfDay = (d: Date) => {
            const res = new Date(d);
            res.setHours(0,0,0,0);
            return res;
        };
        const endOfDay = (d: Date) => {
            const res = new Date(d);
            res.setHours(23,59,59,999);
            return res;
        };

        if (dateRangeType === 'all') {
            return { orders, wallet, supplyOrders: settings?.supplyOrders || [], settings };
        }

        let minDate: Date | null = null;
        let maxDate: Date | null = null;

        const activePeriodStart = settings?.activePeriodStartDate ? parseSafeDate(settings.activePeriodStartDate) : null;

        if (dateRangeType === 'activePeriod' && activePeriodStart) {
            minDate = activePeriodStart;
            maxDate = endOfDay(now);
        } else if (dateRangeType === 'today') {
            minDate = startOfDay(now);
            maxDate = endOfDay(now);
            // If active period started today AFTER startOfDay, use activePeriodStart as minimum
            if (activePeriodStart && activePeriodStart.getTime() > minDate.getTime() && activePeriodStart.getTime() <= maxDate.getTime()) {
                minDate = activePeriodStart;
            }
        } else if (dateRangeType === 'yesterday') {
            const yesterday = new Date(now);
            yesterday.setDate(now.getDate() - 1);
            minDate = startOfDay(yesterday);
            maxDate = endOfDay(yesterday);
        } else if (dateRangeType === '7days') {
            const weekAgo = new Date(now);
            weekAgo.setDate(now.getDate() - 7);
            minDate = startOfDay(weekAgo);
            maxDate = endOfDay(now);
        } else if (dateRangeType === 'thisMonth') {
            minDate = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
            maxDate = endOfDay(now);
        } else if (dateRangeType === 'lastMonth') {
            minDate = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
            maxDate = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
        } else if (dateRangeType === 'custom') {
            if (customStartDate) {
                const s = parseSafeDate(customStartDate);
                if (s) minDate = startOfDay(s);
            }
            if (customEndDate) {
                const e = parseSafeDate(customEndDate);
                if (e) maxDate = endOfDay(e);
            }
        }

        const isItemInRange = (itemDateStr?: string) => {
            const itemDate = parseSafeDate(itemDateStr);
            if (!itemDate) return false; // Exclude items with invalid/missing dates
            const itemTime = itemDate.getTime();
            if (minDate && itemTime < minDate.getTime()) return false;
            if (maxDate && itemTime > maxDate.getTime()) return false;
            return true;
        };

        const filteredOrders = orders.filter(o => isItemInRange(o.date));
        const filteredTransactions = (wallet?.transactions || []).filter(t => isItemInRange(t.date));
        const filteredSupplyOrders = (settings?.supplyOrders || []).filter(o => isItemInRange(o.date));
        const filteredPosSales = (settings?.posSales || []).filter(s => isItemInRange(s.date));
        const filteredCashHandovers = ((settings as any)?.cashHandovers || []).filter((h: any) => isItemInRange(h.date));
        const filteredPartnerTransactions = (settings?.partnerTransactions || []).filter(t => isItemInRange(t.date));

        const filteredWallet = wallet ? {
            ...wallet,
            transactions: filteredTransactions
        } : wallet;

        const filteredSettings = settings ? {
            ...settings,
            supplyOrders: filteredSupplyOrders,
            posSales: filteredPosSales,
            cashHandovers: filteredCashHandovers,
            partnerTransactions: filteredPartnerTransactions
        } : settings;

        return { orders: filteredOrders, wallet: filteredWallet, supplyOrders: filteredSupplyOrders, settings: filteredSettings };
    }, [orders, wallet, settings, dateRangeType, customStartDate, customEndDate]);

    const dateRangeText = useMemo(() => {
        if (dateRangeType === 'activePeriod' && settings?.activePeriodStartDate) {
            return `الدورة الحالية (من ${new Date(settings.activePeriodStartDate).toLocaleDateString('ar-EG')})`;
        }
        if (dateRangeType === 'all') return 'كل البيانات';
        if (dateRangeType === 'today') return 'اليوم';
        if (dateRangeType === 'yesterday') return 'أمس';
        if (dateRangeType === '7days') return 'آخر 7 أيام';
        if (dateRangeType === 'thisMonth') return 'هذا الشهر';
        if (dateRangeType === 'lastMonth') return 'الشهر السابق';
        if (dateRangeType === 'custom') {
            const start = customStartDate ? new Date(customStartDate).toLocaleDateString('ar-EG') : 'البداية';
            const end = customEndDate ? new Date(customEndDate).toLocaleDateString('ar-EG') : 'النهاية';
            return `مخصص (${start} - ${end})`;
        }
        return 'غير محدد';
    }, [dateRangeType, settings?.activePeriodStartDate, customStartDate, customEndDate]);

    return (
        <div className="space-y-6 sm:space-y-8 pb-12 max-w-[1900px] mx-auto text-right" dir="rtl">
            {/* 🚀 Dynamic Executive Reports Hero Banner */}
            <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-slate-900 via-[#0b1c2d] to-indigo-950 text-white p-7 sm:p-9 shadow-xl border border-indigo-500/20">
                <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -translate-x-1/3 -translate-y-1/3" />
                <div className="absolute bottom-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none translate-x-1/4 translate-y-1/4" />

                <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="space-y-3">
                        <div className="flex flex-wrap items-center gap-3">
                            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-black border border-indigo-500/30 backdrop-blur-md">
                                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                                محرك التقارير المحاسبية والموازنة
                            </span>
                            <span className="px-3 py-1 rounded-full bg-white/10 text-slate-200 text-xs font-bold border border-white/10 backdrop-blur-md">
                                النطاق: {dateRangeText}
                            </span>
                            {settings?.activePeriodStartDate && (
                                <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30 backdrop-blur-md flex items-center gap-1.5">
                                    <Lock size={12} />
                                    دورة محاسبية جارية
                                </span>
                            )}
                        </div>

                        <div className="space-y-1">
                            <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight flex items-center gap-3">
                                <span>مركز التقارير والتحليلات المالية</span>
                            </h1>
                            <p className="text-xs sm:text-sm font-medium text-slate-300/90 max-w-2xl leading-relaxed">
                                لوحة التحكم الشاملة لمؤشرات الأداء، الأرباح والخسائر، التدفقات النقدية، مقاصة المخزون، والمركز المالي الدقيق لجميع الشركاء.
                            </p>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 shrink-0">
                        <button
                            onClick={() => setIsClosingModalOpen(true)}
                            className="group relative inline-flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-indigo-600 to-indigo-700 hover:from-amber-500/30 hover:to-indigo-600 text-white font-black text-xs sm:text-sm border border-indigo-400/40 hover:border-amber-400/60 shadow-xl shadow-indigo-950/40 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] cursor-pointer overflow-hidden"
                            title="إقفال الدورة المحاسبية وتسوية مقاصة الشركاء وفق بضاعة المخزون"
                        >
                            <span className="p-1.5 bg-amber-500/30 text-amber-300 rounded-xl border border-amber-400/40 group-hover:rotate-12 transition-transform duration-300 shrink-0 shadow-sm">
                                <Lock size={16} className="text-amber-300" />
                            </span>
                            <span className="tracking-tight text-white font-black">
                                إقفال الفترة وبدء دورة جديدة
                            </span>
                            <span className="px-2.5 py-1 text-[10px] font-black bg-amber-400/20 text-amber-300 rounded-xl border border-amber-400/40 flex items-center gap-1.5 shrink-0">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                                مقاصة المخزون
                            </span>
                        </button>
                    </div>
                </div>
            </div>

            {/* Dynamic Date Range Picker Bar */}
            <div className="bg-white dark:bg-slate-900/90 backdrop-blur-xl p-4 sm:p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
                <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                            <Calendar size={20} />
                        </div>
                        <div>
                            <h3 className="text-sm font-black text-slate-800 dark:text-white">نطاق فلترة تاريخ التقارير</h3>
                            <p className="text-[11px] text-slate-400 font-medium">حدد الفترة الزمنية لتحديث كافة الرسوم والأرباح وإحصاءات الخسائر والشركاء بشكل منسق لحظياً.</p>
                        </div>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-1.5 bg-slate-100/80 dark:bg-slate-800/60 p-1.5 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 w-fit">
                        {[
                            ...(settings?.activePeriodStartDate ? [{ id: 'activePeriod', label: `الدورة الحالية (من ${new Date(settings.activePeriodStartDate).toLocaleDateString('ar-EG')}) 🔒` }] : []),
                            { id: 'all', label: 'كل البيانات' },
                            { id: 'today', label: 'اليوم' },
                            { id: 'yesterday', label: 'أمس' },
                            { id: '7days', label: 'آخر 7 أيام' },
                            { id: 'thisMonth', label: 'هذا الشهر' },
                            { id: 'lastMonth', label: 'الشهر السابق' },
                            { id: 'custom', label: 'نطاق مخصص 📅' }
                        ].map((preset) => (
                            <button
                                key={preset.id}
                                onClick={() => setDateRangeType(preset.id)}
                                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                                    dateRangeType === preset.id
                                        ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                                        : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/60 dark:hover:bg-slate-700/50'
                                }`}
                            >
                                {preset.label}
                            </button>
                        ))}
                    </div>
                </div>

                {dateRangeType === 'custom' && (
                    <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs animate-in slide-in-from-top-1 duration-200">
                        <div className="flex items-center gap-2">
                            <span className="text-slate-500 dark:text-slate-400 font-bold">من تاريخ:</span>
                            <input
                                type="date"
                                value={customStartDate}
                                onChange={(e) => setCustomStartDate(e.target.value)}
                                className="px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-700 dark:text-slate-200"
                            />
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-slate-500 dark:text-slate-400 font-bold">إلى تاريخ:</span>
                            <input
                                type="date"
                                value={customEndDate}
                                onChange={(e) => setCustomEndDate(e.target.value)}
                                className="px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-700 dark:text-slate-200"
                            />
                        </div>
                    </div>
                )}
            </div>

            {/* Premium Modern Navigation Tabs */}
            <div className="flex gap-2 bg-slate-100/80 dark:bg-slate-900/80 p-2 rounded-2xl border border-slate-200/60 dark:border-slate-800 overflow-x-auto no-scrollbar scroll-smooth w-full">
                <button onClick={() => setActiveTab('pnl')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'pnl' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>الأرباح والخسائر P&L ✨</button>
                <button onClick={() => setActiveTab('summary')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'summary' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>ملخص المبيعات</button>
                <button onClick={() => setActiveTab('losses')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'losses' ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>تقرير الخسائر</button>
                <button onClick={() => setActiveTab('pos')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'pos' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>تقرير الكاشير (POS)</button>
                <button onClick={() => setActiveTab('comprehensive')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'comprehensive' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>التقرير الشامل</button>
                <button onClick={() => setActiveTab('final')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'final' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>التقرير الختامي الشامل</button>
                <button onClick={() => setActiveTab('partners')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'partners' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>تقرير الشركاء</button>
                <button onClick={() => setActiveTab('custody')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'custody' ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>العهد المالية</button>
                <button onClick={() => setActiveTab('inventory')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'inventory' ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30' : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'}`}>المشتريات والمخزون</button>
                <button onClick={() => setActiveTab('accounting')} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${activeTab === 'accounting' ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30' : 'text-purple-600 hover:bg-purple-50 dark:text-purple-400 dark:hover:bg-purple-950/30'}`}>الحسابات الختامية 📊</button>
            </div>
            <div className="relative min-h-[calc(100vh-200px)] mt-6 animate-in fade-in-5 duration-300">
                {activeTab === 'pnl' && <FinancialPnLDashboard orders={filteredData.orders} settings={filteredData.settings} treasury={treasury} wallet={filteredData.wallet} />}
                {activeTab === 'summary' && <SalesSummaryReport orders={filteredData.orders} settings={filteredData.settings} wallet={filteredData.wallet} />}
                {activeTab === 'losses' && <LossesReport orders={filteredData.orders} settings={filteredData.settings} activeStore={activeStore} dateRangeText={dateRangeText} />}
                {activeTab === 'pos' && <POSSalesReport orders={filteredData.orders} settings={filteredData.settings} activeStore={activeStore} dateRangeText={dateRangeText} />}
                {activeTab === 'comprehensive' && <ComprehensiveReport orders={filteredData.orders} settings={filteredData.settings} wallet={filteredData.wallet} treasury={treasury} activeStore={activeStore} dateRangeText={dateRangeText} supplyOrders={filteredData.supplyOrders} setSettings={setSettings} setWallet={setWallet} />}
                {activeTab === 'final' && <FinalReport orders={filteredData.orders} settings={filteredData.settings} wallet={filteredData.wallet} treasury={treasury} activeStore={activeStore} dateRangeText={dateRangeText} supplyOrders={filteredData.supplyOrders} />}
                {activeTab === 'partners' && <PartnersFinancialReport orders={filteredData.orders} settings={filteredData.settings} wallet={filteredData.wallet} treasury={treasury} activeStore={activeStore} dateRangeText={dateRangeText} setSettings={setSettings} setWallet={setWallet} />}
                {activeTab === 'custody' && <CustodyLedger settings={filteredData.settings} />}
                {activeTab === 'inventory' && <InventoryReport activeStore={activeStore} settings={filteredData.settings} dateRangeText={dateRangeText} />}
                {activeTab === 'accounting' && <AccountingReports orders={filteredData.orders} settings={filteredData.settings} wallet={filteredData.wallet} activeStore={activeStore} setSettings={setSettings} setWallet={setWallet} supplyOrders={filteredData.supplyOrders} />}
            </div>

            {/* Period Closing and Rollover Modal */}
            <PeriodClosingModal
                isOpen={isClosingModalOpen}
                onClose={() => setIsClosingModalOpen(false)}
                settings={settings}
                updateSettings={setSettings || (() => {})}
                orders={orders}
                wallet={wallet}
                setWallet={setWallet}
                treasury={treasury}
            />
        </div>
    );
};

export default ReportsPage;
