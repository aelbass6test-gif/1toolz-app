
// ... (previous imports and declartions)

// FIX: Declaring the 'google' object in the global scope to make it accessible across all files.


export type OrderStatus = 'في_انتظار_المكالمة' | 'جاري_المراجعة' | 'قيد_التنفيذ' | 'تم_الارسال' | 'قيد_الشحن' | 'تم_توصيلها' | 'تم_التوصيل' | 'تم_التحصيل' | 'مرتجع' | 'مرتجع_جزئي' | 'فشل_التوصيل' | 'ملغي' | 'مؤرشف' | 'مرتجع_بعد_الاستلام' | 'تم_الاستبدال' | 'تمت_الاعادة_لشركة_الشحن' | 'مدفوعة' | 'مؤجل' | 'مجدول' | 'مؤكد';
export type PaymentStatus = 'بانتظار الدفع' | 'مدفوع' | 'مدفوع جزئياً' | 'مرتجع';
export type PreparationStatus = 'بانتظار التجهيز' | 'جاهز';

export interface CityOption {
  id: string;
  name: string;
  deliveryPrice: number;
  extraKgPrice: number;
  returnPrice: number;
  exchangePrice: number;
  maintenancePickupPrice?: number;
  maintenanceReturnPrice?: number;
  cashCollectionPrice: number;
  returnToSenderPrice: number;
  useParentFees?: boolean; 
  active?: boolean; 
  paidReturnPrice?: number;
  cancelReturnPrice?: number;
  partialReturnPrice?: number;
  deliveryDays?: string;
}

export interface ShippingOption {
  id: string;
  label: string;      
  details: string;    
  deliveryPrice: number;      
  extraKgPrice: number; 
  returnPrice: number;   
  exchangePrice: number;      
  maintenancePickupPrice?: number;
  maintenanceReturnPrice?: number;
  cashCollectionPrice: number;
  returnToSenderPrice: number;
  baseWeight: number;
  cities?: CityOption[];
  active?: boolean; 
  paidReturnPrice?: number;
  cancelReturnPrice?: number;
  partialReturnPrice?: number;
  deliveryDays?: string;
}

export interface PlatformIntegration {
  platform: 'none' | 'wuilt';
  apiKey: string;
  shopId?: string;
  shopUrl?: string;
}

export interface ShippingCarrierIntegration {
  id: string;
  provider: 'bosta' | 'mylerz' | 'aramex_api' | 'turbo';
  apiKey: string;
  apiSecret?: string;
  accountNumber?: string;
  isConnected: boolean;
}

export interface BostaBusinessPickupLocation {
  _id?: string;
  id?: string;
  locationName: string;
  districtId?: string;
  districtName?: string;
  city?: string;
  firstLine: string;
  buildingNumber?: string;
  floor?: string;
  apartment?: string;
  secondLine?: string;
  isDefault?: boolean;
}

export interface BostaPickupAddress {
  firstLine: string;
  city: string;
  zone?: string;
  district?: string;
  districtId?: string;
  zoneId?: string;
  buildingNumber?: string;
  floor?: string;
  apartment?: string;
  secondLine?: string;
  locationName?: string;
  businessLocationId?: string;
  contactPersonName?: string;
  contactPersonPhone?: string;
}

export interface BostaConfig {
  apiKey: string;
  businessId?: string;
  isActive: boolean;
  environment?: 'production' | 'staging';
  pickupAddress?: BostaPickupAddress;
  businessLocations?: BostaBusinessPickupLocation[];
  defaultBusinessLocationId?: string;
  defaultReturnLocationId?: string;
  defaultPackageType?: 'Parcel' | 'Document' | 'Bulky' | 'Normal' | 'Light Bulky' | 'Heavy Bulky';
  defaultPackageSize?: 'SMALL' | 'MEDIUM' | 'LARGE' | 'Light Bulky' | 'Heavy Bulky';
  defaultAwbType?: 'A4' | 'A6';
  defaultAwbLang?: 'ar' | 'en';
  allowToOpenPackage?: boolean;
  autoSendOnConfirm?: boolean;
  autoSendWhatsAppTracking?: boolean;
  whatsappTrackingMessageTemplate?: string;
  autoSendWhatsAppOnStatusChange?: boolean;
  whatsappStatusMessageTemplate?: string;
  webhookUrl?: string;
  lastSync?: string;
  connectedUserName?: string;
  connectedUserEmail?: string;
  connectedUserPhone?: string;
}

export interface TurboConfig {
  apiKey: string;
  apiToken?: string;
  authenticationKey?: string;
  mainClientCode?: number;
  secondClient?: string;
  apiFollowupPhone?: string;
  accountEmail?: string;
  accountPassword?: string;
  isActive: boolean;
  environment?: 'production' | 'staging';
  pickupAddress?: string;
  pickupPhone?: string;
  allowOpenPackage?: boolean;
  autoSendOnConfirm?: boolean;
  defaultReturnAmount?: number;
  webhookUrl?: string;
  webhookToken?: string;
  lastSync?: string;
  connectedUserName?: string;
  connectedUserEmail?: string;
  connectedUserPhone?: string;
}

export interface BostaPickupRequest {
  id: string;
  bostaPickupId?: string;
  scheduledDate: string;
  scheduledSlot?: string;
  status: string;
  ordersCount: number;
  orderIds?: string[];
  pickupAddress: string;
  contactPhone: string;
  contactName?: string;
  notes?: string;
  createdAt: string;
}

export interface Warehouse {
  id: string;
  name: string;
  location?: string;
  isDefault?: boolean;
  type?: 'central' | 'pos' | 'backup' | 'logistics'; // نوع الفرع/المستودع
  managerName?: string; // مسؤول أو مدير الفرع
  phone?: string; // رقم هاتف الفرع
  capacity?: number; // السعة التخزينية القصوى
  notes?: string;
  coveredGovernorates?: string[]; // المحافظات المغطاة للتوجيه الجغرافي الذكي
}

export interface ProductVariant {
  id: string;
  sku: string;
  price: number;
  costPrice?: number;
  weight?: number;
  stock?: number;
  stockQuantity: number | null;
  warehouseStock?: Record<string, number>; // New field for multi-warehouse stock
  lastAudited?: Record<string, string>; // New field for audit tracking per warehouse
  minStockLevel?: number; // Minimum stock before alert
  expiryDate?: string; // Product expiry date
  image?: string; // Specific image URL for this variant (color/style)
  options: { [optionName: string]: string };
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  slug?: string;
  description?: string;
  price: number;
  weight: number;
  costPrice: number;
  thumbnail?: string;
  images?: string[];
  inStock?: boolean;
  stock?: number;
  stockQuantity: number | null;
  warehouseStock?: Record<string, number>; // New field for multi-warehouse stock
  collectionId?: string; 
  category?: string;
  hasVariants: boolean;
  options: string[];
  variants: ProductVariant[];
  lastAudited?: Record<string, string>; // New field for audit tracking per warehouse
  minStockLevel?: number; // Minimum stock before alert
  expiryDate?: string; // Product expiry date
  
  // For profit calculation
  useProfitPercentage?: boolean; // Legacy, will be phased out
  profitPercentage?: number;     // For margin mode

  profitMode?: 'manual' | 'margin' | 'commission';
  basePrice?: number;
  commissionPercentage?: number;
  stockThreshold?: number;
  merchantId?: string;
}

export type TransactionCategory = 'shipping' | 'insurance' | 'inspection' | 'collection' | 'cod' | 'return' | 'manual_deposit' | 'manual_withdrawal' | 'expense_ads' | 'expense_salary' | 'expense_hr' | 'expense_rent' | 'expense_packaging' | 'expense_shipping_fees' | 'expense_other' | 'inventory_purchase' | 'capital_addition' | 'profit_withdrawal' | 'loan' | 'repayment' | 'wallet_charge' | 'wallet_withdrawal' | 'withdrawal_fee' | 'partner_supply' | 'supplier_payment' | 'supply_purchase' | 'supply_deposit' | 'supply_funding' | 'supply_expense_shipping' | 'supply_expense_other' | 'pos_digital' | 'pos_cash' | 'vat' | 'treasury_sync' | 'shipping_compensation' | 'compensation' | 'charge';

export type WithdrawStatus = 'pending' | 'accepted' | 'rejected' | 'processing';

export interface WithdrawRequest {
  id: string;
  amount: number;
  date: string;
  status: WithdrawStatus;
  method: 'bank' | 'wallet' | 'instapay' | 'treasury';
  details: string; // JSON or formatted string of bank/wallet details
  fee: number;
  netAmount: number;
  isSameDay?: boolean;
}

export interface BankAccount {
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  iban?: string;
}

export interface WalletSettings {
  preferredWithdrawMethod: 'bank' | 'wallet' | 'instapay' | 'treasury';
  bankAccount?: BankAccount;
  mobileWallet?: string;
  instapayAddress?: string;
  autoWithdrawal: boolean;
  autoWithdrawalDays: ('Sunday' | 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday')[];
  minAutoWithdrawAmount: number;
}

export interface Transaction {
  id: string;
  type: 'إيداع' | 'سحب';
  amount: number;
  date: string;
  note: string;
  category?: TransactionCategory;
  status: 'pending' | 'completed' | 'cancelled';
  fees?: number;
  orderId?: string;
  orderNumber?: string;
  service?: string;
  attachmentUrl?: string; // Image/receipt of the transaction/expense
  attachments?: string[]; // Multiple receipt/invoice images
  details?: any; // Keep details for generic extra data
}

export interface Wallet {
  id?: string;
  data?: any;
  balance: number;
  supplyBalance?: number; // deprecated // Added supplyBalance for inventory funding
  transactions: Transaction[];
  withdrawRequests?: WithdrawRequest[];
  settings?: WalletSettings;
}

export interface CompanyFees {
  insuranceFeePercent: number;
  insuranceMinAmount?: number;
  insuranceMaxAmount?: number;
  inspectionFee: number;
  returnShippingFee: number;
  useCustomFees: boolean;
  defaultInspectionActive: boolean; 
  enableReturnAfter: boolean;    
  enableReturnWithout: boolean;  
  enableExchange: boolean;       
  enableMaintenancePickup?: boolean;
  enableMaintenanceReturn?: boolean;
  enableReturn?: boolean;
  enablePartialDelivery?: boolean;
  enableCashCollection?: boolean;
  enableReturnToSender?: boolean;
  enableFixedReturn: boolean;    
  baseWeight?: number;
  enableCodFees: boolean;
  codThreshold: number;
  codFeeRate: number;
  codTaxRate: number;
  postCollectionReturnRefundsProductPrice: boolean;
  insuranceBasis?: 'cost' | 'price' | 'total' | 'base';
  shippingVatRate?: number;
  vatBasis?: 'shipping_only' | 'shipping_and_insurance' | 'shipping_insurance_and_cod'; // New field
  enableVat?: boolean; // Toggle to completely turn off/on VAT for this company
  enableFlexShip?: boolean;
  flexShipFee?: number;
  flexShipCompanyFee?: number;
}

export const PERMISSIONS = {
  // 1. Dashboard & Reports
  DASHBOARD_VIEW: 'DASHBOARD_VIEW',
  REPORTS_VIEW: 'REPORTS_VIEW',
  
  // 2. Orders & Returns
  ORDERS_VIEW: 'ORDERS_VIEW',
  ORDERS_MANAGE: 'ORDERS_MANAGE',
  RETURNS_MANAGE: 'RETURNS_MANAGE',
  
  // 3. POS
  POS_VIEW: 'POS_VIEW',
  POS_MANAGE: 'POS_MANAGE',
  
  // 4. Products & Inventory
  PRODUCTS_VIEW: 'PRODUCTS_VIEW',
  PRODUCTS_MANAGE: 'PRODUCTS_MANAGE',
  INVENTORY_MANAGE: 'INVENTORY_MANAGE',
  COLLECTIONS_MANAGE: 'COLLECTIONS_MANAGE',
  
  // 5. Customers & Marketing
  CUSTOMERS_VIEW: 'CUSTOMERS_VIEW',
  CUSTOMERS_MANAGE: 'CUSTOMERS_MANAGE',
  MARKETING_MANAGE: 'MARKETING_MANAGE',
  DISCOUNTS_MANAGE: 'DISCOUNTS_MANAGE',
  REVIEWS_MANAGE: 'REVIEWS_MANAGE',

  // 6. Finances & Treasury
  WALLET_VIEW: 'WALLET_VIEW',
  WALLET_MANAGE: 'WALLET_MANAGE',
  CASH_MANAGE: 'CASH_MANAGE',
  EXPENSES_MANAGE: 'EXPENSES_MANAGE',
  
  // 7. Store Settings & Team
  SETTINGS_VIEW: 'SETTINGS_VIEW',
  SETTINGS_MANAGE: 'SETTINGS_MANAGE',
  APPS_MANAGE: 'APPS_MANAGE',
  STOREFRONT_MANAGE: 'STOREFRONT_MANAGE',
  TEAM_VIEW: 'TEAM_VIEW',
  TEAM_MANAGE: 'TEAM_MANAGE'
} as const;

export type Permission = keyof typeof PERMISSIONS;

export interface Employee {
  id: string;
  name: string;
  email: string;
  phone?: string;
  permissions: Permission[];
  status?: 'active' | 'invited' | 'pending';
  isPartner?: boolean;
  partnerId?: string;
  role?: string;
  commissionType?: 'fixed' | 'percentage';
  commissionValue?: number;
  balance?: number;
  commissionTransactions?: Array<{
    id: string;
    amount: number;
    type: 'deposit' | 'reversal';
    orderId: string;
    orderNumber: string;
    date: string;
    status: string;
  }>;
}

export interface StoreSection {
  id: string;
  type: 'hero' | 'products' | 'about_us';
  enabled: boolean;
}

export interface Banner {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  buttonText?: string;
  link?: string;
}

export interface StoreCustomization {
  logoUrl: string;
  faviconUrl: string;
  logoSize: 'sm' | 'md' | 'lg';
  banners: Banner[];
  footerText: string;
  primaryColor: string;
  backgroundColor: string;
  textColor: string;
  fontFamily: 'Cairo' | 'Readex Pro' | 'Tajawal';
  headingFontWeight: 'font-bold' | 'font-black';
  bodyFontSize: 'text-sm' | 'text-base' | 'text-lg';
  announcementBarText: string;
  isAnnouncementBarVisible: boolean;
  socialLinks: {
    facebook: string;
    instagram: string;
    x: string;
    tiktok: string;
  };
  pageSections: StoreSection[];
  buttonBorderRadius: 'rounded-none' | 'rounded-md' | 'rounded-lg' | 'rounded-full';
  cardStyle: 'default' | 'elevated' | 'outlined';
  productColumnsDesktop: 2 | 3 | 4 | 5;
  headerStyle?: 'floating' | 'classic' | 'minimal' | 'luxury';
  footerStyle?: 'simple' | 'multi-column' | 'glass';
  tabStyle?: 'pills' | 'underline' | 'sidebar' | 'bento';
  cardHoverEffect?: 'scale' | 'glow' | 'shadow' | 'none';
  cardInfoAlignment?: 'right' | 'center' | 'left';
  cardShadowSize?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  // --- New SaaS style fields for high-fidelity controls ---
  navigationLinks?: { label: string; url: string }[];
  aboutUs?: {
    enabled: boolean;
    title: string;
    subtitle: string;
    content: string;
    imageUrl?: string;
  };
  contactInfo?: {
    phone: string;
    whatsapp: string;
    email: string;
    address: string;
    workHours: string;
  };
  checkoutFieldsOptions?: {
    fullName: { show: boolean; required: boolean };
    phone: { show: boolean; required: boolean };
    address: { show: boolean; required: boolean };
    email: { show: boolean; required: boolean };
    notes: { show: boolean; required: boolean };
  };
  successScreen?: {
    title: string;
    description: string;
    buttonText: string;
  };
  emailNotifications?: {
    customerEnabled: boolean;
    adminEnabled: boolean;
    templateType: 'minimal' | 'dark' | 'luxury';
  };
  socialLinksExtended?: {
    facebook: string;
    instagram: string;
    x: string;
    tiktok: string;
    youtube: string;
    snapchat: string;
    pinterest: string;
  };
}

export interface DiscountCode {
  id: string;
  code: string;
  type: 'fixed' | 'percentage';
  value: number;
  active: boolean;
  usageCount: number;
}

export interface AbandonedCart {
  id: string;
  customerName: string;
  customerPhone: string;
  date: string;
  items: OrderItem[];
  totalValue: number;
}

export interface CustomerProfile {
  id: string; 
  name: string;
  phone: string;
  phone2?: string;
  address: string;
  totalOrders: number;
  successfulOrders: number;
  returnedOrders: number;
  totalSpent: number; 
  lastOrderDate: string;
  firstOrderDate: string;
  averageOrderValue: number;
  loyaltyPoints: number;
  notes?: string;
  governorate?: string;
  city?: string;
  shippingFee?: number;
  debtBalance?: number;
  debtHistory?: Array<{
    amount: number;
    type: 'increase' | 'decrease';
    reason: string;
    date: string;
    orderId?: string;
  }>;
  tags?: string[];
  email?: string;
  customerSegment?: string;
}

export interface Review {
  id: string;
  productId: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface PartnerAllowedReports {
  salesAndRevenue?: boolean; // تقرير المبيعات والإيرادات
  topSellingProducts?: boolean; // تقرير المنتجات الأكثر مبيعاً والأرباح
  inventoryValuation?: boolean; // تقرير قيمة المخزون ورصيد البضائع
  expensesBreakdown?: boolean; // تقرير المصروفات والتكاليف التشغيلية
  shippingPerformance?: boolean; // تقرير نسب الشحن والتسليم والمرتجعات
  profitDistributions?: boolean; // تقرير دورات وتوزيعات الأرباح
  cashFlowSummary?: boolean; // تقرير التدفقات النقدية والخزائن
}

export interface PartnerPortalPermissions {
  canViewOverview?: boolean; // المركز المالي والأرصدة
  canViewOrdersTab?: boolean; // تبويب أوردراتي وحركة الشحنات للموكل
  canViewTransparencyTab?: boolean; // تبويب تقرير الشفافية وحركة البضاعة
  canViewCapital?: boolean; // رؤية رأس المال
  canViewProfits?: boolean; // رؤية الأرباح المحققة والمسحوبات
  canViewCustody?: boolean; // رؤية العهد النقدية
  canViewWithdrawalsTab?: boolean; // تبويب طلبات السحب والمصروفات
  canRequestWithdrawal?: boolean; // تقديم طلب سحب أرباح
  canRequestExpense?: boolean; // تقديم طلب تسوية مصروف أو سلفة
  canViewStatementTab?: boolean; // تبويب كشف الحساب والعمليات
  canPrintStatement?: boolean; // طباعة وتصدير كشف الحساب
  canViewPerformanceTab?: boolean; // تبويب أداء المتجر والشراكة
  canViewStoreSales?: boolean; // رؤية إجمالي مبيعات وإيرادات المتجر
  canViewStoreProfits?: boolean; // رؤية صافي أرباح المتجر
  canViewReportsTab?: boolean; // تبويب تقارير الشراكة المخصصة
  allowedReports?: PartnerAllowedReports; // التقارير المحددة المسموح برؤيتها
  canViewProfileTab?: boolean; // تبويب الملف الشخصي
  canEditProfile?: boolean; // تعديل البيانات الشخصية
  canEditPayoutAccounts?: boolean; // تعديل محافظ وحسابات الصرف
  canChangeSecurity?: boolean; // تغيير رمز PIN وكلمة المرور
}

export interface BiometricCredentialRecord {
  id: string; // Base64 or string ID of credential
  rawId?: string;
  name: string; // Device friendly name, e.g. "Apple Face ID", "Windows Hello", "Android Biometric"
  createdAt: string;
  lastUsedAt?: string;
  transports?: string[];
  algorithm?: string;
}

export interface Partner {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  notes?: string;
  balance: number;
  profitRatio: number; // Added profit ratio
  capital?: number; // رأس المال / الاستثمار
  initialCapital?: number;
  passcode?: string; // رمز المرور لبوابة الشركاء
  password?: string; // كلمة المرور الآمنة
  permissions?: Permission[]; // صلاحيات الموظفين الممنوحة للشريك
  portalPermissions?: PartnerPortalPermissions; // صلاحيات التحكم في لوحة وبوابة الشريك
  role?: string; // المسمى أو الدور الوظيفي للشريك
  avatar?: string; // رابط الصورة الشخصية
  address?: string; // عنوان الشريك
  nationalId?: string; // الرقم القومي
  payoutAccounts?: {
    walletPhone?: string; // رقم محفظة الكاش
    instaPayHandle?: string; // حساب إنستاباي
    bankName?: string; // اسم البنك
    bankAccount?: string; // رقم الحساب أو الآيبان
    beneficiaryName?: string; // اسم المستفيد
  };
  isEmailVerified?: boolean; // هل تم تأكيد البريد الإلكتروني بكود
  emailVerifiedAt?: string; // تاريخ تأكيد البريد
  lastLoginAt?: string; // تاريخ آخر دخول
  employeeId?: string; // ربط بحساب الموظف
  requireEmailOtp?: boolean; // فرض الدخول برمز تحقق OTP على البريد الإلكتروني
  transactions?: any[];
  biometricCredentials?: BiometricCredentialRecord[]; // بصمات الأجهزة المسجلة (WebAuthn / Passkeys)
  allowBiometricAuth?: boolean; // تفعيل الدخول الحيوي بالبصمة
  subscriptionPlan?: MerchantSubscriptionConfig; // باقة العمل الذاتي للمتجر/الأوردرات
  managerPlan?: MerchantManagerConfig; // باقة المدير المخصص للأوردرات
  pendingPlanRequest?: MerchantPlanChangeRequest | null; // طلب تغيير باقة أو تسعير باقة مخصصة معلق
  planCyclesHistory?: MerchantPlanCycleRecord[]; // سجل دورات الباقات السابقة لتأمين حسابات الأوردرات
}

export type BillingCycleType = 'monthly' | 'quarterly' | 'semi_annual' | 'annual';
export type SelfServicePlanId = 'free' | 'basic' | 'pro' | 'business' | 'ultimate';
export type DedicatedManagerPlanId = 'none' | 'per_order_20' | 'monthly_1000' | 'monthly_700' | 'custom_manager';

export interface MerchantPlanChangeRequest {
  id: string;
  requestedAt: string;
  targetMode: 'self_service' | 'manager';
  targetSelfPlanId?: SelfServicePlanId;
  targetManagerPlanId?: DedicatedManagerPlanId;
  targetPlanId?: string; // Alias for targetSelfPlanId or targetManagerPlanId used in UI
  billingCycle: BillingCycleType;
  planNameAr: string;
  targetPlanNameAr?: string;
  upfrontCost?: number;
  calculatedAmount?: number;
  ordersLimit?: number | null;
  // حقول طلب الباقة المخصصة
  requestedOrdersTarget?: number;
  requestedCustomQuota?: number;
  requestedPrepaidQuota?: boolean;
  requestedCustomBillingPreference?: string;
  merchantNotes?: string;
  // حقول تسعير الإدارة للباقة المخصصة
  quotedOrderFee?: number;
  quotedOrdersTarget?: number;
  quotedTotalUpfront?: number;
  adminNotes?: string;
  quotedAt?: string;
  status:
    | 'pending_admin_approval'
    | 'pending_admin_quote'
    | 'quoted_waiting_merchant'
    | 'approved'
    | 'rejected'
    | 'cancelled';
}

export interface MerchantPlanCycleRecord {
  cycleId: string;
  mode: 'self_service' | 'manager';
  planId: string;
  planName?: string;
  planNameAr?: string;
  billingCycle?: BillingCycleType;
  orderFee?: number;
  totalPaidAmount?: number;
  paidAmount?: number; // Alias for totalPaidAmount
  ordersLimit?: number | null;
  ordersUsedCount?: number;
  usedOrders?: number; // Alias for ordersUsedCount
  quotaOrders?: number;
  startDate?: string;
  activatedAt?: string;
  endedAt: string;
  endReason: 'admin_approved_switch' | 'merchant_accepted_quote' | 'admin_direct_update' | 'refunded' | 'switched_mode' | 'upgraded';
}

export interface MerchantSubscriptionConfig {
  cycleId?: string;
  planId: SelfServicePlanId;
  planName?: string;
  planNameAr?: string;
  billingCycle?: BillingCycleType;
  monthlyPrice?: number;
  totalPaidAmount?: number;
  paidAmount?: number;
  pricePerMonth?: number;
  ordersLimit?: number | null; // null = غير محدود
  monthlyOrderLimit?: number;
  unlimitedOrders?: boolean;
  startDate?: string;
  endDate?: string;
  expiresAt?: string; // Alias for endDate
  activatedAt?: string;
  status: 'active' | 'inactive' | 'pending_refund' | 'refunded' | 'expired' | 'cancelled';
  refundRequestedAt?: string;
  refundRequestId?: string;
  refundedAmount?: number;
}

export interface MerchantManagerConfig {
  cycleId?: string;
  planId: DedicatedManagerPlanId;
  planName?: string;
  planNameAr?: string;
  billingCycle?: BillingCycleType;
  orderFee?: number; // e.g. 20 EGP per order or custom rate set by admin
  customOrderFee?: number; // السعر المخصص للأوردر المعتمد من الإدارة
  monthlyFee?: number; // e.g. 1000 EGP/month or custom bundle
  includedOrdersQuota?: number; // e.g. 50 orders quota per cycle for monthly_1000
  extraOrderFee?: number; // e.g. 20 EGP per order beyond quota
  totalPaidAmount?: number;
  totalPrepaidAmount?: number;
  usedOrdersInCycle?: number;
  customOrdersTarget?: number; // عدد الأوردرات المخصص
  customOrderQuota?: number;
  customPrepaidQuota?: boolean; // هل تم دفع حصة الأوردرات مسبقاً أم خصم مع كل أوردر
  startDate?: string;
  endDate?: string;
  expiresAt?: string; // Alias for endDate
  activatedAt?: string;
  enabled?: boolean;
  notes?: string;
  status: 'active' | 'inactive' | 'pending_refund' | 'refunded' | 'cancelled';
  refundRequestedAt?: string;
  refundRequestId?: string;
  refundedAmount?: number;
}

export interface PartnerTransaction {
  id: string;
  partnerId: string;
  partnerName?: string;
  type: 'loan' | 'capital_addition' | 'profit_withdrawal' | 'repayment' | 'supply_funding' | 'profit_distribution' | 'shipping_funding' | 'customer_advance' | 'expense_coverage' | 'expense_repayment' | 'pos_collection' | 'internal_transfer_out' | 'internal_transfer_in' | 'wallet_withdrawal' | 'personal_withdrawal' | string;
  amount: number;
  date: string;
  note?: string;
  notes?: string;
  description?: string;
  category?: string;
  treasuryAccountId?: string;
  orderId?: string;
  orderNumber?: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address?: string;
  notes?: string;
  balance?: number; // Zero or Positive means debt to them
  category?: 'raw_materials' | 'ready_products' | 'logistics' | 'general'; // تصنيف المورد
  creditLimit?: number; // الحد الائتماني
  taxNumber?: string; // الرقم الضريبي
  bankAccount?: string; // الآيبان أو الحساب البنكي
  rating?: 1 | 2 | 3 | 4 | 5; // تقييم المورد
  tier?: 'vip' | 'gold' | 'standard'; // مستوى الشراكة
  defaultMarketingFeePerOrder?: number; // مصاريف الإعلانات الافتراضية لكل أوردر
  email?: string;
  passcode?: string;
  password?: string;
  payoutAccounts?: {
    walletPhone?: string;
    instaPayHandle?: string;
    bankName?: string;
    bankAccount?: string;
    beneficiaryName?: string;
  };
  transactions?: MerchantTransaction[];
  isMerchantPortalActive?: boolean;
  subscriptionPlan?: MerchantSubscriptionConfig;
  managerPlan?: MerchantManagerConfig;
  pendingPlanRequest?: MerchantPlanChangeRequest | null;
  planCyclesHistory?: MerchantPlanCycleRecord[];
}

export interface MerchantTransaction {
  id: string;
  merchantId: string;
  merchantName: string;
  date: string;
  type: 'order_delivered' | 'order_returned' | 'withdrawal' | 'adjustment' | 'lump_sum_deduction' | 'subscription_charge' | 'subscription_refund' | 'manager_order_fee' | 'wallet_topup' | 'order_profit';
  amount: number; // Positive = Credit (Merchant gets money), Negative = Debit
  balanceAfter: number;
  notes: string;
  referenceId?: string; // Order ID or Settlement ID or Request ID
  transferReference?: string; // رقم المرجع البنكي / التحويل
  receiptImage?: string; // صورة إيصال التحويل المرفقة
  performedBy?: string;
}

export interface SupplyOrderItem {
  productId: string;
  variantId?: string;
  name?: string;
  quantity: number;
  bonusQuantity?: number;
  cost: number;
  discountValue?: number;
  discountType?: 'amount' | 'percentage';
  profitMode?: 'manual' | 'margin' | 'commission';
  profitPercentage?: number;
  basePrice?: number;
  commissionPercentage?: number;
  sellingPrice?: number;
  updateCatalogPrice?: boolean;
  orderedQuantity?: number;
  receivedQuantity?: number;
  damagedQuantity?: number;
  expiryDate?: string;
  batchNumber?: string;
  landedCost?: number;
  returnedQuantity?: number;
  sku?: string;
  isReturn?: boolean;
  warehouseId?: string;
}

export interface PartnerPayment {
  partnerId: string;
  amount: number;
}

export interface TreasuryPayment {
  treasuryAccountId: string;
  amount: number;
}

export interface SupplyOrder {
  id: string;
  supplierId: string;
  date: string;
  orderNumber?: string;
  referenceNumber?: string;
  items: SupplyOrderItem[];
  totalCost: number;
  status: 'completed' | 'draft' | 'cancelled';
  partnerId?: string;
  partnerPayments?: PartnerPayment[]; // New field for multiple partners
  treasuryPayments?: TreasuryPayment[]; // New field for multiple treasury/custody accounts
  custodyPayments?: { cashHolderId: string, amount: number }[]; // New field for custody payments
  notes?: string;
  paymentMethod?: 'cash' | 'credit' | 'partner' | 'supply_wallet' | 'treasury' | 'custody';
  shippingFees?: number;
  shippingFeesNote?: string;
  shippingFeesPaymentMethod?: 'with_order' | 'wallet';
  otherFees?: number;
  taxRate?: number;
  taxAmount?: number;
  grandTotal?: number;
  attachmentUrl?: string;
  attachments?: string[]; // Multiple invoice/delivery receipt images
  treasuryAccountId?: string;
  warehouseId?: string; // New field for warehouse allocation
  recordExpensesFormally?: boolean;
  distributeExpensesEqually?: boolean;
  costUpdateMethod?: 'last_purchase' | 'weighted_average';
  otherFeesNote?: string;
  expensePaidBy?: string;
  isPaid?: boolean;
}

export interface ActivityLog {
  id: string;
  user: string;
  action: string;
  details: string;
  date: string;
  timestamp: number;
}

export interface CustomPage {
  id: string;
  title: string;
  slug: string;
  content: string;
  isActive: boolean;
}

export interface PaymentMethod {
  id: string;
  name: string; 
  details: string;
  instructions: string;
  logoUrl?: string;
  active: boolean;
  type: 'cod' | 'manual';
}

export interface GlobalOption {
  id: string;
  name: string;
  values: string[];
}

export interface Collection {
  id: string;
  name: string;
  image?: string;
  description?: string;
}

export interface WhatsAppTemplate {
  id: string;
  label: string;
  text: string;
  footer?: string;
  buttons?: string[];
}

export interface WhatsAppConfig {
  apiUrl: string;
  instanceId: string;
  token: string;
  isActive: boolean;
  autoSendOnStatusChange: boolean;
  providerType?: 'ultramsg' | 'direct_web' | 'local_gateway' | 'meta_cloud';
  phoneNumberId?: string;
  accessToken?: string;
  wabaId?: string;
  metaAppId?: string;
  metaAppSecret?: string;
  metaConfigId?: string;
  metaVerifyToken?: string;
  metaTemplateName?: string;
  metaTemplateLanguage?: string;
  verifiedName?: string;
  qualityRating?: string;
  metaPhone?: string;
  isConnected?: boolean;
  sessionPhone?: string;
  confirmationTemplateId?: string;
  shippingTemplateId?: string;
  deliveryTemplateId?: string;
}

export interface CallScript {
  id: string;
  title: string;
  text: string;
}

export interface EmployeeDashboardSettings {
  showAssignedOrders: boolean;
  showOrderStatuses: OrderStatus[];
  showFollowUpReminders: boolean;
}

export interface WebhookIntegration {
  id: string;
  storeUrl: string;
  webhookUrl: string;
  secretKey: string;
  isActive: boolean;
}

export type WebhookEventType = 
  | 'cart.abandoned'
  | 'cart.product_added'
  | 'checkout.started'
  | 'customer.created'
  | 'customer.updated'
  | 'order.cancelled'
  | 'order.completed'
  | 'order.updated'
  | 'product.created'
  | 'product.deleted'
  | 'product.updated'
  | 'shipment.updated';

export interface WebhookSubscription {
  id: string;
  name?: string;
  event: WebhookEventType;
  format: 'JSON' | 'XML' | 'FORM';
  url: string;
  apiVersion: 'v1.0' | 'v2.0';
  secretKey?: string;
  isActive: boolean;
  createdAt: string;
  lastTriggeredAt?: string;
  lastStatusCode?: number;
  lastStatusText?: string;
  failedAttempts?: number;
}

export interface StaffMember {
  id: string;
  name: string;
  phone: string;
  email?: string;
  baseSalary: number;
  position: string;
  joinDate: string;
  active: boolean;
  notes?: string;
}

export interface PayrollTransaction {
  id: string;
  staffId: string;
  staffName: string;
  type: 'salary' | 'incentive' | 'deduction';
  amount: number;
  date: string;
  note?: string;
  walletTransactionId?: string;
  treasuryAccountId?: string;
}

export interface StaffAttendance {
  id: string;
  staffId: string;
  staffName: string;
  date: string; // YYYY-MM-DD
  checkIn?: string; // HH:MM
  checkOut?: string; // HH:MM
  status: 'present' | 'absent' | 'leave' | 'delay';
  delayMinutes?: number;
  note?: string;
}

export interface StaffLeave {
  id: string;
  staffId: string;
  staffName: string;
  startDate: string;
  endDate: string;
  type: 'annual' | 'sick' | 'casual' | 'unpaid';
  status: 'pending' | 'approved' | 'rejected';
  reason?: string;
  daysCount: number;
}

export interface StaffAdvance {
  id: string;
  staffId: string;
  staffName: string;
  amount: number;
  date: string;
  status: 'paid' | 'deducted' | 'pending';
  deductedInMonth?: string; // YYYY-MM
  note?: string;
}

export interface StaffDocument {
  id: string;
  staffId: string;
  staffName: string;
  docName: string;
  docType: 'contract' | 'id_card' | 'passport' | 'other';
  fileUrl?: string;
  expiryDate?: string; // YYYY-MM-DD
  notes?: string;
}

export interface AkkedIntegrationConfig {
  isActive: boolean;
  apiKey: string;
  defaultTemplateKey?: 'order_confirmation' | 'confirmed_reply' | 'cancelled_reply' | 'paid_order' | 'abandoned_cart';
  language?: 'ar' | 'en';
  autoSendOnNewOrder?: boolean;
  autoSendOnStatusChange?: boolean;
  autoSendOnCartAbandoned?: boolean;
  connectedSenderPhone?: string;
  connectedSenderStatus?: string;
  lastChecked?: string;
  lastDispatchResult?: {
    success: boolean;
    orderNumber?: string;
    timestamp: string;
    message: string;
    statusCode?: number;
  };
}

export interface MoneyHashMethodConfig {
  id: string; // e.g. 'cards', 'vodafone_cash', 'instapay', 'fawry', 'valu', 'tabby', 'tamara', 'meeza', 'apple_pay', 'souhoola', 'sympl', 'aman'
  name: string;
  category: 'card' | 'wallet' | 'bnpl' | 'kiosk' | 'instant_transfer';
  enabled: boolean;
  minAmount?: number;
  maxAmount?: number;
  icon?: string;
  description?: string;
}

export interface MoneyHashConfig {
  isActive: boolean;
  mode: 'test' | 'live';
  apiKey: string; // MoneyHash Secret API Key (mh_sec_...)
  publicApiKey?: string; // MoneyHash Public Key (mh_pub_...)
  accountKey?: string; // MoneyHash Account Key
  webhookSecret?: string;
  currency?: string; // e.g. 'EGP', 'SAR', 'AED', 'USD'
  selectedMethods: Record<string, boolean>; // e.g. { cards: true, vodafone_cash: true, instapay: true, fawry: true, valu: true, tabby: true, tamara: true, meeza: true, apple_pay: true }
  methodsConfig?: MoneyHashMethodConfig[];
  autoRedirectOnSuccess?: boolean;
  testModeNotes?: string;
}

export interface Settings {
  id?: string;
  storeName?: string;
  onRefresh?: () => void;
  partnerRequests?: any[];
  enforcePartnerOtp?: boolean; // إلزام الشركاء بالتحقق عبر رمز البريد OTP
  defaultWarehouseId?: string;
  data?: any; // For flexible local storage
  storeBranches?: any[];
  companyNames?: string[];
  enableGlobalFinancials: boolean; 
  akkedIntegration?: AkkedIntegrationConfig;
  moneyHashConfig?: MoneyHashConfig;
  webhookIntegrations?: WebhookIntegration[];
  storeWebhooks?: WebhookSubscription[];
  supabaseUrl?: string;
  supabaseAnonKey?: string;
  insuranceFeePercent: number;
  insuranceMinAmount?: number;
  insuranceMaxAmount?: number;
  enableInsurance: boolean; 
  inspectionFee: number;
  enableInspection: boolean; 
  returnShippingFee: number;
  enableReturnShipping: boolean; 
  enableFlexShip?: boolean;
  flexShipFee?: number;
  flexShipCompanyFee?: number;
  enableReturnAfterPrice: boolean;
  enableReturnWithoutPrice: boolean;
  enableExchangePrice: boolean;
  baseWeight?: number;
  products: Product[];
  shippingOptions: Record<string, ShippingOption[]>;
  activeCompanies: Record<string, boolean>;
  exchangeSupported: Record<string, boolean>;
  companySpecificFees: Record<string, CompanyFees>; 
  enableGlobalCod: boolean; 
  codThreshold: number;
  codFeeRate: number;
  codTaxRate: number;
  insuranceBasis?: 'cost' | 'price' | 'total' | 'base';
  shippingVatRate?: number;
  vatBasis?: 'shipping_only' | 'shipping_and_insurance' | 'shipping_insurance_and_cod';
  sku: string; 
  defaultProductPrice: number;
  enableDefaultPrice: boolean;
  enablePlatformIntegration: boolean;
  integration: PlatformIntegration;
  customAppDomain?: string; // <-- New field for SaaS integration
  customDomain?: string; // <-- New field for live store domain mapping
  domainStatus?: 'pending' | 'active' | 'error' | 'pending_validation';
  domainConflict?: boolean;
  domainDNSRecords?: any; 
  subdomain?: string; // <-- New field for subdomains
  isSubdomainFixed?: boolean; // <-- To pin/fix subdomain
  disableCustodySelling?: boolean; // <-- New field to disable personal custody and deposit to wallet instead
  platformConfigs?: Record<string, {
    appId: string;
    apiKey?: string;
    apiSecret?: string;
    shopUrl?: string;
    shopId?: string;
    lastSync?: string;
    lastProductSync?: string;
    isActive: boolean;
  }>;
  employees: Employee[];
  staffMembers?: StaffMember[]; 
  payrollTransactions?: PayrollTransaction[]; 
  staffAttendance?: StaffAttendance[];
  staffLeaves?: StaffLeave[];
  staffAdvances?: StaffAdvance[];
  staffDocuments?: StaffDocument[];
  customization: StoreCustomization;
  discountCodes: DiscountCode[];
  abandonedCarts: AbandonedCart[];
  reviews: Review[]; 
  shippingIntegrations: ShippingCarrierIntegration[];
  suppliers: Supplier[];
  supplyOrders: SupplyOrder[];
  activityLogs: ActivityLog[];
  customPages: CustomPage[];
  paymentMethods: PaymentMethod[];
  globalOptions: GlobalOption[]; 
  collections: Collection[];
  connectedPlatforms: string[]; // <-- Added connected platforms (e.g., 'wuilt', 'shopify')
  whatsappTemplates?: WhatsAppTemplate[];
  whatsappConfig?: WhatsAppConfig;
  bostaConfig?: BostaConfig;
  bostaPickups?: BostaPickupRequest[];
  turboConfig?: TurboConfig;
  callScripts?: CallScript[];
  employeeDashboardSettings?: EmployeeDashboardSettings;
  isPosEnabled?: boolean;
  wallet?: WalletSettings;
  hiddenWalletAmount?: number;
  enableHiddenWalletAmount?: boolean;
  hiddenWalletAmountLabel?: string;
  enableAutoClosingDifference?: boolean;
  partners?: Partner[];
  partnerTransactions?: PartnerTransaction[];

  merchantTransactions?: MerchantTransaction[];
  expenseCategories?: string[]; // Added expense categories
  warehouses?: Warehouse[]; // New field for stores/warehouses
  
  // Wallet & Payment Fees
  depositFeePercent?: number;
  withdrawalFeeType?: 'flat' | 'percent';
  withdrawalFeePercent?: number;
  withdrawalFlatFee?: number;
  sameDayWithdrawalFeeType?: 'flat' | 'percent';
  sameDayWithdrawalFeePercent?: number;
  sameDayWithdrawalFlatFee?: number;
  minWithdrawalFee?: number;
  enableWithdrawalFees?: boolean;
  enableInternalWithdrawalFees?: boolean;
  feeApplicableMethods?: string[]; // e.g. ['card', 'instapay', 'wallet']
  inventoryAudits?: InventoryAuditSession[];
  stockTransfers?: StockTransfer[];
  orderReturns?: OrderReturn[];
  purchaseReturns?: PurchaseReturn[];
  posSales?: POSSale[];
  cashHolders?: CashHolder[];
  cashHandovers?: CashHandover[];
  merchantSettlements?: MerchantSettlement[]; // كشوف تسوية الموكلين وأصحاب البضاعة
  auditAlertDays?: number; // Days between manual audits before alert
  confettiSettings?: {
    particleCount: number;
    gravity: number;
    spread: number;
    theme?: 'rainbow' | 'gold' | 'fireworks';
    enabledEvents?: string[]; // e.g. ['create_order', 'edit_order', 'complete_order', 'add_product', 'delete_product', 'wallet_withdraw', 'save_settings']
    soundVolume?: number; 
    enableSound?: boolean;
    soundType?: 'standard' | 'cash' | 'success' | 'trumpet' | 'fireworks';
    enableWelcomeSound?: boolean;
    welcomeSoundType?: 'standard' | 'cash' | 'success' | 'trumpet' | 'fireworks' | 'magic' | 'modern_shine' | 'pro_chime' | 'future_ui' | 'soft_welcome' | 'tech_rise';
    enableLoadingSound?: boolean;
  };
  insurancePackages?: InsurancePackage[];
  financialPeriods?: FinancialPeriod[];
  activePeriodStartDate?: string;
  activePeriodName?: string;
  openingInventoryValue?: number;
  storeApiKeys?: StoreApiKey[];
}

export type ApiKeyScope = 
  | 'orders:read'
  | 'orders:write'
  | 'orders:confirm'
  | 'orders:status'
  | 'orders:delete'
  | 'shipping:read'
  | 'shipping:write'
  | 'products:read'
  | 'products:write'
  | 'products:delete'
  | 'inventory:read'
  | 'inventory:write'
  | 'customers:read'
  | 'customers:write'
  | 'messages:send'
  | 'messages:read'
  | 'abandoned_carts:read'
  | 'abandoned_carts:recover'
  | 'reports:read'
  | 'webhooks:manage';

export interface StoreApiKey {
  id: string;
  name: string;
  key: string;
  maskedKey: string;
  permissions: ApiKeyScope[];
  createdAt: string;
  lastUsedAt?: string;
  expiresAt?: string;
  isActive: boolean;
  notes?: string;
}

export interface FinancialPeriod {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  closedAt: string;
  closedBy?: string;
  openingInventoryValue: number;
  closingInventoryValue: number;
  totalSales: number;
  cogs: number;
  grossProfit: number;
  totalExpenses: number;
  totalLosses: number;
  netProfit: number;
  distributedProfits: number;
  partnerBalancesSnapshot: Array<{
    partnerId: string;
    partnerName: string;
    profitRatio: number;
    capital: number;
    finalBalance: number;
    inventoryShare: number;
    adjustmentAmount: number; // Positive = deposited, Negative = withdrawn
    newOpeningCapital: number;
  }>;
  notes?: string;
  status: 'closed' | 'archived';
}

export interface InsurancePackage {
  id: string;
  name: string;
  type: 'flat' | 'percent';
  value: number;
  minAmount?: number;
  maxAmount?: number;
  description?: string;
}

export interface CashHolder {
  userId: string;
  userName: string;
  currentBalance: number;
  lastUpdated: string;
}

export interface CashHandover {
  id: string;
  fromUserId: string;
  fromUserName: string;
  toUserId: string;
  toUserName: string;
  amount: number;
  date: string;
  notes?: string;
  status: 'completed' | 'cancelled';
  type?: string;
  orderId?: string; // Explicitly link handover to an order
  details?: Record<string, any>;
}

export interface POSSaleItem {
  productId: string;
  variantId?: string;
  name: string;
  quantity: number;
  price: number;
  cost: number;
}

export interface POSSale {
  id: string;
  saleNumber: string;
  date: string;
  items: POSSaleItem[];
  totalAmount: number;
  paymentMethod: 'cash' | 'card' | 'wallet' | 'credit';
  warehouseId: string;
  customerPhone?: string;
  customerName?: string;
  customerAddress?: string;
  performedBy: string;
  cashHolderId?: string;
  cashHolderName?: string;
  notes?: string;
}

export interface PurchaseReturnItem {
  productId: string;
  variantId?: string;
  name: string;
  sku: string;
  quantity: number;
  costPrice: number;
}

export interface PurchaseReturn {
  id: string;
  returnNumber: string;
  supplierId: string;
  supplierName: string;
  date: string;
  items: PurchaseReturnItem[];
  totalRefundAmount: number;
  warehouseId: string;
  notes?: string;
  performedBy: string;
  attachments?: string[];
  status?: 'completed' | 'draft' | 'cancelled';
}

export interface StockTransferItem {
  productId: string;
  variantId?: string;
  name: string;
  sku: string;
  quantity: number;
}

export interface StockTransfer {
  id: string;
  transferNumber: string;
  date: string;
  sourceWarehouseId: string;
  destinationWarehouseId: string;
  items: StockTransferItem[];
  status: 'completed' | 'draft' | 'cancelled';
  notes?: string;
  performedBy: string;
  attachments?: string[];
  cancelledAt?: string;
  cancelledBy?: string;
  cancellationReason?: string;
}

export interface OrderReturnItem {
  productId: string;
  variantId?: string;
  name: string;
  quantity: number;
  price: number;
  cost: number;
}

export interface OrderReturn {
  id: string;
  returnNumber: string;
  orderId: string;
  orderNumber: string;
  date: string;
  items: OrderReturnItem[];
  totalRefund: number;
  reason: string;
  warehouseId: string;
  restockItems: boolean;
  status: 'completed' | 'cancelled';
  performedBy: string;
  notes?: string;
  attachments?: string[];
}

export type SharedAuditProtocol = 'standard' | 'blind' | 'fast' | 'periodic' | 'location' | 'double' | 'audit';

export interface SharedAuditPresence {
  userId: string;
  userName: string;
  status: 'online' | 'offline' | 'idle';
  activeProductId?: string;
  lastActive: string;
  deviceInfo?: string;
}

export interface SharedAuditAssignment {
  userId: string;
  userName: string;
  scopeType: 'warehouse' | 'zone' | 'rack' | 'shelf' | 'category';
  scopeValue: string;
}

export interface SharedAuditConflict {
  productId: string;
  variantId?: string;
  itemName: string;
  counts: {
    userId: string;
    userName: string;
    qty: number;
    timestamp: string;
  }[];
  status: 'pending' | 'resolved';
  resolvedQty?: number;
  resolvedBy?: string;
  resolvedAt?: string;
  resolutionReason?: string;
}

export interface SharedAuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userEmail?: string;
  action: string;
  details?: string;
  type: 'info' | 'warning' | 'error' | 'success' | 'protocol_change' | 'count_confirm' | 'submission' | 'access' | 'unlock' | 'conflict' | 'assignment' | 'presence';
  metadata?: any;
}

export interface SharedAuditItem {
  productId: string;
  variantId?: string;
  name: string;
  sku: string;
  barcode?: string;
  systemQty: number;
  actualQty?: number;
  isCounted: boolean;
  notes?: string;
  proofImage?: string;
  location?: string;
  zone?: string;
  rack?: string;
  shelf?: string;
  lockedBy?: string; // userId of person currently counting
  lockedAt?: string;
  lastCountedBy?: string;
}

export interface SharedAudit {
  id: string;
  title: string;
  warehouseId: string;
  warehouseName?: string;
  protocol: SharedAuditProtocol;
  isProtocolLocked: boolean;
  status: 'pending' | 'submitted' | 'approved' | 'rejected';
  createdAt: string;
  submittedAt?: string;
  passcode: string;
  managerName?: string;
  managerId?: string;
  items: SharedAuditItem[];
  logs: SharedAuditLogEntry[];
  assignments: SharedAuditAssignment[];
  presence: Record<string, SharedAuditPresence>;
  conflicts: SharedAuditConflict[];
  unlockReason?: string;
  unlockedBy?: string;
  unlockedAt?: string;
  notes?: string;
  signatureData?: string;
  isBlindCount?: boolean;
  workerSignature?: string;
  managerSignature?: string;
  rejectReason?: string;
  progress: number;
  accuracyScore?: number;
  healthScore?: number;
}

export interface InventoryAuditItemDiscrepancy {
  productId: string;
  variantId?: string;
  name: string;
  sku: string;
  systemQty: number;
  actualQty: number;
  variance: number;
  costPrice: number;
  varianceValue: number;
  method: 'correction' | 'scrap' | 'surplus' | 'gift' | 'missing'; // تصفية المخزن أو هالك أو بضاعة زائدة أو هدية أو مفقود
  notes?: string;
  zone?: string; // الرف أو القطاع
  proofImage?: string; // صورة إثبات التلف كـ Base64
}

export interface InventoryAuditSession {
  id: string;
  title: string;
  date: string;
  timestamp?: number;
  performedBy: string; // user name/email
  scope: 'all' | string; // 'all' or collection ID
  warehouseId?: string; // New field for warehouse-specific audits
  totalSystemQty: number;
  totalActualQty: number;
  totalVarianceQty: number;
  totalVarianceValue: number;
  totalItemsAudited: number;
  discrepancies: InventoryAuditItemDiscrepancy[];
  notes?: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  productName?: string;
  quantity: number;
  price: number;
  cost: number;
  weight: number;
  thumbnail?: string;
  image?: string;
  variantId?: string;
  variantName?: string;
  variantDescription?: string;
  description?: string;
  discountValue?: number;
  discountType?: 'amount' | 'percentage';
  discount?: number;
}

export interface ConfirmationLog {
  userId: string;
  userName: string;
  timestamp: string;
  action: string;
  notes?: string;
  duration?: number; // Call duration in seconds
}

export interface CallAttempt {
  id: string;
  userId: string;
  userName: string;
  timestamp: string;
  status: string;
  notes?: string;
  duration?: number;
}

export interface AdvancePaymentHistoryLog {
  id: string;
  timestamp: string;
  amount: number;
  userId: string;
  userName: string;
  recipientType?: 'partner' | 'treasury' | 'employee';
  recipientId?: string;
  recipientName?: string;
  recipientPhone?: string;
  senderDetails?: string;
  action: 'created' | 'updated' | 'reverted' | 'deleted';
  reason?: string;
}

export interface AuditLog {
  id: string;
  userId?: string;
  userName?: string;
  userEmail?: string;
  action?: string;
  details?: string;
  field?: string;
  oldValue?: string;
  newValue?: string;
  timestamp: string;
}

export interface MaintenancePart {
  id: string;
  productId?: string;
  name: string;
  cost: number;
  priceToCustomer: number;
  purchaseSource?: string;
  purchaseDate?: string;
  quantity?: number;
}

export interface MaintenanceRequest {
  id: string;
  storeId: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  governorate?: string;
  city?: string;
  
  itemDescription: string;
  itemSerial?: string;
  itemValue?: number;
  technicalReport?: string;
  initialProblemDescription: string;
  
  status: 'received' | 'inspecting' | 'waiting_for_parts' | 'in_repair' | 'ready' | 'delivered' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  
  parts: MaintenancePart[];
  laborCost: number;
  shippingFee?: number;
  totalCost: number;
  
  receivedDate: string;
  promisedDate?: string;
  deliveryDate?: string;
  
  technicianName?: string;
  internalNotes?: string;
  attachments?: string[];

  // Shipping details
  shippingCompany?: string;
  shippingTrackingNumber?: string;
  shippingCostToShop?: number;
  shippingCostToCustomer?: number;
  shippingPaymentMethod?: 'cash' | 'add_to_debt';
  shippingStatus?: 'none' | 'pickup_requested' | 'picked_up' | 'received_at_shop' | 'ready_for_shipping' | 'shipped_to_customer' | 'delivered' | 'returned_without_repair';

  // Payment & Financial integration
  paymentMethod?: 'cash' | 'add_to_debt' | 'wallet' | 'bank';
  paymentStatus?: 'unpaid' | 'paid';
  treasuryAccountId?: string;
  financialLogged?: boolean;

  // Commission details
  commissionType?: 'percentage' | 'fixed';
  commissionValue?: number;
  commissionAmount?: number;

  // Waybill and companion order
  waybillOrderId?: string;
  stockDeducted?: boolean;
}

export interface WhatsAppMessageLog {
  id: string;
  timestamp: string;
  type: 'confirmation' | 'cancellation' | 'shipping' | 'tracking' | 'custom' | 'incoming' | 'manual';
  direction: 'outgoing' | 'incoming';
  message: string;
  sender?: string;
  recipient?: string;
  status?: 'sent' | 'delivered' | 'read' | 'failed' | 'received';
  buttonSelected?: string;
  actionTaken?: string;
  rawPayload?: any;
}

export interface Order {
  id: string;
  createdAt?: string;
  confirmedAt?: string;
  updatedAt?: string;
  store_id?: string;
  source?: 'manual' | 'synced' | 'saas';
  platform?: string;
  orderNumber: string;
  referenceNumber?: string;
  waybillNumber?: string;
  trackingUrl?: string;
  lastShippingEventAt?: string;
  lastShippingEventKey?: string;
  whatsappLogs?: WhatsAppMessageLog[];
  shipmentTimeline?: Array<{
    carrier: string;
    externalStatus: string;
    externalCode?: string | number | null;
    internalStatus?: OrderStatus;
    reason?: string;
    eventAt: string;
    receivedAt: string;
    trackingNumber?: string;
    externalId?: string;
    metadata?: Record<string, unknown>;
    source: 'webhook' | 'polling' | 'manual';
    eventKey?: string;
  }>;
  bostaDeliveryId?: string;
  bostaTrackingNumber?: string;
  turboDeliveryId?: string;
  turboTrackingNumber?: string;
  bostaBusinessLocationId?: string;
  bostaReturnLocationId?: string;
  bostaDistrictId?: string;
  bostaZoneId?: string;
  bostaCityId?: string;
  platformOrderId?: string;
  date: string;
  shippingCompany: string;
  shippingArea: string;
  customerName: string;
  customerPhone: string;
  customerPhone2?: string;
  customerEmail?: string;
  customerAddress: string;
  city?: string;
  customerCity?: string;
  governorate?: string;
  buildingNumber?: string;
  floorNumber?: string;
  apartmentNumber?: string;
  shippingNotes?: string;
  subSenderName?: string;
  notes?: string;
  internalNotes?: string;
  storeName?: string;
  items: OrderItem[];
  shippingFee: number;
  adminFee?: number;
  tax?: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: string;
  moneyHashIntentId?: string;
  moneyHashPayUrl?: string;
  moneyHashMethod?: string;
  moneyHashStatus?: string;
  paymentReference?: string;
  paymentReceiptUrl?: string; // Customer transfer / payment receipt screenshot
  returnReceiptUrl?: string; // Waybill / defective product return image
  attachments?: string[]; // Multiple invoice/receipt files
  productName: string; 
  productPrice: number; 
  productCost: number; 
  totalPrice?: number;
  insuranceFee?: number;
  inspectionFee?: number;
  codFee?: number;
  vatValue?: number;
  shippingVatRate?: number;
  weight: number; 
  discount: number;
  discountAffectsInsurance?: boolean;
  totalAmountOverride?: number;
  totalAmountOverrideReason?: string;
  netRevenue?: number;
  includeInspectionFee?: boolean; 
  isInsured?: boolean; 
  inspectionFeeDeducted?: boolean;
  inspectionFeePaidByCustomer?: boolean;
  shippingAndInsuranceDeducted?: boolean;
  returnFeeDeducted?: boolean;
  collectionProcessed?: boolean;
  preparationStatus: PreparationStatus;
  classification?: string;
  redeemedPoints?: number;
  pointsDiscount?: number;
  loyaltyPointsAwarded?: boolean;
  stockDeducted?: boolean;
  orderType?: 'standard' | 'exchange' | 'maintenance';
  shipmentType?: 'delivery' | 'partial_delivery' | 'exchange' | 'return' | 'cash_collection' | 'maintenance_pickup' | 'maintenance_return';
  maintenanceCost?: number;
  maintenanceItemDescription?: string;
  merchantBrandName?: string;
  merchantBrandPhone?: string;
  externalProfitMarkup?: number;
  isExternalDropship?: boolean;
  maintenanceItemSerial?: string;
  maintenanceItemValue?: number;
  maintenanceTechnicalReport?: string;
  maintenanceStatus?: 'not_started' | 'received' | 'in_repair' | 'ready_to_ship' | 'delivered' | 'cancelled';
  vatOnStandardShipping?: boolean;
  originalOrderItems?: any[];
  exchangedItems?: any[];
  customerPaidOriginalShipping?: boolean;
  returnProductValue?: number;
  returnTrackingNumber?: string;
  payWithBostaPoints?: boolean;
  originalOrderId?: string;
  confirmationLogs?: ConfirmationLog[];
  cancellationReason?: string;
  followUpReminder?: string;
  compensationStatus?: 'none' | 'pending' | 'compensated' | 'rejected';
  compensationAmount?: number;
  compensationCourierName?: string;
  compensationNotes?: string;
  compensationDate?: string;
  compensationTreasuryAccountId?: string;
  quotationNumber?: string;
  quotationId?: string;
  lockedBy?: string;
  lockedByName?: string;
  lockedAt?: string;
  transferStatus?: 'pending' | 'accepted' | 'rejected';
  transferTo?: string;
  transferFrom?: string;
  assignedTo?: string;
  assignedToName?: string;
  auditLogs?: AuditLog[];
  callAttempts?: CallAttempt[];
  sentiment?: string;
  images?: string[];
  advancePayment?: number;
  advancePaymentPartnerId?: string;
  advancePaymentTreasuryId?: string;
  advancePaymentEmployeeId?: string;
  advancePaymentRecipientPhone?: string;
  advancePaymentSenderDetails?: string;
  advancePaymentHistory?: AdvancePaymentHistoryLog[];
  useProductsForShipment?: boolean;
  shipmentDescription?: string;
  shipmentQuantity?: number;
  customShipmentPrice?: number;
  useProductsForReturn?: boolean;
  returnProductId?: string;
  returnVariantId?: string;
  returnDescription?: string;
  returnQuantity?: number;
  returnImage?: string;
  enableFlexShip?: boolean;
  flexShipFee?: number;
  flexShipCompanyFee?: number;
  flexShipFeePaidByCustomer?: boolean;
  flexShipTransactionAdded?: boolean;
  warehouseId?: string; // New field for sales order fulfillment
  channel?: 'website' | 'pos';
  cashHolderId?: string;
  cashHolderName?: string;
  createdBy?: string;
  recordedAsDebt?: boolean;
  deferPaymentToReturn?: boolean;
  returnCashToCustomer?: boolean;
  cashToReturnAmount?: number;
  creditAmount?: number;
  exchangeDifference?: number;
  storeBranchId?: string;
  allowOpenShipment?: boolean;
  assignedEmployeeId?: string;
  deliveryNotes?: string;
  isManualShippingOverride?: boolean;
  insuranceBaseValue?: number;
  insurancePackageId?: string;
  insurancePackageName?: string;

  // Merchant / Dropship Client Fulfillment Fields
  merchantId?: string;             // معرّف العميل صاحب البضاعة (الموكل)
  merchantName?: string;           // اسم العميل صاحب البضاعة
  merchantItemCost?: number;       // تكلفة قطعة العميل (سعر البضاعة فقط)
  serviceFeePerOrder?: number;     // عمولتك ورسوم خدمتك المسطحة على الأوردر (مثلاً 50 ج.م/أوردر)
  marketingFeePerOrder?: number;   // مصاريف الإعلانات المخصصة للأوردر
  merchantSettlementMode?: 'fixed_fee' | 'profit_share' | 'wholesale'; // نظام المحاسبة (عمولة ثابتة أو نسبة من الربح أو سعر الجملة)
  merchantProfitSharePercent?: number; // نسبة الموكل من الربح (في حالة نظام المشاركة)
  settlementStatus?: 'pending' | 'settled' | 'unsettled'; // حالة التسوية المالية مع صاحب البضاعة
  settlementId?: string;           // رقم كشف التسوية المرتبط
  managerFeeDeducted?: boolean;    // هل تم خصم رسوم المدير المخصص لهذا الأوردر من محفظة الموكل
  managerFeeAmount?: number;       // قيمة رسوم المدير المخصص المخصومة على هذا الأوردر (مثلاً 20 ج.م أو السعر المخصص)
  planCycleId?: string;            // معرّف دورة الباقة وقت إنشاء الأوردر (لتثبيت الحسابات ومنع التداخل)
  planModeAtCreation?: 'self_service' | 'manager'; // نظام الباقة وقت إنشاء الأوردر
  planIdAtCreation?: string;       // نوع الباقة وقت إنشاء الأوردر
  planNameAtCreation?: string;     // اسم الباقة المثبت وقت إنشاء الأوردر
  lockedManagerFee?: number;       // رسوم المدير المخصص المثبتة على الأوردر وقت إنشائه
  quotaIncludedOrder?: boolean;    // هل هذا الأوردر مجاني مشمول ضمن كوتة الباقة (مثلاً أول 50 أوردر)
  cycleOrderNumber?: number;       // رقم تسلسل الأوردر داخل دورة الباقة
  quotaConsumedAt?: string;        // توقيت استهلاك الكوتة/الخصم لأول مرة (لمنع التكرار)
}

export interface MerchantSettlement {
  id: string;
  settlementNumber: string;         // رقم كشف التسوية (SETT-00001)
  merchantId: string;               // معرّف صاحب البضاعة
  merchantName: string;             // اسم صاحب البضاعة
  date: string;                     // تاريخ التسوية
  ordersCount: number;              // عدد الأوردرات المسواة
  totalCollected: number;           // إجمالي التحصيل من شركات الشحن (الشحنات الناجحة)
  totalMerchantGoodsCost: number;   // مستحقات البضاعة لصاحبها (تكلفة البضاعة)
  totalServiceFees: number;         // إجمالي عمولتك على الأوردرات
  totalShippingCosts: number;       // إجمالي مصاريف الشحن واللوجستيات المخصومة
  totalMarketingCosts: number;      // إجمالي مصاريف الإعلانات والتسويق المخصومة
  totalReturnFees: number;         // مصاريف شحن المرتجعات المخصومة
  totalCollectionFees: number;     // عمولات التحصيل النقدية (COD Fees)
  netPayoutToMerchant: number;      // الصافي المستحق للتحويل لصاحب البضاعة
  status: 'draft' | 'paid';         // حالة التسوية (مسودة / تم تحويل المبالغ)
  reversedAt?: string;
  reversedBy?: string;
  reversalNote?: string;
  paidFromTreasuryAccountId?: string;// الخزينة التي تم الصرف منها
  paidFromTreasuryAccountName?: string;
  notes?: string;                   // ملاحظات التسوية
  performedBy?: string;             // المسند إليه أو القائم بالتسوية
  attachments?: string[];           // صور إيصالات التحويل النقدي البنكي/الفودافون كاش
  totalShippingDiscountDifference?: number; // فرق السعر الرسمي للشحن عن المدفوع من العميل
  totalCarrierAdditionalFees?: number; // تأمين/معاينة/ضريبة/رسوم شركة إضافية
  totalReturnLosses?: number;        // إجمالي تكلفة الطلبات المرتجعة والفاشلة
  totalOperatorEarnings?: number;    // عمولة مقدم الخدمة/التشغيل
  orderSnapshots?: MerchantSettlementOrderSnapshot[]; // لقطة ثابتة تحفظ التقرير تاريخياً
}

export interface MerchantSettlementOrderSnapshot {
  orderId: string;
  orderNumber?: string;
  date: string;
  status: string;
  customerName?: string;
  shippingCompany?: string;
  collectedAmount?: number;
  merchantGoodsCost?: number;
  customerPaidShipping?: number;
  officialShippingFee?: number;
  shippingDiscountDifference?: number;
  carrierAdditionalFees?: number;
  collectionFee?: number;
  marketingCost?: number;
  serviceFee?: number;
  returnLoss?: number;
  netMerchantAmount?: number;
  insuranceFee?: number;
  vatFee?: number;
  inspectionFee?: number;
  mode?: 'fixed_fee' | 'profit_share' | 'wholesale';
  sharePercent?: number;
  accountingMode?: 'fixed_fee' | 'profit_share' | 'wholesale' | string;
  goodsCost?: number;
  shippingFee?: number;
  codFee?: number;
  totalShippingAndCarrierFees?: number;
  marketingFee?: number;
  returnFee?: number;
  collectedRevenue?: number;
  netPayoutToMerchant?: number;
  operatorEarnings?: number;
}

export interface TreasuryAccount {
  id: string;
  name: string;
  type: 'safe' | 'bank' | 'wallet' | 'custody';
  balance: number;
  currency: string;
  accountNumber?: string;
  beneficiaryName?: string;
  bankName?: string;
  walletNumber?: string;
  walletName?: string;
  isDefault?: boolean;
  responsiblePerson?: string;
  location?: string;
  maxLimit?: number;
  minLimit?: number;
  lastAuditedAt?: string;
}

export interface TreasuryTransaction {
  id: string;
  date: string;
  fromAccountId?: string;
  toAccountId?: string;
  amount: number;
  type: 'deposit' | 'withdrawal' | 'transfer' | 'advance';
  description: string;
  reference?: string;
  category?: TransactionCategory;
  orderId?: string;
  orderNumber?: string;
  operatorName?: string;
  reconciliationDiff?: number;
  attachmentUrl?: string;
  attachments?: string[];
}

export interface Treasury {
  id?: string;
  data?: any;
  accounts: TreasuryAccount[];
  transactions: TreasuryTransaction[];
}

export type QuotationStatus = 
  | 'مسودة'
  | 'قيد_الانتظار'
  | 'تمت_الموافقة'
  | 'محول_لطلب_شحن'
  | 'ملغي'
  | 'منتهي_الصلاحية';

export interface Quotation {
  id: string;
  storeId?: string;
  quotationNumber: string;
  createdAt: string;
  validUntil: string;
  status: QuotationStatus;
  
  customerName: string;
  customerPhone: string;
  customerPhone2?: string;
  customerEmail?: string;
  customerAddress: string;
  customerCity?: string;
  governorate?: string;
  city?: string;
  buildingNumber?: string;
  floorNumber?: string;
  apartmentNumber?: string;
  
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  tax?: number;
  total: number;
  advancePayment?: number;
  remainingAmount?: number;
  
  shippingCompany?: string;
  shippingArea?: string;
  includeInspectionFee?: boolean;
  inspectionFee?: number;
  isInsured?: boolean;
  insuranceFee?: number;
  vatRate?: number;
  vatValue?: number;
  codFee?: number;
  companyFeesTotal?: number;
  roundingAdjustment?: number;
  combineShippingFeesInPrint?: boolean;
  allowOpenShipment?: boolean;
  notes?: string;
  terms?: string;
  attachments?: string[];
  createdBy?: string;
  
  convertedOrderId?: string;
  convertedOrderNumber?: string;
  convertedAt?: string;
  approvedAt?: string;
  approvedByCustomer?: boolean;
  isDeleted?: boolean;
  deletedAt?: string;
}

export interface StoreData {
  name?: string;
  orders: Order[];
  settings: Settings;
  wallet: Wallet;
  treasury?: Treasury;
  cart: OrderItem[];
  customers: CustomerProfile[]; // Added customers to StoreData
  quotations?: Quotation[];
}

export interface PlaceOrderData {
    customerName: string;
    customerPhone: string;
    customerEmail?: string;
    customerAddress: string;
    buildingNumber?: string;
    floorNumber?: string;
    apartmentNumber?: string;
    shippingCompany?: string;
    shippingArea?: string;
    shippingFee?: number;
    paymentMethod?: string;
    notes?: string;
    redeemedPoints?: number;
    discount?: number;
    items?: OrderItem[];
}

export interface Store {
  id: string;
  name: string;
  specialization: string;
  language: string;
  currency: string;
  url: string;
  customDomain?: string;
  subdomain?: string;
  creationDate: string;
  templateId?: string;
  description?: string;
  phone?: string;
}

export interface Site {
  id: string;
  name: string;
  type: 'business' | 'ecommerce';
  url: string;
}

export interface User {
  name?: string;
  fullName: string;
  phone: string;
  email: string;
  password?: string;
  stores?: Store[];
  sites?: Site[];
  isAdmin?: boolean; 
  isBanned?: boolean; 
  joinDate?: string;
  permissions?: Permission[];
  ownedStoreIds?: string[];
  defaultStoreId?: string;
  autoLaunchDefaultStore?: boolean;
  migrationStatus?: 'legacy' | 'migrated' | 'verified';
  migratedAt?: string;
  legacyVerified?: boolean;
  biometricCredentials?: BiometricCredentialRecord[];
  allowBiometricAuth?: boolean;
}

export interface Invitation {
  storeId: string;
  storeName: string;
  inviterName: string;
}

export interface JoinRequest {
  storeId: string;
  storeName: string;
  employeeId: string;
  employeeName: string;
}

export interface ChatMessage {
  id: string | number;
  store_id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  is_read: boolean;
  is_file?: boolean;
}
